Synthetic production-widget layouts, not in-game screenshots. Current spell icons are unavailable to this renderer. The quiet Omega/laurel emblem is original artwork generated from vector primitives.
