# Olympus Warden 1.1.2 — Recording startup hotfix

Fixes a login timing issue that could leave ChronicleWarden and IntelWarden inactive after history loaded, even with recording enabled. This could prevent new events and inspected players from being saved while older history remained visible.

Previously consented recording now resumes after validation even when Olympus access resolves during world entry. Existing history, private notes, watchlists, feature selections and consent remain intact. No reset is needed. Events missed while the recorder was inactive cannot be reconstructed.

Use `/warden chronicle check` for a short recording-status report. The Windows backup tool remains compatible with all three SavedVariables roots.

# Olympus Warden 1.1.1

CommandWarden brings feature choices and performance controls together. RelayWarden adds in-game bug reporting, while current-character-first loading makes retained history available with less unnecessary startup work.

## CommandWarden and optional modules

- Choose Chat Only, Full Suite or individual features in CommandWarden > Modules. New installations start with Chat selected; existing selections are retained.
- Disable optional work without deleting history, dossiers, notes, watchlists or recording choices. Chat, Shield, Signal alerts and historical consumers have independent runtime gates.
- Overview, Modules, Performance and shared Settings sit in one control center. Module selection does not grant recording consent.
- Performance status separates Warden's client-attributed memory from the whole UI Lua heap. Profiling is optional and stays local to the current session.

## RelayWarden support

- Report a bug directly in game. Choose a module, enter a title and description, then Submit Report once. View Details is optional.
- My Reports shows Sending, Waiting to Deliver, Delivered and Needs Attention. Submitted reports retry automatically while you are online; Delivered requires a validated acknowledgment.
- Unfinished forms remain local across navigation and reload. Advanced Tools includes recovery of older unfinished text, diagnostics and developer self-tests.
- Optional Technical Details starts off for every new or switched form. Your report and native character name are shared with the developer. Chat, history, dossiers, locations and private notes are not silently attached.
- Support, Data & Backups and Help & Updates provide clear routes. Advanced delivery controls remain available when needed.

## Faster readiness and safer retained history

- Validate the current character first. Other packed archives remain intact until explicitly requested by a history view, search, backup or restore.
- Keep unopened character archives unchanged when saving. Invalid, duplicate, oversized or unsupported saved records fail explicitly instead of disappearing silently.
- Previously consented eligible startup observations use a separate local recovery journal. Normal logout/reload preserves accepted observations and retries recovery without duplicating committed records.
- Startup capture is bounded at 1,024 observations or 512 KiB of structural capture data. Recovery IDs add bounded metadata. Overflow is reported in chat and a saved coverage gap.
- Startup coverage remains partial: movement, inspection, scoreboard snapshots and complete duel sessions are not fully captured during validation. Missing events are not reconstructed. WoW must save normally; a crash can lose unsaved observations.
- Loading reports 25/50/75/100% for the current character without needing Warden open. Unloaded history is shown as unavailable rather than confirmed zero.

## Dossiers and interface polish

- Player menus can open exact retained Intel dossiers and shared Chronicle history using a ready identity index. Saved personal notes and watchlist entries now qualify for Intel shortcuts even without historical encounter events.
- Ambiguous names and different realms do not substitute another player. Menu opening starts no inspection, history scan or disabled module.
- Larger module crests, consistent activity artwork, explicit ON/OFF badges, adaptive Olympus navigation and clearer settings improve the suite's readability.
- Search uses CommandWarden wording and includes its module choices and performance controls. Chat Capture defaults off; existing preferences are preserved.

## Back up your history

The supplied Windows backup tool creates or restores one complete backup ZIP while WoW is closed. It includes main history, Relay reports and pending startup recovery in the existing account SavedVariables file. Text export waits for pending recovery and all requested archives.

The addon folder remains `OlympusChatWarden`; main history schema and consent stay compatible. Before switching to an older build, finish pending recovery and make a complete backup. Older TOCs do not declare the new startup journal and may omit it on a later save. Use isolated copies for rollback testing.

Olympus remains required for permitted gameplay access. It is an optional load dependency intentionally, allowing Warden to show missing-Olympus/access guidance instead of being disabled silently by the client.

---

# Olympus Warden 1.1.0 — previous published release

Olympus ChatWarden has grown into Olympus Warden: one Greek-themed workspace for
your personal history, remembered players, chat, signals and contact protection.

## Highlights since the published 1.0.3 release

- **Warden** brings system status, milestones and search across the suite together.
- **ChronicleWarden** surfaces meaningful recorded events, measured time, progress,
  shared activities and supported dungeon, raid and boss evidence. Original
  records remain accessible; missing attendance or results are not invented.
- **IntelWarden** brings recently met players, evidence-based relationships,
  historical dossiers, private notes and watchlists together. Identity, shared
  history and original sources stay connected without merging players by name.
- **Appearance & Gear** shows dated equipment, unique recorded configurations,
  item links/tooltips and a native model only when the exact player is available.
  Historical gear stays historical; unavailable gear is distinct from confirmed
  empty slots. Offline appearance is not reconstructed.
- **Historical talents** presents supported native choices, names, ranks and
  observation dates, retaining original exports. Export-only and partial readings
  remain explicit; specialization IDs never invent a talent tree.
- **Optional duel history** keeps individual encounters and supported before/after
  gear/talent evidence under separate consent. Identical configurations reuse
  saved content while encounters retain their dates, results and original sources.
  Received combat totals do not invent an attacker or complete damage attribution.
- **Native Statistics and PvP observations** preserve supported displayed values,
  scoreboard fields and objective data. Unavailable fields stay unknown; readable
  scoreboards are not automatically presented as fresh final scores.
- **ChatWarden** groups Messages, Capture, Rules, Packs and Reports.
  **SignalWarden** groups personal mentions, Wanted encounters and permitted
  OlympusMute observations. **ShieldWarden** retains contact protection and review.
- The compact Olympus panel has module filters, recent activity, exact source
  links and a target shortcut. Existing recent alerts mark read when opened.
- Large histories use cooperative loading/indexing, chunked saving, bounded
  caches and snapshot deduplication. Crowded-area work reuses unchanged facts
  while retaining timestamps, collection detail, GUID checks and personal routes.
- Your recording choice remains optional. Main and duel permissions stay separate.
  History has no automatic expiry; complete-file backups remain compatible.

## Final interface and bug fixes

- Sidebar order: Warden, ChronicleWarden, IntelWarden, ChatWarden, SignalWarden,
  ShieldWarden, Data & Backups, Updates & Help, Settings. Existing module IDs,
  commands, saved selections and deep links are retained.
- Sidebar buttons are taller with 50px crests; page headers use 56px crests with
  titles and tabs beside the artwork. The column is slightly wider to fit labels.
  Original Zeus artwork and Olympus styling are retained.
- Feature controls keep the same current logo when on or off. ON/OFF badges,
  paused dimming and explicit text replace the mixed legacy artwork. Hover cannot
  leave a paused control bright; ordinary headers restore full-color artwork.
- Recent activity titles and status lines align and fit. Home's identity banner
  is taller so character details clear the decorative trim.
- Talent rows give names and recorded ranks full line height; the last row can
  be fully reached by scrolling.
- Window-size edits wait for Apply or Enter. Fit to screen restores automatic
  sizing. Welcome and navigation preserve size; screen caps retain the preference.
- Welcome uses the current six-module suite tour. Complete documents wrap and
  scroll, selection differs from unread, and original evidence offers return
  navigation with private note drafts and scroll positions retained.
- Missing duel gear is summarized with Show all slots available. Recording state
  is immediate, and backup versus two-step deletion remains clearly separated.

## Installation and compatibility

The install folder remains **OlympusChatWarden** and the saved variable remains
**OlympusChatWardenDB**. Replace the existing addon folder; do not install a second
copy. Close WoW and back up SavedVariables before upgrading. The unchanged Windows
backup tool is supplied separately. `/warden`, `/ow`, `/ocw` and `/chatwarden` work.

No new sharing default, continuous other-player tracking, expiry, classification
vocabulary, schema or collector change was introduced in the final pass from RC5.
Native API availability varies; historical observations retain their limitations.
