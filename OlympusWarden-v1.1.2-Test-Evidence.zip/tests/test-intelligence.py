from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'trusted-recording-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks
local A,I,U,B=ns.ChronicleActivities,ns.ChronicleIntelligence,ns.ChronicleIntelligenceUI,ns.ChronicleBackup
local owner=C.Owner();local c;local base=1800000000
local raid={inInstance=true,instanceType='raid',instanceID=409,instanceName='Molten Core',zone='Molten Core'}
local world={inInstance=false,instanceType='none',zone='Elwynn Forest'}
local bg={inInstance=true,instanceType='pvp',instanceID=489,instanceName='Warsong Gulch',zone='Warsong Gulch'}
local arena={inInstance=true,instanceType='arena',instanceID=559,instanceName='Arena',zone='Arena'}
local function fresh()
 C.Clear();c=S.Character(owner,true);c.currentSession=owner..'/s1';c.sessionSequence=1
end
local function e(kind,t,d,p,source,subject,extra)
 local v={kind=kind,at=base+t,elapsed=t,source=source or 'checkpoint',subject=subject,
 session=c.currentSession,timeSource='server',evidence='observed',details=d or {},location=p or world}
 for k,x in pairs(extra or {}) do v[k]=x end
 return assert(S.Append(owner,v),'bad fixture '..kind)
end
local function span(lo,hi,afk,p,seconds)
 return e('time_span',hi,{firstAt=base+lo,lastAt=base+hi,firstElapsed=lo,lastElapsed=hi,seconds=seconds or hi-lo,samples=1,afk=afk},p)
end
local function native(t,r,d,p,source,subject)
 d=d or {};d.recordType=r;return e('native_event',t,d,p,source,subject)
end
local function build()
 local st=A.Request(owner);local steps=0
 while not st do A.Pump();steps=steps+1;assert(steps<20000);st=A.Request(owner) end
 return st,steps
end
local function close(a,b,msg) check(math.abs(a-b)<.001,msg) end
local pal='Player-Test-FRIEND';local foe='Player-Test-FOE';local same='Player-Test-SAME';local self=owner:match('/(Player%-.+)$')
fresh();e('recording_start',0,{},raid,'control');local entry=e('instance_enter',1,{},raid)
e('group_roster',10,{members={pal},knownMembers=1,sameGuildMembers=0},raid,'GROUP_ROSTER_UPDATE')
native(20,'combat_started',{},raid,'PLAYER_REGEN_DISABLED');span(0,40,true,raid)
native(70,'combat_ended',{combatSeconds=50},raid,'PLAYER_REGEN_ENABLED')
e('group_roster',80,{members={},knownMembers=0,sameGuildMembers=0},raid,'GROUP_ROSTER_UPDATE');span(40,100,false,raid)
local st=build();local i=st.intelligence
close(i.time.seconds,100,'unique measured total uses recorded elapsed time')
close(i.time.afk,40,'AFK overlaps raid without being added twice')
close(i.time.nonAfk,60,'non-AFK retains its truthful label')
close(i.time.categories.raid,100,'location categories use the time record context')
close(i.time.combatSeconds,50,'paired combat window intersects measured coverage')
close(i.time.groupContextSeconds,70,'roster-derived group window is separately measured')
check(i.time.seconds~=i.time.afk+i.time.categories.raid,'overlapping dimensions are not summed into total time')
check(i.time.afkUnknown==0 and i.time.zones['Molten Core']==100,'known AFK and zone dimensions survive classification')
span(0,40,true,raid);st=build();i=st.intelligence
close(i.time.seconds,100,'duplicate time coverage never doubles the measured total')
close(i.overlapSeconds,40,'overlap is visible as evidence while counted once')
local alt={inInstance=true,instanceType='raid',instanceID=409,instanceName='Molten Core',zone='Conflicting zone'}
span(20,60,false,alt);st=build();i=st.intelligence
close(i.time.seconds,100,'partial overlaps retain union duration')
close(i.time.afkUnknown,20,'contradictory AFK becomes unknown for only the conflict region')
close(i.time.afk,20,'uncontested AFK remains usable')
close(i.time.zones.unknown,40,'contradictory zone overlap is not assigned to either zone')
close(I.ActivityTime(st,st.byID[entry.id..'/activity/raid']),99,'activity time query uses unique measured coverage and its actual boundary')
span(100,110,nil,world);span(110,120,false,world,5);span(120,120,false,world)
st=build();i=st.intelligence
close(i.time.seconds,110,'new zone interval extends measured total without filling a compacted hole')
close(i.excludedReportedSeconds,5,'compacted time with unlocated holes is explicit unallocated evidence')
check(i.zeroTimeRecords==1 and i.time.categories['open world']==10,'zero-duration records create no invented activity')
close(i.time.afkUnknown,30,'missing AFK status remains unknown rather than non-AFK')
local saved=B.Encode(c.events);local packed=assert(B.PackSaved(S.db));check(packed.characters[owner].intelligence==nil,'intelligence is never saved as a second incident database')
local total=i.time.seconds;A.Clear();st=build();close(st.intelligence.time.seconds,total,'clean rebuild reproduces interval union')
check(B.Encode(c.events)==saved,'time summaries never edit original records')
-- Explicit boundaries prevent combat inference and rate bridging across gaps.
fresh();e('recording_start',0,{},world,'control');span(0,10,false,world)
native(12,'combat_started',{},world,'PLAYER_REGEN_DISABLED');e('collection_gap',15,{reason='loading'},world)
span(20,30,false,world);native(32,'combat_ended',{combatSeconds=20},world,'PLAYER_REGEN_ENABLED')
e('recording_stop',35,{},world,'control');e('recording_start',40,{},world,'control');span(40,50,true,world)
st=build();i=st.intelligence
close(i.time.seconds,30,'loading and recording gaps are never filled')
close(i.time.combatSeconds,0,'combat pair crossing a recording gap remains unclassified')
check(i.unknownCombatEnds==1 and #i.scopes>=3,'partial recording boundaries remain explicit')
check(i.time.nonAfk==20 and i.time.afk==10,'AFK accounting stays independent across recording segments')
-- Old slice format and recorded UTC boundaries.
fresh();e('time_slice',10,{seconds=10},world);st=build();close(st.intelligence.time.seconds,10,'legacy measured slices remain readable')
check(st.intelligence.scopes[1].partialStart and st.intelligence.time.afkUnknown==10,'legacy partial session and missing AFK are explicit')
fresh();local originalBase=base;base=1800057595;e('recording_start',0,{},world,'control');span(0,10,false,world)
st=build();i=st.intelligence
close(i.calendarUnknown.day,10,'a midnight-crossing span is not arbitrarily divided into calendar days')
check(next(i.periods.day)==nil,'no guessed per-day precision from boundary-spanning compacted time');base=originalBase
-- Directed native credit is not a solo kill, death or ratio.
fresh();e('recording_start',0,{},world,'control')
local function observe(t,guid,name,enc,localSeen)
 return e('player_observed',t,{name=name,encounter=enc,localSighting=localSeen,class='MAGE',guild='Example Guild'},world,'PLAYER_TARGET_CHANGED',guid)
end
observe(1,foe,'Old Name',true,true);observe(2,foe,'Old Name',true,true);observe(40,foe,'Old Name',false,true)
observe(100,foe,'Old Name',true,true);observe(230,foe,'New Name',true,true);observe(240,same,'New Name',false,false)
local function credit(t,actor,target,scope)
 return native(t,'native_kill_credit',{attackerGUID=actor,targetGUID=target,entityKind='Player',credit=scope},world,'PARTY_KILL',target)
end
local own=credit(250,self,foe,'self native credit');credit(250,self,foe,'self native credit')
credit(251,'Pet-0-1-2-3-4-5',foe,'current pet native credit');credit(252,pal,foe,'group native credit')
credit(253,foe,self,'unattributed');native(254,'native_kill_credit',{attackerGUID=self,targetGUID='Creature-0-1-2-3-10-1',entityKind='Creature',credit='self native credit'},world,'PARTY_KILL')
e('player_death',255,{},world,'PLAYER_DEAD');st=build();i=st.intelligence
local p=I.Player(st,foe)
check(p.recordedEncounters==2 and p.firstEncounter==base+1 and p.lastEncounter==base+230,'rapid repeated mouseovers do not create distinct encounter episodes')
check(p.credits.own==1 and p.credits.pet==1 and p.credits.group==1 and p.credits.incoming==1,'own pet group and incoming credit directions stay separate')
check(i.duplicateCredits==1,'same-instant native credit delivery is counted once')
check(A.Player(st,pal).selfCredits==0 and A.Player(st,pal).groupCredits==0,'a credit actor is not incorrectly counted as the victim')
check(A.Player(st,foe).selfCredits==1 and A.Player(st,foe).petCredits==1,'existing player summary uses directed deduplicated credit projection')
check(p.confirmedKillingBlows==nil and p.confirmedDeathsByPlayer==nil and p.headToHeadRatio==nil,'unavailable individual kills deaths and ratio are unknown rather than zero')
check(#i.deaths==1 and i.deathZones['Elwynn Forest']==1,'own death history stays independent from killer attribution')
check(A.Name(st,foe,base+100)=='Old Name' and A.Name(st,foe)=='New Name' and I.Player(st,same).recordedEncounters==0,'dated GUID names remain separate from same-name identities')
S.Observe(owner,foe,{name='New Name'},base+260,'PLAYER_TARGET_CHANGED',world);c.profiles[foe].personal={note='My own note',watch=true};S.Prune(c)
check(I.Player(st,foe).description=='Personal watchlist' and I.Player(st,foe).note=='My own note','manual notes and watchlist remain live without rebuilding history')
local report={format=1,kind='wanted',board='wanted',id='public-test',part=1,parts=1,apiVersion=1,mode='full',rows={{key=pal,values={guid=pal,name='Remote Friend',bounty=50}}},removed={}}
e('olympus_snapshot',270,{snapshotID=report.id,part=1,parts=1},world,'WANTED_CHANGED',nil,{snapshot=report});st=build()
check(I.Player(st,pal).recordedEncounters==0 and #I.Player(st,pal).publicReports==1,'Wanted list alone never creates a rivalry or personal encounter')
check(#I.Query(st,{guid=foe,source='PARTY_KILL',certainty='observed',since=base+250,untilAt=base+252,zone='Elwynn Forest'})==3,'relationship source/date/zone/certainty filters return original references without duplicate deliveries')
e('player_kill_credit',280,{},world,'COMBAT_LOG_EVENT_UNFILTERED',foe);st=build()
check(I.Player(st,foe).legacyRecords==1 and I.Player(st,foe).credits.own==1,'legacy credit remains queryable without being upgraded into current native credit')
check(#I.Query(st,{guid=foe,kind='player_kill_credit'})==1 and A.Provenance(c.events[#c.events]).context=='legacy combat observation','legacy source context is explicit without registering a restricted API')
-- Battleground visits, incomplete matches and unassigned scoreboard observations.
fresh();e('recording_start',0,{},bg,'control');local first=e('location',1,{},bg,'control');e('instance_enter',2,{reason='recording-started-inside'},bg,'control')
span(2,20,false,bg);native(21,'pvp_match_complete',{winner=1,duration=1200},bg,'PVP_MATCH_COMPLETE')
e('instance_exit',25,{},bg);e('instance_enter',30,{},bg);span(30,50,false,bg)
e('instance_exit',55,{},bg);e('instance_enter',60,{},arena);span(60,70,false,arena)
local cap=assert(ns.ChronicleCapture.Validate({format=1,family='scoreboard',values={runID='reused-run',matchSequence=1,rowIndex=1,guid=foe,name='Opponent',killingBlows=0,honorableKills=3,deaths=1,faction=0}}))
local hash=ns.ChronicleCapture.Hash(cap)
local score=e('native_snapshot',71,{family='scoreboard',contentID=hash},arena,'UPDATE_BATTLEFIELD_SCORE',nil,{capture=cap})
e('native_event',72,{recordType='pvp_score_row',contentID=hash,family='scoreboard'},arena)
e('native_snapshot',73,{family='scoreboard',contentID=hash},arena,'UPDATE_BATTLEFIELD_SCORE',nil,{capture=cap})
st=build();i=st.intelligence
local bgs=A.Query(st,{kind='battleground'});local arenas=A.Query(st,{kind='arena'})
check(#bgs==2 and #arenas==1,'exit/re-entry creates distinct visit segments even with the same battleground map')
check(bgs[2].partialStart and bgs[1].matchOutcome=='unknown' and #bgs[2].pvpReports==1,'mid-match startup and missing personal outcome stay explicit')
check(#bgs[1].pvpReports==0,'a new visit does not inherit the earlier completion report')
close(i.time.categories.battleground,38,'battleground measured time uses its recorded intervals')
close(i.time.categories.arena,10,'arena time is separately classified')
check(#i.scoreboards==1 and #I.Player(st,foe).scoreboards==1 and I.Player(st,foe).recordedEncounters==0,'identical score objects are deduplicated and never become sightings')
check(score.capture.values.killingBlows==0 and score.capture.values.honorableKills==3,'measured scoreboard zero is preserved separately from honorable kills')
check(not bgs[1].scoreboardID and not bgs[2].scoreboardID and not i.wins,'reused sequence and nearby time never manufacture match assignment or wins')
check(I.ActivityTime(st,bgs[2])==18,'visit time is unique measured coverage rather than native match duration')
-- Progress and measured rate windows.
fresh();e('recording_start',0,{},world,'control');span(0,100,false,world)
e('level_change',5,{before=1,after=2},world,'PLAYER_LEVEL_UP');e('level_change',95,{before=2,after=3},world,'PLAYER_LEVEL_UP')
e('xp_change',10,{before=0,after=10,delta=10,beforeLevel=2,afterLevel=2,beforeMax=100,afterMax=100},world,'PLAYER_XP_UPDATE')
e('xp_change',20,{before=10,after=30,delta=20,beforeLevel=2,afterLevel=2,beforeMax=100,afterMax=100},world,'PLAYER_XP_UPDATE')
e('quest_turnin',25,{questID=10,rewardXP=20},world,'QUEST_TURNED_IN')
e('skill_change',30,{skill='Alchemy',before=1,after=2,maximum=75},world,'SKILL_LINES_CHANGED')
e('location',40,{},world);e('location',50,{},bg);e('location',60,{},world)
st=build();i=st.intelligence
check(i.progression.xpObserved==30 and i.progression.rateXP==20 and i.progression.rateSeconds==10,'XP rates require linked update values and full measured coverage without double-adding quest rewards')
local lastLevel;for _,v in ipairs(i.cases) do if v.event.kind=='level_change' and v.previous then lastLevel=v end end
check(lastLevel.measuredBetween==90 and lastLevel.completeCoverage,'recorded level chronology exposes covered measured time')
check(#i.progression.quests==1 and #i.progression.skills==1 and #i.visits['Elwynn Forest'].evidence==2,'quest profession and observed zone-entry milestones are indexed')
-- Late flush extends the derived time model without changing original incidents.
e('xp_change',95,{before=30,after=10,delta=80,beforeLevel=2,afterLevel=3,beforeMax=100,afterMax=100},world,'PLAYER_XP_UPDATE')
e('xp_change',110,{before=10,after=20,delta=10,beforeLevel=3,afterLevel=3,beforeMax=100,afterMax=100},world,'PLAYER_XP_UPDATE')
st=build();local rateBefore=st.intelligence.progression.rateXP
span(100,110,false,world);st=build()
check(st.intelligence.progression.rateXP==rateBefore+10,'a later measured-time flush resolves an earlier pending XP window')
local canonical=B.Encode(c.events);local originalN=#c.events
local packed2=assert(B.PackSaved(S.db));ns.DB.chronicle=packed2;C.Initialize();c=S.Character(owner,false);st=build()
check(#c.events==originalN and B.Encode(c.events)==canonical and st.intelligence.progression.rateXP==110,'packed save reload rebuilds projections without history loss')
-- UI modes are usable with source drill-down and bounded controls.
ns.Workspace.Open('recording');local host=ns.Workspace.pages.recording;host:SetView('intelligence');build();local view=host.intelligence;view:Refresh(true)
check(view:IsShown() and not host.events:IsShown() and #view.list.items>0,'Intelligence is a real independent Recording tab')
click(view.list.rows[1]);check(view.document:GetText():find('Recorded in-world time',1,true),'time summary is inspectable through actual row click')
check(view.openSource:IsEnabled(),'summary offers original evidence')
local selected=view.sourceID;click(view.openSource);check(host.view=='events' and host.selected==selected,'intelligence drill-down opens original evidence')
host:SetView('intelligence');view.mode='progress';view.selected=nil;view.dirty=true;view:Refresh(true);click(view.list.rows[1])
check(view.document:GetText():find('Levels',1,true),'progression summary has an actual inspectable UI')
local frameN=#frames;for n=1,5 do view:Refresh(true) end;check(#frames==frameN,'intelligence reuses a bounded row pool')
local keep=B.Encode(c.events);check(keep==canonical and not S.db.enabled,'viewing and querying never enables collection or changes history')
A.Clear();A.Request(owner);local combat=InCombatLockdown;InCombatLockdown=function() return true end;A.Pump();InCombatLockdown=combat
check(A.Request(owner)==nil,'shared rebuild waits in combat');build();C.Clear()
check(view.state==nil and view.selected==nil and #view.list.items==0 and not view.openSource:IsEnabled(),'Clear removes all derived UI and original-source controls')
-- Distinct recording boundaries do not create repeat encounters by themselves.
fresh();e('recording_start',0,{},world,'control');observe(1,foe,'Stable Name',true,true)
e('recording_stop',2,{},world,'control');e('recording_start',3,{},world,'control');observe(4,foe,'Stable Name',true,true)
st=build();check(I.Player(st,foe).recordedEncounters==1,'rapid reload/recording boundaries do not manufacture a second encounter')
e('recording_stop',5,{},world,'control');c.currentSession=owner..'/s2';observe(300,foe,'Stable Name',true,true)
st=build();check(I.Player(st,foe).recordedEncounters==2,'compatible server timestamps can establish separation across recording sessions')
check(#I.ResolveName(st,'Stable Name')==1 and #I.ResolveName(st,'No Such Name')==0,'safe name resolution returns only dated GUID associations')
observe(310,same,'Stable Name',false,false);st=build();check(#I.ResolveName(st,'stable name')==2,'ambiguous names return both GUIDs rather than merging identities')
-- New recording clocks that overlap old wall coverage remain unallocated.
fresh();e('recording_start',0,{},world,'control');span(0,100,false,world)
c.currentSession=owner..'/s2';e('recording_start',90,{},world,'control');span(90,110,false,world)
st=build();close(st.intelligence.time.seconds,100,'overlapping distinct clock ranges never double-count history')
close(st.intelligence.excludedReportedSeconds,20,'cross-clock ambiguity is kept as unallocated reported duration')
check(#I.Query(st,{kind='time_span',limit=10})==2,'unallocated time still has accessible original source evidence')
-- Calendar source menus stay within their selected period, not the whole ledger.
fresh();e('recording_start',0,{},world,'control');span(0,10,false,world);span(86400,86410,false,world);st=build()
local days=U.Rows(st,'day');check(#days==2 and #days[1].refs==1 and #days[2].refs==1 and days[1].refs[1]~=days[2].refs[1],'calendar summaries expose only original sources from their own period')
check(st.intelligence.events[days[1].refs[1]].at>st.intelligence.events[days[2].refs[1]].at,'calendar rows and source evidence preserve chronological order')
-- Same-clock server jumps do not manufacture distinct encounters.
fresh();e('recording_start',0,{},world,'control');observe(1,foe,'Clock Test',true,true)
local v={schema=S.VERSION,id=owner..':999',session=c.currentSession,character=owner,at=base+900,elapsed=2,source='PLAYER_TARGET_CHANGED',
 evidence='observed',timeSource='server',kind='player_observed',subject=foe,location=world,details={name='Clock Test',encounter=true,localSighting=true}}
assert(S.Append(owner,v));st=build();check(I.Player(st,foe).recordedEncounters==1,'a wall-clock jump without elapsed separation does not create an encounter episode')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'schema consent native access and collection scope remain unchanged')
intelligenceChecks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().intelligenceChecks),'failed':0,'liveWoWTested':False,'seconds':round(time.perf_counter()-started,3),
 'coverage':'interval union and conflicts; AFK/combat/roster dimensions; gaps and legacy slices; credit direction and duplicate deliveries; dated GUIDs; Wanted scope; battleground visits and unassigned scoreboards; progression and pending XP; source queries; real UI; packed save rebuild and Clear'}
(out/'intelligence-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
