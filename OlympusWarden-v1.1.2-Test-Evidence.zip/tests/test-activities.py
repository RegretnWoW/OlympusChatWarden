from pathlib import Path
import json, time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'unchanged-recording-baseline','exec'),state)
lua=state['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks
local A,U,B=ns.ChronicleActivities,ns.ChronicleActivitiesUI,ns.ChronicleBackup
C.Clear();local owner=C.Owner();local c=S.Character(owner,true);c.currentSession=owner..'/s1';c.sessionSequence=1
local one,two,three,remote='Player-Test-ONE','Player-Test-TWO','Player-Test-THREE','Player-Test-REMOTE'
local place={inInstance=true,instanceType='party',instanceID=36,instanceName='The Deadmines',zone='Westfall'}
local function emit(kind,t,d,source,subject,loc,extra)
 local v={kind=kind,source=source or 'checkpoint',session=c.currentSession,at=1800000000+t,elapsed=t,
 timeSource='server',evidence='observed',details=d or {},location=loc or place,subject=subject}
 for k,x in pairs(extra or {}) do v[k]=x end
 return assert(S.Append(owner,v),'invalid fixture '..kind)
end
local function roster(t,m) return emit('group_roster',t,{members=m,knownMembers=#m,sameGuildMembers=0},'GROUP_ROSTER_UPDATE') end
local function encounter(t,id,success,start,difficulty)
 return emit('native_event',t,{recordType=start and 'encounter_started' or 'encounter_ended',encounterID=id,name='Boss '..id,
 difficultyID=difficulty or 1,success=success},start and 'ENCOUNTER_START' or 'ENCOUNTER_END')
end
local function observed(t,guid,name,localSighting)
 return emit('player_observed',t,{name=name,realm='Test Realm',localSighting=localSighting or false,encounter=localSighting or false},'PLAYER_TARGET_CHANGED',guid)
end
emit('recording_start',100,{},'control',nil,{})
observed(101,one,'Old Name');observed(101,two,'Same Name');observed(101,three,'Same Name')
roster(102,{one,two})
local entry=emit('instance_enter',110)
roster(111,{one,two})
local start=encounter(120,100,nil,true)
encounter(120,100,nil,true) -- identical delivery, not an extra attempt
roster(125,{two,three})
emit('time_span',130,{seconds=20,samples=1,firstAt=1800000110,lastAt=1800000130,firstElapsed=110,lastElapsed=130})
encounter(140,100,0)
encounter(140,100,0)
encounter(150,100,nil,true);encounter(180,100,1)
emit('native_event',180,{recordType='boss_kill_event',encounterID=100,name='Boss 100'},'BOSS_KILL')
emit('instance_exit',200)
local entry2=emit('instance_enter',210);roster(211,{one});encounter(220,999,1)
emit('recording_stop',240,{},'control')
emit('recording_start',250,{},'control');emit('instance_enter',251,{reason='recording-started-inside'});observed(252,one,'New Name');roster(253,{one})
encounter(260,200,nil,true);emit('recording_stop',265,{},'control')
emit('recording_start',266,{},'control');emit('instance_enter',267,{reason='recording-started-inside'});roster(268,{one});encounter(280,200,1)
local beforeEvents=B.Encode(c.events);local beforeProfiles=B.Encode(c.profiles);local sequence=c.sequence
local function build()
 local st,status=A.Request(owner);local pumps=0
 while not st do A.Pump();pumps=pumps+1;assert(pumps<10000);st,status=A.Request(owner) end
 return st,pumps
end
local st=build();local runs=A.Query(st,{kind='dungeon'});check(#runs==4,'same map across exits/reloads yields four distinct observed segments')
local first=st.byID[entry.id..'/activity/dungeon'];check(first and #first.attempts==2,'native starts/end/kill duplicate delivery yields two attempts')
check(first.attempts[1].outcome=='failure' and first.attempts[2].outcome=='native boss kill','native failure and successful result stay scoped to attempts')
check(first.attempts[1].participation=='unavailable','roster presence never confirms individual boss attendance')
check(first.attempts[1].members[one] and first.attempts[1].members[three],'mid-attempt roster observations retained without rewriting earlier list')
check(not first.attempts[2].members[one],'player no longer listed is not carried into later attempt candidate list')
check(first.completion=='unknown' and first.status=='ended','observed exit ends segment without declaring dungeon completion')
check(first.measuredSeconds==20,'only recorded within-segment time is measured')
check(st.duplicateDeliveries==3,'duplicate start/end plus same-instant boss result are recognized')
check(st.byID[entry2.id..'/activity/dungeon'].attempts[1].missingStart,'orphan result has unknown start')
check(runs[2].partialStart and runs[2].attempts[1].status=='interrupted','reload/mid-instance start and unfinished boss stay partial')
check(runs[1].attempts[1].missingStart,'post-reload result does not complete an earlier interrupted attempt')
check(A.Name(st,one,1800000200)=='Old Name - Test Realm' and A.Name(st,one)=='New Name - Test Realm','historical alias lookup does not rewrite old names')
check(st.players[two]~=st.players[three],'identical names never merge GUIDs')
local stats=A.Player(st,one)
check(stats.listedDungeonSegments==4 and stats.failureResultsWhileListed==1,'player query reuses correlated activities and roster associations')
check(stats.confirmedBossParticipation==nil and stats.groupedSeconds==nil and stats.performance==nil,'unmeasured participation/time/performance is unknown rather than zero')
check(#A.Query(st,{guid=one,kind='dungeon'})==4,'same activities support player-specific history')
check(#A.Query(st,{search='Old Name',kind='dungeon'})==2,'activity search uses names known by that segment date')
check(#A.Query(st,{guid='Player-Unknown-ABC'})==0,'missing player returns no invented history')
check(B.Encode(c.events)==beforeEvents and B.Encode(c.profiles)==beforeProfiles and c.sequence==sequence,'correlation never edits raw ledger, profiles or sequence')
local ids={};for i,a in ipairs(st.activities) do ids[i]=a.id end
A.Clear();st=build();for i,a in ipairs(st.activities) do check(a.id==ids[i],'rebuild produces stable activity ID '..i) end
local ready=A.Request(owner);check(ready==st,'unchanged history uses cached derived view')
-- Real permitted Olympus record with an identity unknown to local observation.
local snap={format=1,kind='wanted',board='wanted',id='public-1',part=1,parts=1,apiVersion=1,mode='full',rows={{key=remote,values={guid=remote,name='Remote Player',bounty=50}}},removed={}}
local public=emit('olympus_snapshot',300,{snapshotID=snap.id,part=1,parts=1},'WANTED_CHANGED',nil,nil,{snapshot=snap})
st=build();local p=A.Player(st,remote)
check(p.olympusReports==1 and p.localEncounters==0 and #p.activities==0,'Olympus listing does not become sighting, roster or local activity')
local provenance=A.Provenance(public)
check(provenance.source=='Olympus API' and provenance.context=='Olympus report' and not provenance.independentVerification,'technical source and report context stay separate from certainty')
local rosterEvent;for _,e in ipairs(c.events) do if e.kind=='group_roster' then rosterEvent=e;break end end
check(A.Provenance(rosterEvent).context=='remote-capable group roster','native roster source is not labelled personally witnessed')
local selfCredit=emit('native_event',301,{recordType='native_kill_credit',attackerGUID=one,targetGUID=two,entityKind='Player',credit='group native credit'},'PARTY_KILL',two)
selfCredit.restored=true
st=build();check(A.Player(st,two).groupCredits==1 and A.Player(st,two).selfCredits==0,'group credit never becomes own individual kill')
check(A.Provenance(selfCredit).restored and not A.Provenance(selfCredit).independentVerification,'import label survives provenance normalization')
-- A meter payload with a real player GUID is evidence, but never an inferred boss performance assignment.
local capture=assert(ns.ChronicleCapture.Validate({format=1,family='meter',values={runID='native-run',sessionID=1,meterType=1,meterEpoch=0,sourceIndex=1,sources={{one,false,'New Name','MAGE',500,25,false,0,false}}}}))
local h=ns.ChronicleCapture.Hash(capture)
emit('native_snapshot',302,{family='meter',contentID=h},'checkpoint',nil,nil,{capture=capture})
emit('native_event',302,{recordType='damage_meter_source',contentID=h,family='meter',sessionID=1,meterType=1,meterEpoch=0})
st=build();check(A.Player(st,one).meterRecords==1 and A.Player(st,one).performance==nil and st.unmatchedPerformance==1,'meter observation remains separate from boss attribution')
check(A.Provenance(c.events[#c.events]).scope=='unmatched native combat session','meter context states its unmatched scope')
-- Append extension and out-of-order imports must produce the same result as a clean rebuild.
local incrementalCount=#st.activities
emit('instance_exit',310);emit('instance_enter',320);roster(321,{two});encounter(322,333,nil,true);encounter(330,333,1)
st=build();check(#st.activities==incrementalCount+1,'append-only updates extend cached correlation')
local incremental={};for i,a in ipairs(st.activities) do incremental[i]=a.id..':'..#a.attempts end
A.Clear();st=build();for i,a in ipairs(st.activities) do check(incremental[i]==a.id..':'..#a.attempts,'incremental and clean rebuild agree '..i) end
local late=observed(115,one,'Middle Name')
st=build();check(A.Name(st,one,1800000200)=='Middle Name - Test Realm','out-of-order import rebuilds historical identity order')
check(st.events[late.id]~=nil,'late evidence preserved and indexed')
-- Conflicting outcomes remain conflicting instead of a guessed winner.
encounter(340,444,nil,true);encounter(350,444,0);encounter(350,444,1)
st=build();local last=st.active.attempts[#st.active.attempts]
check(last.conflictingResults and last.outcome=='conflicting','contradictory same-delivery results are explicit')
check(last.participation=='unavailable','conflict does not upgrade participant certainty')
-- Same native encounter ID at another difficulty must not close an open attempt.
encounter(360,555,nil,true,1);encounter(370,555,1,false,2)
st=build();local attempts=st.active.attempts
check(attempts[#attempts-1].status=='interrupted' and attempts[#attempts].missingStart,'difficulty mismatch cannot bind unrelated start/result')
-- UI click paths, filters, source drill-down, scroll bounds and privacy.
ns.Workspace.Open('recording');local host=ns.Workspace.pages.recording;host:SetView('activities');local view=host.activities
build();view:Refresh(true)
check(view:IsShown() and not host.events:IsShown(),'Activities is a real independent Recording tab')
check(#view.list.items>0 and #view.list.rows<=8,'activity browser has a bounded reusable row pool')
click(view.list.rows[1]);check(view.selected==view.list.items[1].id,'row click selects actual derived activity')
check(view.document:GetText():find('completion: unknown',1,true),'activity details keep completion uncertainty visible')
check(#view.sources>1 and view.openSource:IsEnabled(),'activity exposes original source references')
local selectedSource=view.sourceID;click(view.openSource)
check(host.view=='events' and host.selected==selectedSource and host.detailDocument:GetText():find(selectedSource,1,true),'source drill-down opens original evidence record')
host:SetView('activities');view.filter.guid=one;view.dirty=true;view:Refresh(true)
check(view.document:GetText():find('recorded group history',1,true),'player query summary is accessible without meter data')
click(view.allPlayers);view:Refresh(true);check(not view.filter.guid,'all players restores ordinary activity browsing')
local frameCount=#frames;for i=1,10 do view:Refresh(true) end
check(#frames==frameCount,'repeated refresh reuses all activity UI controls')
local saved=B.Encode(c.events);click(view.rebuild);build();view:Refresh(true)
check(B.Encode(c.events)==saved and not S.db.enabled,'rebuild and UI never enable recording or mutate raw history')
local scopes={ns.ChronicleStore.VERSION,ns.ChronicleStore.CONSENT}
check(scopes[1]==6 and scopes[2]==5,'derived-only pass requires neither destructive migration nor expanded collection consent')
check(forbiddenRegistrations==0,'no restricted combat-log registration')
-- Round-trip the existing saved representation; summaries reconstruct instead of being backed up twice.
local packed=assert(B.PackSaved(S.db));local normalized=assert(S.Normalize(packed));local originalCount=#c.events
check(normalized.characters[owner].activities==nil and normalized.characters[owner].derived==nil,'saved format has no duplicate activity database')
ns.DB.chronicle=packed;C.Initialize();c=S.Character(owner,false);A.Clear();st=build()
check(#c.events==originalCount and #A.Query(st,{kind='dungeon'})==5,'saved-file reload preserves evidence and reconstructs activity history')
-- Cancellation and combat scheduling must not expose another character or stale cleared records.
A.Clear();local initial=A.Request(owner)
local oldCombat=InCombatLockdown;InCombatLockdown=function() return true end;A.Pump();InCombatLockdown=oldCombat
check(A.Request(owner)==nil,'background work waits during combat')
C.Clear();A.Pump();local empty=A.Request(owner)
check(empty and #empty.activities==0 and not S.db.enabled,'Clear cancels pending indexing and removes stale activity views')
activityChecks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().activityChecks),'failed':0,
         'liveWoWTested':False,'seconds':round(time.perf_counter()-started,4),
         'scope':'meter-independent activities, historical identities, provenance, boundaries, replayable caches, source UI, backup reconstruction'}
(out/'activities-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
