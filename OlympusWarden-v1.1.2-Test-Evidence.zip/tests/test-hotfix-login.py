from pathlib import Path
import json,sys,zipfile,time
o=Path(__file__).resolve().parent;r=o.parents[1];started=time.perf_counter()
baseline='--baseline' in sys.argv
host=(o/'test-integration.py').read_text().split('count=0')[0]
h={'__file__':str(o/'test-integration.py')}
if baseline:
 with zipfile.ZipFile(r/'OlympusWarden-v1.1.1.zip') as z:h['releaseSource']={Path(n).name:z.read(n).decode('utf-8') for n in z.namelist() if n.endswith('.lua')}
 host=host.replace("(root/'OlympusChatWarden'/name).read_text(encoding='utf-8')","releaseSource[name]")
exec(compile(host,'native login host','exec'),h)
native=(o/'test-chronicle.py').read_text().split("lua.execute(r'''")[1].split("check(not S.db.enabled")[0]
inspect=(o/'research/Blizzard_InspectUI.lua').read_text()
nativeInspect='\n'.join(inspect[inspect.index(a):inspect.index(b)] for a,b in [('function InspectFrameMixin:GetInspectUnit()','function InspectFrame_Show(unit)'),('function InspectFrame_Show(unit)','function InspectFrameMixin:OnLoad()'),('function InspectFrameMixin:OnEvent(event, ...)','function InspectFrameMixin:UnitChanged()'),('function InspectFrameMixin:UnitChanged()','function InspectFrameMixin:OnShow()'),('function InspectFrameMixin:OnHide()','function InspectSwitchTabs(newID)')])
rows=[]
scopes=['full'] if baseline else ['full','chronicle','intel']
timings=['during'] if baseline else ['before','during','after-entry','after-load']
for scope in scopes:
 for timing in timings:
  for reload in ([False] if baseline else [False,True]):
   selection={k:scope=='full' or k==scope for k in ['chat','shield','alerts','chronicle','intel']}
   l=h['fresh']('modern',True,selection=selection);l.execute(native)
   l.globals().timing=timing;l.globals().reloadFixture=reload;l.globals().scopeFixture=scope
   l.execute(r'''
local M,B=ns.Modules,ns.ChronicleBackup
local hadIntel=M.Enabled('intel');if not hadIntel then M.Set('intel',true) end
ev('PLAYER_ENTERING_WORLD',true,false);assert(C.SetEnabled(true))
local owner=C.Owner();local c=ledger()
local oldEvent=assert(S.Append(owner,{kind='quest_turnin',source='QUEST_TURNED_IN',at=C.Stamp(),elapsed=C.Tick(),timeSource='server',evidence='confirmed',session=c.currentSession,location={},details={questID=11111}}))
local oldID=oldEvent.id;local oldSession=c.currentSession
S.Observe(owner,'Player-Retained-ONE',{name='Retained Friend'},C.Stamp(),'PLAYER_TARGET_CHANGED',{})
assert(c.profiles['Player-Retained-ONE'])
assert(C.SetPersonal('Player-Retained-ONE','Keep this private note',true))
local archive=assert(B.PackSaved(S.db));local original=B.Encode(archive)
if not hadIntel then M.Set('intel',false) end
function nativeEvent(event,...)
 local handlers={}
 for _,f in ipairs(frames) do if f.events and f.events[event] and f.scripts.OnEvent then handlers[#handlers+1]={f,f.scripts.OnEvent} end end
 for _,entry in ipairs(handlers) do entry[2](entry[1],event,...) end
 drain()
end
member=false;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();M.Reconcile()
M.worldReady=nil;ns.DB.chronicle=archive;ns.Initialize();drain()
assert(not ns.Membership.Allowed())
if timing=='before' then member=true;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();drain()
elseif timing=='during' then member=true;ns.OlympusConnection.Invalidate() end
nativeEvent('PLAYER_ENTERING_WORLD',not reloadFixture,reloadFixture)
if timing=='after-entry' then member=true;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();drain() end
local pumps=0;while S.loading do S.PumpLoad();pumps=pumps+1;assert(pumps<10000) end
if timing=='after-load' then member=true;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();drain() end
assert(B.Encode(archive)==original,'loading/resumption must not mutate original archive')
c=ledger();local oldPresent=false;for _,e in ipairs(c.events) do if e.id==oldID then oldPresent=true end end
assert(oldPresent and c.profiles['Player-Retained-ONE'].personal.note=='Keep this private note' and c.profiles['Player-Retained-ONE'].personal.watch,'old evidence and annotations retained')
local count=#c.events
units.target={guid='Player-Login-NEW',name='Login Friend',realm='Test Realm',class='MAGE',level=15}
nativeEvent('PLAYER_TARGET_CHANGED');nativeEvent('QUEST_TURNED_IN',22222,30,40)
local quest=false;for _,e in ipairs(c.events) do if e.kind=='quest_turnin' and e.details.questID==22222 then quest=true end end
proof={active=C.Active(),status=C.Status(),permission=ns.Membership.Allowed(),worldRemembered=M.worldReady==true,newProfile=c.profiles['Player-Login-NEW']~=nil,questRecorded=quest,oldEvidenceRetained=oldPresent,eventCountBefore=count,eventCountAfter=#c.events,priorSession=oldSession,currentSession=c.currentSession}
''')
   proof=dict(l.globals().proof.items());priorSession=proof.pop('priorSession');currentSession=proof.pop('currentSession')
   row={'scope':scope,'permissionTiming':timing,'reload':reload,**proof};rows.append(row)
   if not baseline:
    assert proof['active'],row
    assert (priorSession==currentSession)==reload,('native login/reload session flags',row)
    assert proof['questRecorded']==(scope!='intel'),row
    assert proof['newProfile']==(scope!='chronicle'),row
    # Real displayed and unrendered chat paths, with independently enabled alerts.
    if scope=='full':
     l.execute(r'''
ns.DB.alertsEnabled=true;ns.Mentions.Set('enabled',true)
local before=#ns.Activity.List('mentions');local errors=ns.SignalCore.errors
ns.ChatFilter(DEFAULT_CHAT_FRAME,'CHAT_MSG_SAY','Hello Rune Escape','Other Player',nil,nil,nil,nil,nil,nil,nil,nil,333333)
assert(#ns.Activity.List('mentions')==before+1,'displayed mention reaches SignalWarden after late permission')
nativeEvent('CHAT_MSG_SAY','Rune Escape, hello again','Other Player',nil,nil,nil,nil,nil,nil,nil,nil,333334)
assert(#ns.Activity.List('mentions')==before+2,'event-only mention is assessed through the shared router')
assert(ns.SignalCore.errors==errors,'mention handlers must not swallow errors')
''')
     row['displayedAndEventOnlyMentions']=True
    if scope=='full' and timing=='during' and not reload:
     l.globals().nativeInspectFunctions=nativeInspect
     l.execute(r'''
local I,X,G,A,W=ns.ChronicleEncounters,ns.ChronicleCapture,ns.WardenDossier,ns.ChronicleActivities,ns.Workspace
function hooksecurefunc(object,method,hook)
 if type(object)=='string' then hook=method;method=object;object=_G end
 local original=assert(object[method]);object[method]=function(...) local a,b=original(...);hook(...);return a,b end
end
local cacheGUID
NotifyInspect=function(unit) cacheGUID=UnitGUID(unit) end
ClearInspectPlayer=function() cacheGUID=nil end
CanInspect=function(unit) return units[unit]~=nil end
InspectFrameMixin={};INSPECT_MODE_TAB_INDEX_CHARACTER=1;assert(loadstring(nativeInspectFunctions))()
InspectFrame=CreateFrame('Frame',nil,UIParent);InspectFrame:Hide()
for _,name in ipairs({'GetInspectUnit','UnitChanged','OnEvent','OnHide'}) do InspectFrame[name]=InspectFrameMixin[name] end
InspectFrame.SetupModeTabsForUnit=function() end;InspectFrame.UpdateInspectHeaderForUnit=function() end;InspectFrame.UpdateTabs=function() end
InspectFrame:SetScript('OnHide',InspectFrame.OnHide);InspectFrame:SetScript('OnEvent',InspectFrame.OnEvent)
InspectFrame:RegisterEvent('INSPECT_READY');InspectFrame:RegisterEvent('PLAYER_TARGET_CHANGED')
InspectPVPFrame=CreateFrame('Frame');InspectPVPFrame:Hide()
InspectPaperDollFrame_OnShow=function() end;InspectSwitchTabs=function() end
PlaySound=function() end;SOUNDKIT={IG_CHARACTER_INFO_CLOSE=1}
function HideUIPanel(frame) frame:Hide() end;function ShowUIPanel(frame) frame:Show() end
nativeEvent('ADDON_LOADED','Blizzard_InspectUI')
local function ready()
 local st=A.Request(C.Owner());local n=0;while not st do A.Pump();st=A.Request(C.Owner());n=n+1;assert(n<10000) end;return st
end
ready() -- Existing ready index must be invalidated by the new inspection.
local guid='Player-Manual-LOGIN'
units.target={guid=guid,name='Inspected Login Friend',class='WARRIOR',race='Human',level=8,faction='Alliance'}
GetInventoryItemID=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 then return 1001 end end
GetInventoryItemLink=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 then return '|Hitem:1001:123:0:-4|h[Recorded Chest]|h' end end
GetInventoryItemTexture=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 then return 12345 end end
InspectFrame_Show('target');nativeEvent('INSPECT_READY',guid)
assert(C.Profile(guid),'manual native Inspect saves a new GUID after the repaired login handoff')
local st=ready();local recent=false;local allProfiles=false
for _,row in ipairs(ns.WardenUI.Players(st,'recent')) do if row.id==guid then recent=true end end
for _,row in ipairs(ns.WardenUI.Players(st,'all')) do if row.id==guid then allProfiles=true end end
assert(recent and allProfiles,'new inspected player reaches both Recent and All without reopening history')
local p=G.Request(C.Owner());while not p.done do G.Pump(p) end
assert(#G.Rows(p,guid)==1,'manual inspection retains gear')
nativeEvent('PLAYER_LOGOUT');ns.Initialize();nativeEvent('PLAYER_ENTERING_WORLD',false,true)
local n=0;while S.loading do S.PumpLoad();n=n+1;assert(n<10000) end
assert(C.Active() and C.Profile(guid),'reload resumes recording and retains inspected player')
p=G.Request(C.Owner());while not p.done do G.Pump(p) end
assert(#G.Rows(p,guid)==1,'inspected equipment survives packed save and reload')
''')
     row['manualInspectionRecentAllGearAndReload']=True
    l.execute(r'''
local c=ledger();local count=#c.events;local session=c.currentSession
ns.Chronicle.ModuleWorldReady(true,false)
assert(#c.events==count and c.currentSession==session,'lifecycle handoff must not duplicate an active session')
local messages={};local old=ns.Print;ns.Print=function(v) messages[#messages+1]=v end
C.Slash('check');ns.Print=old
assert(#messages==3 and messages[3]:find('Collector errors:',1,true),'compact diagnostics stays three readable lines')
''')

if not baseline:
 # Gates remain authoritative, including leaving the world before validation ends.
 for mode in ['no-consent','no-access','disabled','left-world']:
  l=h['fresh']('modern',True);l.execute(native);l.globals().modeFixture=mode
  l.execute(r'''
local M,B=ns.Modules,ns.ChronicleBackup
ev('PLAYER_ENTERING_WORLD',true,false);assert(C.SetEnabled(true));local archive=assert(B.PackSaved(S.db))
if modeFixture=='no-consent' then archive.enabled=false;archive.consentVersion=nil end
ns.DB.chronicle=archive;C.Initialize(true)
if modeFixture=='no-access' then member=false;ns.OlympusConnection.Invalidate();ns.Membership.Refresh() end
if modeFixture=='disabled' then M.Set('chronicle',false);M.Set('intel',false) end
for _,f in ipairs(frames) do if f.events and f.events.PLAYER_ENTERING_WORLD and f.scripts.OnEvent then f.scripts.OnEvent(f,'PLAYER_ENTERING_WORLD',true,false) end end
if modeFixture=='left-world' then ev('PLAYER_LEAVING_WORLD') end
local n=0;while S.loading do S.PumpLoad();n=n+1;assert(n<10000) end
assert(not C.Active(),'lifecycle observer must not bypass consent, access, module selection or leaving world: '..modeFixture)
if modeFixture=='left-world' then ev('PLAYER_ENTERING_WORLD',false,false);assert(C.Active(),'return to world resumes the existing consent') end
''')
  rows.append({'gate':mode,'passed':True})
result={'version':'1.1.1-baseline' if baseline else '1.1.2','nativeClient':False,'scenarioCount':len(rows),'failed':0 if not baseline else sum(not x['active'] for x in rows),'scenarios':rows,'seconds':time.perf_counter()-started}
path=o/('login-baseline.json' if baseline else 'login-hotfix-summary.json');path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='scenarios'},indent=2))
