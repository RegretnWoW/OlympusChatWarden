from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1]
h={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'module isolation host','exec'),h)
start=time.perf_counter();l=h['fresh']('modern',True,selection={'chat':False,'shield':True,'chronicle':False,'intel':False,'alerts':False})
l.execute('''
function GetRealmName() return 'Test Realm' end
function UnitFullName() return 'Fixture','Character' end;UnitName=UnitFullName
local M,R=ns.Modules,ns.SignalCore
assert(ns.Shield.Active(),'Shield must work while Chat is disabled')
for n=1,4 do ns.Shield.Observe('trades','Persistent Visitor') end
assert(#ns.Shield.List()==1,'independent contact threshold applies without wording classification')
M.Set('shield',false)
for n=1,10 do ns.Shield.Observe('trades','Second Visitor') end
assert(#ns.Shield.List()==1,'disabled Shield cannot enforce or accumulate old requests')
M.Set('shield',true);ns.Shield.Observe('trades','Second Visitor')
assert(#ns.Shield.List()==1,'re-enable does not replay requests collected while disabled')
for n=1,3 do ns.Shield.Observe('trades','Second Visitor') end
assert(#ns.Shield.List()==2,'fresh requests still enforce the unchanged threshold')
M.Set('shield',false)
local calls=0;local analyze=ns.Confidence.Analyze;ns.Confidence.Analyze=function(...) calls=calls+1;return analyze(...) end
local e=ns.ChatReports.Capture('CHAT_MSG_SAY','A plain native message','Other Player',1234)
assert(e and e.original=='A plain native message' and e.captureSnapshot.classificationAvailable==false and calls==0,'essential reporting works without disabled classification')
M.Set('chat',true)
local e2=ns.ChatReports.Capture('CHAT_MSG_SAY','Another plain native message','Other Player',1235)
assert(e2 and calls>0,'Chat resumes its original classification path when enabled')
local delivered=0
R.Subscribe('disable-during-publish','signal','first',function() M.Set('alerts',false) end)
R.Subscribe('disable-during-publish','alerts','later',function() delivered=delivered+1 end)
M.Set('alerts',true);R.Publish('disable-during-publish',{version=1});assert(delivered==0,'eligibility is rechecked before each consumer')
for _,slots in pairs(R.scratch) do assert(next(slots)==nil,'router retains no payload or subscriber work after delivery') end
''')
# Compact archive stays byte-identical and unvalidated until explicitly needed.
full=h['fresh']('modern',True)
full.execute('''
local S=ns.ChronicleStore;local owner='Test Realm/Player-Preserved-01';local c=assert(S.Character(owner,true));c.currentSession=owner..'/s1'
for n=1,1000 do assert(S.Append(owner,{kind='quest_turnin',at=1800000000+n,elapsed=n,source='QUEST_TURNED_IN',session=c.currentSession,timeSource='server',evidence='confirmed',location={},details={questID=10000+n}})) end
packedArchive=assert(ns.ChronicleBackup.PackSaved(S.db));archive=ns.ChronicleBackup.Encode(packedArchive)
''')
archive=full.globals().archive
off=h['fresh']('modern',True,selection={k:False for k in ['chat','shield','chronicle','intel','alerts']});off.globals().archive=archive
def transfer(lua,value):
 if hasattr(value,'items'):
  result=lua.table()
  for k,v in value.items():result[k]=transfer(lua,v)
  return result
 return value
off.globals().givenArchive=transfer(off,full.globals().packedArchive)
off.execute('''
local S,B=ns.ChronicleStore,ns.ChronicleBackup
ns.Chronicle.Owner=function() return 'Test Realm/Player-Preserved-01' end
ns.DB.chronicle=givenArchive;local original=ns.DB.chronicle
local reads=0;local normalize=S.Normalize;S.Normalize=function(...) reads=reads+1;return normalize(...) end
ns.Initialize();assert(reads==0 and S.db==nil and ns.DB.chronicle==original and B.Encode(original)==archive,'essential-only startup leaves the archive untouched')
ns.Modules.Set('intel',true);assert(S.loading,'history is validated cooperatively only on demand')
ns.Modules.Set('intel',false);assert(not S.loading and ns.DB.chronicle==original and B.Encode(original)==archive,'disabling during loading preserves the original archive')
ns.Modules.Set('intel',true);local pumps=0;while S.loading do S.PumpLoad();pumps=pumps+1;assert(pumps<10000,'native owner must be ready before validation can complete') end
assert(not S.blocked and #S.db.characters['Test Realm/Player-Preserved-01'].events==1000,'re-enable recovers every retained event')
assert(not S.db.enabled,'module changes never grant recording consent')
''')
result={'version':'1.1.1-preview6','failed':0,'independentShieldThresholds':True,'noDelayedEnforcement':True,'minimalEssentialReporting':True,'midDispatchDisable':True,'routerPayloadsRetained':False,'coldArchiveEventsPreserved':1000,'coldArchiveStartupValidationCalls':0,'interruptedLoadPreserved':True,'seconds':time.perf_counter()-start,'nativeClient':False}
(o/'module-isolation-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
