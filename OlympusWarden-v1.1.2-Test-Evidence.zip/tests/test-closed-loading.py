from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1]
h={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'loading host','exec'),h)
native=(o/'test-chronicle.py').read_text().split("lua.execute(r'''")[1].split("check(not S.db.enabled")[0]
start=time.perf_counter();rows=[]
for selected in [{'chronicle'},{'intel'},{'chronicle','intel'}]:
 l=h['fresh']('modern',True,selection={k:k in selected for k in ['chat','shield','alerts','chronicle','intel']});l.execute(native)
 l.globals().personal='chronicle' in selected
 l.execute('''
 ev('PLAYER_ENTERING_WORLD',true,false);assert(C.SetEnabled(true))
 C.Record('native_event','ENCOUNTER_START',{recordType='encounter_started',encounterID=42,name='Test Boss'},nil,'observed')
 local archive=assert(ns.ChronicleBackup.PackSaved(S.db));local original=ns.ChronicleBackup.Encode(archive)
 ns.DB.enabled=false;ns.DB.chronicle=archive
 local old=S.Normalize
 S.Normalize=function(source,checkpoint,owner) for n=1,120 do checkpoint('checksum blocks',8) end;return old(source,checkpoint,owner) end
 local messages={};ns.Print=function(v) messages[#messages+1]=v end
 C.Initialize(true);ns.ChronicleStartup.Handle('PLAYER_ENTERING_WORLD');C.Handle('PLAYER_ENTERING_WORLD',false,true)
 ns.ChronicleStartup.Handle('QUEST_TURNED_IN',998877,100,200);ns.ChronicleStartup.Handle('ENCOUNTER_START',57,'Buffered Boss',1,5)
 assert(ns.ChronicleStartup.diagnostics.captured==(personal and 2 or 1),'startup capture must follow historical scope, never Chat pause')
 local worker;for _,f in ipairs(frames) do if f:GetScript('OnUpdate') then local before=S.loadProgress.pumps;f:GetScript('OnUpdate')(f,.016);if S.loadProgress.pumps>before then worker=f;break end end end
 assert(worker,'dedicated worker schedules itself without ever opening Warden')
 assert(not ns.Workspace.window,'no Warden window needed for validation')
 local updates=0;while S.loading do assert(worker:IsShown());worker:GetScript('OnUpdate')(worker,.25);updates=updates+1;assert(updates<10000) end
 assert(not S.blocked and ns.ChronicleStartup.diagnostics.merged==(personal and 2 or 1))
 assert(ns.ChronicleBackup.Encode(archive)==original,'unvalidated source never modified')
 local progress=S.LoadStatus();assert(progress.closedPumps>0 and progress.openPumps==0,'progress records closed-window worker calls')
 for _,milestone in ipairs({25,50,75,100}) do local count=0;for _,v in ipairs(messages) do if v:find('Saved history '..milestone..'%',1,true) then count=count+1 end end;assert(count==1,'each chat milestone must appear once') end
 assert(messages[#messages]:find('100%',1,true),'completion follows successful validation')
 ''')
 rows.append({'selected':sorted(selected),'closedWindowWorker':True,'startupScopeVerified':True,'quarterMessagesExactlyOnce':True})
result={'version':'1.1.1-preview6','failed':0,'scenarios':rows,'foregroundMinimizedClientVerified':False,'nativeClient':False,'seconds':time.perf_counter()-start}
(o/'closed-loading-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
