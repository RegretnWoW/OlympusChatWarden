from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1];at=time.perf_counter()
h={'__file__':str(o/'smoke.py')};exec(compile((o/'smoke.py').read_text(),'archive regression host','exec'),h);l=h['lua']
l.execute(r'''
local before=checks;local B,A=ns.ChronicleBackup,ns.ChronicleActivities
freshRecording();C.SetEnabled(false)
local owner=C.Owner();local source=S.Character(owner,true)
local function copy(v) if type(v)~='table' then return v end;local t={};for k,x in pairs(v) do t[k]=copy(x) end;return t end
source.profiles['Player-Remember-FRIEND']={guid='Player-Remember-FRIEND',firstObserved=1800000000,lastObserved=1800000000,lastSource='checkpoint',facts={name={value='Remembered Friend',at=1800000000,source='checkpoint'}},personal={note='Private retained note',watch=true}}
for n=1,12 do S.Append(owner,{kind='quest_turnin',session=source.currentSession,at=1800001000+n,elapsed=n,source='QUEST_TURNED_IN',timeSource='server',evidence='confirmed',location={},details={questID=n}}) end
local baseline={schema=6,consentVersion=5,enabled=false,retention='forever',promptSeen=5,duelConsent=1,duels=true,characters={},olympusState={}}
baseline.characters[owner]=copy(source)
otherOwners={}
for n=1,3 do
 local key='TestRealm/Player-Archive-'..n;otherOwners[n]=key;local c=copy(source)
 for _,e in ipairs(c.events) do e.character=key;e.id=key..':'..e.id:match(':(%d+)$');e.session=key..'/s'..e.session:match('/s(%d+)$') end
 c.currentSession=key..'/s'..source.currentSession:match('/s(%d+)$');baseline.characters[key]=c
end
local originals={};for key,c in pairs(baseline.characters) do originals[key]=B.Encode(c.events)..B.Encode(c.profiles) end
S.blocked=false;local packed=assert(B.PackSaved(baseline));ns.DB.chronicle=packed;S.Initialize(true)
local steps=0;while S.loading do S.PumpLoad();steps=steps+1;assert(steps<10000) end
check(not S.blocked and S.Character(owner,false),'current character validates first')
local nativeOwner=C.Owner;C.Owner=function() return nil end
ns.DB.chronicle=packed;S.Initialize(true);for n=1,10 do S.PumpLoad() end
check(S.loading and ns.DB.chronicle==packed,'startup waits for native player identity without committing or guessing')
C.Owner=nativeOwner;while S.loading do S.PumpLoad() end
check(S.Residency().packedCharacters==3 and S.Residency().loadedCharacters==1,'three other characters stay packed')
for _,key in ipairs(otherOwners) do
 local c,status=S.Character(key,true);check(not c and status=='packed','write cannot replace unopened archive with an empty character')
 check(S.db.characters[key]==packed.characters[key],'unopened archive retains exact original representation')
 local stats,status=S.Statistics(key);check(not stats and status=='packed','unloaded statistics cannot be confirmed zero')
end
check(S.Storage().partial and S.Storage().packedCharacters==3,'aggregate storage labels partial expansion')
local current=S.Character(owner,false);S.Append(owner,{kind='quest_turnin',session=current.currentSession,at=1800002000,elapsed=1000,source='QUEST_TURNED_IN',timeSource='server',evidence='confirmed',location={},details={questID=999}})
S.PrepareLogout();local saved=ns.DB.chronicle
for _,key in ipairs(otherOwners) do check(saved.characters[key]==packed.characters[key],'logout preserves opaque archive without decoding it') end
-- Log into an alt by making its native identity current before initialization.
local oldOwner=C.Owner;C.Owner=function() return otherOwners[1],'Player-Archive-1' end
S.Initialize(true);while S.loading do S.PumpLoad() end
check(S.Residency().loadedCharacters==1 and S.Residency().packedCharacters==3,'alt login does not expand A, C or D')
local b=S.Character(otherOwners[1],false);check(B.Encode(b.events)..B.Encode(b.profiles)==originals[otherOwners[1]],'alt full decoded contents match baseline')
local _,status=S.RequestCharacter(owner);check(status=='loading','other history loads cooperatively on demand')
for n=1,10000 do S.PumpArchives();if S.Character(owner,false) then break end end
check(#S.Character(owner,false).events==#source.events+1,'new current-character record survives switching')
local _,status=S.RequestCharacter(otherOwners[2]);check(status=='loading','secondary request is explicit')
S.PrepareLogout();check(ns.DB.chronicle.characters[otherOwners[2]]==saved.characters[otherOwners[2]],'logout during secondary validation keeps original archive')
-- A complete-file save includes D before it was ever decoded.
check(B.Encode(ns.DB.chronicle.characters[otherOwners[3]])==B.Encode(saved.characters[otherOwners[3]]),'full save includes the unopened fourth character')
C.Owner=oldOwner;S.Initialize(true);while S.loading do S.PumpLoad() end
local ready=S.RequireCharacters();check(not ready,'all-character request waits rather than returning incomplete results')
for n=1,10000 do S.PumpArchives();if S.RequireCharacters() then break end end
for _,key in ipairs(otherOwners) do local c=S.Character(key,false);check(c and B.Encode(c.events)..B.Encode(c.profiles)==originals[key],'every loaded alt retains exact event/profile content') end
local export=assert(B.Create());check(export.total>0,'text backup still includes fully requested history')
local snapshot=B.Encode(S.db.characters);local hybrid=assert(B.PackSaved(S.db))
ns.DB.chronicle=hybrid;S.Initialize(true);while S.loading do S.PumpLoad() end
local received,exportError;local timers=C_Timer;C_Timer=nil
check(B.Begin(function(result,err) received=result;exportError=err end),'asynchronous backup accepts a hybrid ledger')
for n=1,10000 do S.PumpArchives();local worker=B.worker;if worker and worker:GetScript('OnUpdate') then worker:GetScript('OnUpdate')(worker,.016) end;if not B.job then break end end
C_Timer=timers
check(received and not exportError and received.batch==export.batch,'asynchronous export loads every archive and preserves the full snapshot')
ns.DB.chronicle=hybrid;S.Initialize(true);while S.loading do S.PumpLoad() end
local part;for _,text in ipairs(export.parts) do if B.Validate(text).owner==otherOwners[3] then part=text;break end end
local restored,reason=B.Restore(part)
check(not restored and reason:find('Loading requested',1,true) and S.db.characters[otherOwners[3]]==hybrid.characters[otherOwners[3]],'restore waits without replacing the unopened destination')
for n=1,10000 do S.PumpArchives();if S.Character(otherOwners[3],false) then break end end
check(B.Restore(part),'restore succeeds after destination validation')
check(B.Encode(S.Character(otherOwners[3],false).events)==B.Encode(baseline.characters[otherOwners[3]].events),'duplicate import preserves original destination events')
ns.DB.chronicle=hybrid;S.Initialize(true);while S.loading do S.PumpLoad() end
local search=ns.WardenSearch.Begin('Remembered Friend')
for n=1,10000 do S.PumpArchives();ns.WardenSearch.Pump(search);if search.done then break end end
local found={};for _,result in ipairs(search.results) do if result.data.guid then found[result.data.owner]=true end end
check(search.done and not search.error,'all-character suite search completes after cooperative archive loads')
for _,key in ipairs(otherOwners) do check(found[key],'search includes an unopened character profile') end
local packSaved=B.PackSaved;B.PackSaved=function() error('simulated packing failure') end
S.PrepareLogout();B.PackSaved=packSaved
check(ns.DB.chronicle==S.db,'failed logout packing retains newest complete hybrid data')
check(S.Normalize(ns.DB.chronicle),'failed-pack fallback can be revalidated without record loss')
-- Corrupted unloaded archives remain recoverable and never become empty records.
local corrupt=copy(saved);corrupt.characters[otherOwners[2]].eventChunks[1]='corrupted'
ns.DB.chronicle=corrupt;S.Initialize(true);while S.loading do S.PumpLoad() end
check(not S.blocked,'corruption in an unopened alt does not discard current history')
S.RequestCharacter(otherOwners[2]);for n=1,1000 do S.PumpArchives();if S.ArchiveError(otherOwners[2]) then break end end
check(S.ArchiveError(otherOwners[2]) and S.db.characters[otherOwners[2]]==corrupt.characters[otherOwners[2]],'failed secondary load preserves exact corrupt representation')
S.PrepareLogout();check(ns.DB.chronicle.characters[otherOwners[2]].eventChunks[1]=='corrupted','logout cannot erase a failed unopened archive')
-- Supported saved records must fail explicitly rather than being filtered.
local e=copy(source.events[#source.events]);local key=e.character
local function reject(c,label)
 local db={schema=6,characters={[key]=c}};local encoded=B.Encode(db);local clean=S.Normalize(db)
 check(not clean,label);check(B.Encode(db)==encoded,'failed normalization leaves original '..label)
end
local c=copy(source);c.events[1].futureUserInformation='kept for recovery';reject(c,'unknown event fields')
c=copy(source);c.events[#c.events+1]=copy(c.events[1]);reject(c,'duplicate event identifiers')
c=copy(source);c.profiles['Player-Remember-FRIEND'].personal.note=string.rep('n',513);reject(c,'oversized private note')
c=copy(source);c.profiles['Player-Remember-FRIEND'].facts.name.source='BAD_SOURCE';reject(c,'partially decoded profile')
c=copy(source);c.events[2]=nil;reject(c,'incomplete legacy event array')
local big=copy(e);big.kind='location';big.details={}
for _,name in ipairs({'reason','skill','name','realm','class','race','faction','guild','via','locale','clientVersion','buildDate','classification','creatureName','title','objective','objectiveType','method','relationship','recordType','unitVisible','inspection','scope','resetSeconds'}) do big.details[name]=string.rep('v',256) end
check(S.Event(big,key) and S.Size(big)>12000,'oversize regression is a valid event that exceeded the old size gate')
c=copy(source);c.events={big};reject(c,'oversized saved event')
S.blocked=false;local pack=assert(B.PackSaved({schema=6,characters={[key]=c}}));reject(pack.characters[key],'oversized packed saved event')
archiveChecks=checks-before
''')
result={'version':'1.1.1-preview8','failed':0,'assertions':int(l.globals().archiveChecks),'nativeClientTested':False,'seconds':time.perf_counter()-at}
(o/'archives-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
