from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'manual-inspect-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
native=(out/'research/Blizzard_InspectUI.lua').read_text(encoding='utf-8')
pieces=[]
for begin,end in [('function InspectFrameMixin:GetInspectUnit()','function InspectFrame_Show(unit)'),('function InspectFrame_Show(unit)','function InspectFrameMixin:OnLoad()'),('function InspectFrameMixin:OnEvent(event, ...)','function InspectFrameMixin:UnitChanged()'),('function InspectFrameMixin:UnitChanged()','function InspectFrameMixin:OnShow()'),('function InspectFrameMixin:OnHide()','function InspectSwitchTabs(newID)')]:
 pieces.append(native[native.index(begin):native.index(end)])
lua.globals().nativeInspectFunctions='\n'.join(pieces)
lua.execute(r'''
local before=checks;local I,X,G,W=ns.ChronicleEncounters,ns.ChronicleCapture,ns.WardenDossier,ns.Workspace
local hookCount=0
function hooksecurefunc(object,method,hook)
 if type(object)=='string' then hook=method;method=object;object=_G end
 local original=assert(object[method]);hookCount=hookCount+1
 object[method]=function(...) local a,b=original(...);hook(...);return a,b end
end
local notifications,cacheGUID=0,nil
NotifyInspect=function(unit) notifications=notifications+1;cacheGUID=UnitGUID(unit) end
ClearInspectPlayer=function() cacheGUID=nil end
CanInspect=function(unit) return units[unit]~=nil end
units.target=nil;units.mouseover=nil;units.party1=nil;groupCount=0;freshRecording()
check(type(InspectFrame_Show)~='function','native inspect UI is initially load-on-demand')
InspectFrameMixin={};INSPECT_MODE_TAB_INDEX_CHARACTER=1
assert(loadstring(nativeInspectFunctions))()
InspectFrame=CreateFrame('Frame',nil,UIParent);InspectFrame:Hide()
for _,name in ipairs({'GetInspectUnit','UnitChanged','OnEvent','OnHide'}) do InspectFrame[name]=InspectFrameMixin[name] end
InspectFrame.SetupModeTabsForUnit=function() end;InspectFrame.UpdateInspectHeaderForUnit=function() end;InspectFrame.UpdateTabs=function() end
InspectFrame:SetScript('OnHide',InspectFrame.OnHide);InspectFrame:SetScript('OnEvent',InspectFrame.OnEvent)
InspectFrame:RegisterEvent('INSPECT_READY');InspectFrame:RegisterEvent('PLAYER_TARGET_CHANGED')
InspectPVPFrame=CreateFrame('Frame');InspectPVPFrame:Hide()
InspectPaperDollFrame_OnShow=function() end;InspectSwitchTabs=function() end
PlaySound=function() end;SOUNDKIT={IG_CHARACTER_INFO_CLOSE=1}
function HideUIPanel(frame) frame:Hide() end;function ShowUIPanel(frame) frame:Show() end
ev('ADDON_LOADED','Blizzard_InspectUI');local installed=hookCount;ev('ADDON_LOADED','AnotherAddon')
check(hookCount==installed,'load-on-demand native hooks install only once')
local guid='Player-Manual-ONE';units.target={guid=guid,name='Inspected Friend',class='WARRIOR',race='Human',level=8,guild='Native Inspect Guild',faction='Alliance'}
local item=1001;local present=true
GetInventoryItemID=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 and present then return item end end
GetInventoryItemLink=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 and present then return '|Hitem:'..item..':123:0:-4|h[Recorded Chest]|h' end end
GetInventoryItemTexture=function(unit,slot) if UnitGUID(unit)==cacheGUID and slot==5 and present then return 12345 end end
local function important() return all('important_player') end
local count=#important();local prior=notifications
InspectFrame_Show('target')
check(not InspectFrame:IsShown() and notifications==prior+1,'native UI issues one inspect and waits hidden for its response')
ev('INSPECT_READY',guid)
check(InspectFrame:IsShown(),'real native handler shows the Inspect window on matching response')
local e=important()[#important()]
check(#important()==count+1 and e.subject==guid and e.details.relationship=='manual inspection','normal user inspection becomes important-player evidence')
check(I.IsImportant(guid) and e.source=='INSPECT_READY' and e.details.gearRef,'manual inspection qualifies important player without queuing another request')
check(notifications==prior+1,'manual response does not issue a second inspection')
local object=X.Find(C.Owner(),e.details.gearRef)
check(object and object.capture.values.guid==guid and object.capture.values.slots[5][4]=='item:1001:123:0:-4','manual gear bound to original GUID with exact item payload')
check(object.capture.values.slots[1][2]=='unavailable','unknown inspected slot remains unknown')
check(C.Profile(guid).facts.name.value=='Inspected Friend','manual inspection creates a stored identity without relying on a target event')
check(ns.RecordingUI.IsEvent(e) and ns.RecordingUI.Title(e)=='Player inspected','completed inspection appears in normal Events view')
local function ready()
 local st=ns.ChronicleActivities.Request(C.Owner());local n=0;while not st do ns.ChronicleActivities.Pump();st=ns.ChronicleActivities.Request(C.Owner());n=n+1;assert(n<10000) end;return st
end
local st=ready();local rows=ns.WardenUI.Players(st,'recent');local row
for _,r in ipairs(rows) do if r.id==guid then row=r end end
check(row and row.data.lastInspection==e.at,'manually inspected player appears in Recently met without false encounter count')
check(row.data.recordedEncounters==0 and row.data.credits.own==0,'manual inspect alone proves no local encounter episode or kill')
local projection=G.Request(C.Owner());while not projection.done do G.Pump(projection) end
check(#G.Rows(projection,guid)==1,'saved manual gear reaches Appearance & Gear projection')
W.Open('intel');local intel=W.pages.intel;intel.selected=guid;intel:Refresh(true);click(intel.gearButton)
local panel=intel.appearance;panel.scripts.OnUpdate(panel,.1)
check(panel.slots[5].link=='item:1001:123:0:-4','production paper doll shows completed manual inspection')
count=#important();ev('INSPECT_READY',guid);check(#important()==count,'duplicate inspect-ready event does not create duplicate observation')
clock=clock+2;item=1002;InspectFrame:UnitChanged();ev('INSPECT_READY',guid)
check(important()[#important()].details.gearRef~=e.details.gearRef,'native UnitChanged refresh preserves new gear as a separate observation')
st=ready();intel:Refresh(true);panel.scripts.OnUpdate(panel,.1)
check(panel.slots[5].link=='item:1002:123:0:-4' and #panel.rows==2,'open dossier updates to newly completed gear and keeps earlier set')
clock=clock+2;InspectFrame_Show('target');count=#important();NotifyInspect('player');ev('INSPECT_READY',guid)
check(#important()==count,'intervening unrelated addon inspection invalidates manual cache ownership')
InspectFrame.unit='target';NotifyInspect('target');ev('INSPECT_READY',guid)
check(#important()==count,'NotifyInspect alone cannot masquerade as deliberate native inspection')
clock=clock+2;InspectFrame_Show('target');ClearInspectPlayer();ev('INSPECT_READY',guid)
check(#important()==count,'native inspection close/clear rejects stale response')
clock=clock+2;InspectFrame_Show('target');units.target.guid='Player-Manual-OTHER';ev('INSPECT_READY',guid)
check(#important()==count,'target GUID recycling rejects mismatched response');units.target.guid=guid
clock=clock+2;InspectFrame_Show('target');ev('INSPECT_READY','Player-Manual-OTHER')
check(#important()==count,'wrong response GUID is ignored');ClearInspectPlayer()
clock=clock+2;InspectFrame_Show('target');local visible=UnitIsVisible;UnitIsVisible=function() return false end;ev('INSPECT_READY',guid)
check(#important()==count,'out-of-range player cannot provide a manual saved inspection');UnitIsVisible=visible;ClearInspectPlayer()
clock=clock+2;InspectFrame_Show('target');clock=clock+9;I.InspectPump();ev('INSPECT_READY',guid)
check(#important()==count,'timed-out manual request cannot save a late response')
local allowed=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end;InspectFrame_Show('target');ev('INSPECT_READY',guid)
check(#important()==count,'membership loss prevents new inspection retention');ns.Membership.Allowed=allowed
C.SetEnabled(false);local beforeRows=#all('important_player');InspectFrame_Show('target');ev('INSPECT_READY',guid)
check(#all('important_player')==beforeRows and not C.Active(),'manual inspect while paused does not record or change consent')
panel.rows={};panel:Render();check(panel.status:GetText():find('recording is paused',1,true),'empty gear explains recording is paused')
C.SetEnabled(true);local beforeRows=#important();ev('INSPECT_READY',guid)
check(#important()==beforeRows,'re-enabling does not backfill previously unowned cached gear')
clock=clock+2;InspectFrame_Show('target');ev('INSPECT_READY',guid)
check(#important()==beforeRows+1,'new deliberate inspection records after consented recording resumes')
-- A changed cache during slot copying cannot mix two inspected identities.
clock=clock+2;InspectFrame_Show('target');beforeRows=#important();local getter=GetInventoryItemID;local switched=false
GetInventoryItemID=function(unit,slot) if slot==9 and not switched then switched=true;NotifyInspect('player') end;return getter(unit,slot) end
ev('INSPECT_READY',guid);check(#important()==beforeRows,'shared-cache interruption inside gear read rejects the entire manual observation');GetInventoryItemID=getter
-- Legacy native UnitChanged entry also qualifies without changing cache ownership.
function InspectFrame_UnitChanged() NotifyInspect(InspectFrame.unit) end
ev('ADDON_LOADED','LegacyInspectCompatibility');InspectFrame.unit='target';InspectFrame_UnitChanged();ev('INSPECT_READY',guid)
check(important()[#important()].details.relationship=='manual inspection','legacy native UnitChanged path supported')

-- Native model rejects hidden SetUnit; production must show it before binding.
local m=getmetatable(UIParent).__index;local hiddenRejects,modelCalls=0,0
function m:SetKeepModelOnHide(value) self.keep=value end
function m:SetUnit(unit)
 modelCalls=modelCalls+1
 if not self:IsShown() then hiddenRejects=hiddenRejects+1;return false end
 self.nativeUnit=unit;return modelSuccess
end
function m:ClearModel() self.nativeUnit=nil end;function m:SetCamDistanceScale() end;function m:SetPortraitZoom() end;function m:SetPosition() end;function m:SetRotation() end
modelSuccess=true;st=ready();row=nil;for _,r in ipairs(ns.WardenUI.Players(st,'all')) do if r.id==guid then row=r end end
local host=CreateFrame('Frame',nil,UIParent);local modelPanel=G.Build(host,host);modelPanel:Show();modelPanel:SetProfile(C.Owner(),row,st)
check(modelPanel.unit=='target' and modelPanel.model:IsShown() and hiddenRejects==0,'native model is visible before SetUnit and never hits hidden-frame failure')
check(modelPanel.model.keep==true,'native keep-model-on-hide capability is enabled when available')
local current=modelCalls;modelPanel:SetProfile(C.Owner(),row,st);check(modelCalls==current,'ordinary dossier refresh does not rebuild native model')
modelPanel:Hide();check(not modelPanel.model:IsShown() and modelPanel.unit==nil,'hide still clears the retained model explicitly')
modelPanel:Show();modelPanel:Bind();check(modelPanel.unit=='target','reopening binds the correct visible player')
local keep=m.SetKeepModelOnHide;m.SetKeepModelOnHide=nil;modelPanel:Bind(true)
check(modelPanel.unit=='target' and hiddenRejects==0,'show-before-SetUnit also works without keep-model support');m.SetKeepModelOnHide=keep
modelSuccess=false;modelPanel:Bind(true);check(not modelPanel.model:IsShown() and modelPanel.unit==nil,'native model failure is still cleared safely');modelSuccess=true
modelPanel:Bind(true);units.target.guid='Player-Model-CHANGED';modelPanel.scripts.OnUpdate(modelPanel,.1)
check(modelPanel.unit==nil and not modelPanel.model:IsShown(),'GUID change clears model after successful initialization');units.target.guid=guid
modelPanel.view='history';modelPanel:Bind();check(not modelPanel.model:IsShown(),'historical view never substitutes a live model')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'existing schema, consent and protected-event boundaries retained')
manualChecks=checks-before
''')
summary={'version':'1.1.0','assertions':int(lua.globals().manualChecks),'failed':0,'nativeInspectSource':'Forever 70425 Camelot UI functions','liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'manual-inspect-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
