from pathlib import Path
import subprocess,json,shutil
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
runs=[]
for name in ['powershell.exe','pwsh.exe']:
 binary=shutil.which(name)
 if not binary: raise RuntimeError('Required Windows test runtime missing: '+name)
 run=subprocess.run([binary,'-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',str(out/'test-backup-tool.ps1'),'-WorkspaceRoot',str(root)],cwd=root,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (out/('source-backup-'+name+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8')
 if run.returncode:print(run.stdout+run.stderr);raise SystemExit(run.returncode)
 value=json.loads(run.stdout);assert value['failed']==0;runs.append(value)
summary={'version':'1.0.3','assertions':sum(r['assertions'] for r in runs),'failed':0,'runtimes':runs,'personalFilesRead':False,'liveWoWTested':False}
(out/'backup-tool-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
