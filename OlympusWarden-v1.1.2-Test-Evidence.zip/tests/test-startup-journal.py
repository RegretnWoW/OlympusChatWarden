from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1];start=time.perf_counter()
h={'__file__':str(o/'smoke.py')};exec(compile((o/'smoke.py').read_text(),'startup recovery host','exec'),h);l=h['lua']
l.execute(r'''
local before=checks;local B,J,T=ns.ChronicleBackup,ns.ChronicleStartupJournal,ns.ChronicleStartup
freshRecording();J.Clear();local owner=C.Owner()
local archive=assert(B.PackSaved(S.db));local archiveBytes=B.Encode(archive)
local function begin()
 ns.DB.chronicle=archive;S.Initialize(true);check(S.loading~=nil,'archive validates cooperatively')
 T.Handle('PLAYER_ENTERING_WORLD')
end
local function finish()
 local n=0;while S.loading do S.PumpLoad();n=n+1;assert(n<10000) end
 J.Merge();while J.Busy() do J.Pump() end
end
begin();local stamp=GetServerTime();T.Handle('QUEST_TURNED_IN',701,10,20);T.Handle('ACHIEVEMENT_EARNED',702,false)
check(J.Count()==2 and T.diagnostics.captured==2,'eligible observations go to local saved recovery journal')
S.CancelLoad();S.PrepareLogout()
check(ns.DB.chronicle==archive and B.Encode(archive)==archiveBytes,'interrupted startup keeps original archive exactly')
check(J.Count()==2 and T.diagnostics.discarded==0,'normal exit does not discard staged observations')
begin();clock=clock+10;T.Handle('QUEST_TURNED_IN',703,30,40)
check(J.Count()==3,'second startup adds observations without replacing earlier window')
finish();check(not S.blocked and J.Count()==0,'successful validation recovers and clears committed staging')
local quests,achievement,sessions={},nil,{}
for _,e in ipairs(S.Character(owner,false).events) do
 if e.kind=='quest_turnin' and e.details.questID>=701 and e.details.questID<=703 then quests[e.details.questID]=e;sessions[e.session]=true end
 if e.kind=='achievement_earned' and e.details.achievementID==702 then achievement=e end
end
check(quests[701] and quests[703] and achievement,'all original event kinds retained')
check(quests[701].at==stamp and quests[703].at==stamp+10,'original event-time timestamps retained across restarts')
check(quests[701].session~=quests[703].session,'different startup windows do not invent one continuous session')
local count=#S.Character(owner,false).events;J.Merge();check(#S.Character(owner,false).events==count,'completed recovery never duplicates observations')
-- Simulate interruption immediately after the first history append succeeds.
archive=assert(B.PackSaved(S.db));begin();T.Handle('QUEST_TURNED_IN',704,1,2);T.Handle('QUEST_TURNED_IN',705,3,4)
local append=S.Append;local interrupted=false
S.Append=function(...) local e=append(...);if e and e.kind=='quest_turnin' then interrupted=true;error('simulated exit after commit') end;return e end
local gate=C.RefreshGate;C.RefreshGate=function() end
while S.loading do S.PumpLoad() end
C.RefreshGate=gate;check(J.Count()==2 and J.error and interrupted,'partial commit keeps original staging with assigned identifier')
S.Append=append;S.PrepareLogout();archive=ns.DB.chronicle;begin();finish()
local counts={};for _,e in ipairs(S.Character(owner,false).events) do if e.kind=='quest_turnin' then local id=e.details.questID;counts[id]=(counts[id] or 0)+1 end end
check(counts[704]==1 and counts[705]==1,'reload detects committed identifier and restores remaining record exactly once')
-- Both overflow limits are observable and appear in the historical gap marker.
archive=assert(B.PackSaved(S.db));begin();local oldLimit=T.LIMIT;T.LIMIT=3
for n=1,5 do T.Handle('QUEST_TURNED_IN',800+n,0,0) end
check(J.Count()==3 and T.diagnostics.overflow==2,'record cap reports overflow without silently dropping accepted records')
T.LIMIT=oldLimit;local oldBytes=T.BYTES;T.BYTES=0;T.Handle('ACHIEVEMENT_EARNED',899,false);T.BYTES=oldBytes
check(T.diagnostics.overflow==3,'byte cap reports overflow')
finish();local gap;for _,e in ipairs(S.Character(owner,false).events) do if e.kind=='collection_gap' then gap=e end end
check(gap and gap.details.samples==3 and gap.details.count==3,'coverage marker preserves overflow count and partial coverage')
-- Validation failure preserves both the archive and the separate journal.
archive=assert(B.PackSaved(S.db));archive.characters[owner].eventChunks[1]='damaged';archiveBytes=B.Encode(archive)
begin();T.Handle('QUEST_TURNED_IN',900,1,2);while S.loading do S.PumpLoad() end
check(S.blocked and J.Count()==1 and B.Encode(archive)==archiveBytes,'failed history validation retains staged and original data')
check(not J.Busy(),'invalid original history is never merged')
-- No recording consent: never create new staging or collect new observations.
J.Clear();archive={schema=6,enabled=false,consentVersion=5,retention='forever',characters={}}
begin();T.Handle('QUEST_TURNED_IN',901,1,2);check(J.Count()==0,'recording off does not capture new startup observations');finish()
archive={schema=6,enabled=true,consentVersion=4,characters={}};begin();T.Handle('ACHIEVEMENT_EARNED',902,false)
check(J.Count()==0,'old consent does not capture');finish()
-- Malformed recovery data must remain available for complete-file backup.
OlympusWardenStartupDB={version=1,characters={[owner]={rows={},run='invalid',bytes=0,overflow=0,firstAt=GetServerTime(),sessions={}}}}
local malformed=B.Encode(OlympusWardenStartupDB);J.Prepare(owner,GetServerTime())
check(J.error and B.Encode(OlympusWardenStartupDB)==malformed,'unsupported recovery data is kept unchanged')
J.Clear();archive={schema=6,enabled=true,consentVersion=5,characters={}};ns.DB.chronicle=archive;S.Initialize()
local entry,run=J.Prepare(owner,GetServerTime());entry.started=true
local other='TestRealm/Player-Other-Journal';local otherEntry=J.Prepare(other,GetServerTime());otherEntry.started=true
local otherBytes=B.Encode(otherEntry);J.Merge();while J.Busy() do J.Pump() end
check(OlympusWardenStartupDB.characters[other] and B.Encode(OlympusWardenStartupDB.characters[other])==otherBytes,'recovery never consumes another character staging')
entry,run=J.Prepare(owner,GetServerTime());entry.started=true
entry.rows[1]={kind='quest_turnin',source='QUEST_TURNED_IN',details={questID=777777},evidence='confirmed',at=GetServerTime(),elapsed=clock,timeSource='server',location={},run=run}
local c=S.Character(owner,true);local session=c.currentSession or owner..'/s1';c.currentSession=session
local existing=S.Append(owner,{kind='quest_turnin',source='QUEST_TURNED_IN',details={questID=888888},session=session,evidence='confirmed',at=GetServerTime(),elapsed=clock,timeSource='server',location={}})
entry.rows[1].targetID=existing.id;entry.rows[1].targetSession=existing.session
J.Merge();while J.Busy() do J.Pump() end
check(J.error and OlympusWardenStartupDB.characters[owner]==entry and existing.details.questID==888888,'conflicting historical identity preserves both originals without overwriting')
J.Clear();C.Clear();check(J.Count()==0,'explicit history clear also clears recovery journal')
startupJournalChecks=checks-before
''')
result={'version':'1.1.1-preview8','failed':0,'assertions':int(l.globals().startupJournalChecks),'nativeClient':False,'seconds':time.perf_counter()-start}
(o/'startup-journal-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
