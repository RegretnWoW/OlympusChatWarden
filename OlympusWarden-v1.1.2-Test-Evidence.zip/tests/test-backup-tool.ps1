param([string]$WorkspaceRoot=(Split-Path (Split-Path $PSScriptRoot -Parent) -Parent))
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$tool=Join-Path $WorkspaceRoot 'ChatWarden-Backup-Tool/ChatWarden-Backup.ps1'
$tokens=$null;$parseErrors=$null
[void][Management.Automation.Language.Parser]::ParseFile($tool,[ref]$tokens,[ref]$parseErrors)
if ($parseErrors.Count) {throw ($parseErrors | Out-String)}
. $tool -Mode Library
$script:Checks=0
function Check([bool]$Value,[string]$Label) {if (-not $Value) {throw $Label};$script:Checks++}
function Reject([scriptblock]$Action,[string]$Label) {
 $thrown=$false
 try {& $Action | Out-Null} catch {$thrown=$true}
 Check $thrown $Label
}
# Isolated synthetic histories; no real client or personal SavedVariables are opened.
$testRoot=Join-Path $WorkspaceRoot ('.work\bk-'+[Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
$dataDir=Join-Path $testRoot 'Game/WTF/Account/TestAccount/SavedVariables';[void][IO.Directory]::CreateDirectory($dataDir)
$archives=Join-Path $testRoot 'Backups';[void][IO.Directory]::CreateDirectory($archives)
$data=Join-Path $dataDir 'OlympusChatWarden.lua';$archive=Join-Path $archives 'complete.zip'
$original=[Text.Encoding]::UTF8.GetBytes("OlympusChatWardenDB = { synthetic = true, chronicle = { note = 'caf"+[char]0xE9+"', data = '"+('x'*8388608)+"' } }`nOlympusWardenRelayDB = { schema = 1, reports = { { id = 'fixture-report', state = 'pending' } }, inbox = { { key = 'fixture-inbox', state = 'Reviewing' } } }`nOlympusWardenStartupDB = { version = 1, characters = { ['fixture-owner'] = { rows = { { kind = 'quest_turnin', at = 1800000000 } } } } }")
[IO.File]::WriteAllBytes($data,$original)
$expected=Get-DataHash $data
$script:SimulatedWoW=$false
function Get-ChatWardenGameProcesses {if ($script:SimulatedWoW) {@('simulated Wow.exe')}}
Reject {New-ChatWardenBackup $data $archive $false} 'backup requires explicit closed-game confirmation'
Check (-not [IO.File]::Exists($archive)) 'rejected backup creates nothing'
$script:SimulatedWoW=$true
Reject {New-ChatWardenBackup $data $archive $true} 'running game blocks backup'
$script:SimulatedWoW=$false
$result=New-ChatWardenBackup $data $archive $true
Check ($result.Sha256 -eq $expected -and $result.Bytes -eq $original.Length) 'large full-file backup preserves exact hash and length'
Check ((Get-DataHash $data) -eq $expected) 'backup leaves source unchanged'
$info=Read-Backup $archive
Check ($info.Sha256 -eq $expected -and $info.ToolVersion -eq '1.0.3') 'backup manifest verifies'
$z=[IO.Compression.ZipFile]::OpenRead($archive)
try {Check ($z.Entries.Count -eq 2 -and $null -ne $z.GetEntry('OlympusChatWarden.lua') -and $null -ne $z.GetEntry('manifest.json')) 'archive contains only fixed safe entries'} finally {$z.Dispose()}
$archiveHash=Get-DataHash $archive
Reject {New-ChatWardenBackup $data $archive $true} 'existing backup never overwritten'
Check ((Get-DataHash $archive) -eq $archiveHash) 'existing backup is byte-identical after refused overwrite'
Reject {New-ChatWardenBackup $data (Join-Path $dataDir 'bad.zip') $true} 'backup cannot be stored inside game installation'
Reject {New-ChatWardenBackup (Join-Path $dataDir 'OtherAddon.lua') (Join-Path $archives 'other.zip') $true} 'wrong addon filename rejected'
Reject {Resolve-SavedFile (Join-Path $testRoot 'OlympusChatWarden.lua') $true} 'wrong account folder shape rejected'
[IO.File]::WriteAllText($data,'synthetic replacement state')
$currentHash=Get-DataHash $data
Reject {Restore-ChatWardenBackup $data $archive $false} 'restore requires explicit closed-game confirmation'
Check ((Get-DataHash $data) -eq $currentHash) 'unconfirmed restore leaves file unchanged'
$script:SimulatedWoW=$true
Reject {Restore-ChatWardenBackup $data $archive $true} 'running game blocks restore'
$script:SimulatedWoW=$false
$restored=Restore-ChatWardenBackup $data $archive $true
Check ((Get-DataHash $data) -eq $expected) 'complete restore recovers every original byte'
Check ([Collections.StructuralComparisons]::StructuralEqualityComparer.Equals($original,[IO.File]::ReadAllBytes($data))) 'independent direct-byte comparison preserves complete UTF8 history'
Check ([IO.File]::ReadAllText($data).Contains("OlympusWardenRelayDB = { schema = 1") -and [IO.File]::ReadAllText($data).Contains("fixture-inbox")) 'unchanged backup tool restores both main and Relay variables in the same account file'
Check ([IO.File]::ReadAllText($data).Contains("OlympusWardenStartupDB = { version = 1") -and [IO.File]::ReadAllText($data).Contains("fixture-owner")) 'complete-file restore also retains startup observations awaiting validation'
Check ([IO.File]::Exists($restored.SafetyCopy) -and (Read-Backup $restored.SafetyCopy).Sha256 -eq $currentHash) 'restore safety ZIP contains exact previous state'
Check (@(Get-ChildItem -LiteralPath $dataDir -Filter '.chatwarden-restore-*' -File).Count -eq 0) 'successful restore leaves no staging file'
# New PC: restore to a correct existing account directory, without a current file.
$newDir=Join-Path $testRoot 'NewPC/WTF/Account/SecondAccount/SavedVariables';[void][IO.Directory]::CreateDirectory($newDir)
$newData=Join-Path $newDir 'OlympusChatWarden.lua'
$new=Restore-ChatWardenBackup $newData $archive $true
Check ((Get-DataHash $newData) -eq $expected -and $null -eq $new.SafetyCopy) 'new-PC restore creates exact file without a nonexistent safety copy'
function Mutant([string]$Name,[scriptblock]$Change) {
 $dest=Join-Path $archives $Name;[IO.File]::Copy($archive,$dest)
 $zip=[IO.Compression.ZipFile]::Open($dest,[IO.Compression.ZipArchiveMode]::Update)
 try {& $Change $zip} finally {$zip.Dispose()}
 return $dest
}
$extra=Mutant 'traversal.zip' {param($zip) [void]$zip.CreateEntry('../outside.lua')}
$before=Get-DataHash $data
Reject {Restore-ChatWardenBackup $data $extra $true} 'unexpected/traversal entry rejected'
Check ((Get-DataHash $data) -eq $before -and -not [IO.File]::Exists((Join-Path $testRoot 'outside.lua'))) 'rejected ZIP neither extracts extra entries nor changes saved data'
$corrupt=Mutant 'corrupt.zip' {
 param($zip)
 $zip.GetEntry('OlympusChatWarden.lua').Delete()
 $stream=$zip.CreateEntry('OlympusChatWarden.lua').Open()
 try {$stream.WriteByte(1)} finally {$stream.Dispose()}
}
Reject {Restore-ChatWardenBackup $data $corrupt $true} 'bad length/content rejected before replacement'
$manifestBad=Mutant 'hash-mismatch.zip' {
 param($zip)
 $entry=$zip.GetEntry('manifest.json');$reader=[IO.StreamReader]::new($entry.Open())
 try {$m=$reader.ReadToEnd() | ConvertFrom-Json} finally {$reader.Dispose()}
 $entry.Delete();$m.sha256=('0'*64);$writer=[IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open())
 try {$writer.Write(($m | ConvertTo-Json -Compress))} finally {$writer.Dispose()}
}
Reject {Restore-ChatWardenBackup $data $manifestBad $true} 'checksum mismatch rejected before replacement'
Check ((Get-DataHash $data) -eq $before) 'corrupt restores preserve the entire original file'
$unknown=Mutant 'future.zip' {
 param($zip)
 $entry=$zip.GetEntry('manifest.json');$reader=[IO.StreamReader]::new($entry.Open())
 try {$m=$reader.ReadToEnd() | ConvertFrom-Json} finally {$reader.Dispose()}
 $entry.Delete();$m.format='FUTURE';$writer=[IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open())
 try {$writer.Write(($m | ConvertTo-Json -Compress))} finally {$writer.Dispose()}
}
Reject {Restore-ChatWardenBackup $data $unknown $true} 'future backup envelope rejected'

$oversized=Mutant 'oversized-manifest.zip' {
 param($zip)
 $zip.GetEntry('manifest.json').Delete()
 $writer=[IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open())
 try {$writer.Write(('x'*16385))} finally {$writer.Dispose()}
}
Reject {Restore-ChatWardenBackup $data $oversized $true} 'oversized manifest rejected before copying'
$duplicate=Mutant 'duplicate-entry.zip' {
 param($zip)
 $zip.GetEntry('manifest.json').Delete();[void]$zip.CreateEntry('OlympusChatWarden.lua')
}
Reject {Restore-ChatWardenBackup $data $duplicate $true} 'duplicate data entries without manifest rejected'
$truncated=Join-Path $archives 'truncated.zip';$zipBytes=[IO.File]::ReadAllBytes($archive)
[IO.File]::WriteAllBytes($truncated,[byte[]]$zipBytes[0..99])
Reject {Restore-ChatWardenBackup $data $truncated $true} 'truncated ZIP rejected before replacement'
Check ((Get-DataHash $data) -eq $before) 'all malformed envelope cases keep the original file'
[IO.File]::WriteAllBytes($newData,[byte[]]@())
Reject {New-ChatWardenBackup $newData (Join-Path $archives 'empty.zip') $true} 'empty current file cannot become a misleading complete backup'
$recover=Restore-ChatWardenBackup $newData $archive $true
Check ((Get-DataHash $newData) -eq $expected -and (Read-Backup $recover.SafetyCopy).Bytes -eq 0) 'valid restore can recover an empty current file while preserving the empty prior state'
Reject {Restore-ChatWardenBackup $newData $recover.SafetyCopy $true} 'an empty safety copy cannot replace a valid restored history'
$script:RaceCalls=0
function Get-ChatWardenGameProcesses { $script:RaceCalls++;if ($script:RaceCalls -ge 3) {@('simulated Wow.exe')}}
Reject {Restore-ChatWardenBackup $data $archive $true} 'game appearing before commit blocks replacement'
Check ((Get-DataHash $data) -eq $before) 'mid-restore game start leaves original file unchanged'
Check (@(Get-ChildItem -LiteralPath $dataDir -Filter '.chatwarden-restore-*' -File).Count -eq 0) 'blocked restore removes its exact staging file'
$script:RaceCalls=0
function Get-ChatWardenGameProcesses { $script:RaceCalls++;if ($script:RaceCalls -eq 3) {[IO.File]::WriteAllText($data,'simulated concurrent edit')}}
Reject {Restore-ChatWardenBackup $data $archive $true} 'concurrent saved-file change blocks replacement'
Check ([IO.File]::ReadAllText($data) -eq 'simulated concurrent edit') 'concurrent new contents are not overwritten'
function Get-ChatWardenGameProcesses {if ($script:SimulatedWoW) {@('simulated Wow.exe')}}
$spaceCheck=(Get-Command Assert-FreeSpace).ScriptBlock
function Assert-FreeSpace {param([string]$Path,[long]$Required) throw 'simulated insufficient space'}
try {Reject {New-ChatWardenBackup $data (Join-Path $archives 'no-space.zip') $true} 'space guard rejects before archive creation'} finally {Set-Item -LiteralPath Function:\Assert-FreeSpace -Value $spaceCheck}
Check (-not [IO.File]::Exists((Join-Path $archives 'no-space.zip'))) 'insufficient space creates no partial backup'

# Deep user folders must work with Windows PowerShell's older .NET runtime too.
$longRoot=$testRoot
for ($i=0;$i -lt 4;$i++) {$longRoot=Join-Path $longRoot ('deep-folder-'+('x'*52))}
$longDir=Join-Path $longRoot 'Game/WTF/Account/LongAccount/SavedVariables'
$longBackups=Join-Path $longRoot 'Backups'
[void][IO.Directory]::CreateDirectory((IO-Path $longDir));[void][IO.Directory]::CreateDirectory((IO-Path $longBackups))
$longData=Join-Path $longDir 'OlympusChatWarden.lua';$longArchive=Join-Path $longBackups 'long-path.zip'
Check ($longData.Length -gt 400) 'explicit fixture exceeds legacy MAX_PATH'
[IO.File]::WriteAllBytes((IO-Path $longData),$original)
$longSaved=New-ChatWardenBackup $longData $longArchive $true
Check ($longSaved.Sha256 -eq $expected) 'deep-path backup retains exact data'
[IO.File]::WriteAllText((IO-Path $longData),'deep-path replacement state')
$longPrior=Get-DataHash $longData
$longRestored=Restore-ChatWardenBackup $longData $longArchive $true
Check ([Collections.StructuralComparisons]::StructuralEqualityComparer.Equals($original,[IO.File]::ReadAllBytes((IO-Path $longData)))) 'deep-path atomic restore preserves all UTF8 bytes'
Check ((Read-Backup $longRestored.SafetyCopy).Sha256 -eq $longPrior) 'deep-path restore safety copy preserves previous file'
Check ((Resolve-SavedFile (IO-Path $longData)) -eq (Normal-Path $longData)) 'extended input normalizes to the same validated display path'
Reject {Resolve-Archive (Join-Path $longDir 'unsafe.zip') (IO-Path $longData) $true} 'extended path cannot bypass inside-game backup guard'
Check (@([IO.Directory]::EnumerateFiles((IO-Path $longDir),'.chatwarden-restore-*')).Count -eq 0) 'deep-path restore leaves no staging files'
# A backup is copied as opaque data, never evaluated by the tool.
[IO.File]::WriteAllText($newData,'throw "This text must never be executed by the backup utility"')
$opaque=New-ChatWardenBackup $newData (Join-Path $archives 'opaque.zip') $true
Check ([IO.File]::Exists($opaque.Archive)) 'saved file contents never execute during backup'
$locked=[IO.File]::Open($data,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
try {Reject {New-ChatWardenBackup $data (Join-Path $archives 'locked.zip') $true} 'locked saved file rejected safely'} finally {$locked.Dispose()}
Check (-not [IO.File]::Exists((Join-Path $archives 'locked.zip'))) 'failed backup leaves no misleading archive'
# Native WinForms controls can be built/rendered without opening a desktop window.
$form=Show-BackupWindow -BuildOnly
try {
 Check ($form.ClientSize.Width -eq 650 -and $form.ClientSize.Height -eq 485) 'native backup window dimensions'
 Check (@($form.Controls | Where-Object {$_ -is [Windows.Forms.Button]}).Count -eq 3) 'native GUI has choose, backup and restore buttons'
 Check (@($form.Controls | Where-Object {$_ -is [Windows.Forms.CheckBox]}).Count -eq 1) 'GUI has explicit game-closed confirmation'
 $bitmap=[Drawing.Bitmap]::new($form.Width,$form.Height)
 try {
  $form.DrawToBitmap($bitmap,[Drawing.Rectangle]::new(0,0,$form.Width,$form.Height))
  foreach ($control in $form.Controls) {
   Check ($control.Right -le $form.ClientSize.Width -and $control.Bottom -le $form.ClientSize.Height) 'control fits native backup window'
   $control.DrawToBitmap($bitmap,[Drawing.Rectangle]::new($control.Left+8,$control.Top+31,$control.Width,$control.Height))
  }
  $bitmap.Save((Join-Path $PSScriptRoot 'backup-tool-preview.png'),[Drawing.Imaging.ImageFormat]::Png)
 } finally {$bitmap.Dispose()}
} finally {$form.Dispose()}
$summary=[ordered]@{version='1.0.3';assertions=$script:Checks;failed=0;powershell=$PSVersionTable.PSVersion.ToString();fixtureBytes=$original.Length;largeFileHash=$expected;longPathChars=$longData.Length;nativeWinFormsBuilt=$true;personalFilesRead=$false;gameLaunched=$false}
$summary | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot ('backup-tool-summary-'+$PSVersionTable.PSVersion.Major+'.json')) -Encoding UTF8
$summary | ConvertTo-Json
