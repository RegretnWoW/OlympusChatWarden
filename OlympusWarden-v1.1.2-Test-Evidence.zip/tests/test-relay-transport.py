from pathlib import Path
import sys,json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime
checks=0
def check(v,label):
 global checks
 if not v and 'a' in globals():
  for tag,instance in [('sender',globals()['a']),('receiver',globals().get('b'))]:
   if instance:
    print(tag,[(r.id,r.state,r.status) for r in instance.globals().ns.RelayStore.db.reports.values()])
    print(tag,'sent',[(x.target,x.wire[:95]) for x in instance.globals().sent.values()])
 assert v,label
 checks+=1
def peer(name,realm='Classic Beta PvP'):
 l=LuaRuntime(unpack_returned_tuples=True)
 l.execute(r'''
 ns={VERSION='1.1.1-preview6'};clock=100;epoch=1800000000;sent={};timers={};frames={}
 function GetTime() return clock end;function GetServerTime() return epoch+math.floor(clock) end
 function IsLoggedIn() return true end
 function UnitName() return characterName end;function GetRealmName() return characterRealm end
 function UnitGUID() return 'Player-Test-001' end
 function ns.CanRead(v) return type(v)=='string' end
 function ns.Readable(v) return true end
 function ns.Checked(v) return v==true or v==1 end
 function ns.SafeCall(fn,...) if type(fn)=='function' then local ok,v=pcall(fn,...);if ok then return v end end end
 ns.Engine={Lower=string.lower}
 ns.Membership={Allowed=function() return access~=false end}
 function CreateFrame() local f={events={},scripts={}};function f:RegisterEvent(e) self.events[e]=true end
 function f:SetScript(e,fn) self.scripts[e]=fn end;frames[#frames+1]=f;return f end
 C_ChatInfo={RegisterAddonMessagePrefix=function() return true end,SendAddonMessage=function(prefix,wire,channel,target)
 sent[#sent+1]={prefix=prefix,wire=wire,channel=channel,target=target,at=clock};return 0 end}
 function errorsOriginal(e) lastOriginalError=e end
 errHandler=errorsOriginal;function geterrorhandler() return errHandler end;function seterrorhandler(h) errHandler=h end
 ''')
 l.globals().characterName=name;l.globals().characterRealm=realm
 for file in ['Shield.lua','RelayStore.lua','RelayDiagnostics.lua','RelayTransport.lua']:
  l.execute('return assert(loadstring(...))', (root/'OlympusChatWarden'/file).read_text())('OlympusChatWarden',l.globals().ns)
 l.execute('ns.RelayStore.Initialize();ns.RelayDiagnostics.Initialize();ns.RelayTransport.Initialize()')
 return l
def send_report(l,title='A display problem',diag=''):
 l.globals().testTitle=title
 l.execute("r=ns.RelayStore.New();assert(ns.RelayStore.Save(r.id,{module='relay',category='bug',title=testTitle,description='Description with |H harmless markup and a newline.\\nNext line.',steps='Open Warden.'}))")
 rid=l.globals().r.id
 result=l.globals().ns.RelayStore.Submit(rid,diag)
 check(result is True,'explicit submission accepted')
 return rid
def drive(sender,receiver,seconds=90,drop=None,alias=None,schedule=False,split_sender=False):
 pos={id(sender):int(sender.globals().deliveredPosition or 0),id(receiver):int(receiver.globals().deliveredPosition or 0)};delivered=[]
 for tick in range(round(seconds/.4)):
  for p in [sender,receiver]:
   p.globals().clock+=.4;p.globals().ns.RelayTransport.Pump()
   if schedule:
    for f in list(p.globals().frames.values()):
     if f.scripts.OnUpdate:f.scripts.OnUpdate(f,.4)
  for p,other in [(sender,receiver),(receiver,sender)]:
   messages=p.globals().sent
   for index in range(pos[id(p)]+1,len(messages)+1):
    m=messages[index];delivered.append(m.wire)
    if drop and drop(p,m):continue
    if p.globals().ns.RelayTransport.Identity(m.target,'Classic Beta PvP') != other.globals().ns.RelayTransport.Identity(other.globals().characterName,'Classic Beta PvP'):continue
    origin=(p.globals().characterName.replace(' ','-') if split_sender else p.globals().characterName)+'-ClassicBetaPvP'
    other.globals().ns.RelayTransport.Handle(m.prefix,m.wire,m.channel,origin)
   pos[id(p)]=len(messages);p.globals().deliveredPosition=len(messages)
 return delivered
start=time.perf_counter()
# Native Forever first/surname returns, including hyphen-separated chat senders.
for name in ['Rune Escape','Olympus Wardn']:
 a=peer('Example Reporter');b=peer(name)
 for l in [a,b]:
  l.execute("function UnitName() return characterName:match('^(%S+) (.+)$') end;UnitFullName=UnitName")
 check(b.globals().ns.RelayTransport.IsDeveloper(),'split native full name grants receiver role: '+name)
 check(b.globals().ns.RelayTransport.LocalIdentity()==name.lower()+'-classicbetapvp','native surname is retained in receiver identity')
 rid=send_report(a);drive(a,b,split_sender=True)
 check(a.globals().ns.RelayStore.Find(rid).state=='received' and len(b.globals().ns.RelayStore.db.inbox)==1,'full transfer and receipt support Forever split names')
 b.globals().characterRealm='Other Realm'
 check(not b.globals().ns.RelayTransport.IsDeveloper(),'matching split character on a different realm remains unauthorized')
# A developer's self-test still traverses actual messaging and requires a receipt.
l=peer('Rune Escape');l.execute("function UnitName() return 'Rune','Escape' end;UnitFullName=UnitName")
r=l.globals().ns.RelayStore.New();l.globals().r=r
l.execute("r.selfTestReceiver=ns.RelayTransport.LocalIdentity();ns.RelayStore.Save(r.id,{module='relay',category='delivery',title='Self-test',description='Explicit native loopback test',steps=''})")
check(l.globals().ns.RelayStore.Submit(r.id,'') is True,'developer self-test requires explicit submission')
drive(l,l,seconds=20,split_sender=True)
check(r.state=='received' and len(l.globals().ns.RelayStore.db.inbox)==1,'native loopback fixture reaches the real receiver and final receipt')
l=peer('Other Player');r=l.globals().ns.RelayStore.New();l.globals().r=r
l.execute("r.selfTestReceiver='rune escape-classicbetapvp';ns.RelayStore.Save(r.id,{module='relay',category='delivery',title='Unauthorized',description='Not a developer',steps=''})")
check(l.globals().ns.RelayStore.Submit(r.id,'')[0] is False,'local self-test flag cannot authorize another character')
# Automatic delivery retries only explicitly submitted reports, with backoff.
a=peer('Reporter');b=peer('Offline Receiver');rid=send_report(a);drive(a,b,seconds=125,schedule=True)
r=a.globals().ns.RelayStore.Find(rid)
check(r.attempts==2 and r.state=='pending' and r.nextAttempt>a.globals().ns.RelayStore.Now(),'offline automatic delivery retries once then waits five minutes')
check(a.globals().ns.RelayTransport.SetAutomatic(rid,False) is True,'pending automatic delivery can be paused')
before=len(a.globals().sent);drive(a,b,seconds=400,schedule=True)
check(len(a.globals().sent)==before,'pausing removes automatic traffic')
b=peer('Rune Escape');check(a.globals().ns.RelayTransport.SetAutomatic(rid,True) is True,'user can resume automatic delivery')
a.execute('ns.RelayStore.db=nil;ns.RelayStore.Initialize();ns.RelayTransport.Initialize()')
drive(a,b,seconds=90,schedule=True)
r=a.globals().ns.RelayStore.Find(rid)
check(r.state=='received' and len(b.globals().ns.RelayStore.db.inbox)==1,'queued report resumes after reload and delivers when receiver becomes available')
before=len(a.globals().sent);drive(a,b,seconds=1900,schedule=True)
check(len(a.globals().sent)==before and not r.autoRetry,'receipt stops all future automatic delivery')
check([a.globals().ns.RelayTransport.RetryDelay(n) for n in [1,2,3,4,100000]]==[60,300,900,1800,1800],'retry backoff is bounded at thirty minutes')
l=peer('Reporter');l.execute("r=ns.RelayStore.New();ns.RelayStore.Save(r.id,{module='relay',category='bug',title='Old pending',description='Old manual submission',steps=''});r.wire=ns.RelayStore.Encode(ns.RelayStore.Payload(r,''));r.checksum=ns.RelayStore.Checksum(r.wire);r.state='pending';ns.RelayStore.db=nil;ns.RelayStore.Initialize();ns.RelayTransport.Initialize()")
drive(l,peer('Rune Escape'),seconds=2000,schedule=True)
check(len(l.globals().sent)==0,'older manual-only reports are preserved without silently enabling retransmission')
a=peer('Reporter');b=peer('Olympus Wardn')
modern=peer('Reporter')
modern.execute('Enum={RegisterAddonMessagePrefixResult={Success=0},SendAddonMessageResult={Success=0}};C_ChatInfo.RegisterAddonMessagePrefix=function() return 0 end;C_ChatInfo.IsAddonMessagePrefixRegistered=function() return true end;ns.RelayTransport.registered=nil;ns.RelayTransport.Initialize()')
check(modern.globals().ns.RelayTransport.registered is True,'native enum prefix registration is supported alongside legacy boolean returns')
modern.execute('C_ChatInfo.IsAddonMessagePrefixRegistered=function() return false end;ns.RelayTransport.registered=nil;ns.RelayTransport.Initialize()')
check(not modern.globals().ns.RelayTransport.registered,'failed native registration does not enable transport')
check(len(a.globals().sent)==0,'no startup traffic or presence polling')
rid=send_report(a)
drive(a,b)
check(a.globals().ns.RelayStore.Find(rid).state=='received','receipt follows full transfer')
check(len(b.globals().ns.RelayStore.db.inbox)==1,'receiver inbox has one report')
entry=b.globals().ns.RelayStore.db.inbox[1]
check(entry.sender=='reporter-classicbetapvp','native sender identity normalized by realm only')
check(b.globals().ns.RelayStore.Decode(entry.wire).description.endswith('Next line.'),'wire framing preserves content without execution')
check(all(m.channel=='WHISPER' and len(m.wire.encode())<=240 for l in [a,b] for m in l.globals().sent.values()),'all traffic stays bounded and private whisper')
for l in [a,b]:
 times=[m.at for m in l.globals().sent.values()]
 check(all(y-x>=.349 for x,y in zip(times,times[1:])),'sender and receiver share bounded pacing without burst catch-up')
check(a.globals().ns.RelayTransport.Busy() is False,'idle transfer finishes')
check(all(f.scripts.OnUpdate is None for i,f in a.globals().frames.items() if i>1),'idle transport and retry scheduler remove their update callbacks')
# Timeout, failover and no automatic later retry.
a=peer('Reporter');b=peer('Rune Escape');rid=send_report(a);drive(a,b)
check(a.globals().ns.RelayStore.Find(rid).state=='received','secondary developer character receives after first handshake timeout')
a=peer('Reporter');b=peer('Offline Receiver');rid=send_report(a);drive(a,b)
check(a.globals().ns.RelayStore.Find(rid).state=='pending','offline characters leave an honest pending report')
before=len(a.globals().sent);drive(a,b,seconds=180)
check(len(a.globals().sent)==before,'automatic work is driven by the bounded scheduler, never by the wire pump while idle')
# A lost final ACK is not delivery proof; an explicit retry deduplicates.
a=peer('Reporter');b=peer('Olympus Wardn');rid=send_report(a)
drive(a,b,drop=lambda p,m:p is b and m.wire.startswith('A|'))
check(a.globals().ns.RelayStore.Find(rid).state=='pending' and len(b.globals().ns.RelayStore.db.inbox)==1,'lost receipt leaves sender pending despite receiver copy')
check(a.globals().ns.RelayTransport.Try(rid) is True,'manual retry restarts a pending report')
drive(a,b)
check(a.globals().ns.RelayStore.Find(rid).state=='received' and len(b.globals().ns.RelayStore.db.inbox)==1,'retry acknowledges existing identical report without duplicate inbox item')
# Spoofed peer, wrong channel, old protocol, partial and corrupt messages.
a=peer('Reporter');b=peer('Olympus Wardn');rid=send_report(a);a.globals().ns.RelayTransport.Pump();r=a.globals().ns.RelayStore.Find(rid)
for sender,channel in [('Impostor-ClassicBetaPvP','WHISPER'),('Olympus Wardn-OtherRealm','WHISPER'),('Olympus Wardn-ClassicBetaPvP','GUILD')]:
 a.globals().ns.RelayTransport.Handle('OWRelay1','A|1|'+rid+'|'+r.checksum,channel,sender)
check(r.state=='sending','forged identity, realm and broadcast receipts cannot mark success')
before=len(b.globals().ns.RelayStore.db.inbox)
for msg in ['H|2|valid-id|1|10|00000000','H|1|valid-id|9999|999999|00000000','D|1|valid-id|999999|01','F|1|valid-id|00000000','EXEC|1|valid-id|print(1)']:
 b.globals().ns.RelayTransport.Handle('OWRelay1',msg,'WHISPER','Attacker-ClassicBetaPvP')
check(len(b.globals().ns.RelayStore.db.inbox)==before,'unsupported, oversized, incomplete and command messages save nothing')
a=peer('Reporter');b=peer('Olympus Wardn');rid=send_report(a)
def corrupt(p,m):
 if p is a and m.wire.startswith('D|'):
  b.globals().ns.RelayTransport.Handle(m.prefix,m.wire[:-2]+'00',m.channel,'Reporter-ClassicBetaPvP');return True
 return False
drive(a,b,drop=corrupt)
check(len(b.globals().ns.RelayStore.db.inbox)==0 and a.globals().ns.RelayStore.Find(rid).state!='received','corruption never produces receipt or inbox record')
# Safe storage, actual receiver role, optional diagnostics and handler chaining.
l=peer('Reporter');s=l.globals().ns.RelayStore;d=l.globals().ns.RelayDiagnostics
l.execute("OlympusWardenRelayDB.developer=true;ns.DB={privateNotes='PRIVATE_NOTE',chatHistory='PRIVATE_CHAT'};ns.ChronicleStore={db={characters={private='SECRET_HISTORY'}},loading={}}")
check(not l.globals().ns.RelayTransport.IsDeveloper(),'saved developer toggle has no authority')
l.execute("geterrorhandler()('Interface/AddOns/OlympusChatWarden/RelayUI.lua:123: PRIVATE_NOTE PRIVATE_CHAT')")
snapshot=d.Prepare()
check('RelayUI.lua:123' in snapshot and 'PRIVATE_' not in snapshot and 'SECRET_HISTORY' not in snapshot,'error snapshots keep file/line and exclude actual error text/private data')
check(l.globals().lastOriginalError.endswith('PRIVATE_CHAT'),'existing native error handler still receives its original input')
check(not d.Valid('history=private'),'unprepared attachments are rejected')
check(s.Decode('R1'+'99999:x') is None and s.Decode('return print(1)') is None,'safe parser rejects oversized lengths and executable input')
r=s.New();l.globals().temp=r
l.execute("temp.fields.title='Title';temp.fields.description='Body'")
check(s.Submit(r.id,'private secret')[0] is False,'attachment cannot bypass explicit diagnostic preparation')
check(s.Submit(r.id,snapshot) is True,'prepared exact diagnostic snapshot allowed')
l.execute('saved=OlympusWardenRelayDB;ns.RelayStore.db=nil;ns.RelayStore.Initialize()')
check(l.globals().ns.RelayStore.Find(r.id).state=='pending','interrupted sending state survives reinitialization as pending')
l.execute('OlympusWardenRelayDB.schema=999;ns.RelayStore.db=nil;ns.RelayStore.Initialize()')
check(l.globals().ns.RelayStore.blocked is not None and l.globals().OlympusWardenRelayDB.schema==999,'unsupported Relay schema is preserved and blocked instead of reset')
result={'suite':'Relay transport, storage and privacy','assertions':checks,'failed':0,'seconds':time.perf_counter()-start,'nativeForever':False}
(out/'relay-transport-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
