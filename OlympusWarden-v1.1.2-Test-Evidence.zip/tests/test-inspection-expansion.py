from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-manual-inspect.py')};exec(compile((out/'test-manual-inspect.py').read_text(encoding='utf-8'),'native-inspection-prerequisite','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local I,X,G=ns.ChronicleEncounters,ns.ChronicleCapture,ns.WardenDossier
InspectFrame:Hide();units.target=nil;units.party1=nil;freshRecording();clock=clock+60
local guid='Player-Talents-ONE';units.target={guid=guid,name='Talent Friend',class='MAGE',level=60}
local valid,export,spec=true,'NativeInspectExport_A',62;local exportCalls=0
C_Traits={HasValidInspectData=function() return valid end,GenerateInspectImportString=function(unit) exportCalls=exportCalls+1;assert(UnitGUID(unit)==guid);return export end}
C_SpecializationInfo={GetInspectSpecialization=function(unit) assert(UnitGUID(unit)==guid);return spec end}
local function inspect() InspectFrame_Show('target');ev('INSPECT_READY',guid);return all('important_player')[#all('important_player')] end
local e=inspect();local object=X.Find(C.Owner(),e.details.traitRef)
check(object.capture.values.guid==guid and object.capture.values.exportString==export and object.capture.values.specializationID==62,'manual inspection saves native export and specialization to the exact GUID')
check(e.details.traitObservedAt==e.at and object.source=='INSPECT_READY','talents preserve observation time and native source')
local h=e.details.traitRef;clock=clock+60;local same=inspect()
check(same.details.traitRef==h and same.details.traitObservedAt>e.details.traitObservedAt,'unchanged builds share content with later dated observations')
clock=clock+60;I.Important('target','control','personal bookmark');inspect();InspectFrame:Hide();clock=clock+10
local notify=NotifyInspect;local notifications=0;NotifyInspect=function(...) notifications=notifications+1;return notify(...) end
I.InspectPump();check(notifications==0,'completed manual inspection removes an already queued duplicate automatic request');NotifyInspect=notify
export='NativeInspectExport_B';clock=clock+60;local newer=inspect()
check(newer.details.traitRef~=h,'changed talents retain a separate content object')
local j=G.Request(C.Owner());while not j.done do local n=j.cursor;G.Pump(j,2);check(j.cursor-n<=2,'shared gear and talent index uses a bounded cooperative walk') end
local rows=G.Rows(j,guid,'traits')
check(#rows==2 and rows[1].hash==newer.details.traitRef and rows[2].hash==h,'historical native talent exports are browseable in order')
local p=G.BuildTalents(UIParent);p:Show();p:SetProfile(C.Owner(),{id=guid,title='Talent Friend'});p.scripts.OnUpdate(p)
check(p.export:GetText()=='NativeInspectExport_B' and p.status:GetText():find('Historical inspection',1,true),'Talents page shows saved native export and historical status')
click(p.previous);check(p.export:GetText()=='NativeInspectExport_A','older talent export retained')
local original=ns.RecordingUI.OpenSource;local opened
ns.RecordingUI.OpenSource=function(_,event) opened=event end;click(p.source)
check(opened==p.rows[p.index].event,'talent source points to its original exact evidence')
ns.RecordingUI.OpenSource=original
p.export:SetText('typed replacement');p.export.scripts.OnTextChanged(p.export,true)
check(p.export:GetText()=='NativeInspectExport_A' and object.capture.values.exportString=='NativeInspectExport_A','copy field cannot mutate saved or displayed historical export')
-- Spec-only responses are partial; no local-player talent fallback is queried.
export=nil;spec=63;clock=clock+60;e=inspect();object=X.Find(C.Owner(),e.details.traitRef)
check(object.capture.values.specializationID==63 and not object.capture.values.exportString,'specialization can be saved while talent export is unavailable')
j=G.Request(C.Owner());while not j.done do G.Pump(j) end
p.index=1;p:SetProfile(C.Owner(),{id=guid,title='Talent Friend'});p.scripts.OnUpdate(p)
check(p.detail:GetText():find('Partial inspection',1,true) and not p.select.enabled,'partial specialization does not become a complete build or copyable export')
valid=false;spec=0;local calls=exportCalls;clock=clock+60;e=inspect()
check(not e.details.traitRef and exportCalls==calls,'invalid shared trait cache and unknown specialization remain unknown')
check(not e.details.lifetimeHK and not e.details.honor,'targetless honor cache is not attached to an inspected player')
local rep=C_Reputation;local repCalls=0;C_Reputation={GetFactionDataByID=function() repCalls=repCalls+1;return {currentStanding=100,reaction=5} end}
clock=clock+60;inspect();check(repCalls==0,'other-player inspection never reads the recorder’s reputation');C_Reputation=rep
-- Eligible automatic inspections use the same talent path and do not need an open dossier.
InspectFrame:Hide();units.party1=units.target;units.target=nil;valid=true;export='AutomaticNativeExport';spec=64
clock=clock+I.AUTO_BACKOFF+10;I.Important('party1','control','party teammate');clock=clock+10;I.InspectPump();I.InspectReady(guid)
e=all('important_player')[#all('important_player')];object=X.Find(C.Owner(),e.details.traitRef)
check(e.details.relationship=='party teammate' and object.capture.values.exportString==export,'existing eligible automatic inspection captures the same native talent fields')
-- Competing cache owners and unit changes abort before the export is committed.
units.target=units.party1;units.party1=nil;local count=#all('important_player');clock=clock+60
InspectFrame_Show('target');NotifyInspect('mouseover');I.InspectReady(guid)
check(#all('important_player')==count,'competing request rejects inspected talents and observation together')
clock=clock+60;C_Traits.GenerateInspectImportString=function() units.target.guid='Player-Talents-OTHER';return 'WrongOwnerExport' end
InspectFrame_Show('target');I.InspectReady(guid);check(#all('important_player')==count,'identity changes during export reject the observation')
units.target.guid=guid;clock=clock+60;InspectFrame_Show('target');clock=clock+9;I.InspectReady(guid)
check(#all('important_player')==count,'late response is rejected even if the per-frame timeout pump has not run')
-- Snapshot validators and normal backup retain the optional specialization extension.
check(not X.Validate({format=1,family='traits',values={guid=guid,specializationID=0}}),'unknown specialization is not encoded as a confirmed spec')
local B=ns.ChronicleBackup;C.SetEnabled(false);local backup=assert(B.Create());for _,part in ipairs(backup.parts) do check(B.Validate(part)~=nil,'normal backup validates inspected talent and specialization evidence') end
C.Clear();for n=#backup.parts,1,-1 do check(B.Restore(backup.parts[n])==true,'normal restore accepts talent and specialization extension') end
local restored=X.Find(C.Owner(),h);check(restored and restored.capture.values.exportString=='NativeInspectExport_A' and restored.capture.values.specializationID==62,'restore preserves original native export, specialization and content hash')
C.SetEnabled(false);local prior=S.db.consentVersion;local n=#all('important_player');InspectFrame_Show('target');I.InspectReady('Player-Talents-OTHER')
check(#all('important_player')==n and S.db.consentVersion==prior and not C.Active(),'inspection does not enable or expand recording consent')
check(S.VERSION==6 and S.CONSENT==5,'existing talent/inspection consent scope retained; no unverified PvP/reputation scope added')
expansionChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().expansionChecks,'failed':0,'manualAndAutomatic':True,'pvpInspection':'deferred: targetless freshness/identity not verified','otherPlayerReputation':'no supported API found','liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'inspection-expansion-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
