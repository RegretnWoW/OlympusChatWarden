from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime
compile_lua=LuaRuntime().eval('function(s,n) assert(loadstring(s,n)) end')
modules=[n for n in (root/'OlympusChatWarden/OlympusChatWarden.toc').read_text().splitlines() if n.endswith('.lua')]
for n in modules:compile_lua((root/'OlympusChatWarden'/n).read_text(encoding='utf-8'),n)
print('Compiled',len(modules),'Lua 5.1 modules',flush=True)
scope={'__file__':str(out/'test-chronicle.py')}
code=(Path(__file__).resolve().parent/'test-chronicle.py').read_text(encoding='utf-8').split("summary={'version'")[0]
exec(compile(code,'unchanged-chronicle-regression','exec'),scope)
lua=scope['lua']
lua.execute('local m=getmetatable(UIParent).__index;function m:SetHighlightTexture() end')
lua.execute('''
ns.Workspace.Open('intel');ns.Workspace.pages.intel:Refresh(true)
ns.Workspace.Open('chronicle');ns.Workspace.pages.chronicle:Refresh(true)
ns.Workspace.Open('overview');ns.Workspace.pages.overview:Refresh(true)
ns.Workspace.Open('messages');ns.Workspace.Open('capture');ns.Workspace.Open('rules');ns.Workspace.Open('packs');ns.Workspace.Open('reports');ns.Workspace.Open('mentions');drain()
''')
print('Startup, Chronicle regression and all section smoke checks passed',lua.globals().checks)
