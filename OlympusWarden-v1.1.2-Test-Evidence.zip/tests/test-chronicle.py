from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
host={'__file__':str(Path(__file__).resolve().parent/'test-integration.py')}
exec(compile((Path(__file__).resolve().parent/'test-integration.py').read_text().split('count=0')[0],'trusted-native-host','exec'),host)
lua=host['fresh']('modern',True)
lua.execute(r'''
S=ns.ChronicleStore;C=ns.Chronicle
epoch=1800000000;clock=100
function date(fmt,at) return os.date(fmt,at) end
function GetServerTime() return epoch+math.floor(clock) end
function GetRealmName() return 'Test Realm' end
function IsLoggedIn() return true end
units={player={guid='Player-Home-01',name='Rune Escape',level=30,class='MAGE',race='Human',faction='Alliance',guild='Olympus Reloaded'}}
function UnitGUID(unit) return units[unit] and units[unit].guid end
function UnitIsPlayer(unit) return units[unit]~=nil end
function UnitIsVisible(unit) return units[unit]~=nil end
function UnitFullName(unit) return units[unit] and units[unit].name,units[unit] and units[unit].realm end
function UnitName(unit) return UnitFullName(unit) end
function UnitLevel(unit) return units[unit] and units[unit].level or -1 end
function UnitClass(unit) return '',units[unit] and units[unit].class end
function UnitRace(unit) return '',units[unit] and units[unit].race end
function UnitFactionGroup(unit) return units[unit] and units[unit].faction end
function GetGuildInfo(unit) return units[unit] and units[unit].guild end
xp=500;xpmax=1000;money=10000;zone='Elwynn Forest';subzone='Goldshire';inside=false;instanceID=0
function UnitXP() return xp end;function UnitXPMax() return xpmax end
function GetMoney() return money end
function GetRealZoneText() return zone end;function GetSubZoneText() return subzone end
function IsInInstance() return inside,inside and 'party' or 'none' end
function GetInstanceInfo() return 'The Deadmines','party',1,'Normal',5,nil,nil,instanceID end
function UnitIsAFK() return false end
skills={{'Alchemy',false,false,30,0,0,75}}
function GetNumSkillLines() return #skills end
function GetSkillLineInfo(i) return unpack(skills[i]) end
groupCount=0;function GetNumGroupMembers() return groupCount end;function IsInRaid() return false end
function ev(event,...) for _,f in ipairs(frames) do if f.events and f.events[event] and f.scripts.OnEvent then f.scripts.OnEvent(f,event,...) end end;drain() end
function step(n) clock=clock+n;for _,f in ipairs(frames) do if f.scripts.OnUpdate then f.scripts.OnUpdate(f,n) end end;drain() end
function ledger() return S.Character(C.Owner(),false) end
function all(kind) local list={};for _,e in ipairs(ledger() and ledger().events or {}) do if e.kind==kind then list[#list+1]=e end end;return list end
function freshRecording() C.Clear();check(C.SetEnabled(true),'explicit opt-in works');return ledger() end
check(not S.db.enabled and next(S.db.characters)==nil,'fresh installs record nothing')
ev('PLAYER_ENTERING_WORLD',true,false);ev('PLAYER_TARGET_CHANGED');ev('PLAYER_MONEY');step(30)
check(next(S.db.characters)==nil,'native events and ticks before consent save nothing')
if ns.Workspace.window then ns.Workspace.window:Hide();drain() end
check(ns.RecordingConsentWindow and ns.RecordingConsentWindow:IsShown() and S.db.promptSeen==S.CONSENT,'first eligible login shows a separate recording prompt')
local notNow;for _,f in ipairs(frames) do if f:GetObjectType()=='Button' and f.GetText and f:GetText()=='Not now' then notNow=f end end
check(notNow~=nil,'prompt has an explicit Not now choice')
click(notNow);check(not S.db.enabled and not ns.RecordingConsentWindow:IsShown(),'Not now saves no recording consent')
ev('PLAYER_ENTERING_WORLD',false,true);check(not ns.RecordingConsentWindow:IsShown(),'declined prompt does not nag on reload')
S.db.enabled=true;S.db.consentVersion=nil;C.RefreshGate();ev('PLAYER_ENTERING_WORLD',true,false)
check(not C.Active() and next(S.db.characters)==nil,'enabled boolean cannot bypass versioned consent')
S.db.enabled=false
freshRecording()
check(C.Active() and S.db.consentVersion==S.CONSENT,'recording active only after consent')
check(not ns.ChatCapture.db.enabled,'recording does not enable Capture')
check(#all('skill_observed')==1 and #all('character_snapshot')==1,'initial facts are observed snapshots rather than historical gains')
check(C.Statistics().logins==0,'opting in mid-session does not invent a login')
step(30);check(C.Statistics().seconds==30,'tracked interval comes from monotonic elapsed time')
step(100);check(C.Statistics().seconds==30 and C.diagnostics.gaps>0,'long unobserved gap is excluded')
zone='Westfall';ev('ZONE_CHANGED_NEW_AREA');step(30)
check(C.Statistics().zones.Westfall==30,'zone time is attributed to observer location')
xp=700;ev('PLAYER_XP_UPDATE','player');check(C.Statistics().xp==200,'same-level XP delta measured')
units.player.level=31;xp=100;xpmax=1200;ev('PLAYER_LEVEL_UP',31);ev('PLAYER_XP_UPDATE','player')
check(C.Statistics().xp==600 and #all('level_change')==1,'level boundary XP uses both native snapshots without duplicates')
units.player.level=33;xp=200;ev('PLAYER_LEVEL_UP',33)
check(C.Statistics().xp==600,'unobserved intermediate level thresholds are not guessed')
money=10500;ev('PLAYER_MONEY');money=10200;ev('PLAYER_MONEY')
check(C.Statistics().moneyNet==200 and #all('money_change')==2,'money records net changes without claiming transaction type')
ev('QUEST_COMPLETE');check(C.Statistics().quests==0,'quest reward dialog is not quest completion')
ev('QUEST_TURNED_IN',1234,200,50);ev('QUEST_TURNED_IN',1234,200,50)
check(C.Statistics().quests==1,'identifiable native turn-in deduplicated')
skills[1][4]=31;ev('SKILL_LINES_CHANGED');check(#all('skill_change')==1,'skill change compares observed ranks')
inside=true;instanceID=36;ev('PLAYER_LEAVING_WORLD');ev('PLAYER_ENTERING_WORLD',false,false)
check(#all('instance_enter')==1,'instance entry recognized across loading screen')
inside=false;ev('PLAYER_LEAVING_WORLD');ev('PLAYER_ENTERING_WORLD',false,false)
check(#all('instance_exit')==1,'instance exit does not claim completion')
units.target={guid='Player-Enemy-AA',name='Blood Fang',realm='Other Realm',class='WARRIOR',race='Orc',faction='Horde',level=40,guild='Other Guild'}
units.mouseover=units.target
wantedRows={{guid='Player-Enemy-AA',name='Blood Fang',active=true,current=100,lifetimeKills=3,cycle=2}}
clock=clock+61;C.Handle('PLAYER_ENTERING_WORLD',false,false)
local alerts=#ns.Activity.List('wanted')
ns.Wanted.Set('enabled',false);ns.DB.alertsEnabled=false
ev('PLAYER_TARGET_CHANGED');ev('UPDATE_MOUSEOVER_UNIT');ev('PLAYER_TARGET_CHANGED')
local p=C.Profile('Player-Enemy-AA')
check(p and p.facts.name.value=='Blood Fang' and p.facts.realm.value=='Other Realm','GUID profile preserves full name and actual realm')
check(C.Statistics().encounters==1,'target and mouseover form one encounter')
check(C.Statistics().wantedEncounters==1,'permitted Olympus snapshot enriches observation with alerts off')
check(#ns.Activity.List('wanted')==alerts,'recording never creates Wanted notifications')
check(p.lastSighting.observerLocation.zone==zone,'profile location is explicitly observer context')
p.facts.name.value='tampered';check(C.Profile('Player-Enemy-AA').facts.name.value=='Blood Fang','profile reads return copies')
check(C.SetPersonal('Player-Enemy-AA','My own note',true),'personal notes and watch flags available for observed identities')
check(C.Profile('Player-Enemy-AA').personal.watch,'watch flag is personal metadata')
local listing=all('player_observed')[1]
check(listing.details.wantedBounty==100 and listing.details.wantedCheckedAt==epoch+math.floor(clock),'listing records read time and source snapshot')
units.target={guid='Player-Enemy-BB',name='Blood Fang',level=40};ev('PLAYER_TARGET_CHANGED')
check(C.Statistics().profiles==2,'same full name never merges distinct GUIDs')
units.target={name='No GUID',level=40};ev('PLAYER_TARGET_CHANGED')
check(C.Statistics().profiles==2,'missing GUID creates no persistent identity')
units.target=units.mouseover;clock=clock+121;ev('PLAYER_TARGET_CHANGED')
check(C.Statistics().encounters==3,'absence beyond grouping interval starts a new encounter')
local latest=all('player_observed')[#all('player_observed')]
check(latest.details.wantedListed==nil,'stale Olympus snapshot is unknown, not a negative listing')
-- Roster observations identify players but do not establish local proximity.
units.party1={guid='Player-Friendly-CC',name='Distant Friend',level=20,guild='Olympus Reloaded'};groupCount=2;ev('GROUP_ROSTER_UPDATE')
check(C.Profile('Player-Friendly-CC')~=nil and C.Profile('Player-Friendly-CC').lastSighting==nil,'remote party roster is not a local sighting')
check(all('group_roster')[#all('group_roster')].details.sameGuildMembers==1,'guild composition uses actual guild observations')
local beforeEncounters=C.Statistics().encounters
check(C.registered.COMBAT_LOG_EVENT_UNFILTERED==nil,'restricted combat-log event is never registered')
ev('COMBAT_LOG_EVENT_UNFILTERED',1,'PARTY_KILL',false,'Player-Home-01','Rune Escape',0,0,'Player-Enemy-AA','Blood Fang',0,0)
check(#all('player_combat')==0 and C.Statistics().killCredits==0,'disabled combat collector creates no damage or kill claims')
ev('PLAYER_DEAD');ev('PLAYER_DEAD');check(C.Statistics().deaths==1,'death event counted once until resurrection')
check(all('player_death')[1].details.killer==nil,'self death does not guess killer')
ev('PLAYER_ALIVE');ev('PLAYER_DEAD');check(C.Statistics().deaths==2,'new life permits new death')
local session=ledger().currentSession;local seconds=C.Statistics().seconds
ev('PLAYER_LOGOUT');clock=clock+5000;C.Initialize();ev('PLAYER_ENTERING_WORLD',false,true)
check(ledger().currentSession==session and C.Statistics().seconds==seconds,'UI reload resumes session without counting offline gap')
check(C.Profile('Player-Enemy-AA').personal.note=='My own note','personal metadata survives reload normalization')
ev('PLAYER_LOGOUT');C.Initialize();ev('PLAYER_ENTERING_WORLD',true,false)
check(ledger().currentSession~=session and C.Statistics().logins==1,'native initial login starts a new confirmed session')
local count=#ledger().events;C.SetEnabled(false);ev('PLAYER_MONEY');ev('PLAYER_TARGET_CHANGED');step(30)
check(not C.Active() and #ledger().events>=count and #ledger().events==count+1,'opt-out appends stop marker only and blocks subsequent events')
C.SetEnabled(true);member=false;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();ev('PLAYER_TARGET_CHANGED')
check(not C.Active(),'loss of Olympus membership stops recording')
SlashCmdList.OLYMPUSCHATWARDEN('chronicle off');check(not S.db.enabled,'privacy opt-out works after membership loss')
SlashCmdList.OLYMPUSCHATWARDEN('chronicle clear confirm');check(next(S.db.characters)==nil,'privacy clear works after membership loss')
member=true;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();freshRecording()
local c=ledger();local owner=C.Owner()
check(not S.Append(owner,{kind='time_slice',source='checkpoint',session=c.currentSession,at=epoch+clock,elapsed=clock,timeSource='server',evidence='observed',location={},details={seconds='fake',afk=false}}),'malformed numeric records rejected')
check(not S.Append(owner,{kind='quest_turnin',source='QUEST_TURNED_IN',session=c.currentSession,at=epoch+clock,elapsed=clock,timeSource='server',evidence='inferred',location={},details={questID=1}}),'inferred evidence rejected')
for i=1,3200 do
 S.Append(owner,{kind='location',source='ZONE_CHANGED',session=c.currentSession,at=epoch+i,elapsed=i,timeSource='server',evidence='observed',location={zone='Elwynn Forest'},details={}})
end
for i=1,1200 do S.Observe(owner,'Player-History-'..i,{name='Person '..i},epoch,'PLAYER_TARGET_CHANGED',{}) end
local before=#c.events;local profileCount=C.Statistics().profiles
S.db.retentionDays=7;S.Prune(c,epoch+10*365*86400)
check(#c.events==before and before>3000 and C.Statistics().profiles==profileCount and profileCount>=1200,'old count, age and byte limits never delete history')
C.Initialize();c=ledger()
check(#c.events==before and C.Statistics().profiles==profileCount,'legacy schema normalization preserves all events and profiles beyond old caps')
check(S.db.retention=='forever' and S.db.retentionDays==nil,'old retention setting migrates to indefinite retention')
S.db.characters.bad={events={{kind='time_slice',details={seconds=false}}},profiles={}};C.Initialize()
check(pcall(C.Statistics),'malformed saved data cannot break statistics')
ns.DB.chronicle={schema=99,enabled=true,characters={untouched=true}};C.Initialize()
check(S.blocked and ns.DB.chronicle.schema==99 and ns.DB.chronicle.characters.untouched,'future schema preserved and recording blocked')
ns.DB.chronicle=nil;C.Initialize();check(not S.db.enabled,'fresh schema stays opt-in after reset')
ns.BuildChronicleOptions();ns.OpenChronicleOptions();drain()
check(ns.Workspace.activeSetting=='chronicle' and ns.ChronicleOptionsPanel:IsShown(),'recording setup opens inside themed settings: '..tostring(ns.Workspace.activeSetting)..' / '..ns.Membership.Status())
check(C.Disclosure:find('Player Intelligence',1,true) and C.Disclosure:find('Olympus',1,true) and C.Disclosure:find('does not upload',1,true),'disclosure explains both purposes and external source versus outgoing sharing')
check(C.diagnostics.errors==0,'collectors produced no swallowed runtime errors')
''')
lua.execute(r'''
freshRecording();local owner=C.Owner();local c=ledger()
-- No migration inherits recording consent from old unrelated switches.
C.SetEnabled(false);ns.DB.chronicle.enabled=true;ns.DB.chronicle.consentVersion=0;C.Initialize()
check(not S.db.enabled,'old consent version never auto-enables recording')
freshRecording()
ns.DB.enabled=false;ns.PolicyChanged();ev('PLAYER_TARGET_CHANGED')
check(C.Active(),'filtering pause does not disable independent historical modules')
ns.DB.enabled=true;ns.PolicyChanged();ev('PLAYER_ENTERING_WORLD',false,false)
check(C.Active(),'recorder remains consented across an independent filtering pause')
local at=GetServerTime();local count=#ledger().events
epoch=epoch-10000;ev('PLAYER_MONEY');units.target={guid='Player-Clock-AA',name='Clock Test'};ev('PLAYER_TARGET_CHANGED')
check(#ledger().events==count and not C.Profile('Player-Clock-AA'),'backward wall clock cannot backdate profile observations')
epoch=epoch+10000
local oldGUID=UnitGUID;local reads=0
UnitGUID=function(unit) if unit=='target' then reads=reads+1;return reads==1 and 'Player-Swap-AA' or 'Player-Swap-BB' end;return oldGUID(unit) end
ev('PLAYER_TARGET_CHANGED');check(not C.Profile('Player-Swap-AA') and not C.Profile('Player-Swap-BB'),'recycled unit token cannot join different players facts')
UnitGUID=oldGUID
units.target={guid='Player-Missing-AA',name='Hidden',level=-1}
local oldName=UnitFullName;UnitFullName=function(unit) if unit=='target' then return nil end;return oldName(unit) end
ev('PLAYER_TARGET_CHANGED');check(not C.Profile('Player-Missing-AA'),'unavailable name remains unrecorded instead of placeholder identity')
UnitFullName=oldName;units.target.name='Visible';ev('PLAYER_TARGET_CHANGED')
check(C.Profile('Player-Missing-AA').facts.level==nil,'unknown level remains absent')
local playerFlag=UnitIsPlayer;UnitIsPlayer=function(unit) if unit=='target' then return false end;return playerFlag(unit) end
units.target={guid='Player-NPC-AA',name='Not A Player'};ev('PLAYER_TARGET_CHANGED')
check(not C.Profile('Player-NPC-AA'),'NPC unit never creates player profile')
UnitIsPlayer=playerFlag
local oldRealm=GetRealmName;GetRealmName=function() return nil end;C.SetEnabled(false);C.SetEnabled(true)
check(not C.Active(),'missing recording realm blocks ambiguous character scope')
GetRealmName=oldRealm;ev('PLAYER_ENTERING_WORLD',false,false);check(C.Active(),'late realm availability can start recording safely')
local prior=ledger().currentSession
ev('PLAYER_ENTERING_WORLD',false,false);ev('PLAYER_ENTERING_WORLD',false,false)
check(ledger().currentSession==prior,'ordinary world entries do not create extra sessions')
local prevProfile=C.Profile('Player-Missing-AA')
local originalGuid=units.player.guid;units.player.guid='Player-Other-99';ev('PLAYER_TARGET_CHANGED')
check(not C.Active(),'identity switch ends runtime recording before any foreign facts are saved')
units.player.guid=originalGuid;ev('PLAYER_ENTERING_WORLD',false,true)
check(C.Active() and C.Owner()==owner,'return to prior identity resumes correct realm/GUID history')
-- Getter presence must never be mistaken for permission to read a restricted API.
local calls=0;CombatLogGetCurrentEventInfo=function() calls=calls+1;error('restricted') end
ev('COMBAT_LOG_EVENT_UNFILTERED')
C.Handle('COMBAT_LOG_EVENT_UNFILTERED')
check(calls==0 and #all('player_combat')==0,'restricted combat getter is never called, even when present')
CombatLogGetCurrentEventInfo=nil
local quests=C.Statistics().quests
ev('QUEST_TURNED_IN','1234',200,30);ev('QUEST_TURNED_IN',0,200,30)
check(C.Statistics().quests==quests,'malformed quest IDs are dropped')
-- AFK boundaries use their own native event; no time is classified across them.
local afk=false;UnitIsAFK=function() return afk end
freshRecording();step(10);afk=true;ev('PLAYER_FLAGS_CHANGED','player');step(20)
afk=false;ev('PLAYER_FLAGS_CHANGED','player');check(C.Statistics().seconds==30 and C.Statistics().afkSeconds==20,'AFK boundaries keep measured duration attribution')
local seconds=C.Statistics().seconds;ev('PLAYER_LEAVING_WORLD');step(40);ev('PLAYER_ENTERING_WORLD',false,false)
check(C.Statistics().seconds==seconds,'loading-screen time is excluded')
local xpTotal=C.Statistics().xp;xp=50;xpmax=5000;ev('PLAYER_XP_UPDATE','player')
check(C.Statistics().xp==xpTotal,'XP decreases or changed thresholds are not invented gains')
xp=100;ev('PLAYER_XP_UPDATE','party1');check(C.Statistics().xp==xpTotal,'another unit XP update is ignored')
local nativeMoney=GetMoney;GetMoney=function() return nil end;ev('PLAYER_MONEY');GetMoney=nativeMoney;money=99999;ev('PLAYER_MONEY')
check(#all('money_change')==0,'unavailable money resets baseline instead of bridging unknown gap')
local beforeProfiles=C.Statistics().profiles
wantedRows={{guid='Player-Listing-Only',name='Listed Only',active=true,current=500,lifetimeKills=8,cycle=1}}
clock=clock+61;step(1)
check(C.Statistics().profiles==beforeProfiles,'shared Wanted list alone creates no persistent profile or sighting')
local bad={};bad.self=bad
check(not S.Append(owner,{kind='location',source='ZONE_CHANGED',session=ledger().currentSession,at=GetServerTime(),elapsed=clock,timeSource='server',evidence='observed',location={},details=bad}),'cyclic arbitrary payload rejected')
check(not C.SetPersonal('Player-Unknown-AA','note',true),'annotations cannot invent unseen identity')
units.target={guid='Player-Note-AA',name='Notes Person'};ev('PLAYER_TARGET_CHANGED')
check(not C.SetPersonal('Player-Note-AA',string.rep('x',513),true),'notes have bounded size')
check(not C.SetPersonal('Player-Note-AA','|Hplayer:fake|htext|h',true),'notes cannot inject WoW markup')
check(C.SetPersonal('Player-Note-AA','',false),'personal annotations can be cleared')
for i=1,110 do local x=S.Character('Realm/Player-History-'..i,true);x.updated=i end
local count=0;for _ in pairs(S.db.characters) do count=count+1 end
C.Initialize();local normalized=0;for _ in pairs(S.db.characters) do normalized=normalized+1 end
check(count==111 and normalized==111,'all character histories survive beyond old creation and migration limits')
C.Clear();check(not C.Active() and not S.db.enabled and next(S.db.characters)==nil,'clear stops recording without repopulating store')
ns.BuildChronicleOptions();ns.OpenChronicleOptions();drain()
local panel=ns.ChronicleOptionsPanel;local buttons={};local toggle
for _,f in ipairs(frames) do
 if f:GetObjectType()=='Button' and f.GetText and f:GetText()=='Clear recorded history' then buttons[#buttons+1]=f end
 if f.Caption and f.Caption:GetText()=='Record Chronicle & Player Intelligence' then toggle=f end
end
check(toggle and not toggle:GetChecked(),'visible recording checkbox starts unchecked')
toggle:SetChecked(true);click(toggle);check(S.db.enabled and C.Active(),'visible opt-in control starts recorder after disclosure')
check(#buttons==1,'one clear control in recording panel')
click(buttons[1]);check(S.db.enabled and next(S.db.characters)~=nil,'first clear click asks before deleting history')
click(buttons[1]);check(not S.db.enabled and next(S.db.characters)==nil,'second clear click removes history and stops recording')
check(C.diagnostics.errors==0,'edge cases produce no swallowed collector errors')
''')
summary={'version':'1.0.3','assertions':lua.globals().checks,'failed':0,'liveWoWTested':False}
scene_scope={}
export_source=(Path(__file__).resolve().parent/'test-integration.py').read_text()
export_source=export_source[export_source.index('def export_scene('):export_source.index("(out/'scene-old.json')")]
exec(compile(export_source,'reviewed-scene-export','exec'),scene_scope)
(out/'scene-recording.json').write_text(json.dumps(scene_scope['export_scene'](lua,'workspace'),default=str))
(out/'chronicle-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
