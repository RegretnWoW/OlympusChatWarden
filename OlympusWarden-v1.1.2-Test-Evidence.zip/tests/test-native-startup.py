from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'native-startup-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local X,B=ns.ChronicleCapture,ns.ChronicleBackup
freshRecording();local owner=C.Owner();local c=ledger()
for n=1,1000 do C.Record('quest_turnin','QUEST_TURNED_IN',{questID=10000+n,rewardXP=n},nil,'observed') end
local object={format=1,family='traits',values={guid=UnitGUID('player'),exportString=string.rep('A',2800),specializationID=1491}}
local hash=X.Hash(object)
-- Append native objects using the store's actual event contract, retaining
-- full checksum validation instead of bypassing it in the fixture.
for n=1,24 do S.Append(owner,{kind='native_snapshot',at=C.Stamp(),elapsed=C.Tick(),source='INSPECT_READY',session=c.currentSession,
 timeSource='server',evidence='observed',location={},details={contentID=hash,family='traits'},capture=object}) end
check(#c.events>=1024,'large startup fixture includes real checksum-validated objects')
C.SetEnabled(false);local packed=assert(B.PackSaved(S.db));local encoded=B.Encode(packed);local expected=B.Encode(c.events)
ns.DB.chronicle=packed;C.Initialize(true)
check(S.loading and not S.db and ns.DB.chronicle==packed,'native initialization returns while the private candidate is still loading')
check(C.Status():find('Loading saved history',1,true) and not C.SetEnabled(true),'loading is distinct from recording off; controls cannot mutate pending history')
local frames=0;while S.loading do S.PumpLoad();frames=frames+1;assert(frames<10000) end
check(frames>3 and S.db and not S.blocked and S.loadProgress.checksumBlocks>0,'checksum validation cooperates over many native frame steps')
check(B.Encode(S.Character(owner,false).events)==expected,'asynchronous load preserves every original canonical event')
check(B.Encode(packed)==encoded,'original packed input stays byte-equivalent through loading')
check(not S.db.enabled and not C.Active(),'loading does not consent or start recording')
check(C.SetEnabled(true) and C.Active(),'recording controls work after complete validation')
check(ns.ChronicleDuels.SetEnabled(true),'duel opt-in works after complete validation')
C.SetEnabled(false);packed=assert(B.PackSaved(S.db));packed.enabled=true;ns.DB.chronicle=packed;C.Initialize(true)
C.Handle('PLAYER_ENTERING_WORLD',false,true);while S.loading do S.PumpLoad() end
check(C.Active(),'world entry during loading is remembered and valid previous consent resumes afterwards')
C.SetEnabled(false);packed=assert(B.PackSaved(S.db));local original=B.Encode(packed);ns.DB.chronicle=packed;C.Initialize(true);S.PumpLoad();C.Handle('PLAYER_LOGOUT')
check(not S.loading and S.blocked and ns.DB.chronicle==packed and B.Encode(packed)==original,'logout during loading cancels the candidate and keeps original recovery data')
S.Initialize();local bad=assert(B.PackSaved(S.db));bad.characters[owner].eventChunks[#bad.characters[owner].eventChunks]='damaged'
local originalBad=B.Encode(bad);ns.DB.chronicle=bad;C.Initialize(true);while S.loading do S.PumpLoad() end
check(S.blocked and not S.db and B.Encode(bad)==originalBad,'late corrupt chunk fails closed without committing a partial candidate')
ns.DB.chronicle=packed;local normalize=S.Normalize;S.Normalize=function() error('synthetic startup failure') end
C.Initialize();S.Normalize=normalize
check(S.blocked and C.Status():find('unavailable',1,true),'unexpected validation exception is a blocked state, never recording off')
ns.DB.chronicle=packed;C.Initialize();check(C.SetEnabled(true),'valid input can recover after a failed initialization without reset')
C.SetEnabled(false)
local init=ns.History.Initialize;ns.History.Initialize=function() error('synthetic optional history initializer failure') end
local ok=pcall(ns.Initialize);ns.History.Initialize=init
while S.loading do S.PumpLoad() end
check(ok and ns.Initializing==false and #ns.StartupErrors==1 and S.db,'optional initialization failure cannot strand suite initialization or Chronicle')
-- Native signature requires category first and canvas second. The old fixture
-- accepted both tables, which missed the exact Blizzard_Category failure.
Settings=Settings or {RegisterAddOnCategory=function() end}
local calls=0;local old=Settings.RegisterCanvasLayoutSubcategory
local parent={ID=72,subcategories={}};function parent:GetID() return self.ID end
Settings.RegisterCanvasLayoutSubcategory=function(category,canvas,name)
 assert(category==parent and category.subcategories and canvas.CreateTexture and name=='Chronicle & Intel','native category/canvas argument order')
 calls=calls+1;return {ID=73,GetID=function() return 73 end}
end
ns.ChronicleOptionsPanel=nil;ns.BuildChronicleOptions(parent)
check(calls==0,'workspace recording preferences do not add a duplicate native settings entry')
local workspace=ns.Workspace;ns.Workspace=nil;ns.ChronicleOptionsPanel=nil
ns.BuildChronicleOptions(parent);ns.Workspace=workspace;Settings.RegisterCanvasLayoutSubcategory=old
check(calls==1,'standalone fallback passes the correct native category and canvas')
local label=ns.ChronicleActivitiesUI.DuelLabel
check(label({duel={accepted=true,result='win'}})=='Duel victory' and label({duel={accepted=true,result='loss'}})=='Duel defeat','verified duel outcomes use readable labels')
check(label({duel={accepted=true,result='unknown'},endAt=123})=='Duel completed • Result unknown','ended unknown duel uses one clear supported status')
check(label({duel={accepted=false},endAt=123})=='Duel challenge ended','challenge end never invents cancellation or victory')
startupChecks=checks-before;startupPumpFrames=frames
''')
result={'version':'1.1.0','assertions':int(lua.globals().startupChecks),'failed':0,'loadPumpCalls':int(lua.globals().startupPumpFrames),'nativeWatchdogFailureReported':True,'nativeSettingsFailureReported':True,'liveFixVerified':False,'seconds':round(time.perf_counter()-started,3)}
(out/'native-startup-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
