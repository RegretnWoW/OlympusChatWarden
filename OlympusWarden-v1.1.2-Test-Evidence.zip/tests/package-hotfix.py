from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,sys,difflib
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent;stem='OlympusWarden-v1.1.2'
def sha(b):return hashlib.sha256(b).hexdigest()
baseline=r/'OlympusWarden-v1.1.1.zip'
assert sha(baseline.read_bytes())=='c6b9d405b83a8915f2b9e1da73be26622d6618ed524419a57fcc6080211e7edb'
with zipfile.ZipFile(baseline) as z:
 assert z.testzip() is None
 old={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
files={n:(r/n).read_bytes() for n in old}
allowed={'OlympusChatWarden/'+n for n in 'Core.lua OlympusChatWarden.toc Chronicle.lua WardenLifecycle.lua ChronicleOptions.lua UpdateUI.lua README.md CHANGELOG.md RELEASE-NOTES.md'.split()}
changed=sorted(n for n in files if files[n]!=old[n]);assert set(changed)==allowed,changed
protected=[n for n in files if n not in allowed];assert all(files[n]==old[n] for n in protected)
sys.path.insert(0,str(r/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime
compileLua=LuaRuntime().eval('function(s,n) return assert(loadstring(s,n)) end')
toc=files['OlympusChatWarden/OlympusChatWarden.toc'].decode();modules=[n for n in toc.splitlines() if n.endswith('.lua')]
assert len(files)==167 and len(modules)==118
assert '## Version: 1.1.2' in toc and '## OptionalDeps: Olympus' in toc
assert '## SavedVariables: OlympusChatWardenDB, OlympusWardenRelayDB, OlympusWardenStartupDB' in toc
for n in modules:compileLua(files['OlympusChatWarden/'+n].decode('utf-8'),n)
digest=hashlib.sha256()
for p in sorted((r/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(p.name.encode());digest.update(p.read_bytes())
sourceHash=digest.hexdigest();assert (o/'hotfix-tests-source-sha256.txt').read_text().strip()==sourceHash
results=json.loads((o/'hotfix-suite-results.json').read_text());assert len(results)==13 and all(x['exitCode']==0 for x in results)
login=json.loads((o/'login-hotfix-summary.json').read_text());before=json.loads((o/'login-baseline.json').read_text())
assert login['failed']==0 and login['scenarioCount']==28 and before['failed']==1
assert any(s.get('manualInspectionRecentAllGearAndReload') for s in login['scenarios'])
assert json.loads((o/'modules-summary.json').read_text())['configurationCases']==32
def archive(path,data):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(data.items()):
   p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and ':' not in n
   assert not any(x in n.lower() for x in ['authorsigningkit','private-key','savedvariables/','__pycache__','read-saved-metadata'])
   for kind in [b'PRIVATE KEY',b'RSA PRIVATE KEY',b'EC PRIVATE KEY']:assert b'-----BEGIN '+kind not in b,n
   info=zipfile.ZipInfo(n,(2026,10,18,23,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and len(z.namelist())==len(data)
  for n,b in data.items():assert z.read(n)==b
addon=r/(stem+'.zip');archive(addon,files)
proof={'version':'1.1.2','status':'hotfix prepared for native login retest','baseline':{'file':baseline.name,'sha256':sha(baseline.read_bytes())},'addon':{'file':addon.name,'sha256':sha(addon.read_bytes()),'files':len(files),'bytes':addon.stat().st_size,'lua51Modules':len(modules),'luaSourceSha256':sourceHash},'offlineSuitesPassed':13,'suites':results,'loginAndGateScenarios':28,'moduleConfigurations':32,'baselineBugReproduced':True,'manualInspectionRecentAllGearAndReloadPassed':True,'mentionsDisplayedAndEventOnlyPassed':True,'changedFiles':changed,'unchangedFiles':len(protected),'mainHistorySchema':6,'consentVersion':5,'savedVariables':['OlympusChatWardenDB','OlympusWardenRelayDB','OlympusWardenStartupDB'],'storeArchiveBackupAndJournalUnchanged':True,'inspectionCollectorUnchanged':True,'mentionsAndSignalRouterUnchanged':True,'relayTransportUnchanged':True,'signedPacksAndTrustUnchanged':True,'artworkUnchanged':True,'nativeEvidence':{'userReportedWaitingForWorldEntry':True,'userConfirmedChronicleOnRestoredRecording':True,'patchedAutomaticLoginLiveVerified':False,'nativeWoWOperatedByBuildEnvironment':False,'separateMentionDefectConfirmed':False},'publicationPerformed':False,'liveInstallationModified':False}
validation=r/(stem+'-Validation.json');validation.write_text(json.dumps(proof,indent=2)+'\n')
verification=r/(stem+'-Package-Verification.json');verification.write_text(json.dumps({'version':'1.1.2',**proof['addon'],'archiveCRC':'passed','packagedSourceParity':'passed','allLua51Compile':'passed','offlineSuitesPassed':13,'nativePatchedLoginTested':False},indent=2)+'\n')
changedDoc=r/(stem+'-Changed-Files.md');changedDoc.write_text('# Changes from 1.1.1\n\n'+'\n'.join('- '+n for n in changed)+'\n\nAll other 158 packaged files remain byte-identical, including storage, recovery, inspection, Signal/Mentions, Relay, signed packs and artwork.\n')
diff='\n'.join('\n'.join(difflib.unified_diff(old[n].decode('utf-8').splitlines(),files[n].decode('utf-8').splitlines(),fromfile='1.1.1/'+n,tofile='1.1.2/'+n,lineterm='')) for n in changed)
docs=[r/(stem+s) for s in ['-Patch-Notes.md','-Test-Guide.md','-Build-Notes.md','-Changed-Files.md']]
evidence={p.name:p.read_bytes() for p in docs+[validation,verification]};evidence['source-changes.diff']=diff.encode()
for row in results:
 name=row['suite'];evidence['tests/'+name]=(o/name).read_bytes();evidence['results/'+name+'.log']=(o/(name+'.log')).read_bytes()
for name in ['login-baseline.json','login-hotfix-summary.json','hotfix-suite-results.json','manual-inspect-summary.json','inspection-expansion-summary.json','native-startup-summary.json','modules-summary.json','module-isolation-summary.json','closed-loading-summary.json','startup-journal-summary.json','archives-summary.json']:
 p=o/name
 if p.exists():evidence['results/'+name]=p.read_bytes()
for name in ['smoke.py','test-integration.py','test-chronicle.py','test-backup-tool.ps1','run-hotfix-checks.py','package-hotfix.py']:
 evidence['tests/'+name]=(o/name).read_bytes()
evidence['README.txt']=b'Offline fixture sources/results, not native gameplay verification. Inherited suite summary version labels describe fixture ancestry; the runner and source hash identify the tested 1.1.2 source. Some inherited workspace mock/runtime dependencies are not distributed. No real saved history or private signing material is included.\n'
evidenceZip=r/(stem+'-Test-Evidence.zip');archive(evidenceZip,evidence)
backup=r/'OlympusChatWarden-Backup-Tool-v1.0.3.zip';assert sha(backup.read_bytes())=='496185fda6704fbcbc04c398fe375dd38d6f680f1f9aa0a02569fbf1fcdd1386'
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
artifacts=[addon,backup,validation,verification,evidenceZip]+docs
checks=r/(stem+'-SHA256.txt');checks.write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in artifacts))
bundle=r/(stem+'-Hotfix-Bundle.zip');archive(bundle,{p.name:p.read_bytes() for p in [checks]+artifacts})
with checks.open('a') as f:f.write(sha(bundle.read_bytes())+'  '+bundle.name+'\n')
print(json.dumps({'addon':proof['addon'],'bundle':bundle.name,'changedFiles':len(changed),'unchangedFiles':len(protected),'offlineSuitesPassed':13,'nativePatchedLoginVerified':False},indent=2))
