from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1]
host={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'native module fixture','exec'),host)
start=time.perf_counter();checks=0;rows=[]
keys=['chat','chronicle','intel','shield','alerts']
for bits in range(32):
 selection={k:bool(bits&(1<<n)) for n,k in enumerate(keys)}
 l=host['fresh']('modern',True,selection=selection)
 l.execute('''
 function IsLoggedIn() return true end
 function GetRealmName() return 'Test Realm' end
 function UnitGUID(unit) if unit=='player' then return 'Player-Fixture-001' end end
 function UnitFullName(unit) if unit=='player' then return 'Fixture Character','Test Realm' end end
 UnitName=UnitFullName
 local M=ns.Modules
 assert(#ns.StartupErrors==0,'essential services must initialize without optional modules')
 for _,id in ipairs(M.order) do assert(M.State(id)~='error',id..' failed initialization') end
 assert(not ns.ModuleUI.welcome and not M.needsWelcome,'existing install must not show first-launch selection')
 if not M.Enabled('history') then assert(ns.ChronicleStore.db==nil and not ns.ChronicleStore.loading,'disabled history must not normalize or load') end
 if not M.Enabled('chat') then assert(ns.Matcher==nil and not ns.Spelling.ready and next(ns.Spelling.words)==nil,'disabled Chat must not build matcher or spelling buckets') end
 for _,f in ipairs(frames) do if f.events and f.events.PLAYER_ENTERING_WORLD and f.scripts.OnEvent then f.scripts.OnEvent(f,'PLAYER_ENTERING_WORLD',true,false) end end
 drain()
 if M.Enabled('history') then assert(ns.Chronicle.SetEnabled(true));assert(ns.Chronicle.Active(),'selected history can record independently of Chat: '..ns.Chronicle.Status()) end
 for _,row in ipairs(M.frames) do if not M.Enabled(row.owner) then
   assert(not next(row.frame.events or {}),'disabled frame retained events: '..row.owner)
   assert(not row.frame:GetScript('OnUpdate'),'disabled frame retained update: '..row.owner)
 end end
 ns.Workspace.Open('relay');assert(ns.Workspace.current=='relay' and ns.Workspace.pages.relay)
 ns.Workspace.Open('modules');assert(ns.Workspace.current=='modules')
 ns.Workspace.Refresh();assert(ns.Workspace.filterStatus:GetText()==(ns.Workspace.FeatureEnabled('filtering') and 'Filtering: ON' or 'Filtering: OFF'),'header text must match the actual module badge')
 ns.Workspace.Open('settings');assert(ns.Workspace.current=='settings')
 ns.Workspace.Open('chronicle');assert(ns.Workspace.current==(M.Enabled('chronicle') and 'chronicle' or 'modules'))
 ns.Workspace.Open('intel');assert(ns.Workspace.current==(M.Enabled('intel') and 'intel' or 'modules'))
 local search=ns.WardenSearch.Begin('test');while not search.done do ns.WardenSearch.Pump(search) end
 for _,source in ipairs(search.sources) do
  assert(M.Enabled('chronicle') or source.kind~='events','disabled Chronicle source was indexed')
  assert(M.Enabled('intel') or source.kind~='profiles','disabled Intel source was indexed')
 end
 ''')
 checks+=1
 metrics=l.eval("function() local events,updates,optionalEvents,optionalUpdates=0,0,0,0;for _,row in ipairs(ns.Modules.frames) do for _ in pairs(row.frame.events or {}) do events=events+1;if row.owner~='core' then optionalEvents=optionalEvents+1 end end;if row.frame:GetScript('OnUpdate') then updates=updates+1;if row.owner~='core' then optionalUpdates=optionalUpdates+1 end end end;return events,updates,collectgarbage('count'),optionalEvents,optionalUpdates end")()
 rows.append({'selection':selection,'ownedEventSubscriptions':metrics[0],'ownedUpdateCallbacks':metrics[1],'optionalOwnedEventSubscriptions':metrics[3],'optionalOwnedUpdateCallbacks':metrics[4],'hostLuaKiB':round(metrics[2],1)})
l=host['fresh']('modern',True,installation='new')
l.execute('''
assert(ns.Modules.needsWelcome and ns.Modules.Enabled('chat'))
for _,id in ipairs({'chronicle','intel','shield','alerts'}) do assert(not ns.Modules.Enabled(id)) end
assert(not ns.ChronicleStore.db and not ns.OptionsPanel and not ns.ChronicleOptionsPanel,'new install builds no history or full settings')
local M=ns.Modules;M.worldReady=true
local allowed=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end;M.dirty=true;M.Reconcile()
assert(not ns.ModuleUI.welcome,'onboarding waits for access without losing the pending introduction')
ns.Membership.Allowed=allowed;M.Reconcile()
assert(ns.ModuleUI.welcome:IsShown(),'late permission confirmation must still open the first-launch picker')
assert(not ns.DB.chronicle,'choosing modules is not consent')
''');checks+=1
l=host['fresh']('modern',True)
l.execute('''
local M,R=ns.Modules,ns.SignalCore
local report=ns.RelayStore.New();ns.RelayStore.Save(report.id,{module='relay',category='bug',title='Local draft',description='Must remain a draft across all configurations',steps=''})
for _,id in ipairs(M.order) do M.Set(id,false) end
assert(ns.RelayStore.Find(report.id).state=='draft' and not ns.RelayTransport.Busy())
local good,optional=0,0
assert(R.Subscribe('fixture','signal','failure',function() error('isolated handler failure') end))
assert(R.Subscribe('fixture','signal','required',function() good=good+1 end))
assert(R.Subscribe('fixture','alerts','optional',function() optional=optional+1 end))
R.Publish('fixture',{version=1});assert(good==1 and optional==0 and R.errors==1)
M.Set('alerts',true);R.Publish('fixture',{version=1});assert(good==2 and optional==1)
R.Unsubscribe('fixture','alerts','optional');R.Publish('fixture',{version=1});assert(good==3 and optional==1)
for n=1,8 do M.Set('shield',true);M.Set('shield',false) end
for _,row in ipairs(M.frames) do if row.owner=='shield' then assert(not next(row.frame.events or {}) and not row.frame:GetScript('OnUpdate')) end end
local old=InCombatLockdown;InCombatLockdown=function() return true end
M.Set('intel',true);assert(M.Selected('intel') and not M.Enabled('intel') and M.State('intel')=='suspended')
InCombatLockdown=function() return false end
for _,f in ipairs(frames) do if f.events and f.events.PLAYER_REGEN_ENABLED and f.scripts.OnEvent then f.scripts.OnEvent(f,'PLAYER_REGEN_ENABLED') end end
assert(M.Enabled('intel') and M.State('intel')=='enabled');InCombatLockdown=old
assert(ns.RelayStore.Find(report.id).state=='draft','module toggles must never submit reports')
''');checks+=1
result={'version':'1.1.1-preview6','failed':0,'configurationCases':32,'additionalScenarios':checks-32,'configurations':rows,'seconds':time.perf_counter()-start,'nativeClient':False}
(o/'modules-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='configurations'}))
