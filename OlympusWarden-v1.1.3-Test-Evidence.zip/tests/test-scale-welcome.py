from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'scale-welcome-host','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local hookCalls=0;debug.sethook(function() hookCalls=hookCalls+1;if hookCalls>500 then error(debug.traceback('scale fixture instruction watchdog')) end end,'',100000)
local before=checks;local W,T=ns.Workspace,ns.Theme
local methods=getmetatable(UIParent).__index;function methods:SetNumeric(value) self.numeric=value end
local oldWidth,oldHeight=UIParent:GetWidth(),UIParent:GetHeight();local parent=UIParent.GetEffectiveScale;local oldSaved=ns.DB.workspaceScale
local calls=0;local oldSet=W.window.SetScale
W.window.SetScale=function(self,value) calls=calls+1;oldSet(self,value) end
scaleWelcomeCases=0
for _,screen in ipairs({{1366,768},{1920,1080},{2560,1600},{3840,2160}}) do for _,ui in ipairs({.64,.8,1}) do
 UIParent:SetSize(screen[1]/ui,screen[2]/ui);UIParent.GetEffectiveScale=function() return ui end
 W.SetScale(nil);local automatic=W.appliedScale
 check(automatic<=1.5 and automatic*ui*(W.width+2*W.leftOverhang)<=screen[1]+.1 and automatic*ui*(W.height+2*W.bottomOverhang)<=screen[2]+.1,'automatic scale bounded to editor range and physical display')
 local initial=calls;for n=1,4 do ns.OpenWelcome();W.Open('intel');W.Open('chronicle');W.Open('settings');W.Fit() end
 check(calls==initial and not ns.DB.workspaceScale and W.appliedScale==automatic,'module/welcome navigation cannot rescale or save an automatic fit')
 W.SetScale(90);local applied=W.appliedScale;W.ScaleSettings();local p=W.scalePage
 check(p.input:GetText()=='90','custom input reflects saved preference rather than temporary screen cap')
 p.slider:GetScript('OnValueChanged')(p.slider,125,true)
 check(ns.DB.workspaceScale==.9 and W.appliedScale==applied and p.input:GetText()=='125','drag stages size without moving control under cursor or saving')
 p:ApplyScale();check(ns.DB.workspaceScale==1.25 and W.appliedScale<=1.25,'Apply saves exactly once and fits screen safely')
 local saved=ns.DB.workspaceScale;ns.OpenWelcome();check(ns.DB.workspaceScale==saved and W.pages.updates.mode=='tour' and not W.mounted,'welcome uses suite tour, never mounts a separately scaled legacy frame')
 p.slider:GetScript('OnValueChanged')(p.slider,50,false);p.slider:GetScript('OnValueChanged')(p.slider,50,true)
 check(ns.DB.workspaceScale==saved,'hidden/programmatic slider callbacks cannot change saved scale')
 scaleWelcomeCases=scaleWelcomeCases+1
end end
UIParent:SetSize(1920,1080);UIParent.GetEffectiveScale=function() return 1 end
W.SetScale(100);W.ScaleSettings();local p=W.scalePage;local count=#frames
for n=1,20 do W.Open('overview');W.ScaleSettings();check(W.scalePage==p,'scale editor is reused across navigation') end
check(#frames==count,'reopening scale editor does not create another control tree')
p.input:SetText('200');p:ApplyScale();check(ns.DB.workspaceScale==1,'invalid manual size does not alter prior saved preference')
W.SetScale(150);UIParent:SetSize(900,600);W.Fit();local small=W.appliedScale
check(ns.DB.workspaceScale==1.5 and small<1,'smaller resolution temporarily clamps without rewriting preference')
UIParent:SetSize(2560,1600);W.Fit();check(W.appliedScale==1.5 and ns.DB.workspaceScale==1.5,'larger display restores saved size without guessing')
W.ScaleSettings();p.slider:GetScript('OnValueChanged')(p.slider,80,true);W.Open('overview');W.ScaleSettings()
check(p.input:GetText()=='150' and ns.DB.workspaceScale==1.5,'leaving unsaved draft does not commit it and reopening shows saved size')
ns.OpenWelcome();local tour=W.pages.updates;local targets={}
for _,card in ipairs(tour.features) do check(card:IsShown(),'suite tour feature visible') end
local consent=ns.ChronicleStore.db and ns.ChronicleStore.db.enabled;local duel=ns.ChronicleStore.db and ns.ChronicleStore.db.duels
ns.OpenWelcome();check((ns.ChronicleStore.db and ns.ChronicleStore.db.enabled)==consent and (ns.ChronicleStore.db and ns.ChronicleStore.db.duels)==duel,'welcome does not activate recording or optional duels')
W.window.SetScale=oldSet;UIParent:SetSize(oldWidth,oldHeight);UIParent.GetEffectiveScale=parent;ns.DB.workspaceScale=oldSaved;W.Fit()
scaleWelcomeChecks=checks-before
''')
result={'version':'1.1.0','failed':0,'assertions':int(lua.globals().scaleWelcomeChecks),'displayScaleCases':int(lua.globals().scaleWelcomeCases),'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'scale-welcome-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
