from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;start=time.perf_counter()
h={'__file__':str(o/'test-ui-pass.py')};exec(compile((o/'test-ui-pass.py').read_text(),'release talent fixture','exec'),h);l=h['l']
l.execute(r'''
local before=checks;local G,T,W=ns.WardenDossier,ns.WardenTalents,ns.Workspace
local owner=ns.Chronicle.Owner();local guid='Player-Geometry-ONE';local p=G.BuildTalents(UIParent);p:Show();p:SetProfile(owner,{id=guid,title='Recorded player'})
for n=1,50 do p.scripts.OnUpdate(p) end
local g=p.tree;check(g:IsShown(),'recorded tree opens normally')
check(p.export:GetParent()==p and not p.export:IsShown() and p.export:GetWidth()==1,'retained copy value has no inline backing panel or placeholder')
local unwanted=false
for _,f in ipairs(frames) do
 local parent=f.parent;local inside=false
 for n=1,20 do if parent==p then inside=true;break end;if not parent then break end;parent=parent.parent end
 if inside and f.kind=='FontString' and (f.text=='No talent export was recorded.' or (f.text or ''):find('Recorded ranks and native layout',1,true)) then unwanted=true end
end
check(not unwanted,'overlapping placeholder and permanent instruction paragraph are absent')
check(g.scroll:GetHeight()==292 and g:GetHeight()==342,'tree uses the space released by the removed footer')
check(g.nodes[1]:GetParent()==g.content and g.headers[1]:GetParent()==g.content and g.lines[1]:GetParent()==g.content,'icons ranks headings and connections share one zoomed content frame')
local rawX,rawY=g.nodes[1].x,g.nodes[1].y;local gap=g.layout.list[2].x-g.layout.list[1].x
local width=g.nodes[1]:GetWidth();local iconWidth=width-6;local labelHeight=g.nodes[1].rank:GetHeight()
local native=C_Spell.GetSpellInfo;local calls=0;C_Spell.GetSpellInfo=function(...) calls=calls+1;return native(...) end
local frameCount=#frames
g.zoomIn:GetScript('OnClick')()
check(g.zoom==1.25 and g.content.scale==1.25 and g.zoomText:GetText()=='125%','zoom-in selects an exact 125% whole-content scale')
check(g.nodes[1]:GetWidth()*g.content.scale==52.5 and iconWidth*g.content.scale==45 and labelHeight*g.content.scale==22.5,'visual button icon and rank dimensions all grow by 25 percent')
check(g.nodes[1].x==rawX and g.nodes[1].y==rawY and g.layout.list[2].x-g.layout.list[1].x==gap,'zoom keeps native node coordinates and relative layout unchanged')
check(g.canvas:GetWidth()>=g.baseWidth*1.25 and g.canvas:GetHeight()>=g.baseHeight*1.25,'unscaled scroll canvas covers the actual scaled content')
local previousZoom=g.zoom;g.zoomOut:GetScript('OnClick')();check(g.zoom==1 and g.content.scale==1,'zoom-out reverses the same whole-tree scale')
g:SetZoom(2);local vw,vh=g.scroll:GetWidth(),g.scroll:GetHeight()
local left,top=100,100;g.scroll:SetHorizontalScroll(left);g.scroll:SetVerticalScroll(top)
local cx=(left+vw/2-g.originX)/g.zoom;local cy=(top+vh/2)/g.zoom
g:SetZoom(1.75)
check(math.abs(g.scroll:GetHorizontalScroll()-(g.originX+cx*1.75-vw/2))<.001 and math.abs(g.scroll:GetVerticalScroll()-(cy*1.75-vh/2))<.001,'zoom retains the viewport center when it lies inside the new bounds')
for _,zoom in ipairs({.75,1.25,1.5,1.75,2}) do
 g:SetZoom(zoom);g.scroll:SetHorizontalScroll(g.width-vw);g.scroll:SetVerticalScroll(g.height-vh);g.reset:GetScript('OnClick')()
 check(g.zoom==1 and g.content.scale==1 and g.zoomText:GetText()=='100%' and g.scroll:GetHorizontalScroll()==0 and g.scroll:GetVerticalScroll()==0,'Reset always restores 100 percent and the start of the same tree')
end
g:SetZoom(1.5);g.scroll:SetHorizontalScroll(80);g.scroll:SetVerticalScroll(60);local key=g.viewKey
p:Render();check(g.zoom==1.5 and g.content.scale==1.5 and g.viewKey==key and g.scroll:GetHorizontalScroll()==80 and g.scroll:GetVerticalScroll()==60,'ordinary dossier refresh preserves zoom and pan for the same build')
local row=p.rows[p.index];local values=row.object.capture.values
g:Present(values,p.job.objects,'another observation time',key)
check(g.zoom==1.5 and g.scroll:GetHorizontalScroll()==80,'a refreshed observation date does not reset the same recorded build')
g:Present(values,p.job.objects,'other character','other-owner:'..guid)
check(g.zoom==1 and g.scroll:GetHorizontalScroll()==0 and g.scroll:GetVerticalScroll()==0,'a different character or build starts at the canonical view')
g:SetZoom(.75);check(g.content.scale==.75 and not g.zoomOut:IsEnabled(),'75 percent lower limit is exact and disables further zoom-out')
g:SetZoom(2);check(g.content.scale==2 and not g.zoomIn:IsEnabled(),'200 percent upper limit is exact and disables further zoom-in')
calls=0
for n=1,100 do g:SetZoom(.75);g:SetZoom(2);g:ResetView() end
check(#frames==frameCount,'repeated zoom and Reset reuse all controls without accumulating frames')
check(calls==0,'zoom and Reset do not query spell metadata or rebuild the tree');C_Spell.GetSpellInfo=native
local copied;local copy=W.Copy;W.Copy=function(text) copied=text end;p.select:GetScript('OnClick')();W.Copy=copy
check(copied==p.exportValue and copied~='' and p.export:GetText()==copied,'copy export remains available through its separate dialog action')
g:SetZoom(2);g.canvas:SetScript('OnUpdate',function() end);g:ResetView();check(not g.canvas:GetScript('OnUpdate'),'Reset cancels a stale pan drag before restoring the view')
local digest=ns.ChronicleBackup.Encode(row.object.capture);p:Render();g:SetZoom(1.75);g:ResetView()
check(ns.ChronicleBackup.Encode(row.object.capture)==digest,'presentation changes leave saved talent evidence byte-equivalent')
releaseZoomChecks=checks-before
''')
result={'version':'1.1.3','assertions':int(l.globals().releaseZoomChecks),'failed':0,'nativeClient':False,'wholeTreeZoomRange':[75,200],'resetPercent':100,'repeatedZoomCycles':100,'seconds':time.perf_counter()-start}
(o/'release-zoom-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
