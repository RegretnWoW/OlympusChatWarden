from pathlib import Path
import json,time,hashlib
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'duel-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks
local D,I,X,A,G,B=ns.ChronicleDuels,ns.ChronicleEncounters,ns.ChronicleCapture,ns.ChronicleActivities,ns.WardenDossier,ns.ChronicleBackup
function hooksecurefunc(object,method,hook)
 if type(object)=='string' then hook=method;method=object;object=_G end
 local original=assert(object[method]);object[method]=function(...) local a,b=original(...);hook(...);return a,b end
end
local notified,cacheGUID=0,nil
NotifyInspect=function(unit) notified=notified+1;cacheGUID=UnitGUID(unit) end
ClearInspectPlayer=function() cacheGUID=nil end
CanInspect=function(unit) return units[unit]~=nil end
StartDuel=function(unit) end;CancelDuel=function() end
InspectFrame=nil;units.target=nil;units.party1=nil;units.mouseover=nil;groupCount=0;freshRecording()
local guid='Player-Duel-ONE';units.target={guid=guid,name='Rival Person',class='WARRIOR',race='Human',level=8,guild='Duel Guild',faction='Alliance'}
UnitClass=function(unit) return 'Warrior',units[unit] and units[unit].class or 'WARRIOR',1 end
UnitRace=function(unit) return 'Human','Human',1 end;UnitSex=function() return 2 end
UnitIsPlayer=function(unit) return units[unit]~=nil end
local weapon=1001
GetInventoryItemID=function(unit,slot) if slot==16 then return weapon end end
GetInventoryItemLink=function(unit,slot) if slot==16 then return '|Hitem:'..weapon..':123:0:-4|h[Recorded weapon]|h' end end
GetInventoryItemTexture=function(unit,slot) if slot==16 then return 12345 end end
Constants={TraitConsts={INSPECT_TRAIT_CONFIG_ID=-1}}
C_ClassTalents={GetActiveConfigID=function() return 7 end}
C_Traits={HasValidInspectData=function() return true end,ConfigHasStagedChanges=function() return false end,
 GetConfigInfo=function(id) return {ID=id,treeIDs={1}} end,GetTreeNodes=function() return {10,11} end,
 GetNodeInfo=function(config,id) return {ID=id,currentRank=1,activeEntry={entryID=id+100,rank=1}} end,
 GetEntryInfo=function(config,id) return {definitionID=id+1000} end,GetDefinitionInfo=function(id) return {spellID=id+1000} end,
 GenerateImportString=function() return 'NativeOwnExport' end,GenerateInspectImportString=function() return 'NativeRivalExport' end}
C_SpecializationInfo={GetSpecialization=function() return 1 end,GetSpecializationInfo=function() return 1491 end,GetInspectSpecialization=function() return 1491 end}
DUEL_WINNER_KNOCKOUT='%s has defeated %s in a duel.';DUEL_WINNER_RETREAT='%1$s has defeated %2$s; fled.'
local own=UnitGUID('player');local ownName=UnitFullName('player')
local function count(record)
 local n=0;for _,e in ipairs(all('native_event')) do if e.details.recordType==record then n=n+1 end end;return n
end
local function ready()
 local st=A.Request(C.Owner());local n=0
 while not st do A.Pump();st=A.Request(C.Owner());n=n+1;assert(n<10000) end
 return st
end
local function respond()
 clock=clock+6;I.InspectPump();ev('INSPECT_READY',guid)
end
check(not D.Enabled(),'duel collection starts off independently of existing Chronicle consent')
StartDuel('target');ev('DUEL_COUNTDOWN',3);ev('CHAT_MSG_SYSTEM',ownName..' has defeated Rival Person in a duel.')
check(count('duel_session_request')==0,'off opt-in collects no expanded duel history')
D.SetEnabled(true)
-- Ten separate sessions, forty dated captures, shared immutable components.
for n=1,10 do
 clock=clock+10;StartDuel('target');ev('DUEL_COUNTDOWN',3);respond()
 ev('UNIT_COMBAT','target','WOUND','',100,1);ev('UNIT_COMBAT','player','HEAL','',25,1)
 ev('UNIT_SPELLCAST_SUCCEEDED','player','cast-'..n,111);ev('UNIT_SPELLCAST_SUCCEEDED','target','other-'..n,222)
 ev('PLAYER_REGEN_DISABLED');ev('DUEL_FINISHED');ev('CHAT_MSG_SYSTEM',ownName..' has defeated Rival Person in a duel.');respond()
 ev('DUEL_FINISHED');ev('CHAT_MSG_SYSTEM',ownName..' has defeated Rival Person in a duel.')
end
local st=ready();local h=D.History(st,guid)
check(h.total==10 and h.wins==10 and h.losses==0 and h.unknown==0,'ten duels remain ten distinct verified victories')
check(count('duel_capture')==40,'ten duels retain all forty dated participant/phase observations')
check(count('duel_session_result')==10 and count('duel_session_end')==10,'duplicate finish/result delivery does not duplicate sessions or wins')
check(notified==20,'two eligible prioritized opponent requests per duel with global spacing')
local unique={};for _,a in ipairs(h.rows) do
 for _,g in ipairs({own,guid}) do
  local pre,post=D.Observation(a,g,'before'),D.Observation(a,g,'after')
  check(pre and post and pre.id~=post.id and pre.at<post.at,'separate dated before/after observations for '..g)
  check(pre.details.gearRef==post.details.gearRef and pre.details.traitRef==post.details.traitRef,'unchanged before/after reuses immutable component references')
  unique[g]=unique[g] or {gear={},traits={}}
  unique[g].gear[pre.details.gearRef]=true;unique[g].traits[pre.details.traitRef]=true
 end
end
for g,v in pairs(unique) do local ng,nt=0,0;for _ in pairs(v.gear) do ng=ng+1 end;for _ in pairs(v.traits) do nt=nt+1 end
 check(ng==1 and nt==1,'one unique gear and talent configuration per unchanged GUID')
end
local intel=ns.ChronicleIntelligence.Player(st,guid)
check(intel.tier==1,'verified duel opponent is Tier 1 important')
check(I.IsImportant(guid),'verified duel opponent also qualifies for existing important-player enrichment')
check(h.rate==1,'verified win rate excludes unknowns')
-- Component reuse survives nonconsecutive changes, preserves item modifiers.
local first=D.Observation(h.rows[1],guid,'before').details.gearRef
weapon=1002;local changed=ns.ChronicleLoadout.Gear('target',guid,'control');weapon=1001
check(ns.ChronicleLoadout.Gear('target',guid,'control')==first and changed~=first,'A/B/A gear reuses original immutable A')
local object=X.Find(C.Owner(),first);check(object.capture.values.slots[16][4]=='item:1001:123:0:-4','full item modifiers preserved')
local encode=B.Encode(object.capture);local oldHash=X.Hash;X.Hash=function() return first end
weapon=9999;local prior=X.diagnostics.collisions
check(not ns.ChronicleLoadout.Gear('target',guid,'control') and X.diagnostics.collisions==prior+1,'forced fingerprint collision never reuses unequal content')
X.Hash=oldHash;weapon=1001;check(B.Encode(object.capture)==encode,'original immutable snapshot unchanged after collision')
local traits={guid=guid,choices={{1,11,111,1,1111,2111},{1,10,110,1,1110,2110}},choicesComplete=true,nodesRead=2,nodesTotal=2,exportString='OrderIndependent'}
local t1=X.Store('traits',traits,'control');traits.choices={traits.choices[2],traits.choices[1]}
check(X.Store('traits',traits,'control')==t1,'unordered selected talent entries normalize losslessly')
traits.choices[1][4]=2;check(X.Store('traits',traits,'control')~=t1,'talent rank change produces unique content')
local fullSlots,knownIDs,unknownIDs={},{},{}
for n=1,19 do fullSlots[n]={n,'empty',false,false};knownIDs[n]=false;unknownIDs[n]=false end
fullSlots[16]={16,'present',1001,'item:1001:123:0:-4'};knownIDs[16]='Item-Example-01'
local knownGear=X.Store('gear',{guid=guid,slots=fullSlots,itemGUIDs=knownIDs},'control')
local unknownGear=X.Store('gear',{guid=guid,slots=fullSlots,itemGUIDs=unknownIDs},'control')
local label,changedSlots=D.Compare({details={gearRef=knownGear}},{details={gearRef=unknownGear}},'gear',(C.Owner()))
check(#changedSlots==0 and label:find('incomplete',1,true),'missing item-instance identity is unknown rather than an equipment change')
-- Unknown results, outgoing target switches and unsupported localization.
clock=clock+10;StartDuel('target');ev('DUEL_COUNTDOWN');respond();ev('DUEL_FINISHED');respond()
st=ready();h=D.History(st,guid);check(h.total==11 and h.unknown==1 and h.wins==10,'generic finish alone remains an unknown result')
clock=clock+10;StartDuel('target');units.target.guid='Player-Unrelated-OTHER';units.target.name='Unrelated Target';ev('DUEL_COUNTDOWN')
ev('CHAT_MSG_SYSTEM',ownName..' has defeated Unrelated Target in a duel.');ev('DUEL_FINISHED')
st=ready();check(D.History(st,'Player-Unrelated-OTHER').total==0,'target switch never substitutes unrelated duel opponent')
units.target.guid=guid;units.target.name='Rival Person'
clock=clock+10;StartDuel('target');ev('DUEL_COUNTDOWN');DUEL_WINNER_KNOCKOUT=nil
ev('CHAT_MSG_SYSTEM',ownName..' has defeated Rival Person in a duel.');ev('DUEL_FINISHED')
st=ready();check(D.History(st,guid).wins==10,'missing native locale string does not fall back to guessed English')
DUEL_WINNER_KNOCKOUT='%2$s wurde von %1$s besiegt.'
check(D.Parse('Rival Person wurde von '..ownName..' besiegt.').winner==ownName,'localized positional result format supported')
DUEL_WINNER_KNOCKOUT='%s has defeated %s in a duel.'
-- Incoming ambiguous identity does not borrow target, and declined is no duel win.
clock=clock+10;ev('DUEL_REQUESTED','Someone Else');ev('DUEL_COUNTDOWN');ev('CHAT_MSG_SYSTEM',ownName..' has defeated Someone Else in a duel.');ev('DUEL_FINISHED')
st=ready();check(D.History(st,guid).wins==10,'unresolved challenger remains unbound and result unknown')
clock=clock+10;ev('DUEL_REQUESTED','Rival Person');CancelDuel();st=ready()
check(D.History(st,guid).challenges>=1,'native canceled request retained separately from accepted duels')
-- Request ownership / unavailable priority attempt / ordinary backoff.
clock=clock+20;StartDuel('target');ev('DUEL_COUNTDOWN');local n=notified;I.InspectPump()
check(notified==n+1,'duel priority may bypass ordinary per-player backoff')
NotifyInspect('player');ev('INSPECT_READY',guid);local captures=count('duel_capture')
ev('DUEL_FINISHED');clock=clock+6;CanInspect=function() return false end;I.InspectPump();clock=clock+10;I.InspectPump()
check(count('duel_capture')==captures+1,'foreign inspection cache cannot be saved for the opponent; own post capture survives')
check(count('duel_capture_missed')>0,'missed capture opportunities are retained honestly')
CanInspect=function(unit) return units[unit]~=nil end
-- Delayed pre response cannot be mislabeled before.
clock=clock+20;StartDuel('target');ev('DUEL_COUNTDOWN');I.InspectPump();ev('PLAYER_REGEN_DISABLED')
local nc=count('duel_capture');ev('INSPECT_READY',guid)
check(count('duel_capture')==nc,'late pre-fight response rejected after phase boundary')
ev('DUEL_FINISHED');respond()
-- Bounded casts, third-party unit data and source semantics.
clock=clock+20;StartDuel('target');ev('DUEL_COUNTDOWN');respond()
units.focus={guid='Player-Third-PARTY',name='Other Player'}
for n=1,100 do ev('UNIT_SPELLCAST_SUCCEEDED','target','x',n) end
ev('UNIT_COMBAT','focus','WOUND','',9000,1);ev('DUEL_FINISHED');respond()
st=ready();local latest=D.History(st,guid).rows[1];local spells=0
for _,e in ipairs(latest.duel.combat[guid] or {}) do if e.details.spellID then spells=spells+1 end end
check(spells<=32,'duel spell detail has fixed per-participant bound')
check(not latest.duel.combat['Player-Third-PARTY'],'unrelated unit combat excluded')
local saved=B.PackSaved(S.db);local normalized=S.Normalize(saved)
check(normalized and normalized.duels==true and normalized.duelConsent==1,'packed file restore retains explicit duel opt-in')
local beforeHash=ns.PackCrypto.Hex(ns.PackCrypto.SHA256(B.Encode(S.Character(C.Owner(),false).events)))
local afterHash=ns.PackCrypto.Hex(ns.PackCrypto.SHA256(B.Encode(normalized.characters[C.Owner()].events)))
check(beforeHash==afterHash,'packed backup roundtrip preserves duel and snapshot content exactly')
-- Production views, gallery and item/talent controls.
ns.Workspace.Open('chronicle');local panel=ns.Workspace.pages.chronicle;panel.mode='activities';panel:Activate();panel:Refresh(true)
panel.activities.selected=latest.id;panel.activities:ShowActivity(latest)
check(panel.activities.analysis:IsShown(),'selected Chronicle duel opens analysis comparison')
local analysis=panel.activities.analysis;while analysis.job and not analysis.job.done do analysis.scripts.OnUpdate(analysis,.1) end
local compactRows=#analysis.sides[2].list.items
check(compactRows<#G.slots,'unknown gear collapses to a concise comparison instead of repeated missing slots')
local phase=analysis.phase;local evidence=analysis.selectedEvidence
click(analysis.allSlots);check(#analysis.sides[2].list.items==#G.slots and analysis.phase==phase and analysis.selectedEvidence==evidence,'all-slots action restores individual details without changing phase or evidence')
click(analysis.allSlots);check(#analysis.sides[2].list.items==compactRows,'unknown gear can collapse again without losing recorded slots')
analysis.selectedEvidence=D.Observation(latest,guid,'before');click(analysis.after)
check(analysis.phase=='after' and not analysis.selectedEvidence,'phase switch cannot retain evidence selection from the previous phase')
click(analysis.before);analysis:Render();click(analysis.sides[2].traits)
check(analysis.talentPopup and analysis.talentPopup:IsShown(),'Duel Analysis opens historical talent evidence without inspection')
analysis:Hide();check(not analysis.job and not analysis.activity and not analysis.state,'hidden duel analysis releases historical projections')
local j=G.Request(C.Owner());while not j.done do G.Pump(j) end
local configs=G.Configurations(j,guid);local observed=0
for _,r in ipairs(configs) do observed=observed+#r.observations end
check(#configs<observed,'gear gallery counts unique configurations separately from observations')
D.SetEnabled(false);local old=count('duel_session_request');StartDuel('target');ev('DUEL_COUNTDOWN')
check(count('duel_session_request')==old,'disabling duel capture stops new records and preserves old history')
ns.BuildChronicleOptions();local options=ns.ChronicleOptionsPanel
options.duelCheck:SetChecked(true);options.duelCheck.scripts.OnClick(options.duelCheck)
check(options.duelConsent and options.duelConsent:IsShown() and not S.db.duels,'duel checkbox opens a separate disclosure without enabling collection')
options.duelConsent:Hide();options:Refresh();check(not options.duelCheck:GetChecked(),'dismissing duel disclosure leaves opt-in off')
C.SetEnabled(false);D.SetEnabled(true);StartDuel('target');ev('DUEL_COUNTDOWN');check(not D.Enabled(),'duel opt-in cannot bypass main recording consent')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'existing schema/consent and forbidden combat-log boundary preserved')
duelChecks=checks-before;duelStorageBytes=S.Storage().bytes;duelUniqueConfigs=#configs
''')
summary={'version':'1.1.0','assertions':int(lua.globals().duelChecks),'failed':0,'tenDuelCaptures':40,'tenDuelSessions':10,'gearConfigurationsFirstTen':2,'talentConfigurationsFirstTen':2,'galleryConfigurationsAfterAdversarialCases':int(lua.globals().duelUniqueConfigs),'syntheticStorageBytesAfterAdversarialCases':int(lua.globals().duelStorageBytes),'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
digest=hashlib.sha256()
for name in sorted(p.name for p in (root/'OlympusChatWarden').glob('*.lua')):
 digest.update(name.encode());digest.update((root/'OlympusChatWarden'/name).read_bytes())
summary['luaSourceSha256']=digest.hexdigest()
(out/'duel-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
