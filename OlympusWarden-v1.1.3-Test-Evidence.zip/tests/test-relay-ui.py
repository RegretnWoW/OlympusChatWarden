from pathlib import Path
import json,time
o=Path(__file__).resolve().parent
scope={'__file__':str(o/'smoke.py')};exec(compile((o/'smoke.py').read_text(),'release-host','exec'),scope);lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local W=ns.Workspace;local S=ns.RelayStore;local P=ns.RelayTransport
W.Open('relay');local p=W.pages.relay
check(p and p.mode=='report' and p.draft and p.draft.state=='draft','Relay opens its saved local composer')
local order={'overview','chronicle','intel','messages','mentions','shield','relay'};local last=-1
for _,id in ipairs(order) do local b=W.navigation[id];local y=-(b.y or b.points[1].y);check(y>last,'seven branded navigation entries in final order');last=y end
check(not W.navigation.settings,'shared Settings belongs to CommandWarden')
check(not W.navigation.recording and not W.navigation.updates,'legacy destinations are consolidated, not separate sidebar entries')
check(ns.WardenBrand.Icon('recording')=='RelayWarden' and ns.WardenBrand.Icon('updates')=='RelayWarden','legacy destinations use Relay crest')
p.title:SetText('UI report title');p.description:SetText('A reproducible display issue.');p.steps:SetText('Open Warden.\nSelect a page.')
local id=p.draft.id
check(S.Find(id).fields.title=='UI report title','typing saves only the local draft')
p:Preview();check(p.previewWire and p.send:IsEnabled(),'explicit preview arms the submit control')
for _,box in ipairs({p.title,p.description,p.steps}) do box:GetScript('OnTextChanged')(box,false) end
check(p.previewWire and p.send:IsEnabled(),'identical native text notifications do not invalidate the reviewed report')
p.title:SetText('Revised title');check(not p.previewWire and p.send:IsEnabled(),'editing invalidates details but keeps valid report submittable')
p.includeDiagnostics=true;p.diagnostics=ns.RelayDiagnostics.Prepare();p.attach:SetChecked(true);p:Preview()
check(S.Decode(p.previewWire).diagnostics~='','only the previewed optional aggregate diagnostics are included')
local original=S.Find(id).fields.title
W.Open('recording');check(W.current=='recording' and W.pages.recording and W.heading:GetText()=='RelayWarden','old recording route opens Relay data section')
for _,view in ipairs({'events','backup','coverage','activities','intelligence'}) do W.pages.recording:SetView(view);check(W.pages.recording.view==view,'existing recording view remains accessible: '..view) end
check(W.canvas:GetHeight()==644 and W.relayLegacy[W.pages.recording],'nested legacy tools use a scrollable viewport, keeping all controls reachable')
W.Open('updates');check(W.pages.updates~=nil and W.heading:GetText()=='RelayWarden','old updates route remains functional')
W.pages.updates:SetView('tour');W.pages.updates:SetView('notes');W.Guide('basics')
check(W.pages.guide and W.relayLegacy[W.pages.guide],'help document reader retains its controls and clipping bounds')
W.Open('relay');check(p.draft.id==id and p.title:GetText()==original,'draft and selected report survive navigation')
p:SetView('mine');p.mine:Refresh();check(#p.mine.list.items==0,'My Reports omits unsubmitted text')
p:SetView('diagnostics');check(p.healthDoc~=nil,'diagnostic page opens without profiling')
local oldName,oldFullName,oldRealm,oldNormalized=UnitName,UnitFullName,GetRealmName,GetNormalizedRealmName
function UnitName() return 'Rune','Escape' end;UnitFullName=UnitName;function GetRealmName() return 'Classic Beta PvP' end
function GetNormalizedRealmName() return 'ClassicBetaPvP' end
check(P.IsDeveloper(),'receiver role derives from exact native character and realm')
local icon=W.navigation.relay.Icon
check(icon:GetWidth()==52.5 and icon:GetHeight()==52.5,'Relay crest matches the larger sidebar artwork footprint')
p:NewSelfTest();check(p.draft.selfTestReceiver=='rune escape-classicbetapvp' and not p.previewWire and p.send:IsEnabled(),'developer self-test needs only explicit Submit')
check(p.recipient:GetText():find('self-test to',1,true) and S.Find(p.draft.id).state=='draft','self-test names its native recipient and remains a local draft')
check(p.diagnostics=='' and not p.attach:GetChecked(),'self-test clears a previous report attachment instead of silently reusing it')
p:SetDraft(S.Find(id))
p:SetView('mine');check(#p.mine.list.items==0 and not p.mine.selected,'unfinished text never gets delivery controls')
p:SetDraft(S.Find(id))
p:SetView('inbox');check(p.mode=='inbox' and #W.relayTabs==3 and #W.tabs>=4,'configured receiver exposes the inbox within Support under three primary areas')
local wire=S.Encode(S.Payload(S.Find(id),''));local data=S.Decode(wire)
check(S.Receive('example-classicbetapvp',data,wire,S.Checksum(wire)),'configured receiver saves complete inbox report')
p.inbox.revision=nil;p.inbox:Refresh();check(#p.inbox.list.items==1,'populated inbox renders original report without a missing ID')
p.inbox.list.rows[1]:GetScript('OnClick')(p.inbox.list.rows[1])
check(p.inbox.selected and p.inbox.document:GetText():find(original,1,true),'inbox selection shows original contents')
check(S.SetInboxState(p.inbox.selected.key,'Reviewing'),'developer can mark a report Reviewing')
p.inbox.status='Fixed';p.inbox.revision=nil;p.inbox:Refresh();check(#p.inbox.list.items==0,'inbox status filter selects exact states')
p.inbox.status='all';p.inbox.revision=nil;p.inbox:Refresh();p.inbox.list.rows[1]:GetScript('OnClick')(p.inbox.list.rows[1])
local originalWire=p.inbox.selected.wire;p:CopyReport(p.inbox.selected,true);local frameCount=#frames
for n=1,20 do p:SetView('inbox');p:CopyReport(p.inbox.selected,true) end
check(#frames==frameCount and p.export:GetText():find(original,1,true),'repeated report copying reuses its editor without allocating another window')
check(p.inbox.selected.wire==originalWire,'copy view does not modify original report evidence')
local payload=S.Payload(S.Find(id),'');payload.description='Literal |Hunsafe:command|hvisible|h |cffaabbcc color |r'
S.Find(id).fields.description=payload.description;p:SetDraft(S.Find(id));p:Preview()
check(p.previewDoc:GetText():find('||Hunsafe:command||hvisible||h',1,true),'review shows literal user markup rather than evaluating or stripping it')
check(p.previewScroll:GetHeight()==220 and p.mine.list.scroll:GetHeight()==394,'report readers retain scrollable viewports beside the new Submit readiness message')
function UnitName() return 'Someone','Else' end;UnitFullName=UnitName
p:Refresh();check(p.mode=='report','inbox closes when native identity no longer qualifies')
OlympusWardenRelayDB.developer=true;check(not P.IsDeveloper(),'a local saved developer flag cannot grant inbox authority')
UnitName,UnitFullName,GetRealmName,GetNormalizedRealmName=oldName,oldFullName,oldRealm,oldNormalized
p:SetDraft(S.Find(id));p:Preview();p.send:GetScript('OnClick')(p.send)
check(S.Find(id).state~='draft' and p.mode=='mine','real Submit button queues the exact reviewed report and opens delivery status')
W.Open('messages');W.Open('capture');W.Open('chronicle');W.Open('intel');W.Open('overview')
check(W.current=='overview','other six modules still navigate')
relayUIChecks=checks-before
''')
result={'suite':'Relay UI and legacy routes','assertions':int(lua.globals().relayUIChecks),'failed':0,'seconds':time.perf_counter()-start,'nativeForever':False}
(o/'relay-ui-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
