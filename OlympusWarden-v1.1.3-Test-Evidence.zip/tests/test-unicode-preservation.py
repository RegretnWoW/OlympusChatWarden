from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'unicode-history-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local B=ns.ChronicleBackup
freshRecording();local owner=C.Owner();local c=S.Character(owner,false);local name='Unicode '..string.char(208,144)..' Player'
check(S.Text(name)==name,'UTF-8 continuation byte 0x90 is valid text regardless of locale')
for _,v in ipairs({string.char(0),string.char(1),string.char(9),string.char(10),string.char(31),string.char(127),'|cffffffffName|r'}) do check(not S.Text(v),'actual ASCII controls and markup remain rejected') end
local snapshot={format=1,kind='wanted',board='wanted',id=c.currentSession..'/olympus1',part=1,parts=1,apiVersion=1,mode='full',rows={{key='Player-Unicode-ONE',values={name=name,guid='Player-Unicode-ONE',place=1,bounty=3,kills=0}}},removed={}}
local event=C.Record('olympus_snapshot','WANTED_CHANGED',{snapshotID=snapshot.id,snapshotKind='wanted',board='wanted',part=1,parts=1,rowCount=1,removedCount=0,apiVersion=1,snapshotMode='full'},nil,'observed',{},nil,snapshot)
check(event and event.snapshot.rows[1].values.name==name,'Wanted snapshot retains exact Unicode name bytes')
local packed=assert(B.PackSaved(S.db));local clean=assert(S.Normalize(packed))
local original=B.Encode(c.events);check(B.Encode(clean.characters[owner].events)==original,'Unicode public history survives strict packed normalization byte-for-byte')
ns.DB.chronicle=packed;S.Initialize();check(not S.blocked and S.db~=nil,'valid Unicode history no longer blocks the whole ledger')
check(C.SetEnabled(true),'main recording control works after successful load')
check(ns.ChronicleDuels.SetEnabled(true) and S.db.duels==true,'optional duel enable control works after successful load')
local bad=assert(B.PackSaved(S.db));bad.characters[owner].eventChunks[1]='not valid packed history';ns.DB.chronicle=bad;S.Initialize()
check(S.blocked and ns.DB.chronicle==bad and not C.SetEnabled(true),'actual corrupt history still fails closed without overwriting recovery data')
check(not ns.ChronicleDuels.SetEnabled(true),'duel toggle cannot bypass a real load failure')
ns.DB.chronicle=packed;S.Initialize();check(not S.blocked and C.SetEnabled(true),'reloading intact original restores history access without reset')
unicodeChecks=checks-before
''')
summary={'version':'1.1.0','assertions':int(lua.globals().unicodeChecks),'failed':0,'syntheticUnicodeRegression':True,'currentRealHistoryProof':'See aggregate startup history proof: 49,253 events / four characters, canonically unchanged','liveGameFilesModified':False,'seconds':round(time.perf_counter()-start,3)}
(out/'unicode-preservation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
