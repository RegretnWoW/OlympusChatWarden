from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'statistics-stress-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local T,X=ns.ChronicleStatistics,ns.ChronicleCapture
local reads=0
GetStatisticsCategoryList=function() return {100,101,102,103,104} end
GetCategoryInfo=function(id) return 'Native category '..id,-1 end
GetCategoryNumAchievements=function() return 1000 end
GetAchievementInfo=function(category,index) return category*1000+index,'Native ID '..index,0,false,nil,nil,nil,'Description',0,nil,nil,false,false,nil,true end
GetStatistic=function(id) reads=reads+1;return '42' end
freshRecording();local maxStep,loops=0,0
while not T.ready or T.reading or reads<4096 do
 local old=reads;X.Pump();maxStep=math.max(maxStep,reads-old);loops=loops+1;assert(loops<10000)
end
check(#T.catalog==4096 and not T.catalogComplete,'five thousand advertised statistics stop at the explicit catalog ceiling')
check(maxStep<=T.READS_PER_STEP*2,'native statistic getter calls stay bounded per enrichment pump')
local count=0;for _,e in ipairs(all('native_event')) do if e.details.recordType=='statistic_observed' then count=count+1 end end
check(count==4096,'one readable native baseline per discovered ID')
local old=reads;clock=clock+121;T.Request('BOSS_KILL')
local combat=InCombatLockdown;InCombatLockdown=function() return true end
for n=1,100 do X.Pump() end;check(reads==old,'large native catalog adds no combat getter work');InCombatLockdown=combat
local important=false;X.Queue('important-enrichment-fixture',function() important=true end)
for n=1,5 do X.Pump() end;check(important,'large native-statistics job yields behind ordinary enrichment')
local loops2=0;while T.reading or reads<8192 do X.Pump();loops2=loops2+1;assert(loops2<10000) end
local latestCount=0;for _,e in ipairs(all('native_event')) do if e.details.recordType=='statistic_observed' then latestCount=latestCount+1 end end
check(latestCount==count,'full repeated catalog read adds zero unchanged observations')
local packed=assert(ns.ChronicleBackup.PackSaved(S.db));check(S.Normalize(packed)~=nil,'large native-statistics baseline uses existing bounded saved chunks')
statStressChecks=checks-before;statStressReads=maxStep;statStressLoops=loops;statStressBytes=#ns.ChronicleBackup.Encode(packed)
''')
summary={'version':'1.1.0','assertions':int(lua.globals().statStressChecks),'failed':0,'ids':4096,'maxStatisticReadsPerPump':int(lua.globals().statStressReads),'pumpCalls':int(lua.globals().statStressLoops),'syntheticFullHistoryBytes':int(lua.globals().statStressBytes),'liveWoWTested':False,'seconds':round(time.perf_counter()-started,3)}
(out/'statistics-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
