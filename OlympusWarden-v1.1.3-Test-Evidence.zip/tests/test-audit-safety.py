from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1]
h={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'audit host','exec'),h)
start=time.perf_counter();scenarios=[]
for warm in [False,True]:
 l=h['fresh']('modern',True,selection={k:warm for k in ['chat','shield','alerts','chronicle','intel']})
 l.globals().warm=warm
 l.execute('''
 local W,M=ns.Workspace,ns.Modules
 if warm then for _,id in ipairs({'capture','shield','intel','chronicle','mentions'}) do W.Open(id) end;for _,id in ipairs(M.order) do M.Set(id,false) end end
 for _,call in ipairs({function() ns.OpenCapturePlayer('Unavailable Person') end,function() ns.OpenCaptureBookmark(1) end,
  function() ns.OpenShieldPlayer('Unavailable Person') end,function() W.ShieldEditor('Unavailable Person') end,
  function() W.CaptureSettings() end,function() ns.OpenPacks('import') end,function() ns.OpenReport('test') end,
  function() ns.WardenUI.Navigate('player','NoOwner','Player-Test') end}) do call();assert(W.current=='modules','disabled entry must resolve to module selection') end
 if not warm then assert(not W.pages.capture and not W.pages.shield and not W.pages.intel and not W.pages.chronicle,'cold-disabled pages must never be constructed') end
 for _,id in ipairs(M.order) do assert(not M.Selected(id),'deep links must not silently activate anything') end
 W.Open('overview');assert(W.current=='overview' and W.pages.overview,'CommandWarden exists in essential-only configuration')
 assert(not W.navigation.settings and W.navigation.overview:IsShown(),'settings consolidated under CommandWarden')
 if not warm then assert(W.profile.points[1].y==-154,'cold essential-only profile follows the two visible module buttons') end
 for _,id in ipairs({'overview','modules','performance','settings'}) do assert(W.Open(id));assert(W.heading:GetText()=='CommandWarden','shared configuration retains Command identity') end
 assert(W.navigation.overview.Icon.ChatWardenIconBox.size>=60 and W.pageIcon.ChatWardenIconBox.size>=72,'large crests remain beside readable text')
 if not warm then assert(not ns.ChronicleStore.db,'Command dashboard must not load a disabled archive') end
 ''');scenarios.append('warm-disabled-links' if warm else 'cold-disabled-links')
l=h['fresh']('modern',True)
l.execute('''
 local W,M=ns.Workspace,ns.Modules;W.Open('relay');local p=W.pages.relay
 assert(#W.relayTabs==3,'three primary Relay areas')
 p.title:SetText('First private draft');p.description:SetText('Synthetic description');p.includeDiagnostics=true;p.diagnostics=ns.RelayDiagnostics.Prepare();p.attach:SetChecked(true);p:Preview();local first=p.draft
 assert(ns.RelayStore.Decode(p.previewWire).diagnostics~='')
 p:NewDraft();assert(not p.includeDiagnostics and p.diagnostics=='' and not p.attach:GetChecked(),'new draft resets attachment consent')
 p.title:SetText('Second private draft');p.description:SetText('Another synthetic description');p:Preview();assert(ns.RelayStore.Decode(p.previewWire).diagnostics=='')
 p:SetDraft(first);p:Preview();assert(ns.RelayStore.Decode(p.previewWire).diagnostics=='','switching resets attachment consent')
 local copy=assert(ns.RelayStore.Copy(first.id));p:SetDraft(copy);assert(not p.includeDiagnostics and p.diagnostics=='','duplicates require a fresh explicit attachment choice')
 p:Preview();p.title:GetScript('OnTextChanged')(p.title,false);assert(p.previewWire and p.send:IsEnabled(),'unchanged notifications keep exact preview')
 p.title:SetText('Actual change');assert(not p.previewWire and p.send:IsEnabled())
 p:Submit();p:SetView('mine');p.mine:Refresh();p.mine.list.rows[1]:GetScript('OnClick')(p.mine.list.rows[1]);p.mine.advancedButton:GetScript('OnClick')(p.mine.advancedButton);p.mine.delete:GetScript('OnClick')(p.mine.delete);assert(p.mine.deleteKey)
 p.mine.advancedButton:GetScript('OnClick')(p.mine.advancedButton);assert(not p.mine.deleteKey,'unrelated action disarms delete')
 p.mine.delete:GetScript('OnClick')(p.mine.delete);p:SetView('diagnostics');assert(not p.mine.deleteKey,'leaving view disarms delete')
 local spamReset,release=ns.Spam.Reset,ns.Spelling.Release;local calls=0
 ns.Spam.Reset=function() error('active Shield counters must remain') end;ns.Spelling.Release=function() error('active dictionary must remain') end
 M.ClearCaches();ns.Spam.Reset=spamReset;ns.Spelling.Release=release
 local job=ns.WardenSearch.Begin('test');M.Set('alerts',false);assert(ns.WardenSearch.Pump(job) and job.stale and #job.sources==0,'module transition cancels old search references')
 local refresh,combat=ns.RefreshUI,InCombatLockdown;ns.RefreshUI=function() calls=calls+1 end;InCombatLockdown=function() return true end
 M.Set('chat',false);assert(calls==0 and not M.Enabled('chat'),'disable stops work immediately but defers display cleanup')
 InCombatLockdown=function() return false end
 for _,f in ipairs(frames) do if f.events and f.events.PLAYER_REGEN_ENABLED and f.scripts.OnEvent then f.scripts.OnEvent(f,'PLAYER_REGEN_ENABLED') end end
 assert(calls>0,'UI cleanup applies safely after combat');ns.RefreshUI=refresh;InCombatLockdown=combat
 ''');scenarios.append('attachments-delete-cleanup-combat')
for paused in [False,True]:
 l=h['fresh']('modern',True)
 l.globals().paused=paused
 l.execute('''
 local M=ns.Modules;ns.DB.moduleSelection=nil;ns.DB.enabled=not paused
 ns.DB.shield.enabled=true;ns.DB.alertsEnabled=true
 M.Initialize(true);M.Reconcile()
 assert(M.Selected('chat') and M.Selected('chronicle') and M.Selected('intel') and M.Selected('shield'),'configured features survive migration')
 if paused then assert(not ns.Active('chat') and not M.Enabled('history') and M.State('chronicle')=='paused','old global pause must not silently resume recording')
  M.Set('chronicle',true);assert(M.Enabled('chronicle'),'explicit choice resumes the legacy selection')
 else assert(M.Enabled('history'),'active legacy install keeps its available historical consumers') end
 ''');scenarios.append('legacy-paused' if paused else 'legacy-active')
result={'version':'1.1.1-preview6','failed':0,'scenarios':scenarios,'nativeClient':False,'seconds':time.perf_counter()-start}
(o/'audit-safety-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
