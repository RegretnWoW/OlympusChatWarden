from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,sys,difflib
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent;version='1.1.3';stem='OlympusWarden-v'+version
def sha(b):return hashlib.sha256(b).hexdigest()
baseline=r/'OlympusWarden-v1.1.3-preview2.zip'
assert sha(baseline.read_bytes())=='ef8a02cea0202816e401571c895d9aa09308f5fb7f81e374471b7a29018d3835'
with zipfile.ZipFile(baseline) as z:
 assert z.testzip() is None
 old={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
changedExpected={'OlympusChatWarden/'+n for n in 'Core.lua OlympusChatWarden.toc UpdateUI.lua WardenDossier.lua WardenTalents.lua README.md CHANGELOG.md RELEASE-NOTES.md'.split()}
added=set()
files={n:(r/n).read_bytes() for n in set(old)|added}
changed=sorted(n for n in old if files[n]!=old[n]);assert set(changed)==changedExpected,changed
unchanged=sorted(set(old)-set(changed));assert all(files[n]==old[n] for n in unchanged)
assert len(files)==173
toc=files['OlympusChatWarden/OlympusChatWarden.toc'].decode();modules=[n for n in toc.splitlines() if n.endswith('.lua')]
assert len(modules)==120 and '## Version: '+version in toc
assert '## SavedVariables: OlympusChatWardenDB, OlympusWardenRelayDB, OlympusWardenStartupDB' in toc
assert '## OptionalDeps: Olympus' in toc
sys.path.insert(0,str(r/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime
compileLua=LuaRuntime().eval('function(s,n) return assert(loadstring(s,n)) end')
for n in modules:compileLua(files['OlympusChatWarden/'+n].decode('utf-8'),n)
digest=hashlib.sha256()
for p in sorted((r/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(p.name.encode());digest.update(p.read_bytes())
sourceHash=digest.hexdigest();assert (o/'preview-tests-source-sha256.txt').read_text().strip()==sourceHash
results=json.loads((o/'preview-suite-results.json').read_text());assert len(results)==20 and all(x['exitCode']==0 for x in results)
specific=json.loads((o/'release-zoom-summary.json').read_text());assert specific['assertions']==26 and specific['failed']==0
assert json.loads((o/'preview2-summary.json').read_text())['assertions']==43
assert json.loads((o/'ui-pass-summary.json').read_text())['assertions']==42
assert json.loads((o/'modules-summary.json').read_text())['configurationCases']==32
assert json.loads((o/'backup-tool-summary.json').read_text())['assertions']==130
assert json.loads((o/'scale-welcome-summary.json').read_text())['displayScaleCases']==12
def archive(path,data):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(data.items()):
   p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and ':' not in n
   assert not any(x in n.lower() for x in ['authorsigningkit','private-key','savedvariables/','__pycache__','read-saved-metadata'])
   for kind in [b'PRIVATE KEY',b'RSA PRIVATE KEY',b'EC PRIVATE KEY']:assert b'-----BEGIN '+kind not in b,n
   info=zipfile.ZipInfo(n,(2026,10,18,23,30,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and len(z.namelist())==len(data)
  for n,b in data.items():assert z.read(n)==b
addon=r/(stem+'.zip');archive(addon,files)
proof={'version':version,'status':'release package prepared; native acceptance pending','baseline':{'file':baseline.name,'sha256':sha(baseline.read_bytes())},'addon':{'file':addon.name,'sha256':sha(addon.read_bytes()),'files':len(files),'bytes':addon.stat().st_size,'lua51Modules':len(modules),'luaSourceSha256':sourceHash},'offlineSuitesPassed':20,'suites':results,'releaseZoomAssertions':26,'previousBugRegressionAssertions':43,'zoomRangePercent':[75,200],'resetPercent':100,'repeatedZoomCycles':100,'collectorImplementationsUnchangedFromPreview2':True,'previousUiAndDataAssertions':42,'moduleConfigurations':32,'loginAndGateScenarios':28,'backupToolAssertions':130,'scaleDisplayCases':12,'changedFiles':changed,'addedFiles':sorted(added),'byteIdenticalBaselineFiles':len(unchanged),'mainHistorySchema':6,'consentVersion':5,'savedVariables':['OlympusChatWardenDB','OlympusWardenRelayDB','OlympusWardenStartupDB'],'shortcutsDefaultOff':['shopLauncher','inspectLauncher','wardenMinimap'],'minimapDragUpdateIdle':False,'staticTalentGeometryDeduplicated':True,'historicalTalentBackupRestorePassed':True,'oldTalentListFallbackRetained':True,'nativeProtectedTextBypassed':False,'storeArchiveAndRecoveryUnchanged':True,'relayTransportUnchanged':True,'signedPacksAndTrustUnchanged':True,'nativeWoWOperated':False,'nativeAcceptance':{'secretStringEngine':'pending','historicalNativeTreeParity':'pending','shopAndInspectSideTab':'pending','itemTooltipAndCacheTiming':'pending','coldReportViews':'pending','wholeTalentZoomAndReset':'pending','talentOverlayRemoval':'pending','minimapBorderAndDrag':'pending','combatDeferral':'pending'},'initialAttempt':{'zoomFixture':'one fixture assertion included intentional refresh metadata calls; narrowed to zoom-only calls before final passing run'},'artworkUnchanged':True,'coldRelayViewsPopulatedWithoutSubmission':True,'inspectedGearCompletionReadLimit':3,'inspectedGearCompletionDeadlineSeconds':4,'exactGearEvidencePreserved':True,'itemTypeFallbackExplicitlyLabeled':True,'publicationPerformed':False,'liveInstallationModified':False}
validation=r/(stem+'-Validation.json');validation.write_text(json.dumps(proof,indent=2)+'\n')
verification=r/(stem+'-Package-Verification.json');verification.write_text(json.dumps({'version':version,**proof['addon'],'archiveCRC':'passed','sourceParity':'passed','allLua51Compile':'passed','offlineSuitesPassed':20,'nativeClientVerified':False},indent=2)+'\n')
changedDoc=r/(stem+'-Changed-Files.md');changedDoc.write_text('# Changes from 1.1.3-preview2\n\nChanged:\n\n'+'\n'.join('- '+n for n in changed)+'\n\nAdded:\n\n'+('\n'.join('- '+n for n in sorted(added)) or '- None.')+f'\n\n{len(unchanged)} baseline files remain byte-identical, including ChronicleStore, ChronicleBackup, recovery, Relay transport, signed packs, and existing artwork.\n')
diff='\n'.join('\n'.join(difflib.unified_diff(old.get(n,b'').decode('utf-8').splitlines(),files[n].decode('utf-8').splitlines(),fromfile='1.1.3-preview2/'+n,tofile=version+'/'+n,lineterm='')) for n in changed+sorted(added) if n.endswith(('.lua','.toc','.md')))
docs=[r/(stem+s) for s in ['-Patch-Notes.md','-Test-Guide.md','-Build-Notes.md','-Changed-Files.md']]
evidence={p.name:p.read_bytes() for p in docs+[validation,verification]};evidence['source-changes.diff']=diff.encode()
for p in o.glob('*.py'):evidence['tests/'+p.name]=p.read_bytes()
evidence['tests/test-backup-tool.ps1']=(o/'test-backup-tool.ps1').read_bytes()
for p in (o/'research').glob('*'):
 if p.suffix in ('.lua','.xml'):evidence['tests/research/'+p.name]=p.read_bytes()
for p in list(o.glob('*summary.json'))+list(o.glob('*results.json'))+list(o.glob('*.log'))+list(o.glob('*source-sha256.txt')):evidence['results/'+p.name]=p.read_bytes()
evidence['README.txt']=b'Offline synthetic fixtures and production-widget layout previews; not native gameplay verification. Inherited suite version labels describe fixture ancestry. The runner/source hash identifies tested 1.1.3 release code. Some inherited runtime/mock dependencies are not distributed. No personal saved history or signing material is included. Native client testing is separate from these offline results.\n'
evidenceZip=r/(stem+'-Test-Evidence.zip');archive(evidenceZip,evidence)
previews=r/(stem+'-UI-Previews.zip');archive(previews,{p.name:p.read_bytes() for p in [o/'command-preview.png',o/'settings-preview.png',o/'talents-preview.png',o/'talents-zoom-preview.png',o/'talents-right-preview.png']}|{'README.txt':b'Synthetic production-widget layouts, not in-game screenshots. Current spell icons are unavailable to this renderer. The quiet Omega/laurel emblem is original artwork generated from vector primitives.\n'})
backup=r/'OlympusChatWarden-Backup-Tool-v1.0.3.zip';assert sha(backup.read_bytes())=='496185fda6704fbcbc04c398fe375dd38d6f680f1f9aa0a02569fbf1fcdd1386'
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
artifacts=[addon,backup,validation,verification,evidenceZip,previews]+docs
checks=r/(stem+'-SHA256.txt');checks.write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in artifacts))
bundle=r/(stem+'-Release-Bundle.zip');archive(bundle,{p.name:p.read_bytes() for p in [checks]+artifacts})
with checks.open('a') as f:f.write(sha(bundle.read_bytes())+'  '+bundle.name+'\n')
print(json.dumps({'addon':proof['addon'],'bundle':bundle.name,'changed':len(changed),'added':len(added),'unchanged':len(unchanged),'offlineSuitesPassed':20,'nativeClientVerified':False},indent=2))
