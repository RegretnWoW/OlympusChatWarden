from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'synthetic-search-stress-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;C.Clear();local owner=C.Owner();local c=S.Character(owner,true)
local details={seconds=30,afk=false};local place={zone='Sentinel Needle'}
for n=1,200000 do
 c.events[n]={id=owner..':'..n,kind='time_slice',source='checkpoint',character=owner,at=1800000000+n*30,
 elapsed=n*30,details=details,location=place,session=owner..'/s1',timeSource='server',evidence='observed',schema=S.VERSION}
end
local Q=ns.WardenSearch;local job=Q.Begin('Sentinel Needle');local original=c.events;local enabled=ns.DB.enabled
local steps=0
repeat
 local count=job.processed;Q.Pump(job);check(job.processed-count<=128,'per-frame search work stays bounded')
 steps=steps+1;assert(steps<2000)
until job.done
check(job.matches.ChronicleWarden==200000 and #job.results==30,'all retained events checked with a bounded result list')
check(c.events==original and #c.events==200000 and ns.DB.enabled==enabled and not C.Active(),'search preserves evidence and opt-in state')
local locked=Q.Begin('Sentinel Needle');local beforeProcessed=locked.processed
local old=InCombatLockdown;InCombatLockdown=function() return true end
check(not Q.Pump(locked) and locked.processed==beforeProcessed,'large suite searches pause during combat');InCombatLockdown=old
local replacement=Q.Begin('Sentinel Needle');C.Clear();for n=1,100 do if Q.Pump(replacement) then break end end
check(replacement.done and replacement.stale,'large-history Clear invalidates the pending search')
local c2=S.Character(owner,true);c2.events={{id=owner..':1',kind='location',details={},location={zone='old'},source='control',character=owner}}
local late=Q.Begin('old');table.insert(c2.events,1,{id=owner..':2',kind='location',details={},location={zone='late'},source='control',character=owner})
for n=1,100 do if Q.Pump(late) then break end end
check(late.done and late.stale,'late insertion invalidates a shifted event snapshot instead of duplicating results')
searchStressSteps=steps;searchStressChecks=checks-before
''')
summary={'version':'1.1.0','assertions':int(lua.globals().searchStressChecks),'records':200000,'steps':int(lua.globals().searchStressSteps),'seconds':round(time.perf_counter()-started,3),'failed':0,'liveWoWTested':False}
(out/'search-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
