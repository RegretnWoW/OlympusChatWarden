from pathlib import Path
import json,time,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'ui-pass-host','exec'),scope);lua=scope['lua'];began=time.perf_counter()
lua.execute(r'''
local before=checks;local W,U=ns.Workspace,ns.WardenUI
local duel={kind='duel',startAt=100,lastAt=120,context={zone='Westfall'},opponentGUID='Player-UI-LATE',duel={accepted=true,result='win'}}
local names={identities={['Player-UI-LATE']={{at=110,name='Observed during duel'}}}}
check(ns.ChronicleActivitiesUI.Title(duel,names):find('Observed during duel',1,true) and ns.ChronicleActivitiesUI.Title(duel):find('Westfall',1,true),'duel name may be observed after challenge but within activity; compact fallback stays unchanged')
local ow,oh=UIParent:GetWidth(),UIParent:GetHeight();local effective=UIParent.GetEffectiveScale;local oldScale=ns.DB.workspaceScale
ns.DB.workspaceScale=nil;scaleCases=0;minimumBody=999
for _,screen in ipairs({{1366,768},{1920,1080},{2560,1600},{3840,2160}}) do for _,uiScale in ipairs({.64,.8,1}) do
 UIParent:SetSize(screen[1]/uiScale,screen[2]/uiScale);UIParent.GetEffectiveScale=function() return uiScale end
 local scale=W.Fit();local pixels=scale*uiScale
 check((W.width+2*W.leftOverhang)*pixels<=screen[1]+.01 and (W.height+2*W.bottomOverhang)*pixels<=screen[2]+.01,'automatic fit includes ornament at each screen and WoW scale')
 check(16*pixels>=12.8 and 28*pixels>=22,'document text and smallest primary button remain usable at target scales')
 minimumBody=math.min(minimumBody,16*pixels);scaleCases=scaleCases+1
end end
UIParent:SetSize(ow,oh);UIParent.GetEffectiveScale=effective;ns.DB.workspaceScale=oldScale;W.Fit()
freshRecording();units.target={guid='Player-UI-PASS',name='Αθηνά 長い名前',class='MAGE',level=30,guild='Olympus'};C.ObserveUnit('target','PLAYER_TARGET_CHANGED',true)
local st;while not st do ns.ChronicleActivities.Pump();st=ns.ChronicleActivities.Request(C.Owner()) end
W.Open('intel');local p=W.pages.intel;p.mode='all';p.selected=units.target.guid;p:Activate();p:Refresh(true)
check(p.currentRow and p.currentRow.id==units.target.guid,'Unicode player stays selected by exact GUID')
local text=p.document:GetText();check(text:find('Your history together',1,true) and not text:find('Tier 3',1,true),'default dossier leads with identity and history rather than a technical tier')
p.detailsToggle:GetScript('OnClick')();check(p.showDetails and p.document:GetText():find('Personal encounters',1,true),'full dossier details and uncertainty remain accessible')
p.detailsToggle:GetScript('OnClick')();p.note:SetText('Unsaved private note');p.noteDirty=true;p.scroll:SetVerticalScroll(42)
local e=st.intelligence.events[p.currentRow.refs[#p.currentRow.refs]] or st.events[p.currentRow.refs[#p.currentRow.refs]]
ns.RecordingUI.OpenSource(nil,e);local raw=W.pages.recording
check(W.current=='recording' and raw.sourceBack:IsShown(),'original evidence offers an explicit return action')
raw.sourceBack:GetScript('OnClick')()
check(W.current=='intel' and p.selected==units.target.guid and p.note:GetText()=='Unsaved private note' and p.noteDirty,'evidence return preserves exact selection and unsaved note')
check(p.scroll:GetVerticalScroll()==42,'dossier detail scroll survives evidence round trip')
p.scroll:SetVerticalScroll(70);p:Refresh(true);check(p.scroll:GetVerticalScroll()==70,'same-selection refresh does not jump to an older offset')
p.detail='gear';p:Activate();local gear=p.appearance;gear.view='history';gear:Bind(true);gear:Render()
check(not gear.unit and not gear.reset:IsEnabled() and not gear.status:GetText():find('rotate',1,true),'offline appearance has honest help and disabled controls')
check(ns.WardenDossier.TalentLabel({1,2,3,1,false,false})=='Talent name unavailable','talent fallback avoids a raw-ID title without inventing a name')
W.Open('overview');local home=W.pages.overview;home.chronicle:GetScript('OnClick')();check(W.current=='modules','Command module shortcut works')
W.Open('overview');home.intel:GetScript('OnClick')();check(W.current=='performance','Command performance shortcut works')
ns.BuildChronicleOptions();check(ns.ChronicleOptionsPanel.dangerZone~=nil,'history deletion has an isolated warning area')
check(ns.ChronicleStore.CONSENT==5 and ns.ChronicleStore.VERSION==6,'presentation does not change data/consent contracts')
uiRefinementChecks=checks-before
''')
protected=['ChronicleCoverage.lua','ChronicleTransitions.lua','ChronicleLoadout.lua','ChronicleDuels.lua','ChronicleProgress.lua','ChronicleStatistics.lua','ChronicleCodec.lua','Engine.lua','PackCrypto.lua','PackData.lua','TrustedPackKeys.lua']
with zipfile.ZipFile(root/'OlympusWarden-v1.1.0-rc5.zip') as z:
 for name in protected:assert z.read('OlympusChatWarden/'+name)==(root/'OlympusChatWarden'/name).read_bytes(),name
with zipfile.ZipFile(root/'OlympusWarden-v1.1.1-preview5.zip') as z:
 integration=z.read('OlympusChatWarden/OlympusIntegration.lua').decode().replace('\r\n','\n')
for before,after in [
 ('Open Olympus once to create the ChatWarden tab. /ocw opens Overview.','Open Olympus once to create the Warden tab. /ocw opens the Warden suite.'),
 ('Olympus required. Use /ocw to open ChatWarden while installing/updating it.','Olympus required. Use /ocw to open Warden while installing/updating it.'),
 ('Open ChatWarden after combat.','Open CommandWarden after combat.'),
 ('if SlashCmdList.OLYMPUSCHATWARDEN then SlashCmdList.OLYMPUSCHATWARDEN("options") end',"ns.Workspace.Open('settings')"),
 ('Left-click: Overview. Right-click: ChatWarden settings. Select messages in Messages to dismiss their alerts.','Left-click: CommandWarden. Right-click: CommandWarden settings. Open a recent activity entry to mark it read.')]:
 assert before in integration;integration=integration.replace(before,after)
for before,after in [('Olympus tab ready. Left-click for Overview; right-click for Settings.','Olympus tab ready. Open the Warden suite; right-click for CommandWarden settings.'),('Open Overview. Settings: /ocw settings.','Open CommandWarden. Settings: /ocw settings.')]:
 assert before in integration;integration=integration.replace(before,after)
assert integration==(root/'OlympusChatWarden/OlympusIntegration.lua').read_text(),'all native integration behavior outside the requested launcher changes remains unchanged'
result={'version':'1.1.0','failed':0,'assertions':int(lua.globals().uiRefinementChecks),'scaleCases':int(lua.globals().scaleCases),'minimumDocumentBodyPhysicalPixels':float(lua.globals().minimumBody),'protectedFilesUnchanged':protected,'actualForeverTest':False,'seconds':time.perf_counter()-began}
(out/'ui-refinement-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
