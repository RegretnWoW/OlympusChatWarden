from pathlib import Path
import json
out=Path(__file__).resolve().parent;root=out.parents[1]
setup=(out/'test-city.py').read_text().split('results={}')[0];exec(compile(setup,'attribution-host','exec'))
lua=host['fresh']('modern',True);lua.execute(fixture)
lua.execute('''
debugprofilestop=function() return os.clock()*1000 end
local P=ns.WardenPerformance;P.Slash('start')
for n=1,2000 do observe(n) end
for n=1,50 do ns.NameDisplays.Scan() end
for n=1,100 do ns.ChatFilter(DEFAULT_CHAT_FRAME,'CHAT_MSG_SAY','Ordinary city conversation '..n,'Fixture visitor') end
for n=1,100 do ns.ChronicleCapture.Pump();ns.ChronicleEvidence.Pump() end
ns.Workspace.Open('intel');ns.Workspace.pages.intel:Refresh(true)
for n=2001,2200 do observe(n) end
P.Report();timingRows=P.stats;P.active=false
for name,row in pairs(timingRows) do
 assert(not name:find('Citizen',1,true) and not name:find('Player-City-',1,true))
 for _,value in pairs(row) do assert(type(value)=='number') end
end
local spelling=ns.Spelling;collectgarbage('collect');dictionaryBefore=collectgarbage('count');dictionaryRawBytes=#ns.SpellingDictionary.data
while not spelling.ready do spelling.LoadStep() end
collectgarbage('collect');dictionaryAfter=collectgarbage('count');dictionaryWords=0;dictionaryBuckets=0
for _ in pairs(spelling.words) do dictionaryWords=dictionaryWords+1 end;for _ in pairs(spelling.buckets) do dictionaryBuckets=dictionaryBuckets+1 end
''')
rows={name:{k:v for k,v in row.items()} for name,row in lua.globals().timingRows.items()}
assert any(n.startswith('chat processing') for n in rows) and any('UI open' in n for n in rows) and any('UI closed' in n for n in rows)
result={'version':'1.1.0','failed':0,'synthetic':True,'actualForeverTest':False,'timingsInclusive':True,'rawMessagesOrIdentitiesLogged':False,'rows':rows,'dictionary':{'rawBytes':lua.globals().dictionaryRawBytes,'expandedWords':lua.globals().dictionaryWords,'buckets':lua.globals().dictionaryBuckets,'hostHeapDeltaKiB':lua.globals().dictionaryAfter-lua.globals().dictionaryBefore}}
(out/'attribution-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
