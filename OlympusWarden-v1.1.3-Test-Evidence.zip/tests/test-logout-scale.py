from pathlib import Path
import json,time,hashlib
out=Path(__file__).resolve().parent;root=out.parents[1]
# Native bit operations are enabled, JIT is disabled. No private history is read.
exec(compile((out/'native-runtime.py').read_text(),'native-runtime','exec'))
host={'__file__':str(out/'test-integration.py')};exec(compile((out/'test-integration.py').read_text().split('count=0')[0],'large-history-host','exec'),host)
host['prefix']=host['prefix'].replace('from lupa.lua51 import LuaRuntime','from __main__ import NativeRuntime as LuaRuntime')
lua=host['fresh']('modern',True)
fixture=(out/'benchmark.py').read_text();fixture=fixture[fixture.index(" S=ns.ChronicleStore"):fixture.index(" ''')")]
lua.execute(fixture);began=time.perf_counter();lua.globals().buildFixture(200000,600)
h=hashlib.sha256();lua.globals().digestUpdate=lambda s:h.update(s.encode());lua.globals().digestLedger();expected=h.hexdigest()
lua.execute('collectgarbage("collect");largeHeap=heap();local at=os.clock();S.PrepareLogout();largePackSeconds=os.clock()-at;packed=ns.DB.chronicle;largeChunks=#packed.characters[benchOwner].eventChunks+#packed.characters[benchOwner].profileChunks')
lua.execute('local at=os.clock();S.db=assert(S.Normalize(packed));ns.DB.chronicle=S.db;largeRestoreSeconds=os.clock()-at')
h=hashlib.sha256();lua.globals().digestUpdate=lambda s:h.update(s.encode());lua.globals().digestLedger();assert h.hexdigest()==expected
result={'version':'1.1.0','failed':0,'events':200000,'profiles':2000,'canonicalEventsAndProfilesEqual':True,'packCpuSeconds':lua.globals().largePackSeconds,'restoreCpuSeconds':lua.globals().largeRestoreSeconds,'preSaveHostHeapKiB':lua.globals().largeHeap,'chunks':lua.globals().largeChunks,'runtime':'LuaJIT interpreter with native bit operations; not actual WoW','nativeWatchdogTest':False,'seconds':time.perf_counter()-began}
(out/'logout-scale-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
