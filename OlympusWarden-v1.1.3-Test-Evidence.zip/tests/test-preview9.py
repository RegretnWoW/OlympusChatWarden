from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recording-baseline','exec'),scope)
lua=scope['lua'];lua.execute(r'''
local before=checks
local A,R,B=ns.ChronicleActivities,ns.RecordingUI,ns.ChronicleBackup
local function build(owner)
 local st=A.Request(owner);local steps=0
 while not st do A.Pump();st=A.Request(owner);steps=steps+1;assert(steps<10000) end
 return st
end
-- Exercise the real recorder startup, with GetTime advancing between reads.
clock=clock+1000;inside=true;instanceID=36
local originalTick=GetTime
GetTime=function() clock=clock+.013;return clock end
freshRecording();local owner=C.Owner();local c=ledger();local st=build(owner)
local runs=A.Query(st,{kind='dungeon'});local loc,entry
for _,e in ipairs(c.events) do if e.kind=='location' then loc=e elseif e.kind=='instance_enter' then entry=e end end
check(loc and entry and loc.elapsed~=entry.elapsed,'real startup fixture has different elapsed timestamps')
check(#runs==1 and runs[1].status=='open' and runs[1].partialStart,'real mid-dungeon opt-in produces one partial open segment')
check(runs[1].evidenceSet[loc.id] and runs[1].evidenceSet[entry.id] and runs[1].startupBoundary,'one startup activity retains both original records and its recording boundary')
local saved=B.Encode(c.events);A.Clear();st=build(owner)
check(#A.Query(st,{kind='dungeon'})==1 and B.Encode(c.events)==saved,'startup fix rebuilds without changing original history')
-- Reload inside a raid must start its own segment, then join only its own pair.
local oldInside,oldInfo=IsInInstance,GetInstanceInfo
IsInInstance=function() return true,'raid' end
GetInstanceInfo=function() return 'Molten Core','raid',9,'Raid',40,nil,nil,409 end
freshRecording();owner=C.Owner();st=build(owner)
check(#A.Query(st,{kind='raid'})==1,'real startup inside a raid also has one segment')
C.Handle('PLAYER_LOGOUT');C.Initialize();C.Handle('PLAYER_ENTERING_WORLD',false,true);st=build(owner)
local raids=A.Query(st,{kind='raid'})
check(#raids==2 and raids[1].status=='open' and raids[2].status=='interrupted','reload preserves two distinct recording boundaries without doubling either startup')
GetTime=originalTick;IsInInstance=oldInside;GetInstanceInfo=oldInfo;inside=false;instanceID=0;C.Clear()
-- Structural matching, not an expanded time window.
local testOwner='Fixture/Player-Test-START';local party={inInstance=true,instanceType='party',instanceID=36,instanceName='Deadmines'}
local raid={inInstance=true,instanceType='raid',instanceID=409,instanceName='Molten Core'}
local function make()
 local s=A.New(testOwner);local seq=0
 local function feed(kind,t,d,p,source,session)
  seq=seq+1;local e=assert(S.Event({schema=S.VERSION,id=testOwner..':'..seq,character=testOwner,
   session=testOwner..'/s'..(session or 1),kind=kind,source=source or 'control',at=1800000000+math.floor(t),elapsed=t,
   evidence='observed',timeSource='server',details=d or {},location=p or party},testOwner))
  A.Feed(s,e);return e
 end
 return s,feed
end
local function startup(modifier)
 local s,feed=make();feed('recording_start',10,{reason='recording-enabled'});feed('character_snapshot',10.1,{name='Player'})
 local location=feed('location',10.99)
 if modifier then modifier(feed) end
 local entry=feed('instance_enter',11.01,{reason='recording-started-inside'})
 return s,feed,location,entry
end
local s,feed,l,e=startup()
check(#A.Query(s,{kind='dungeon'})==1 and s.active.evidenceSet[l.id] and s.active.evidenceSet[e.id],'startup pair crosses a wall-clock second while preserving both evidence references')
feed('instance_exit',12);feed('instance_enter',12.1)
check(#A.Query(s,{kind='dungeon'})==2,'actual exit/re-entry to same map is never merged into startup')
local gap=startup(function(f) f('collection_gap',11,{reason='gap'}) end)
check(#A.Query(gap,{kind='dungeon'})==2,'an intervening recording gap cancels startup matching')
local roster=startup(function(f) f('group_roster',11,{members={},knownMembers=0,sameGuildMembers=0}) end)
check(#A.Query(roster,{kind='dungeon'})==2,'a later entry after roster activity is not treated as the startup pair')
s,feed=make();feed('recording_start',10);feed('location',10.1);feed('instance_enter',10.2)
check(#A.Query(s,{kind='dungeon'})==2,'normal entry without the explicit started-inside reason is not loosely merged')
s,feed=make();feed('location',10);feed('instance_enter',10.1,{reason='recording-started-inside'})
check(#A.Query(s,{kind='dungeon'})==2,'missing recording boundary does not justify guessed merging')
s,feed=make();feed('recording_start',10);feed('location',10.1);feed('instance_enter',10.2,{reason='recording-started-inside'},raid)
check(#A.Query(s,{kind='dungeon'})==1 and #A.Query(s,{kind='raid'})==1,'different instance contexts cannot join a startup pair')
s,feed=make();feed('recording_start',10);feed('location',10.1);feed('instance_enter',10.2,{reason='recording-started-inside'},nil,'PLAYER_ENTERING_WORLD')
check(#A.Query(s,{kind='dungeon'})==2,'different source sequences are not combined')
s,feed=make();feed('recording_start',10);feed('location',10.1);feed('instance_enter',10.2,{reason='recording-started-inside'},nil,nil,2)
check(#A.Query(s,{kind='dungeon'})==2,'different recording sessions cannot join a startup pair')
s,feed=make();feed('recording_start',10);feed('location',10.1);feed('instance_enter',9.9,{reason='recording-started-inside'})
check(#A.Query(s,{kind='dungeon'})==2,'clock regression interrupts startup matching')
-- A mixed real ledger: native actions and native background summaries share a kind.
C.Clear();owner=C.Owner();c=S.Character(owner,true);c.currentSession=owner..'/s1';c.sessionSequence=1
local n=0
local function append(kind,d,source,location,subject)
 n=n+1;return assert(S.Append(owner,{kind=kind,source=source or 'checkpoint',session=c.currentSession,
 at=1800001000+n,elapsed=1000+n,timeSource='server',evidence='observed',details=d or {},location=location or {},subject=subject}))
end
local actions={}
actions[#actions+1]=append('level_change',{before=4,after=5},'PLAYER_LEVEL_UP')
actions[#actions+1]=append('quest_turnin',{questID=123},'QUEST_TURNED_IN')
actions[#actions+1]=append('player_death',{},'PLAYER_DEAD')
local enter=append('instance_enter',{},nil,party)
actions[#actions+1]=enter
local friend='Player-Test-FRIEND';local other='Player-Test-OTHER'
append('group_roster',{members={friend},knownMembers=1,sameGuildMembers=0},'GROUP_ROSTER_UPDATE',party)
actions[#actions+1]=append('native_event',{recordType='encounter_ended',encounterID=10,success=1,name='Boss'},'ENCOUNTER_END',party)
actions[#actions+1]=append('native_event',{recordType='native_craft_result',itemID=123,quantity=1},'TRADE_SKILL_ITEM_CRAFTED_RESULT')
append('native_event',{recordType='pvp_counter_snapshot',lifetimeHK=10},'PLAYER_PVP_KILLS_CHANGED')
append('native_event',{recordType='currency_observed',currencyID=1,after=20},'CURRENCY_DISPLAY_UPDATE')
append('native_event',{recordType='collector_session'},'control')
append('location',{},'ZONE_CHANGED')
append('character_snapshot',{name='Initial snapshot'})
append('player_observed',{name='Friend',encounter=true,localSighting=true},'PLAYER_TARGET_CHANGED',{},friend)
append('inventory_observed',{bagID=0,slot=1,hasCurrent=false})
append('bind_observed',{name='Initial home'},'control')
actions[#actions+1]=append('bind_observed',{name='New home'},'HEARTHSTONE_BOUND')
local allRaw=B.Encode(c.events);local rawCount=#c.events
local events=R.Query({mode='events'});local expected={};for _,a in ipairs(actions) do expected[a.id]=true end
local valid=#events==#actions;for _,item in ipairs(events) do if not expected[item.id] then valid=false end end
check(valid,'Events view includes real actions while hiding observations and background native subtypes')
local allData=R.Query({mode='all'});check(#allData==rawCount,'All recorded data exposes the complete small ledger')
check(R.Title(actions[5])=='Boss encounter ended' and R.Title(actions[6])=='Item crafted','meaningful native rows have readable action titles')
local nativeOnly=R.Query({mode='all',kinds={native_event=true}})
check(#nativeOnly==5,'explicit type selection can inspect native actions and background summaries together')
ns.Workspace.Open('recording');local host=ns.Workspace.pages.recording;host:SetView('events')
check(host.filter.mode=='events' and #host.list.items==#actions,'first opening defaults to the quiet event view')
check(host.recordMode:GetText()=='View: Events  v','default view is labelled in the UI')
click(host.recordMode);click(host.recordMode.MenuRows[2])
check(host.filter.mode=='all' and #host.list.items==rawCount,'actual dropdown click exposes background data')
click(host.typeFilter);click(host.typeFilter.MenuRows[2]) -- Clear selection.
local locationRow;for _,row in ipairs(host.typeFilter.MenuRows) do if row.choice[1]=='location' then locationRow=row end end
click(locationRow);check(host.filter.mode=='all' and #host.list.items==1 and host.list.items[1].kind=='location','manual inclusion of an observation works without a hidden profile veto')
host:SetView('backup');host:SetView('events')
check(host.filter.kinds.location and host.filter.mode=='all','tab navigation preserves the explicit custom filter')
host:SetRecordMode('events');check(not host.filter.kinds and #host.list.items==#actions,'Events preset restores its quiet view explicitly')
host.selected=actions[1].id;host.detailDocument:SetBlocks(R.Detail(actions[1]));host.filter.search='impossible';host.dirty=true;host:Refresh(true)
check(not host.selected and host.detailDocument:GetText():find('Your recording history',1,true),'record filtering clears an excluded source selection')
host.filter.search=nil;host.dirty=true;host:Refresh(true)
check(B.Encode(c.events)==allRaw and #c.events==rawCount and not S.db.enabled,'filter profiles do not change collection, retention or saved evidence')
-- Select an activity, then exclude it through search, kind, player and page.
append('instance_exit',{},nil,party);append('instance_enter',{},nil,raid)
append('group_roster',{members={other},knownMembers=1,sameGuildMembers=0},'GROUP_ROSTER_UPDATE',raid)
st=build(owner);host:SetView('activities');local view=host.activities
view.filter={page=0};view:Refresh(true)
local function selectKind(kind)
 for _,a in ipairs(view.list.items) do if a.kind==kind then view.selected=a.id;view:ShowActivity(a);return a end end
 error('No visible '..kind)
end
selectKind('dungeon');check(#view.people==2 and #view.sources>1,'selected activity supplies its own player and source choices')
view.filter.search='no matching activity';view.dirty=true;view:Refresh(true)
check(not view.selected and #view.people==1 and #view.sources==1 and not view.openSource:IsEnabled(),'search exclusion clears activity, people, sources and source actions together')
check(not view.document:GetText():find('Activity: ',1,true),'excluded activity details are no longer shown')
view.filter.search=nil;view.dirty=true;view:Refresh(true);selectKind('dungeon')
view.filter.kind='raid';view.dirty=true;view:Refresh(true)
check(not view.selected and #view.people==1,'activity-kind filter clears a now-excluded selection')
view.filter.kind=nil;view.dirty=true;view:Refresh(true);selectKind('dungeon')
view.filter.guid=other;view.dirty=true;view:Refresh(true)
check(not view.selected and #view.people==1 and view.peopleMenu:GetText()=='Player in selected activity  v','player filter keeps global intent without stale roster dropdown entries')
view.filter.guid=nil;view.dirty=true;view:Refresh(true);selectKind('dungeon');view.filter.page=1;view.dirty=true;view:Refresh(true)
check(not view.selected and #view.people==1 and #view.sources==1,'paging away clears hidden selection')
view.filter.page=0;view.dirty=true;view:Refresh(true);selectKind('dungeon');view.selected=nil;view:ShowActivity(nil)
check(#view.people==1 and view.sourceID==nil and not view.nextSources:IsEnabled(),'explicit deselection clears all dependent controls')
selectKind('dungeon');local sourceID=view.sourceID;click(view.openSource)
check(host.view=='events' and host.filter.mode=='all' and host.filter.eventID==sourceID and host.selected==sourceID,'source drill-down deliberately bypasses the event-only default')
check(host.detailDocument:GetText():find(sourceID,1,true),'source drill-down displays its original record')
C.Clear();check(#view.people==1 and #view.sources==1 and not view.selected,'Clear also removes stale player/source choices')
check(ns.VERSION=='1.1.1-preview8' and #ns.UpdateHistory==6 and ns.UpdateHistory[2].version=='1.1.0' and ns.UpdateHistory[3].version=='1.0.3','preview naming preserves published 1.1.0 and 1.0.3 update history')
check(forbiddenRegistrations==0,'this pass never probes restricted combat-log access')
preview9Checks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().preview9Checks),'failed':0,'liveWoWTested':False,
 'coverage':'real advancing-clock dungeon/raid startup and reload; conservative negative boundaries; event subtype presets; selection/filter/source synchronization; preservation; corrected release naming'}
(out/'preview9-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
