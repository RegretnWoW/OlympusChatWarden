from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recording-host','exec'),scope)
lua=scope['lua'];lua.globals().fixtureClock=time.perf_counter;started=time.perf_counter()
lua.execute(r'''
local before=checks
local R,B,I=ns.RecordingUI,ns.ChronicleBackup,ns.ChronicleEncounters
local function wait(f)
 local rows,more,total,revision;local steps=0
 repeat rows,more,total,revision=R.Request(f);steps=steps+1;assert(steps<20000) until rows
 return rows,more,total,steps
end
local function ids(rows) local a={};for _,e in ipairs(rows) do a[#a+1]=e.id end;return table.concat(a,'|') end
-- Real existing encounter collector, not an invented local-sighting row.
freshRecording();local owner=C.Owner();local c=ledger()
local wantedGUID='Player-Test-WANTED';units.target={guid=wantedGUID,name='Wanted Person',class='MAGE',level=30}
local previousWanted=ns.Wanted.byGUID;ns.Wanted.byGUID={[wantedGUID]={}}
I.Observe('target','PLAYER_TARGET_CHANGED')
local wanted;for _,e in ipairs(c.events) do if e.kind=='important_player' and e.subject==wantedGUID then wanted=e end end
check(wanted and wanted.details.unitVisible==true and R.IsEvent(wanted),'real visible Wanted target is notable without adding a collector')
check(R.Title(wanted)=='Wanted encounter','local Wanted row has a clear event title')
local found=false;for _,e in ipairs(wait({mode='events'})) do if e.id==wanted.id then found=true end end
check(found,'default browser surfaces the real saved Wanted encounter')
local function append(kind,d,source,subject,at)
 return assert(S.Append(owner,{kind=kind,details=d or {},source=source or 'checkpoint',subject=subject,
 at=at or GetServerTime()+100+#c.events,elapsed=1000+#c.events,timeSource='server',evidence='observed',session=c.currentSession,location={}}))
end
local remote=append('important_player',{name='Remote list',relationship='Wanted encounter',unitVisible=true},'WANTED_CHANGED',wantedGUID)
check(not R.IsEvent(remote),'remote public update never becomes a local Wanted encounter even with a visibility-shaped flag')
local oldVisible=UnitIsVisible;UnitIsVisible=function(unit) return unit=='player' end
local remoteGUID='Player-Test-REMOTE';units.focus={guid=remoteGUID,name='Remote Focus'};ns.Wanted.byGUID[remoteGUID]={}
clock=clock+1000;I.Observe('focus','PLAYER_FOCUS_CHANGED');local remoteUnit=c.events[#c.events]
check(remoteUnit.kind=='important_player' and remoteUnit.details.unitVisible==false and not R.IsEvent(remoteUnit),'actual nonvisible focus record stays out of notable Events')
UnitIsVisible=oldVisible;ns.Wanted.byGUID=previousWanted;units.target=nil;units.focus=nil
check(not R.IsEvent({kind='important_player',subject=wantedGUID,source='PLAYER_TARGET_CHANGED',details={relationship='Wanted encounter'}}),'older Wanted record with missing visibility remains uncertain')
check(not R.IsEvent({kind='important_player',source='PLAYER_TARGET_CHANGED',details={relationship='Wanted encounter',unitVisible=true}}),'missing GUID cannot establish a local Wanted identity')
local restored={};for k,v in pairs(wanted) do restored[k]=v end;restored.restored=true
check(R.IsEvent(restored) and table.concat((function() local t={};for _,b in ipairs(R.Detail(restored)) do t[#t+1]=b.text end;return t end)(),' '):find('not an independent observation',1,true),'restored local evidence stays browseable with its original backup warning')
C.Clear();c=S.Character(owner,true);c.currentSession=owner..'/s1';c.sessionSequence=1
local action=append('native_event',{recordType='encounter_ended',encounterID=9,name='Test Boss',success=1},'ENCOUNTER_END')
append('native_event',{recordType='pvp_counter_snapshot',lifetimeHK=10},'PLAYER_PVP_KILLS_CHANGED')
append('native_event',{recordType='currency_observed',currencyID=1,after=20},'CURRENCY_DISPLAY_UPDATE')
local base=B.Encode(c.events)
local actions=R.Query({mode='all',kinds={native_actions=true}})
local backgrounds=R.Query({mode='all',kinds={native_background=true}})
check(#actions==1 and actions[1].id==action.id,'native actions filter selects the meaningful subtype only')
check(#backgrounds==2 and not R.IsEvent(backgrounds[1]) and not R.IsEvent(backgrounds[2]),'native background filter selects counters and currency summaries separately')
check(#R.Query({mode='all',kinds={native_event=true}})==3,'explicit Native activity (all) retains complete subtype access')
check(#R.Query({mode='all',kinds={native_actions=true,native_background=true}})==3,'native subgroup choices combine without duplicates')
check(#R.Query({mode='all',kinds={native_actions=true},search='pvp_counter_snapshot'})==0,'native subgroup and literal search combine')
ns.Workspace.Open('recording');local p=ns.Workspace.pages.recording;p:SetView('events');p:SetRecordMode('events')
click(p.typeFilter);local choices={};for _,row in ipairs(p.typeFilter.MenuRows) do choices[row.choice[1]]=row end
check(choices.native_actions.Check:IsShown() and not choices.native_background.Check:IsShown() and not choices.native_event.Check:IsShown(),'Events checklist accurately distinguishes native actions from all native activity')
click(choices.location)
check(p.filter.kinds.native_actions and not p.filter.kinds.native_event and not p.filter.kinds.native_background,'adding an observation to Events does not silently add native background summaries')
click(choices["none"]);click(choices.native_background)
check(#p.list.items==2 and p.filter.mode=='all','real multiselect callback can show background-only data')
click(choices.native_event)
check(#p.list.items==3 and not p.filter.kinds.native_background,'all-native option replaces subgroup aliases cleanly')
click(choices.native_actions)
check(#p.list.items==2 and not p.filter.kinds.native_event and p.filter.kinds.native_background and not p.filter.kinds.native_actions,'unchecking actions from all native activity keeps background summaries')
click(choices.native_background);check(#p.list.items==0,'unchecking both native groups gives a genuinely empty selection')
check(B.Encode(c.events)==base,'Wanted/native filtering preserves every original byte of the small ledger')
-- Cooperative results agree with the legacy direct query, including paging,
-- character scope, raw ID lookup and literal metacharacters.
for _,f in ipairs({{mode='events'},{mode='all'},{mode='events',search='not present [.*]'},
 {mode='all',kinds={native_actions=true}},{mode='all',kinds={native_background=true}},
 {mode='all',eventID=wanted.id,raw=true},{mode='events',owner=owner,since=wanted.at},
 {mode='all',kinds={}},{mode='events',page=1}}) do
 local expected,more,total=R.Query(f);local actual,amore,atotal=wait(f)
 check(ids(actual)==ids(expected) and more==amore and total==atotal,'cooperative results preserve query semantics: '..(f.search or f.kind or f.eventID or f.mode))
end
C.Clear();p:SetView('backup')
-- Five years, two characters, 200,000 mostly background records including routes.
-- Build through the real validator/appender; no actual player history is read.
local owners={C.Owner(),'Other Realm/Player-Other-SPARSE'}
for n,key in ipairs(owners) do
 local ch=S.Character(key,true);ch.currentSession=key..'/s1';ch.sessionSequence=1
 for i=1,100000 do
  local at=1600000000+i*1578;local t={kind='location',source='checkpoint',at=at,elapsed=i*1578,session=ch.currentSession,
   timeSource='server',evidence='observed',details={},location={zone='Sparse fixture'}}
  if i%2500==0 then t.kind='level_change';t.details={before=i/2500,after=i/2500+1}
  elseif i%10==0 then t.kind='route_segment';t.details={segment=key..':route:'..i,pointCount=1};t.route={format=1,mapID=37,points={{at,t.elapsed,.3,.4,false,false,false,false,0,at,t.elapsed,1}}}
  elseif i%3==0 then t.kind='native_event';t.details={recordType='pvp_counter_snapshot',lifetimeHK=i};t.source='PLAYER_PVP_KILLS_CHANGED' end
  assert(S.Append(key,t))
 end
end
sparseRecords=200000;sparseYears=(1578*100000)/(86400*365.25)
local rawRefs={};for _,key in ipairs(owners) do local ch=S.Character(key,false);rawRefs[key]={events=ch.events,count=#ch.events,tail=ch.events[#ch.events],bytes=ch.bytes,sequence=ch.sequence} end
R.ClearIndex();local start=fixtureClock();local rows=R.Request({mode='events'});coldRequestSeconds=fixtureClock()-start
local progress=R.Progress()
check(not rows and progress.indexed==R.BUDGET,'cold sparse-history request returns after one bounded chunk rather than scanning the ledger')
local combat=InCombatLockdown;InCombatLockdown=function() return true end
check(R.Pump()==0 and R.Progress().indexed==progress.indexed,'browser indexing pauses in combat')
InCombatLockdown=combat
local iterations=0;local maxWork=0;local maxPump=0
repeat local pumpStart=fixtureClock();local used=R.Pump();maxPump=math.max(maxPump,fixtureClock()-pumpStart);maxWork=math.max(maxWork,used);iterations=iterations+1;assert(iterations<10000) until R.Progress().complete
sparsePumps=iterations;sparseMaxWork=maxWork;sparseMaxPumpSeconds=maxPump
local indexedRows,more,total=R.Request({mode='events'})
check(iterations>1500 and maxWork<=128 and #indexedRows==50 and more and total==200000,'five-year default Events index is cooperative, paged and complete across both characters')
local expected,expectedMore=R.Query({mode='events'})
check(ids(indexedRows)==ids(expected) and more==expectedMore,'sparse index preserves ordering and pagination against a direct query')
local cachedStart=fixtureClock();local reused=R.Request({mode='events'});warmRequestSeconds=fixtureClock()-cachedStart
check(reused==indexedRows,'unchanged refresh reuses its page instead of scanning years again')
local page2,more2=wait({mode='events',page=1});local expected2,emore2=R.Query({mode='events',page=1})
check(#page2==30 and not more2 and ids(page2)==ids(expected2) and more2==emore2,'older sparse page reaches every retained milestone without duplicates')
-- Opening actual widgets does not hide an unbounded statistics scan behind the index.
local stats,storage=C.Statistics,S.Storage
C.Statistics=function() error('browser must not calculate full statistics on open') end
S.Storage=function() error('browser must not calculate full storage on open') end
R.ClearIndex();start=fixtureClock();p:SetView('events');p:SetRecordMode('events');coldUISeconds=fixtureClock()-start
check(p.waiting and #p.list.items==0,'cold production UI shows loading state without a full stats scan')
local spins=0;while p.waiting do p.scripts.OnUpdate(p,.016);spins=spins+1;assert(spins<10000) end
check(#p.list.items==50 and not p.detailDocument:GetText():find('Loading recorded history',1,true),'production update loop completes the sparse view and clears its loading document')
C.Statistics=stats;S.Storage=storage;ns.Art.CloseMenus()
for _,key in ipairs(owners) do local ch=S.Character(key,false);local raw=rawRefs[key]
 check(ch.events==raw.events and #ch.events==raw.count and ch.events[#ch.events]==raw.tail and ch.bytes==raw.bytes and ch.sequence==raw.sequence,'browser never replaces or modifies the saved ledger/accounting for '..key)
end
owner=owners[1];c=S.Character(owner,false)
local newest=append('level_change',{before=41,after=42},'PLAYER_LEVEL_UP',nil,1800000000)
local added=wait({mode='events'});check(added[1].id==newest.id and R.Progress().indexed==1,'ordinary append extends the sparse index by one original record')
-- An append during the cold pass cannot cause endless restart/starvation.
R.ClearIndex();R.Request({mode='events'});append('location',{},'checkpoint',nil,1800000001)
wait({mode='events'});local catchup=wait({mode='events'})
check(catchup[1].id==newest.id and R.Progress().indexed<=1,'append during indexing finishes its stable prefix then catches up incrementally')
local backdated=append('level_change',{before=1,after=2},'PLAYER_LEVEL_UP',nil,1600000001)
local historical=wait({mode='events',owner=owner,page=0});local old=wait({mode='events',owner=owner,page=1})
check(#historical==42 and not next(old) and historical[#historical].id==backdated.id,'out-of-order insertion invalidates the affected index and preserves older evidence')
local absent,_,_,steps=wait({mode='all',search='absent from all raw records'})
check(#absent==0 and steps>1500,'rare All data search also yields rather than monopolizing a frame')
R.ClearIndex();local mutable={mode='events',search='nothing here'};R.Request(mutable);mutable.mode='all';mutable.search=nil;mutable.eventID=newest.id
local redirected=wait(mutable);check(#redirected==1 and redirected[1].id==newest.id,'changing filters during a long scan cancels stale results and opens the exact requested source')
local otherOnly=wait({mode='events',owner=owners[2]});check(#otherOnly==40 and otherOnly[1].character==owners[2],'character scope cannot borrow another character milestones')
local ownerEvents=c.events;S.Initialize();check(S.Character(owner,false).events~=ownerEvents,'normal reload replaces ledgers in the fixture')
local reloaded=wait({mode='events',owner=owner});check(ids(reloaded)==ids(historical),'reloaded/replaced ledger rebuilds from original events')
R.ClearIndex();R.Request({mode='events'});C.Clear()
check(not R.Progress() and #wait({mode='events'})==0 and next(S.db.characters)==nil,'Clear cancels pending browse work and removes stale index references')
local db=S.db;S.blocked=true;check(#wait({mode='events'})==0,'blocked saved history does not leave an endless loading state');S.blocked=false;S.db=db
check(ns.VERSION=='1.1.1-preview8' and ns.UpdateHistory[2].version=='1.1.0' and ns.UpdateHistory[3].version=='1.0.3' and forbiddenRegistrations==0,'private preview naming, prior public releases and native access boundaries remain')
preview10Checks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().preview10Checks),'failed':0,'liveWoWTested':False,
 'sparseHistory':{'records':int(lua.globals().sparseRecords),'modeledYearsPerCharacter':round(float(lua.globals().sparseYears),2),'characters':2,
 'coldRequestHostSeconds':round(float(lua.globals().coldRequestSeconds),6),'warmRequestHostSeconds':round(float(lua.globals().warmRequestSeconds),6),
 'twoColdUIRequestsHostSeconds':round(float(lua.globals().coldUISeconds),6),'maxRecordsPerPump':int(lua.globals().sparseMaxWork),'coldPumps':int(lua.globals().sparsePumps),'maxIndexPumpHostSeconds':round(float(lua.globals().sparseMaxPumpSeconds),6)},
 'totalFixtureHostSeconds':round(time.perf_counter()-started,3),
 'coverage':'real visible/nonvisible Wanted collector; no remote sightings; native subfilters and real UI callbacks; direct/cooperative equivalence; sparse history and cold production UI; combat; append/out-of-order/reload/Clear; unchanged original records'}
(out/'preview10-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
