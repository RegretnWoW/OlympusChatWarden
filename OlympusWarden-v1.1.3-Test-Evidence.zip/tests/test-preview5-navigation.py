from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'navigation-host','exec'),scope)
lua=scope['lua'];lua.execute((out/'policy-fixture.lua').read_text());start=time.perf_counter()
lua.execute(r'''
local before=checks;local F,A,U,W,G,P=Preview5,ns.ChronicleActivities,ns.WardenUI,ns.Workspace,ns.WardenDossier,ns.OlympusPanel
local c=F.Fresh();local one,two='Player-Link-ONE','Player-Link-TWO'
local old=F.Emit('quest_turnin',1,{questID=1000},'QUEST_TURNED_IN')
local entry=F.Emit('instance_enter',10,{},'ZONE_CHANGED_NEW_AREA',nil,F.raid)
F.Observe(11,one,'Same Name',F.raid);F.Observe(12,two,'Same Name',F.raid)
F.Emit('group_roster',13,{members={one,two},knownMembers=2,sameGuildMembers=0},'GROUP_ROSTER_UPDATE',nil,F.raid)
local inspect=F.Emit('important_player',14,{relationship='manual inspection'},'INSPECT_READY',one,F.raid)
F.Emit('instance_exit',20,{},'ZONE_CHANGED_NEW_AREA',nil,F.raid)
for n=1,70 do F.Emit('quest_turnin',30+n,{questID=1000+n},'QUEST_TURNED_IN') end
local st=F.Build();local activity
for _,a in ipairs(st.activities) do if a.kind=='raid' then activity=a end end;assert(activity)
local eventsBefore=ns.ChronicleBackup.Encode(c.events);local sequence=c.sequence
check(U.Navigate('player',F.owner,one,inspect),'GUID dossier navigation accepted')
check(W.current=='intel' and W.pages.intel.selected==one,'inspection opens correct dossier despite duplicate display name')
local p=W.pages.intel;click(p.detailsToggle);check(p.document:GetText():find('Tier 1',1,true),'secondary dossier details retain explicit tier and reasons')
click(p.shared);check(W.current=='chronicle' and W.pages.chronicle.activities.filter.guid==one,'dossier shared activity action uses exact GUID')
check(W.pages.chronicle.back:IsShown(),'shared activity view has a return path to the dossier')
click(W.pages.chronicle.back);check(W.current=='intel' and W.pages.intel.selected==one,'Back returns to the exact player')
U.Navigate('activity',F.owner,activity.id,entry);local view=W.pages.chronicle.activities
check(W.current=='chronicle' and view.selected==activity.id,'activity opens its meaningful Chronicle destination')
check(#view.people==3 and not view.dossier:IsEnabled(),'multiple roster names require an explicit player selection')
view.personGUID=two;view:ShowActivity(activity);click(view.dossier)
check(W.current=='intel' and W.pages.intel.selected==two and W.pages.intel.returnTo.id==activity.id,'selected associated roster player opens a dossier with return context')
click(W.pages.intel.back);check(W.current=='chronicle' and W.pages.chronicle.activities.selected==activity.id,'Back preserves original activity selection')
view=W.pages.chronicle.activities;click(view.openSource)
check(W.current=='recording' and W.pages.recording.selected~=nil,'source action works from standalone Chronicle without raw browser controls on its host')
local absent=true;for _,r in ipairs(U.Highlights(st)) do if r.id==old.id then absent=false end end
check(absent,'old quest fixture is outside the bounded Highlights list')
U.Navigate('highlight',F.owner,old.id,old)
check(W.current=='chronicle' and W.pages.chronicle.selected==old.id and W.pages.chronicle.currentRow.event==old,'an old linked milestone remains reachable beyond recent highlight limits')
local original=ns.RecordingUI.OpenSource;local opened;ns.RecordingUI.OpenSource=function(_,e) opened=e end
click(W.pages.chronicle.open);check(opened==old,'linked highlight retains its exact original evidence');ns.RecordingUI.OpenSource=original
local score=F.Snapshot(110,'scoreboard',{guid=one,name='Same Name',runID='report-A',matchSequence=1,rowIndex=1,killingBlows=2,deaths=3})
F.Snapshot(111,'scoreboard',{guid=two,name='Same Name',runID='report-A',matchSequence=1,rowIndex=2,killingBlows=5,deaths=0})
st=F.Build();U.Navigate('scores',F.owner,one,nil,{kind='player',owner=F.owner,id=one})
check(W.pages.intel.mode=='scoreboards' and W.pages.intel.deep.guidFilter==one,'player-scoped PvP reports open inside IntelWarden')
check(#W.pages.intel.deep.rows==1 and W.pages.intel.deep.rows[1].data.capture.values.guid==one,'same-name scoreboard participants do not cross-link')
click(W.pages.intel.back);check(W.pages.intel.selected==one,'PvP report view returns to player dossier')
-- Direct compact links route to modules, not to a name or the currently targeted unit.
units.target={guid=two,name='Same Name'}
P.OpenRecord({wardenModule='intel',owner=F.owner,guid=one,event=inspect})
check(W.current=='intel' and W.pages.intel.selected==one,'compact Intel link ignores a switched target')
P.OpenRecord({wardenModule='chronicle',owner=F.owner,event=entry,activity=activity})
check(W.current=='chronicle' and W.pages.chronicle.activities.selected==activity.id,'compact activity opens the corresponding Chronicle activity')
local sourceFallback
ns.RecordingUI.OpenSource=function(_,e) sourceFallback=e end
U.Navigate('player',F.owner,'Player-Link-MISSING',old)
check(sourceFallback==old,'missing exact dossier uses original source fallback')
ns.RecordingUI.OpenSource=original
check(ns.ChronicleBackup.Encode(c.events)~=eventsBefore and c.sequence>sequence,'fixture extended only by explicit new evidence')
local bytes=ns.ChronicleBackup.Encode(c.events);local seq=c.sequence
C.SetEnabled(false);U.Navigate('player',F.owner,one);U.Navigate('history',F.owner,one);U.Navigate('highlight',F.owner,old.id,old)
check(not C.Active() and c.sequence==seq and ns.ChronicleBackup.Encode(c.events)==bytes,'navigation while paused does not record, inspect or mutate historical evidence')
-- UI cache lookup must never fall back to own/local specialization or a different ID.
GetSpecializationInfoByID=function(id) return id,'Verified native name','Description','native-spec-icon' end
local name,icon=G.Specialization(62);check(name=='Verified native name' and icon=='native-spec-icon','supported specialization metadata resolves the recorded ID')
GetSpecializationInfoByID=function() return 63,'Wrong spec',nil,'wrong-icon' end
check(G.Specialization(62)==nil,'mismatched specialization metadata is rejected');GetSpecializationInfoByID=nil
check(G.Specialization(62)==nil,'unavailable specialization resolver retains raw-ID fallback')
-- Rebrand regression: status refresh cannot overwrite module identity.
W.Open('shield');W.Refresh();check(W.pageIcon.texture:find('ShieldWardenSmall.tga',1,true),'ShieldWarden header retains its module logo after feature refresh')
local shield=W.pages.shield;shield:Refresh();check(shield.senderIcon.texture:find('ShieldWardenSmall.tga',1,true),'ShieldWarden empty dossier uses the ShieldWarden emblem')
local enabled=ns.DB.shield.enabled;ns.DB.shield.enabled=false;W.Refresh();check(W.pageIcon.texture:find('ShieldWardenSmall.tga',1,true) and W.pageIcon.alpha==.35 and W.pageIconButton.StateMark.label:GetText()=='OFF','paused Shield keeps module logo with a dimmed state and explicit OFF marker')
ns.DB.shield.enabled=enabled;W.Open('chronicle');check(W.pageIcon.alpha==1,'other headers do not inherit paused-icon alpha')
-- Cooperative deferred lookup and combat/navigation cancellation.
A.Clear();W.Open('overview');U.Navigate('player',F.owner,one,inspect);check(U.pending~=nil,'uncached dossier navigation waits for the shared index')
units.target={guid=two,name='Same Name'};st=F.Build();U.PumpNavigation()
check(not U.pending and W.current=='intel' and W.pages.intel.selected==one,'deferred lookup keeps the clicked GUID after target switch')
local combatBefore=InCombatLockdown;InCombatLockdown=function() return true end
U.Navigate('highlight',F.owner,old.id,old);check(U.pending~=nil and W.current=='intel','navigation waits during combat')
InCombatLockdown=combatBefore;U.PumpNavigation();check(not U.pending and W.current=='chronicle' and W.pages.chronicle.selected==old.id,'navigation resumes after combat with exact source')
A.Clear();U.Navigate('player',F.owner,one,inspect);W.Open('settings');st=F.Build();U.PumpNavigation()
check(W.current=='settings' and not U.pending,'new user navigation cancels a pending destination')
A.Clear();U.Navigate('player',F.owner,one,inspect);C.Clear();U.PumpNavigation()
check(not U.pending,'clearing history cancels pending source navigation')
check(forbiddenRegistrations==0,'new navigation never registers restricted events')
navigationChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().navigationChecks,'failed':0,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'preview5-navigation-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
