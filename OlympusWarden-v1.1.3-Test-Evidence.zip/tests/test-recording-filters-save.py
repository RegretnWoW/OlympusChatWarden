from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];lua.execute(r'''
local beforeChecks=checks
local B,R=ns.ChronicleBackup,ns.RecordingUI
freshRecording();C.SetEnabled(false)
ns.Workspace.Open('recording');drain()
local view=ns.Workspace.pages.recording;local filter=view.typeFilter
click(filter)
check(filter.Menu:IsShown() and filter.Menu:GetHeight()<=282,'long event-type menu has a bounded viewport')
check(filter.MenuScroll.scrollChild==filter.MenuContent and filter.MenuContent:GetHeight()>filter.MenuScroll:GetHeight(),'options live in a real clipped scroll child')
check(filter.MenuRows[3].Check:IsShown(),'initial all-types view checks individual types')
click(filter.MenuRows[3]);local excluded=filter.MenuRows[3].choice[1]
check(filter.Menu:IsShown() and view.filter.kinds[excluded]==nil,'unchecking one type keeps menu open and excludes it')
local allowed=R.Query(view.filter);local valid=true;for _,e in ipairs(allowed) do if e.kind==excluded then valid=false end end
check(valid,'excluded type does not appear in results')
click(filter.MenuRows[2]);check(next(view.filter.kinds)==nil and filter:GetText()=='No event types  v','clear selection creates an explicit empty filter')
check(#R.Query(view.filter)==0,'empty selection shows no events instead of silently showing all')
local function choose(kind)
 for _,row in ipairs(filter.MenuRows) do if row.choice[1]==kind then click(row);return row end end
 error('Missing option '..kind)
end
choose('recording_start');choose('recording_stop')
check(view.filter.kinds.recording_start and view.filter.kinds.recording_stop and filter:GetText()=='2 event types  v','multiple included types combine into one filter')
check(view.filter.kinds.native_snapshot==nil,'ordinary type selections do not unexpectedly expose raw storage objects')
local only=R.Query(view.filter);valid=#only>0;for _,e in ipairs(only) do if e.kind~='recording_start' and e.kind~='recording_stop' then valid=false end end
check(valid,'selected types use OR within the event-type filter')
view.filter.search='impossible-literal-test';check(#R.Query(view.filter)==0,'type selection combines with literal search');view.filter.search=nil
local row=choose('xp_change');local index
for i,r in ipairs(filter.MenuRows) do if r==row then index=i end end
filter.MenuScroll.ChatWardenGoldScroll:SetValue(0);row.scripts.OnMouseWheel(row,-20)
check(filter.MenuScroll:GetVerticalScroll()>0,'mouse wheel on an option scrolls the menu')
click(filter);click(filter)
local offset=filter.MenuScroll:GetVerticalScroll()
check((index-1)*30>=offset and index*30<=offset+filter.MenuScroll:GetHeight(),'reopening makes the last selected type visible')
click(filter.MenuRows[1]);check(view.filter.kinds==nil and filter:GetText()=='All event types  v','All event types resets every exclusion')
local objectRow;for _,r in ipairs(filter.MenuRows) do if r.choice[1]=='native_snapshot' then objectRow=r end end
check(objectRow.Check:IsShown(),'explicit All event types includes saved storage objects')
view.rawCheck:SetChecked(true);click(view.rawCheck)
check(objectRow.Check:IsShown(),'raw-view choice is reflected in the event-type checklist')
view.rawCheck:SetChecked(false);click(view.rawCheck)
check(objectRow.Check:IsShown(),'Olympus grouping changes parts rather than hiding other saved objects')
choose('location');click(filter.MenuRows[1]);check(view.filter.page==0,'changing a filter resets pagination')
ns.Art.CloseMenus();check(not filter.Menu:IsShown(),'normal popup dismissal still closes the multi-select menu')
local single=ns.Art.Dropdown(view.events,0,0,220,{{1,'First'},{2,'Second'}},function() return view.singleValue or 1 end,function(v) view.singleValue=v end)
click(single);check(not single.MenuScroll.ChatWardenGoldScroll:IsShown(),'short single-select menus have no unnecessary scrollbar')
click(single.MenuRows[2]);check(view.singleValue==2 and not single.Menu:IsShown() and single:GetText()=='Second  v','ordinary dropdowns retain select-and-close behavior')
click(single);check(single.MenuScroll:GetVerticalScroll()==0,'short menus reopen without a spurious offset');ns.Art.CloseMenus()
-- Explicit object selection reveals those records even when raw view is off.
local hash=ns.ChronicleCapture.Store('appearance',{guid='Player-Home-01',raceID=1,sex=2,exact=false},'control')
-- Store is gated while paused; produce an object through normal opted-in flow.
C.SetEnabled(true);hash=assert(ns.ChronicleCapture.Store('appearance',{guid='Player-Home-01',raceID=1,sex=2,exact=false},'control'));C.SetEnabled(false)
local objects=R.Query({kinds={native_snapshot=true}})
check(#objects>0 and objects[1].kind=='native_snapshot','explicit preserved-snapshot selection is usable without raw toggle')
local count=#ledger().events;local profileCount=C.Statistics().profiles
local events=B.Encode(ledger().events);local profiles=B.Encode(ledger().profiles)
local live=S.db;local packed=assert(B.PackSaved(live));local owner=C.Owner()
check(packed~=live and packed.characters[owner].events==nil and live.characters[owner].events~=nil,'packing changes the saved representation without mutating the live ledger')
local normalized=assert(S.Normalize(packed))
check(B.Encode(normalized.characters[owner].events)==events and B.Encode(normalized.characters[owner].profiles)==profiles,'chunked save reload preserves all exact event and profile values')
check(not normalized.enabled and normalized.consentVersion==S.CONSENT,'disabled recording and consent survive save representation')
S.PrepareLogout();check(ns.DB.chronicle~=S.db and ns.DB.chronicle.characters[owner].storageFormat==1,'logout saves bounded strings while live state remains usable')
C.Initialize();check(#ledger().events==count and C.Statistics().profiles==profileCount,'normal initialization restores the packed representation')
local corrupt=B.PackSaved(S.db);corrupt.characters[owner].eventChunks[1]='return evil()'
check(S.Normalize(corrupt)==nil,'corrupt chunk data blocks loading rather than executing or silently deleting history')
local unknown=B.PackSaved(S.db);unknown.characters[owner].storageFormat=99
check(S.Normalize(unknown)==nil,'future saved storage formats remain untouched')
local duplicate=B.PackSaved(S.db);duplicate.characters[owner].eventChunks[#duplicate.characters[owner].eventChunks+1]=duplicate.characters[owner].eventChunks[1]
check(S.Normalize(duplicate)==nil,'duplicate IDs across saved chunks reject the whole container')
local old=assert(S.Normalize(S.db));old.schema=3;old.enabled=true;old.consentVersion=3
local migrated=assert(S.Normalize(old));check(not migrated.enabled and migrated.needsConsentUpgrade and #migrated.characters[owner].events==count,'old flat history migrates without backfilling consent')
-- Chunk decoding uses a distinct bounded limit; external text import keeps its lower limit.
local large=string.rep('x',25000);local decoded=B.DecodeChunk(B.Encode({{test=large}}))
check(decoded and decoded[1].test==large,'one unusually large stored value remains lossless within the saved-data limit')
check(not B.DecodeChunk(string.rep('x',196609)),'saved chunk size is bounded')
local malicious=B.PackSaved(S.db);malicious.characters[owner].eventChunks[1]=B.Encode({{evil='unsupported'}})
check(S.Normalize(malicious)==nil,'typed event validation still runs after chunk decode')
local backupBefore=B.Create();S.PrepareLogout();local backupAfter=B.Create()
check(backupBefore and backupAfter and backupBefore.batch==backupAfter.batch,'preparing logout does not alter user text backups')
local safe=ns.DB.chronicle;ns.DB.chronicle=corrupt;C.Initialize()
check(S.blocked and ns.DB.chronicle==corrupt and S.db==nil,'failed chunk loading keeps the original container and disables live access')
local unavailable,_,_,reason=R.Query({})
check(not unavailable and reason and C.Statistics().events==0 and S.Storage().events==0,'blocked history reports unavailability rather than an empty complete result')
check(not C.SetEnabled(true) and not C.Clear(),'blocked history cannot be collected into or accidentally cleared')
ns.DB.chronicle=safe;C.Initialize();check(#ledger().events==count,'recovering a valid saved container returns all preserved history')
recordingFilterChecks=checks-beforeChecks
''')
summary={'version':'1.0.3','assertions':int(lua.globals().recordingFilterChecks),'failed':0,'liveWoWTested':False}
(out/'recording-filters-save-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
