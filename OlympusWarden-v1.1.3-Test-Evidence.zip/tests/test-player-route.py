"""Encounter snapshots and retained schema5 histories; no continuous player tracks."""
from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];started=time.perf_counter();lua.execute(r'''
local beforeChecks=checks
local K,B,R=ns.ChronicleCodec,ns.ChronicleBackup,ns.RecordingUI
check(ns.ChroniclePlayerRoute==nil,'continuous collector is absent')
local positions={player={x=.123456789012345,y=.987654321098765,a=123.12345678901234,b=-456.9876543210987,z=0,world=0},target={a=222.1234567890123,b=-333.9876543210987,z=0,world=0}}
local subjectReads,uiSubjectReads=0,0;local visible=true
UnitIsVisible=function(u) return visible and units[u]~=nil end
C_Map={GetBestMapForUnit=function() return 37 end,GetPlayerMapPosition=function(id,u)
 if u~='player' then uiSubjectReads=uiSubjectReads+1 end
 local p=positions[u];if p and p.x then return {GetXY=function() return p.x,p.y end} end
end}
UnitPosition=function(u) if u~='player' then subjectReads=subjectReads+1 end;local p=positions[u];if p then return p.a,p.b,p.z,p.world end end
local normal=UnitPosition
local function latest(guid) local r;for _,e in ipairs(all('player_observed')) do if e.subject==guid then r=e end end;return r end
local function observe(id) units.target={guid='Player-Encounter-'..id,name='Example '..id};ev('PLAYER_TARGET_CHANGED');return latest(units.target.guid) end
groupCount=0;units.party1=nil;units.party2=nil;units.mouseover=nil;units.focus=nil;units.target=nil
freshRecording();local owner=C.Owner();local e=assert(observe(1));local p=assert(e.encounterPosition)
check(e.details.encounter and e.details.localSighting and e.location.zone==zone,'visible encounter retains fresh zone context')
check(p.observer.uiX==positions.player.x and p.observer.uiY==positions.player.y,'observer UI precision preserved')
check(p.observer.native1==positions.player.a and p.subject.native1==positions.target.a,'observer and subject positions distinct')
check(p.subject.native2==positions.target.b and p.subject.native3==0 and p.subject.worldMapID==0,'native axes and zero source fields preserved')
check(p.subject.mapID==nil and uiSubjectReads==0,'unsupported target UI coordinates never probed')
check(p.subjectGUID==e.subject and p.at==e.at and p.elapsed==e.elapsed,'snapshot binds identity and read time')
check(C.Profile(e.subject).lastEncounter.position.subject.native1==p.subject.native1,'profile retains latest dated encounter')
local detached=C.Profile(e.subject);detached.lastEncounter.position.subject.native1=999
check(C.Profile(e.subject).lastEncounter.position.subject.native1==p.subject.native1,'profile coordinate reads return independent copies')
check(C.SetPersonal(e.subject,'Preserve this note',true),'notes/watch metadata available')
local text='';for _,b in ipairs(R.Detail(e)) do text=text..b.text end
check(text:find('Your position at the encounter',1,true) and text:find('Other player position returned by the API',1,true),'UI labels observer and subject separately')
units.mouseover=units.target;local reads=subjectReads;local count=C.Statistics().encounters
for i=1,50 do ev('PLAYER_TARGET_CHANGED');ev('UPDATE_MOUSEOVER_UNIT') end
check(subjectReads==reads and C.Statistics().encounters==count,'repeat target/mouseover never resamples or inflates encounters')
clock=clock+35;ev('PLAYER_TARGET_CHANGED')
check(subjectReads==reads and C.Profile(e.subject).lastEncounter.position.at==p.at,'fact refresh keeps old snapshot with original timestamp')
clock=clock+121;positions.target.a=777.0000000000001;ev('PLAYER_TARGET_CHANGED')
check(subjectReads==reads+1 and C.Statistics().encounters==count+1,'new separated encounter takes one new position')
local at=C.Profile(e.subject).lastEncounter.at;visible=false;clock=clock+121;reads=subjectReads;ev('PLAYER_TARGET_CHANGED')
check(not latest(e.subject).details.localSighting and not latest(e.subject).details.encounter,'remote target is not proximity')
check(subjectReads==reads and C.Profile(e.subject).lastEncounter.at==at,'remote observation cannot replace encounter location')
visible=true;positions.target=nil;local missing=assert(observe(2))
check(missing.encounterPosition.observer and not missing.encounterPosition.subject,'missing subject coordinates never copy observer')
positions.player=nil;missing=assert(observe(3))
check(missing.location.zone==zone and not missing.encounterPosition,'zone-only encounter remains when all coordinates missing')
positions.target={a=12,b=34,z=0,world=0};missing=assert(observe(4))
check(missing.encounterPosition.subject.native1==12 and not missing.encounterPosition.observer,'subject-only position survives')
positions.player={x=0,y=1,a=0,b=0,z=0,world=0};positions.party1={x=0,y=1,a=8,b=9,z=0,world=0}
units.party1={guid='Player-Group-1',name='Group Companion'};visible=false;groupCount=2;reads=subjectReads;ev('GROUP_ROSTER_UPDATE')
check(C.Profile(units.party1.guid) and not C.Profile(units.party1.guid).lastSighting,'remote roster identity preserved without sighting')
check(subjectReads==reads and #all('group_roster')>0,'roster alone never requests coordinates')
visible=true;C.ObserveUnit('party1','GROUP_ROSTER_UPDATE',true);local friend=assert(latest(units.party1.guid))
check(friend.encounterPosition.subject.uiX==0 and friend.encounterPosition.subject.uiY==1,'visible party encounter preserves real map edges')
check(friend.encounterPosition.observer.native1==0,'native zero is readable')
local v=UnitIsVisible;UnitIsVisible=nil;reads=subjectReads;missing=assert(observe(5))
check(not missing.details.localSighting and subjectReads==reads,'unknown visibility establishes no sighting');UnitIsVisible=v
UnitPosition=function(u) if u=='target' then units.target={guid='Player-Recycled-2',name='New Person'} end;return 1,2,0,0 end
check(not observe(6) and not C.Profile('Player-Encounter-6'),'unit reuse rejects mixed encounter');UnitPosition=normal
local map=C_Map.GetBestMapForUnit;local n=0
C_Map.GetBestMapForUnit=function(u) if u=='target' then n=n+1;return n==1 and 37 or 38 end;return 37 end
observe(7);check(not latest('Player-Encounter-7'),'map change rejects ambiguous snapshot');C_Map.GetBestMapForUnit=map
local savedZone=zone;UnitPosition=function(u) if u=='target' then zone=savedZone=='Westfall' and 'Elwynn Forest' or 'Westfall' end;return 1,2,0,0 end
observe(8);check(not latest('Player-Encounter-8'),'observer context change rejects ambiguous snapshot');zone=savedZone;UnitPosition=normal
UnitPosition=function(u) if u=='target' then visible=false end;return 1,2,0,0 end
observe(9);check(not latest('Player-Encounter-9'),'visibility loss rejects snapshot');visible=true;UnitPosition=normal
local readable=ns.Readable;local secret={};ns.Readable=function(x) return x~=secret and readable(x) end
positions.target={a=secret,b=2,z=0,world=0};missing=assert(observe(10))
check(not missing.encounterPosition.subject,'secret fields not coerced');ns.Readable=readable
UnitPosition=function() error('unavailable') end;C_Map.GetPlayerMapPosition=function() return nil end
missing=assert(observe(11));check(not missing.encounterPosition,'throwing getters leave zone-only encounter');UnitPosition=normal
local function invalid(change,label) local copy=assert(B.DecodeChunk(B.Encode({e})))[1];change(copy);check(not S.Event(copy,owner),label) end
invalid(function(x) x.encounterPosition.subjectGUID='Player-Wrong-1' end,'snapshot GUID mismatch rejected')
invalid(function(x) x.encounterPosition.subject.uiX=.5 end,'partial UI tuple rejected')
invalid(function(x) x.encounterPosition.subject.native1=math.huge end,'nonfinite coordinates rejected')
invalid(function(x) x.encounterPosition.at=x.at+1 end,'future read timestamp rejected')
invalid(function(x) x.details.encounter=false end,'coordinates require actual encounter')
invalid(function(x) x.encounterPosition.subject.facing=7 end,'unknown coordinate fields rejected')
-- Legacy native shape constructed independently; no removed module is loaded.
C.SetEnabled(false);local raw={format=1,mapID=37,worldMapID=0,points={{GetServerTime(),clock,.123456789012345,.876543210987654,123.1234567890123,-987.1234567890123,0,false,false,GetServerTime(),clock,1}}}
local packed=assert(K.Encode(raw));local c=ledger();local subject='Player-Legacy-1'
local track=assert(S.Append(owner,{kind='player_route',source='checkpoint',session=c.currentSession,at=GetServerTime(),elapsed=clock,timeSource='server',evidence='observed',subject=subject,location={zone=zone},route=packed,details={name='Historical Companion',relationship='raid teammate',interval=10,segment=c.currentSession..'/p1',pointCount=1,evidenceClass='value-snapshot',method='subject coordinates; native axes preserved'}}));track.schema=5
local gap=assert(S.Append(owner,{kind='player_route_gap',source='checkpoint',session=c.currentSession,at=GetServerTime(),elapsed=clock,timeSource='server',evidence='observed',subject=subject,location={},details={name='Historical Companion',relationship='raid teammate',interval=10,reason='coordinates-unavailable',evidenceClass='value-snapshot'}}));gap.schema=5
check(S.Event(track,owner) and S.Event(gap,owner),'schema5 track and gap accepted')
local count=#ledger().events;local events=B.Encode(ledger().events);local profiles=B.Encode(ledger().profiles)
local saved=assert(B.PackSaved(S.db));saved.schema=5;saved.enabled=true;saved.consentVersion=5
local migrated=assert(S.Normalize(saved))
check(migrated.schema==6 and migrated.enabled and migrated.consentVersion==5,'narrower scope retains preview6 consent')
check(B.Encode(migrated.characters[owner].events)==events and B.Encode(migrated.characters[owner].profiles)==profiles,'schema5 chunk migration preserves exact records')
saved.enabled=false;ns.DB.chronicle=saved;C.Initialize()
check(#ledger().events==count and C.Profile(e.subject).personal.note=='Preserve this note','migration preserves records and notes')
local decoded=assert(K.Decode(all('player_route')[1].route));for j=1,12 do check(decoded.points[1][j]==raw.points[1][j],'legacy column exact '..j) end
check(C.PlayerStatistics(subject).routeSamples==1,'legacy route counts stay available')
local snapshot=assert(B.Create());C.Clear();for i=#snapshot.parts,1,-1 do check(B.Restore(snapshot.parts[i]),'reverse restore '..i) end
check(#ledger().events==count and #all('player_route')==1 and #all('player_route_gap')==1,'text restore preserves track/gap/history totals')
check(C.Profile(e.subject).lastEncounter.position.subject.native1==777.0000000000001,'backup preserves exact latest encounter')
check(C.Profile(e.subject).personal.watch and C.Profile(e.subject).personal.note=='Preserve this note','backup preserves personal metadata')
for i=1,#snapshot.parts do check(B.Restore(snapshot.parts[i]),'repeat restore '..i) end
check(#ledger().events==count,'repeat restore never duplicates events')
local stats=S.Statistics(owner);local storage=S.Storage();local actual,intel,legacy=0,0,0
for _,x in ipairs(ledger().events) do
 actual=actual+S.Size(x)
 if x.kind=='player_route' or x.kind=='player_route_gap' then legacy=legacy+S.Size(x) end
 if x.kind=='player_observed' or x.kind=='important_player' or x.kind=='player_combat' or x.kind=='player_kill_credit' or x.kind=='group_roster' or x.kind=='native_event' and x.subject then intel=intel+S.Size(x) end
end
for _,p in pairs(ledger().profiles) do actual=actual+S.Size(p);intel=intel+S.Size(p) end
check(storage.bytes==actual and stats.bytes==actual,'independently summed retained record total')
check(storage.playerIntelBytes==intel,'Player Intel matches declared families plus profiles')
check(storage.playerRouteBytes==legacy,'legacy storage includes gaps')
check(storage.ownRouteBytes+storage.playerIntelBytes+storage.playerRouteBytes+storage.otherBytes==storage.bytes,'four disjoint storage buckets reconcile')
check(storage.breakdown[1].playerIntelBytes==intel,'per-character Intel bucket reconciles')
S.Observe(owner,e.subject,{name='Renamed Example'},GetServerTime(),'PLAYER_TARGET_CHANGED',{})
local cached=S.Statistics(owner);S.Prune(ledger());local rebuilt=S.Statistics(owner)
check(cached.playerIntelBytes==rebuilt.playerIntelBytes and cached.bytes==rebuilt.bytes,'incremental profile cache matches rebuild')
local old=assert(S.Normalize(S.db));old.schema=4;old.enabled=true;old.consentVersion=4;local paused=assert(S.Normalize(old))
check(not paused.enabled and paused.needsConsentUpgrade and #paused.characters[owner].events==count,'older scopes pause without deleting history')
ns.Workspace.Open('recording');local view=ns.Workspace.pages.recording;view:SetView('coverage');view:Refresh(true)
view:SelectCollection('Player encounter locations')
local found,size=false,false
for i,b in ipairs(view.coverageDocument.blocks) do
 check(type(b.tooltip)=='string' and #b.tooltip>30,'coverage tooltip '..i)
 if b.text=='Player encounter locations' then found=true end

end
view:SelectCollection('storage');for _,b in ipairs(view.coverageDocument.blocks) do if b.text:find('Historical player tracks and gaps:',1,true) then size=true end end
check(found and size,'clickable coverage shows encounter policy and historical storage')
check(view.statusHelp.scripts.OnEnter~=nil,'recording status tooltip retained')
view.coverageDocument:SetBlocks({{text='No tooltip here'}});check(view.coverageDocument.boxes[1].scripts.OnEnter==nil,'recycled tooltip cleared')
check(#R.Query({kinds={player_route=true,player_route_gap=true}})==2 and R.Names.player_route:find('Historical',1,true),'historical filters remain usable')
local text='';for _,b in ipairs(R.Detail(all('player_route')[1])) do text=text..b.text end
check(text:find('Historical track retained',1,true),'route detail labels legacy history')
check(C.diagnostics.errors==0,'no swallowed errors')
playerRouteChecks=checks-beforeChecks
''')
summary={'version':'1.0.3','assertions':int(lua.globals().playerRouteChecks),'failed':0,'seconds':round(time.perf_counter()-started,3),'liveWoWTested':False,'collection':'encounter snapshots only; continuous other-player routes removed','legacyFixture':'independently constructed schema5 track/gap shapes; all12 columns compared','nativeCoverage':'synthetic available/unavailable/unstable inputs'}
(out/'player-route-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
