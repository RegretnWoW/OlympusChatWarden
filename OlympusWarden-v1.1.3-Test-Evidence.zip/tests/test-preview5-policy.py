from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'policy-host','exec'),scope)
lua=scope['lua'];lua.execute((out/'policy-fixture.lua').read_text());start=time.perf_counter()
lua.execute(r'''
local before=checks;local F,A,I,X,B=Preview5,ns.ChronicleActivities,ns.ChronicleIntelligence,ns.ChronicleCapture,ns.ChronicleBackup
local c=F.Fresh();local one,two,remote,roster,manual='Player-Policy-ONE','Player-Policy-TWO','Player-Policy-REMOTE','Player-Policy-ROSTER','Player-Policy-MANUAL'
local seen=F.Observe(1,one,'Same Name');F.Observe(2,two,'Same Name')
local report={format=1,kind='wanted',board='wanted',id='public-policy',part=1,parts=1,apiVersion=1,mode='full',rows={{key=remote,values={guid=remote,name='Remote Only',bounty=50}}},removed={}}
F.Emit('olympus_snapshot',3,{snapshotID=report.id,part=1,parts=1},'WANTED_CHANGED',nil,nil,{snapshot=report})
F.Emit('group_roster',4,{members={roster},knownMembers=1,sameGuildMembers=0},'GROUP_ROSTER_UPDATE')
F.Observe(5,manual,'Manual Friend');F.Emit('important_player',6,{relationship='manual inspection'},'INSPECT_READY',manual)
local bytes=B.Encode(c.events);local profiles=B.Encode(c.profiles);local st=F.Build()
check(I.Player(st,one).tier==3 and I.Player(st,two).tier==3,'ordinary local encounters are Tier 3')
check(I.Player(st,roster).tier==1 and I.Player(st,roster).recordedEncounters==0,'recorded teammates are important without invented local contact')
check(I.Player(st,manual).tier==1 and I.Player(st,manual).tierReasons[1].label=='Deliberately inspected','manual inspection has an explicit importance reason')
check(not I.Player(st,remote).tier and I.Player(st,remote).tierLabel=='Olympus source only','remote Olympus records do not become local Tier 3 encounters')
check(A.Name(st,one)=='Same Name' and one~=two and #I.Player(st,one).evidence~=#I.Player(st,manual).evidence,'same display names retain separate GUID evidence')
check(B.Encode(c.events)==bytes and B.Encode(c.profiles)==profiles,'tier projection never rewrites raw evidence or stored profiles')
F.Observe(140,one,'Same Name');st=F.Build();check(I.Player(st,one).tier==3,'repeated sightings alone do not promote a rival or request inspection')
local score,hash=F.Snapshot(150,'scoreboard',{guid=one,name='Same Name',classToken='MAGE',runID='capture-report-A',matchSequence=1,rowIndex=1,killingBlows=2,honorableKills=5,deaths=0,damageDone=1000})
st=F.Build();local p=I.Player(st,one)
check(p.tier==2 and p.recordedEncounters==2 and #p.evidence>=3,'scoreboard promotes dossier depth and preserves local encounter evidence')
local bOnly='Player-Policy-SCORE';F.Snapshot(151,'scoreboard',{guid=bOnly,name='Scoreboard Name',classToken='PRIEST',runID='capture-report-A',matchSequence=1,rowIndex=2,killingBlows=0,deaths=1,healingDone=900})
F.Snapshot(152,'scoreboard',{name='Same Name',runID='capture-report-A',matchSequence=1,rowIndex=3,killingBlows=20,deaths=1})
st=F.Build();check(I.Player(st,bOnly).tier==2 and I.Player(st,bOnly).recordedEncounters==0,'scoreboard-only player is not a physical encounter')
check(A.Name(st,bOnly)=='Scoreboard Name' and #ns.WardenUI.Players(st,'all','PRIEST')==1,'GUID-bearing scoreboard metadata is searchable and readable')
check(#I.Player(st,one).scoreboards==1,'name-only scoreboard row cannot merge with a known GUID dossier')
-- Same report, updated counters or changed row order: one latest report, never summed.
local updated,hash2=F.Snapshot(153,'scoreboard',{guid=one,name='Same Name',classToken='MAGE',runID='capture-report-A',matchSequence=1,rowIndex=4,killingBlows=3,honorableKills=7,deaths=0,damageDone=1500})
F.Native(154,'pvp_score_row',{contentID=hash2,family='scoreboard',part=4,parts=4},'UPDATE_BATTLEFIELD_SCORE')
F.Native(155,'pvp_score_row',{contentID=hash2,family='scoreboard',part=4,parts=4},'UPDATE_BATTLEFIELD_SCORE')
st=F.Build();p=I.Player(st,one)
check(#p.scoreReports==1 and p.scoreReports[1].object.capture.values.killingBlows==3,'repeated report updates replace display values rather than adding killing blows')
check(p.scoreReports[1].lastAt==F.base+155 and p.firstScoreAt==F.base+150,'report references preserve actual first and last observation dates')
check(p.confirmedKillingBlows==nil and p.confirmedMatches==nil and p.headToHeadRatio==nil,'unknown unique matches, lifetime totals and K/D are not invented')
F.Snapshot(156,'scoreboard',{guid=one,name='Same Name',runID='capture-report-B',matchSequence=1,rowIndex=1,killingBlows=10,deaths=4})
st=F.Build();p=I.Player(st,one);check(#p.scoreReports==2 and not p.totalKillingBlows,'separate recording report tokens are not claimed to be distinct matches or summed')
local rows=ns.ChronicleIntelligenceUI.Rows(st,'scoreboards',one)
for _,r in ipairs(rows) do check(r.data.capture.values.guid==one,'dossier PvP reports use exact GUID filtering') end
check(#rows==3,'all distinct stored scoreboard payloads remain reachable')
local text={};for _,block in ipairs(ns.WardenUI.Profile(st,{id=one,title='Same Name'})) do text[#text+1]=block.text or '' end;local doc=table.concat(text,'\n')
check(doc:find('Deaths: 0',1,true) and doc:find('Unknown',1,true),'dossier distinguishes observed zero from unavailable counters')
F.Emit('important_player',160,{relationship='personal bookmark'},'control',one);st=F.Build();p=I.Player(st,one)
check(p.tier==1 and p.firstScoreAt==F.base+150 and p.recordedEncounters==2,'Tier 1 promotion keeps earlier activity and casual evidence')
local once=c.profiles[two];once.personal={note='Private',watch=true};S.Prune(c)
check(I.Player(st,two).tier==1 and I.Player(st,two).tierReasons[1].label=='On your current watchlist','current watchlist promotes display without recording or inspecting')
once.personal.watch=false;S.Prune(c);check(I.Player(st,two).tier==3,'removing a current-only watch flag returns to supported historical classification')
local legacy='Player-Policy-LEGACY';F.Emit('player_kill_credit',170,{},'COMBAT_LOG_EVENT_UNFILTERED',legacy)
st=F.Build();check(not I.Player(st,legacy).tier,'legacy credit semantics do not fabricate modern opponent importance')
local foe='Player-Policy-CREDIT';F.Native(180,'native_kill_credit',{attackerGUID=units.player.guid,targetGUID=foe,entityKind='Player',credit='self native credit'},'PARTY_KILL',foe)
st=F.Build();check(I.Player(st,foe).tier==1 and I.Player(st,foe).confirmedKillingBlows==nil,'direct native credit establishes meaningful importance, not a solo kill')
-- Inspectable eligibility remains separate: rebuilding these records sends no requests.
local notifications=0;local old=NotifyInspect;NotifyInspect=function() notifications=notifications+1 end
A.Clear();st=F.Build();check(notifications==0,'tiers and scoreboard rebuilds never enqueue inspections');NotifyInspect=old
local backup=assert(B.Create());local expected=B.Encode(c.events);C.Clear();for _,part in ipairs(backup.parts) do assert(B.Restore(part)) end
st=F.Build();check(I.Player(st,one).tier==1 and #I.Player(st,one).scoreReports==2 and not C.Active(),'tiers and report projections rebuild after restore without enabling recording')
local normalized=ns.ChronicleStore.Normalize(ns.DB.chronicle);check(normalized~=nil,'history stays in the existing schema')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'schema, consent and protected-event rules preserved')
policyChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().policyChecks,'failed':0,'savedTierDatabase':False,'uniqueMatchTotalsEnabled':False,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'preview5-policy-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
