from pathlib import Path
import json,subprocess,sys
o=Path(__file__).resolve().parent;r=o.parents[1]
h={'__file__':str(o/'test-ui-pass.py')};exec(compile((o/'test-ui-pass.py').read_text(),'UI preview fixture','exec'),h);l=h['l']
export=(r/'.work/v103-release-intelligence/test-integration.py').read_text();export=export[export.index('def export_scene('):export.index("(out/'scene-old.json')")]
export=export.replace("page=lua.globals().ns.Workspace.window if style in ('workspace','updates') else lua.globals().nativePages[style]","page=lua.globals().renderRoot")
export=export.replace("'justify':f['justify'],","'justify':f['justify'],'justifyV':f['justifyV'],'fromPoint':[f['from'][1],f['from'][2]] if f['from'] is not None else None,'toPoint':[f['to'][1],f['to'][2]] if f['to'] is not None else None,")
export=export.replace("r['allPoints']=index(f['allPoints']);r['points']=[]","r['verticalScroll']=f['verticalScroll'] or 0;r['horizontalScroll']=f['hs'] or 0;r['scrollChild']=index(f['scrollChild']);r['allPoints']=index(f['allPoints']);r['points']=[]")
env={};exec(compile(export,'production widget export','exec'),env)
l.execute(r'''
local W,A=ns.Workspace,ns.ChronicleActivities
W.Open('intel');local p=W.pages.intel;p.owner=ns.Chronicle.Owner();p.query='';p.search:SetText('');p.mode='all';p.selected='Player-Geometry-ONE';p.detail='talents'
for n=1,100 do A.Pump();p:Activate();if p.state then break end end
for n=1,100 do p.talents.scripts.OnUpdate(p.talents) end
local tree={id=700,nodes={},groups={{1,'Beast Mastery'},{2,'Marksmanship'},{3,'Survival'}}};local id=1000
for g=1,3 do for row=0,7 do for col=0,3 do
 id=id+1;tree.nodes[id]={id,3000+(g-1)*4000+col*600,1500+row*600,5,0,{{id+2000,id+3000,1001,1}},row<7 and {{id+4,1,1}} or {},{g},true}
end end end
local graph=p.talents.tree;graph.layout=assert(ns.WardenTalents.Layout({tree}));graph.selected={};graph.complete=false;graph.observed='Synthetic layout fixture';graph:Draw();graph:Show()
p.talents.choicesScroll:Hide();p.talents.choicesTitle:Hide()
renderRoot=W.window;ns.Art.CloseMenus()
''')
def save(name):
 (o/('scene-'+name+'.json')).write_text(json.dumps(env['export_scene'](l,name),default=str))
 subprocess.run([sys.executable,'-X','utf8',str(o/'render-preview.py'),name],cwd=r,check=True,capture_output=True)
save('talents')
l.execute("ns.Workspace.pages.intel.talents.tree:SetZoom(1.25)")
save('talents-zoom')
l.execute("ns.Workspace.pages.intel.talents.tree:ResetView()")
l.execute("local graph=ns.Workspace.pages.intel.talents.tree;graph.scroll:SetHorizontalScroll(graph.width-1076);graph.scroll:SetVerticalScroll(graph.height-graph.scroll:GetHeight())")
save('talents-right')
l.execute("ns.Workspace.Open('overview');renderRoot=ns.Workspace.window;ns.Art.CloseMenus()")
save('command')
l.execute("ns.Workspace.Open('settings');renderRoot=ns.Workspace.window;ns.Art.CloseMenus()")
save('settings')
node='C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
subprocess.run([node,str(o/'render-preview.cjs'),'talents','talents-zoom','talents-right','command','settings'],cwd=r,check=True)
