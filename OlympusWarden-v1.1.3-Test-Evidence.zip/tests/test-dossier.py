from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'dossier-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local G,X,W=ns.WardenDossier,ns.ChronicleCapture,ns.Workspace
units.target=nil;units.party1=nil;units.mouseover=nil;groupCount=0;freshRecording()
units.target={guid='Player-Gear-ONE',name='Gear Tester',class='MAGE',level=30,guild='A long recorded guild name',race='Human',faction='Alliance'};ev('PLAYER_TARGET_CHANGED')
local guid=units.target.guid;local owner=C.Owner();local c=S.Character(owner,false)
local function gear(id)
 local slots={};for n=1,19 do slots[n]={n,'unavailable',false,false} end
 slots[1]={1,'present',id,'item:'..id..':123:456:0'};slots[2]={2,'empty',false,false};slots[3]={3,'pending',id+1,false}
 return assert(X.Store('gear',{guid=guid,slots=slots},'INSPECT_READY'))
end
local h1=gear(1001);assert(X.Record('important_player','INSPECT_READY',{gearRef=h1,gearObservedAt=C.Stamp(),relationship='party teammate'},guid,false))
clock=clock+60;local h2=gear(1002);assert(X.Record('important_player','INSPECT_READY',{gearRef=h2,gearObservedAt=C.Stamp(),relationship='party teammate'},guid,false))
clock=clock+60;assert(X.Record('important_player','INSPECT_READY',{gearRef=h1,gearObservedAt=C.Stamp(),relationship='party teammate'},guid,false))
clock=clock+60;assert(X.Record('important_player','INSPECT_READY',{gearRef=h1,gearObservedAt=C.Stamp(),relationship='party teammate'},guid,false))
local j=G.Request(owner);local iterations=0
while not j.done do local cursor=j.cursor;G.Pump(j,3);check(j.cursor-cursor<=3,'gear indexing budget bounded');iterations=iterations+1;assert(iterations<1000) end
local rows=G.Rows(j,guid)
check(#rows==3 and rows[1].hash==h1 and rows[2].hash==h2,'gear changes and return to earlier set preserved; unchanged checkpoints coalesce')
check(rows[1].event.details.gearRef==h1 and rows[1].object.capture.values.guid==guid,'original references and snapshot identity preserved')
check(G.Slot(rows[1],1)[4]=='item:1001:123:456:0','original item string preserved')
check(G.Slot(rows[1],2)[2]=='empty' and G.Slot(rows[1],4)[2]=='unavailable','confirmed empty distinct from unavailable')
check(G.Request(owner)==j and j.done,'cached reopening does not rescan unchanged ledger')
local oldcombat=InCombatLockdown;InCombatLockdown=function() return true end
local n=j.cursor;j.done=nil;G.Pump(j);check(j.cursor==n,'gear projection pauses in combat');j.done=true;InCombatLockdown=oldcombat
local st=ns.ChronicleActivities.Request(owner);while not st do ns.ChronicleActivities.Pump();st=ns.ChronicleActivities.Request(owner) end
local pr=ns.WardenUI.Players(st,'all')[1];assert(pr and pr.id==guid)
local m=getmetatable(UIParent).__index
function m:SetUnit(unit) self.calls=(self.calls or 0)+1;self.modelUnit=unit;return modelSuccess end
function m:ClearModel() self.clears=(self.clears or 0)+1;self.modelUnit=nil end
function m:SetRotation(v) self.facing=v end;function m:SetCamDistanceScale(v) self.distance=v end
function m:SetPosition() end;function m:SetPortraitZoom() end
modelSuccess=true
GetItemInfo=function(link) return 'Observed Helm',link,3,30,30,'Armor','Cloth',1,'INVTYPE_HEAD','fake-item-icon' end
GetItemQualityColor=function() return .1,.4,1 end
local holder=CreateFrame('Frame',nil,UIParent);local p=G.Build(holder,holder);p:Show();p:SetProfile(owner,pr,st)
p.scripts.OnUpdate(p,.1)
check(p.unit=='target' and p.model:IsShown() and p.model.modelUnit=='target','available exact GUID displays native model')
check(p.slots[1].itemName=='Observed Helm' and p.slots[1].link=='item:1001:123:456:0','icons and names use native cache; original link retained')
check(p.slots[1].icon.texture=='fake-item-icon','native item icon survives multi-return reader')
check(p.slots[2].name:GetText()=='Confirmed empty' and p.slots[4].name:GetText()=='Not inspected','paper doll presents distinct empty and unknown states')
check(p.status:GetText():find('Historical gear',1,true) and p.modelStatus:GetText():find('Live Appearance',1,true),'live model and historical equipment clearly separated')
local calls=p.model.calls;p:SetProfile(owner,pr,st);check(p.model.calls==calls,'normal UI refresh does not rebuild model')
p:Zoom(100);check(p.zoom==.55,'zoom lower bound');p:Zoom(-100);check(p.zoom==1.8,'zoom upper bound');p:Reset();check(p.zoom==1 and p.rotation==0,'reset camera and rotation')
cursorX=100;p.model.scripts.OnMouseDown(p.model,'LeftButton');cursorX=120;p.scripts.OnUpdate(p,.1);check(p.rotation>0,'mouse drag rotates');p.model.scripts.OnMouseUp(p.model);check(p.dragX==nil,'mouse release ends rotation')
units.target.guid='Player-Gear-OTHER';p.scripts.OnEvent(p,'PLAYER_TARGET_CHANGED');check(p.unit==nil and not p.model:IsShown(),'target switch clears original model without substitution')
units.party1={guid=guid,name='Gear Tester',race='Orc'};p.scripts.OnEvent(p,'GROUP_ROSTER_UPDATE');check(p.unit=='party1','matching party GUID can resolve despite target switch')
units.party1=nil;p.scripts.OnUpdate(p,.1);check(p.unit==nil and not p.model:IsShown(),'out of range clears model')
click(p.recorded);check(p.view=='history' and not p.model:IsShown() and #p.rows==2,'offline historical gear gallery shows two unique configurations without a substitute character')
click(p.previous);check(p.index==2 and p.slots[1].link=='item:1002:123:456:0','older equipment view selects original set')
click(p.next);check(p.index==1,'newer equipment view')
click(p.source);check(W.current=='recording' and W.pages.recording.selected==p.rows[1].event.id,'equipment source opens exact original observation')
units.target={guid=guid,name='Gear Tester',race='NightElf'};p.view='live';p:Bind(true);check(p.unit=='target','different race supported by native SetUnit without race reconstruction')
modelSuccess=false;p:Bind(true);check(not p.model:IsShown() and p.unit==nil,'native SetUnit failure stays empty');modelSuccess=true
local visible=UnitIsVisible;UnitIsVisible=function() return false end;p:Bind(true);check(p.unit==nil,'invisible unit not accepted');UnitIsVisible=visible
p.view='live';p:Bind(true);p:Hide();check(p.unit==nil and not p.model:IsShown(),'hiding dossier releases model')
GetItemInfo=nil;C_Item=C_Item or {};C_Item.GetItemInfo=function(link) return 'Modern Item',link,2,nil,nil,nil,nil,nil,nil,'modern-icon' end
p:Show();p:Render();check(p.slots[1].itemName=='Modern Item','modern C_Item API fallback supported')
local saved=ns.ChronicleBackup.Encode(c.events);local decoded=assert(ns.ChronicleBackup.DecodeChunk(saved))
local originalEvents=c.events;c.events=decoded;local reloaded=G.Request(owner);while not reloaded.done do G.Pump(reloaded) end
check(#G.Rows(reloaded,guid)==3 and G.Rows(reloaded,guid)[1].hash==h1,'reloaded history preserves snapshots and references');c.events=originalEvents
-- Same-name substitute and malformed attachment cannot contaminate a dossier.
local other='Player-Gear-OTHER';local otherProfile={id=other,title='Gear Tester'}
p:SetProfile(owner,otherProfile,st);p.scripts.OnUpdate(p,.1);check(p.unit==nil and #p.rows==0,'same display name never borrows another GUID model or gear')
local length=#c.events;clock=clock+60;assert(X.Record('important_player','INSPECT_READY',{gearRef=h1,gearObservedAt=C.Stamp(),relationship='party teammate'},other,false))
local job=G.Request(owner);while not job.done do G.Pump(job) end;check(#G.Rows(job,other)==0,'mismatched subject gear reference rejected')
local copy={};for n,e in ipairs(c.events) do copy[n]=e end;c.events=copy
check(G.Request(owner)~=job,'restored event table invalidates equipment cache');c.events=j.events
W.Open('intel');local intel=W.pages.intel;intel.selected=guid;intel:Refresh(true);intel.note:SetText('Keep unsaved text');intel.noteDirty=true
click(intel.gearButton);check(intel.detail=='gear' and intel.appearance:IsShown() and not intel.body:IsShown(),'production Appearance & Gear page opens')
check(not intel.note:IsShown() and not intel.save:IsShown(),'note controls do not overlay paper doll')
click(intel.profileButton);check(intel.note:GetText()=='Keep unsaved text','switching dossier views preserves draft')
W.Open('overview');local home=W.pages.overview;home:Refresh(true)
check(#home.states==4 and not home.cards[4].value:GetText():find('/',1,true),'home separates feature states from data statistics')
home.search:SetText('  \t ');home:Search();check(home.job==nil and home.label:GetText()=='Recent highlights','whitespace-only search restores Home highlights')
local oldName=units.player.name;units.player.name='Renamed Character';ns.OlympusConnection.profile=nil;home:Refresh(true)
check(home.heroTitle:GetText()=='Renamed Character','home banner refreshes current character name');units.player.name=oldName
local profileCard;for _,card in ipairs(home.cards) do if card.destination=='intel' then profileCard=card end end
check(profileCard~=nil,'adaptive dashboard retains an enabled profile statistic');click(profileCard.action);check(W.current=='intel','profile statistic navigates')
local Q=ns.WardenSearch;local search=Q.Begin('Gear Tester');while not Q.Pump(search) do end
for _,r in ipairs(search.results) do check(not r.title:find('Player-',1,true) and not r.sub:find('Player-',1,true),'result metadata hides technical GUIDs') end
local orig=c.events;local e=orig[#orig];local result={data={event=e,owner=owner,character=c}};c.events={};local current=W.current;Q.Open(result);check(W.current==current,'removed source result explains unavailability without navigating');c.events=orig
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'no schema, consent or protected registration changes')
local eventCount=#c.events;C.SetEnabled(false);local consent=S.db.consentVersion;local enabled=S.db.enabled
check(C.SetPersonal(guid,'Private note while paused',true),'historical note saves while recording is paused')
check(not C.Active() and S.db.enabled==enabled and S.db.consentVersion==consent,'note edit does not change recording or consent')
check(#c.events>=eventCount and C.Profile(guid).personal.watch==true,'watchlist persists through normal profile API')
local allowed=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end
check(not C.SetPersonal(guid,'Should not save',false),'notes remain gated by membership access');ns.Membership.Allowed=allowed
for _,dimensions in ipairs({{1920,1080},{1920,1200},{1280,720},{1024,768}}) do
 UIParent:SetSize(dimensions[1],dimensions[2]);W.SetScale(nil);local scale=W.Fit()
 check((W.width+2*W.leftOverhang)*scale<=dimensions[1]-25 and (W.height+2*W.bottomOverhang)*scale<=dimensions[2]-25,'production window fits 16:9, 16:10 and narrow game windows')
end
for _,scale in ipairs({50,75,100}) do local _,screen=ns.Theme.WindowScale(W.width+2*W.leftOverhang,W.height+2*W.bottomOverhang);check(W.SetScale(scale) and ns.DB.workspaceScale==scale/100 and math.abs(W.window:GetEffectiveScale()-math.min(scale/100,screen))<.001,'saved custom scale accepted and temporarily bounded to the display') end
UIParent:SetSize(1200,900);W.SetScale(nil)
local original=c.events;local large={};for n=1,200000 do large[n]={id='ui-stress:'..n,kind='native_event',details={gearRef=h1}} end;c.events=large
local stress=G.Request(owner);local steps=0;while not stress.done do local cursor=stress.cursor;G.Pump(stress);assert(stress.cursor-cursor<=128);steps=steps+1;assert(steps<2000) end
check(#stress.refs==0 and next(stress.players)==nil,'large personal ledger does not duplicate own loadout references in player dossier cache')
check(steps>1500,'large gear projection remains cooperative');c.events=original
dossierChecks=checks-before;dossierSteps=iterations
''')
summary={'version':'1.1.0','assertions':int(lua.globals().dossierChecks),'gearIndexSteps':int(lua.globals().dossierSteps),'failed':0,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'dossier-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
