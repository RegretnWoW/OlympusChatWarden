from pathlib import Path
import sys,hashlib,json,random,time
out=Path(__file__).resolve().parent;root=out.parents[1];sys.path.insert(0,str(root/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime as Fallback
from lupa.luajit21 import LuaRuntime as Native
code=(root/'OlympusChatWarden/PackCrypto.lua').read_bytes();old=(out/'baseline/OlympusChatWarden/PackCrypto.lua').read_bytes()
rng=random.Random(7101);samples=[b'',b'abc',b'a'*1000000]+[rng.randbytes(n) for n in [1,3,55,56,63,64,65,119,120,127,128,129,1024,8192]]
results={};started=time.perf_counter()
for label,cls,data in [('native-baseline',Native,old),('native-candidate',Native,code),('fallback-candidate',Fallback,code)]:
 lua=cls(encoding=None);lua.execute(b'if jit then jit.off() end');ns=lua.table();lua.eval(b'function(s,ns) assert(loadstring(s))("fixture",ns) end')(data,ns)
 selected=samples if label!='fallback-candidate' else [s for s in samples if len(s)<1000000]
 at=time.perf_counter()
 for s in selected:assert ns.PackCrypto.SHA256(s)==hashlib.sha256(s).digest(),(label,len(s))
 results[label]={'vectors':len(selected),'bytes':sum(map(len,selected)),'seconds':time.perf_counter()-at}
 # Checkpoints remain compatible with yielding callers; bytes stay identical.
 lua.globals().crypto=ns.PackCrypto
 lua.execute(b'calls=0;assert(crypto.SHA256(string.rep("a",8192),function() calls=calls+1 end)==crypto.SHA256(string.rep("a",8192)));assert(calls==129)')
 print(label,results[label],flush=True)
results.update(failed=0,version='1.1.0',liveClientTest=False,seconds=time.perf_counter()-started)
(out/'crypto-parity-summary.json').write_text(json.dumps(results,indent=2)+'\n')
