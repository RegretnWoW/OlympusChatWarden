from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1]
host={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'collection module fixture','exec'),host)
source=(o/'test-chronicle.py').read_text();native=source.split("lua.execute(r'''")[1].split("check(not S.db.enabled")[0]
start=time.perf_counter();cases=[]
for mode in ['chronicle','intel']:
 selection={k:k==mode for k in ['chat','shield','alerts','chronicle','intel']}
 l=host['fresh']('modern',True,selection=selection);l.execute(native)
 l.globals().testMode=mode
 l.execute('''
 ev('PLAYER_ENTERING_WORLD',true,false);assert(C.SetEnabled(true));assert(C.Active())
 local before=#ledger().events
 units.target={guid='Player-Other-001',name='Known Companion',level=25,class='MAGE',race='Human',faction='Alliance',guild='Olympus Reloaded'}
 ev('PLAYER_TARGET_CHANGED');ev('UPDATE_MOUSEOVER_UNIT')
 units.party1=units.target;groupCount=2;ev('GROUP_ROSTER_UPDATE')
 xp=xp+100;money=money+100;ev('PLAYER_XP_UPDATE','player');ev('PLAYER_MONEY');ev('QUEST_TURNED_IN',12345,100,100)
 step(31)
 local quests,times,routes=0,0,0
 for _,e in ipairs(ledger().events) do
  if e.kind=='quest_turnin' then quests=quests+1 end
  if e.kind=='time_span' or e.kind=='time_slice' then times=times+1 end
  if e.kind=='route_segment' then routes=routes+1 end
 end
 C.Flush()
 if testMode=='chronicle' then
  assert(quests==1,'Chronicle personal events must continue without Intel')
  assert(not ledger().profiles['Player-Other-001'],'Chronicle-only must not create Intel dossiers')
 else
  assert(C.Profile('Player-Other-001'),'Intel records exact available player facts without Chronicle')
  assert(quests==0 and times==0 and routes==0,'Intel-only must not create personal Chronicle history')
 end
 local expected=ns.ChronicleBackup.Encode(S.db)
 for _,id in ipairs(ns.Modules.order) do ns.Modules.Set(id,false) end
 local preserved=ns.ChronicleBackup.Encode(S.db)
 assert(expected==preserved,'disabling must preserve all flushed historical data')
 local source=ns.DB.chronicle
 ev('PLAYER_LOGOUT')
 assert(ns.DB.chronicle.storageFormat==1 or ns.DB.chronicle.characters[C.Owner()].storageFormat==1,'disabled modules retain chunked logout saving')
 local normalized=assert(S.Normalize(ns.DB.chronicle));local canonical=assert(S.Normalize(S.db))
 assert(#normalized.characters[C.Owner()].events==#ledger().events,'no disabled logout events are removed')
 assert(ns.ChronicleBackup.Encode(normalized)==ns.ChronicleBackup.Encode(canonical),'disabled logout pack round trip is lossless')
 ''')
 cases.append(mode)
result={'version':'1.1.1-preview6','failed':0,'scenarios':cases,'independentConsentedCollection':True,'noIntelDossiersWhenDisabled':True,'noPersonalEventsInIntelOnly':True,'disablePreservesHistory':True,'chunkedLogoutWhenDisabled':True,'seconds':time.perf_counter()-start,'nativeClient':False}
(o/'module-collection-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
