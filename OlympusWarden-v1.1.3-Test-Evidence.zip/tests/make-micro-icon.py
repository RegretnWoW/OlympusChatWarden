from pathlib import Path
from PIL import Image,ImageDraw
import math
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent
s=4;im=Image.new('RGBA',(128*s,128*s));d=ImageDraw.Draw(im)
def box(v):return tuple(int(x*s) for x in v)
def line(v,fill,width):d.line([tuple(int(c*s) for c in p) for p in v],fill=fill,width=width*s,joint='curve')
d.ellipse(box((7,7,121,121)),fill='#232120',outline='#74614a',width=3*s)
d.ellipse(box((12,12,116,116)),fill='#142638',outline='#b29b71',width=2*s)
d.arc(box((22,16,106,114)),25,155,fill='#8e7954',width=2*s)
# A restrained Omega rather than the full ornate Zeus crest at micro-menu size.
d.arc(box((38,34,90,86)),155,385,fill='#ddc58d',width=7*s)
line([(41,69),(47,87),(34,87)],'#ddc58d',7)
line([(87,69),(81,87),(94,87)],'#ddc58d',7)
for side in (-1,1):
 pts=[]
 for k in range(8):
  a=math.radians(35+k*13);x=64+side*43*math.sin(a);y=63+43*math.cos(a);pts.append((x,y))
  # Small paired laurel leaves, defined directly as vector ellipses.
  d.ellipse(box((x-4,y-7,x+4,y+3)),fill='#aa946c')
 line(pts,'#8e7954',2)
im=im.resize((128,128),Image.Resampling.LANCZOS)
im.save(r/'OlympusChatWarden/Media/Warden/WardenMicro.tga')
im.save(o/'WardenMicro.png')
for shape in ['Square','Circle','Choice']:
 border=Image.new('RGBA',(64*s,64*s));art=ImageDraw.Draw(border)
 for inset,color,width in [(4,'#5b4831',5),(7,'#c2a16b',2)]:
  rect=tuple(v*s for v in (inset,inset,64-inset,64-inset))
  if shape=='Circle':art.ellipse(rect,outline=color,width=width*s)
  elif shape=='Choice':art.line([(32*s,inset*s),((64-inset)*s,32*s),(32*s,(64-inset)*s),(inset*s,32*s),(32*s,inset*s)],fill=color,width=width*s,joint='curve')
  else:art.rounded_rectangle(rect,radius=3*s,outline=color,width=width*s)
 border.resize((64,64),Image.Resampling.LANCZOS).save(r/f'OlympusChatWarden/Media/Warden/Talent{shape}.tga')
(o/'WardenMicro.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><circle cx="64" cy="64" r="57" fill="#232120" stroke="#74614a" stroke-width="3"/><circle cx="64" cy="64" r="52" fill="#142638" stroke="#b29b71" stroke-width="2"/><path d="M47 78A26 26 0 1 1 81 78L81 87H94M47 78V87H34" fill="none" stroke="#ddc58d" stroke-width="7" stroke-linejoin="round"/><g fill="#aa946c">'''+''.join(f'<ellipse cx="{64+side*43*math.sin(math.radians(35+k*13)):.2f}" cy="{61+43*math.cos(math.radians(35+k*13)):.2f}" rx="4" ry="5"/>' for side in (-1,1) for k in range(8))+'''</g></svg>''')
print('Created original subdued Omega/laurel micro-menu emblem: 128px RGBA TGA')
