from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'objective-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local M,X,B=ns.ChronicleCombat,ns.ChronicleCapture,ns.ChronicleBackup
GetStatisticsCategoryList=nil;GetStatistic=nil;freshRecording()
local function pump() for n=1,200 do X.Pump() end end
local guid='Player-Flags-ONE';local flags=3;local include=true
GetNumBattlefieldScores=function() return 1 end
C_PvP={GetScoreInfo=function(i) if i~=1 then return end
 return {guid=guid,name='Flag Runner',killingBlows=0,honorableKills=7,deaths=0,damageDone=100,healingDone=0,
  stats=include and {{pvpStatID=9001,pvpStatValue=flags,orderIndex=1,name='Flags captured',tooltip='Observed scoreboard flags',iconName='FlagIcon'},
   {pvpStatID=9002,pvpStatValue=1,orderIndex=2,name='Flags returned'}} or nil}
end,
GetMatchPVPStatColumns=function() return {{pvpStatID=9001,columnHeaderID=77,orderIndex=1,name='Flags',tooltipTitle='Flag captures',tooltip='Native column metadata'}} end}
M.Handle('PVP_MATCH_COMPLETE',1,600);pump()
local function objects()
 local out={};for _,e in ipairs(all('native_snapshot')) do if e.capture.family=='scoreboard' then out[#out+1]=e end end;return out
end
local scores=objects();local e=scores[#scores];local v=e.capture.values
check(v.guid==guid and #v.objectives==2 and v.objectives[1][1]==9001 and v.objectives[1][2]==3,'three native flags captured preserved with exact player GUID and stat ID')
check(v.objectives[1][5]==77 and v.objectives[1][9]=='Flags','column metadata resolved by numeric ID when only columns API is available')
check(v.objectiveReadCount==2 and v.objectivesComplete==true,'objective coverage explicitly recorded')
local n=#scores;M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(#objects()==n,'unchanged objective refresh shares original immutable score content')
flags=4;M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(#objects()==n+1 and objects()[#objects()].capture.values.objectives[1][2]==4,'changed objective value creates a dated observation without merging totals')
local oldSecret=issecretvalue;issecretvalue=function(v) return v==424242 end
local rows,count,total,complete=M.Objectives({stats={{pvpStatID=9001,pvpStatValue=424242,name='Flags'}}})
check(rows[1][2]==false and complete==false,'secret objective value remains unknown instead of zero');issecretvalue=oldSecret
rows,count,total,complete=M.Objectives({stats={{pvpStatID=9001,pvpStatValue=0},{pvpStatID=9001,pvpStatValue=99}}})
check(not complete and total==2 and rows[1][2]==false,'duplicate native objective IDs never imply an unambiguous value or complete projection')
local many={};for n=1,20 do many[n]={pvpStatID=10000+n,pvpStatValue=n,name='Native objective '..n} end
rows,count,total,complete=M.Objectives({stats=many});check(count==12 and total==20 and not complete,'objective projection has an explicit twelve-row bound')
include=false;M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();v=objects()[#objects()].capture.values
check(v.objectives==nil and v.objectivesComplete==nil,'unsupported objective array remains unavailable rather than empty fabricated objectives')
-- Final retry is bounded and canceled when the observed instance changes.
local delayed={};local oldTimer=C_Timer;C_Timer={After=function(delay,fn) delayed[#delayed+1]=fn end}
include=true;M.Handle('PVP_MATCH_COMPLETE',1,700);pump();check(#delayed==1,'final score observation schedules a bounded delayed follow-up')
local first=table.remove(delayed,1);first();pump();local second=table.remove(delayed,1);second();pump();check(#delayed==0,'final score retry stops after three observations')
local statuses=0;for _,e in ipairs(all('native_event')) do if e.details.recordType=='score_capture_status' then statuses=statuses+1 end end
check(statuses>=3,'capture status distinguishes observed scoreboard rows from guaranteed final freshness')
M.Handle('PVP_MATCH_COMPLETE',1,800);pump();local later=table.remove(delayed,1)
local oldInstance=GetInstanceInfo;GetInstanceInfo=function() return 'Different battleground','pvp',1,'PvP',40,0,false,999 end
n=#objects();later();pump();check(#objects()==n,'leaving the observed context cancels stale final capture');GetInstanceInfo=oldInstance;C_Timer=oldTimer
-- A row getter/column getter can switch contexts synchronously; reject that row.
local getter=C_PvP.GetScoreInfo;C_PvP.GetScoreInfo=function(i) local result=getter(i);M.Handle('PVP_MATCH_ACTIVE');return result end
M.Handle('PVP_MATCH_COMPLETE',1,600);pump();check(#objects()==n,'score epoch change while copying cannot attach a stale row');C_PvP.GetScoreInfo=getter
-- Native creature metadata uses only an already GUID-matching unit.
local creature='Creature-0-1-2-3-12345-000000AB';units.target={guid=creature,name='Observed Beast'}
UnitClassification=function(unit) return 'elite' end
M.Kill('PARTY_KILL',UnitGUID('player'),creature)
local function kills() local out={};for _,e in ipairs(all('native_event')) do if e.details.recordType=='native_kill_credit' then out[#out+1]=e end end;return out end
e=kills()[#kills()];check(e.details.creatureID==12345 and e.details.creatureName=='Observed Beast' and e.details.classification=='elite','native creature ID/name/classification preserved from matching unit')
check(e.details.credit=='self native credit' and e.details.targetGUID==creature,'creature enrichment does not change native credit semantics')
units.target={guid='Creature-0-1-2-3-777-000000AB',name='Unrelated Beast'};M.Kill('PARTY_KILL',UnitGUID('player'),creature);e=kills()[#kills()]
check(e.details.creatureID==12345 and not e.details.creatureName and not e.details.classification,'unrelated target cannot donate creature name or classification')
local unitName=UnitName;UnitName=function(unit) local name=unitName(unit);if unit=='target' then units.target.guid='Creature-0-1-2-3-999-000000AB' end;return name end
units.target={guid=creature,name='Transient Beast'};M.Kill('PARTY_KILL',UnitGUID('player'),creature);e=kills()[#kills()]
check(not e.details.creatureName,'unit recycling during enrichment rejects mismatched metadata');UnitName=unitName
M.Kill('PARTY_KILL',UnitGUID('player'),'Creature-Unknown');e=kills()[#kills()];check(not e.details.creatureID,'malformed or unsupported GUID shape never gets a guessed NPC ID')
local packed=assert(B.PackSaved(S.db));local restored=assert(S.Normalize(packed))
check(B.Encode(restored.characters[C.Owner()].events)==B.Encode(S.Character(C.Owner(),false).events),'objective and creature evidence survive exact chunked save/reload')
check(forbiddenRegistrations==0,'no raw combat-log registration introduced')
objectiveChecks=checks-before
''')
summary={'version':'1.1.0','assertions':int(lua.globals().objectiveChecks),'failed':0,'objectiveRowsLimit':12,'finalScoreAttempts':3,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'objectives-creatures-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
