from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];lua.execute(r'''
local beforeChecks=checks
local X,G,M,B=ns.ChronicleCapture,ns.ChronicleProgress,ns.ChronicleCombat,ns.ChronicleBackup
local function pump(n) for i=1,n or 100 do X.Pump() end end
local function rows(kind) local a={};for _,e in ipairs(all('native_event')) do if e.details.recordType==kind then a[#a+1]=e end end;return a end
local function objects(family) local a={};for _,e in ipairs(all('native_snapshot')) do if e.capture.family==family then a[#a+1]=e end end;return a end
local reads,mutations=0,0;local quantity=10;local account=false
C_CurrencyInfo={GetCurrencyListSize=function() reads=reads+1;return 2 end,GetCurrencyListInfo=function(i) return {currencyID=i==1 and 42 or 100,isHeader=i==2} end,
 GetCurrencyInfo=function(id) reads=reads+1;return {currencyID=id,name='Test currency',quantity=quantity,maxQuantity=100,isAccountWide=account} end,
 ExpandCurrencyList=function() mutations=mutations+1 end}
C_MountJournal={GetMountIDs=function() reads=reads+1;return {11,12} end,GetMountInfoByID=function(id) return 'Test mount',111,123,false,true,1,false,false,nil,false,id==11,id end,
 SetCollectedFilterSetting=function() mutations=mutations+1 end}
local pets={'BattlePet-0-0001'}
C_PetJournal={GetOwnedPetIDs=function() reads=reads+1;return pets end,GetPetInfoTableByPetID=function(id) return {speciesID=44,name='Native species',customName='PRIVATE DO NOT COPY',creatureID=100,petLevel=5,displayID=1234,petType=2} end}
local toyFilter={77};C_ToyBox={GetNumFilteredToys=function() reads=reads+1;return #toyFilter end,GetToyFromIndex=function(i) return toyFilter[i] end,
 GetToyInfo=function(id) return id,'Test toy' end,SetFilterString=function() mutations=mutations+1 end}
PlayerHasToy=function(id) return id==77 or id==78 end
local lockCount=1
GetNumSavedInstances=function() reads=reads+1;return lockCount end;GetNumSavedWorldBosses=function() return 1 end
GetSavedInstanceInfo=function(i) return 'Saved raid',12345,3600,1,true,false,7,true,40,'Normal' end
GetSavedWorldBossInfo=function() return 'Saved world boss',555,1800 end
RequestRaidInfo=function() mutations=mutations+1 end
local readsBefore=reads;G.Mount(11,'control');G.Pet(pets[1],'control');G.Toy(77,'control');G.CurrencyEvent(42,10,0,0,0)
check(reads==readsBefore and not C.Active(),'paused direct collector calls never read native state')
freshRecording();pump(120)
check(#objects('currency')==1 and rows('currency_observed')[1].details.baseline==true,'initial balance is a baseline, not a gain')
check(objects('currency')[1].capture.values.catalogView:find('filtered or collapsed',1,true),'currency objects explain restricted list discovery scope')
check(rows('currency_observed')[1].details.delta==nil,'initial balance has no invented delta')
check(#objects('collection')==3,'only collected mount, pet and owned toy are archived')
local toy;for _,e in ipairs(objects('collection')) do if e.capture.values.collectionType=='toy' then toy=e.capture.values end end
check(toy and toy.catalogView:find('not exhaustive',1,true),'toy objects do not claim exhaustive catalog coverage')
check(#rows('collection_added')==0,'baseline catalogs never backfill unlock dates')
local pet=objects('collection')[2].capture.values
local encoded=ns.ChronicleBackup.Encode(ledger().events)
check(not encoded:find('PRIVATE DO NOT COPY',1,true),'pet private custom name excluded')
check(mutations==0,'catalogs do not change filters or force native data refresh')
local lock=objects('lockout_list')[1].capture.values
check(lock.complete and #lock.rows==2 and lock.instanceCount==1 and lock.worldBossCount==1,'saved instances and world bosses preserved')
check(lock.rows[1][10]>=GetServerTime()+1800 and lock.rows[2][10]>=GetServerTime()+1800,'relative reset duration is stored as dated observed expiry')
check(lock.rows[1][3]==7 or lock.rows[2][3]==7,'high instance identifier retained without folding into low ID')
local lockRows=#objects('lockout_list');G.Handle('UPDATE_INSTANCE_INFO');pump(60)
check(#objects('lockout_list')==lockRows,'unchanged lockout update suppresses duplicate content')
quantity=15;G.Handle('CURRENCY_DISPLAY_UPDATE',42,15,5,9,2)
local delivery=rows('currency_changed')[1]
check(delivery.details.quantityChange==5 and delivery.details.quantityGainSource==9 and delivery.details.destroyReason==2,'native currency event preserves raw source payload separately')
check(delivery.details.delta==nil and delivery.details.evidenceClass=='native-event','event payload is not a synthesized getter delta')
pump(80)
local getter=rows('currency_changed')[#rows('currency_changed')]
check(getter.details.delta==5 and getter.details.evidenceClass=='value-snapshot','known matching-scope balance difference has its own snapshot evidence')
quantity=3;G.Handle('CURRENCY_DISPLAY_UPDATE',42,3,-12,0,1);pump(80)
check(rows('currency_changed')[#rows('currency_changed')].details.delta==-12,'currency decrease preserved without guessed purchase cause')
account=true;quantity=50;G.Handle('CURRENCY_DISPLAY_UPDATE',42,50,nil,nil,nil);pump(80)
check(rows('currency_changed')[#rows('currency_changed')].details.delta==nil,'currency scope change never produces a false delta')
check(rows('currency_observed')[#rows('currency_observed')].details.baseline==true,'a different account/character scope establishes a new baseline')
local combat=true;UnitAffectingCombat=function() return combat end
local readCount=reads;quantity=60;G.Handle('CURRENCY_DISPLAY_UPDATE',42,60,10,0,0);pump(30)
check(reads==readCount and rows('currency_changed')[#rows('currency_changed')].details.quantityChange==10,'native currency payload retained in combat without unsafe getter')
combat=false;pump(80)
local currencyReader=C_CurrencyInfo.GetCurrencyInfo;C_CurrencyInfo.GetCurrencyInfo=function() return {currencyID=99,quantity=500} end
local prior=#objects('currency');G.Currency(42,'checkpoint');check(#objects('currency')==prior,'mismatched native currency identity rejected')
C_CurrencyInfo.GetCurrencyInfo=currencyReader
G.Handle('NEW_MOUNT_ADDED',11);G.Handle('NEW_PET_ADDED',pets[1]);G.Handle('NEW_TOY_ADDED',78);pump(80)
check(#rows('collection_added')==3,'explicit new native unlock events retained separately from observed catalog')
check(rows('collection_added')[1].details.evidenceClass=='native-event','unlock event carries precise native-source class')
toyFilter={};G.Handle('TOYS_UPDATED');pump(50)
check(#objects('collection')==4,'changing filtered toy view never invents losses or removes history')
local worldReader=GetNumSavedWorldBosses;GetNumSavedWorldBosses=nil;lockCount=0;G.Handle('UPDATE_INSTANCE_INFO');pump(60)
local partial=objects('lockout_list')[#objects('lockout_list')].capture.values
check(partial.complete==false and #partial.rows==0,'missing reader remains partial rather than claiming authoritative empty lockout list')
GetNumSavedWorldBosses=worldReader
-- Unify legacy evidence and current credits without counting group credit as own combat.
units.party1={guid='Player-Group-20',name='Party'}
M.Handle('PARTY_KILL',units.player.guid,'Player-Enemy-21')
M.Handle('PARTY_KILL',units.party1.guid,'Player-Enemy-22')
local ps=C.PlayerStatistics('Player-Enemy-21');local gs=C.PlayerStatistics('Player-Enemy-22')
check(ps.selfNativeCredits==1 and ps.combatEvents==1 and ps.legacyKillCredits==0,'per-player native own credit is reflected in evidence statistics')
check(gs.groupNativeCredits==1 and gs.combatEvents==0,'group credit is not own combat evidence')
check(C.Statistics().combatPlayers==1 and C.Statistics().namedPlayerCredits==1,'global current evidence statistics do not remain empty')
local owner=C.Owner();local event=C.Record('player_combat','COMBAT_LOG_EVENT_UNFILTERED',{},'Player-Legacy-23')
local legacy=C.PlayerStatistics('Player-Legacy-23');check(legacy.legacyCombatEvents==1 and legacy.combatEvents==1,'legacy evidence retained in shared reporting model')
M.Handle('ENCOUNTER_END',123,'A boss',1,5,0)
local result=rows('encounter_ended')[1]
check(result.details.evidenceClass=='native-event' and result.details.outcome=='failure' and result.details.outcomeScope=='boss-encounter','native encounter result is scoped precisely without claiming wipe')
M.Handle('DUEL_FINISHED');check(rows('duel_finished')[1].details.outcome=='unknown','duel completion preserves unknown outcome')
local old=S.Event(event,owner);check(old and old.details.evidenceClass==nil,'older event is never silently assigned a stronger class')
local bad={};for k,v in pairs(result) do bad[k]=v end;bad.details={};for k,v in pairs(result.details) do bad.details[k]=v end;bad.details.outcome='victory'
check(not S.Event(bad,owner),'invalid stronger outcome metadata rejected')
local class=X.Classify('native_event','control',{recordType='boss_kill_event',encounterID=12})
check(class=='value-snapshot','event-looking record type cannot claim native delivery from the wrong source')
class=X.Classify('native_event','PLAYER_REGEN_ENABLED',{recordType='own_spell_success_count'})
check(class=='source-aggregate','grouped native spell counts remain a summary rather than one event delivery')
check(not X.ValidActivity({recordType='currency_changed',currencyID=42,before=10,after=20,delta=99}),'malformed currency delta rejected')
check(not X.Validate({format=1,family='collection',values={collectionType='mount',collectionID=10,collected=false}}),'non-owned collection payload rejected')
check(not X.Validate({format=1,family='currency',values={currencyID=42,quantity=-10}}),'negative balance payload rejected')
local storage=S.Storage();check(storage.events==#ledger().events and storage.bytes==ledger().bytes,'all-character storage diagnostics reflect current ledger')
local bytes=ledger().bytes;ledger().bytes=64*1048576;check(S.Storage().stage=='growing','storage warning threshold visible without deleting history')
ledger().bytes=256*1048576;check(S.Storage().stage=='large' and #ledger().events==storage.events,'large-history warning has no retention side effect');ledger().bytes=bytes
local detail=ns.RecordingUI.Detail(result);local text='';for _,block in ipairs(detail) do text=text..block.text end
check(text:find('Native event delivery',1,true) and text:find('boss-encounter',1,true),'event detail displays source and outcome scope')
C.SetEnabled(false);local backup,err=B.Create();check(backup,err or 'expanded backup created')
local count=#ledger().events;local parts=backup.parts;C.Clear()
for i=#parts,1,-1 do local ok,why=B.Restore(parts[i]);check(ok,why or 'new families restore in reverse order') end
check(#ledger().events==count and #objects('collection')==4,'expanded collections/balances/lockouts survive backup without duplicate events')
local db=ns.DB.chronicle;db.schema=3;db.enabled=true;db.consentVersion=3;C.Initialize()
check(not S.db.enabled and S.db.needsConsentUpgrade and #ledger().events==count,'preview4 history retained and old consent pauses for added collection scope')
collectionChecks=checks-beforeChecks
''')
summary={'version':'1.0.3','assertions':lua.globals().collectionChecks,'failed':0,'liveWoWTested':False,'nativeContracts':'pinned Forever 70425 references; simulated payloads'}
(out/'collection-accuracy-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
