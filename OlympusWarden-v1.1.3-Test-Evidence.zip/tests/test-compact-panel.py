from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'compact-panel-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local P,A,W=ns.OlympusPanel,ns.Activity,ns.Workspace
units.target=nil;units.party1=nil;units.mouseover=nil;groupCount=0;freshRecording();A.Initialize()
local page=CreateFrame('Frame',nil,UIParent);page:SetSize(326,360);page:Show();P.Build(page)
local v=page.warden
local function indexed()
 local st=ns.ChronicleActivities.Request(C.Owner());local loops=0
 while not st do ns.ChronicleActivities.Pump();st=ns.ChronicleActivities.Request(C.Owner());loops=loops+1;assert(loops<10000) end
 P.Refresh(page);return st
end
check(v.heading:GetText()=='Warden' and #v.filters==6 and #v.features==5,'compact panel includes dedicated Chat filtering and five module controls')
check(v.features[4].feature=='chronicle' and v.features[4].caption:GetText()=='On','Chronicle recording status replaces old Capture shortcut')
for n,name in ipairs({'ChatWarden','ShieldWarden','SignalWarden','ChronicleWarden'}) do check(v.features[n].toggle.Icon.texture:find(name..'Small.tga',1,true),'status uses the correct rebranded module texture') end
check(v.listView.scroll:GetHeight()>=132,'full five-module stock panel retains over two and a half scrollable rows')
check(v.hero:GetHeight()==44 and v.logo:GetWidth()==44,'larger crest fits compact header')
for _,size in ipairs({{326,360},{744,480}}) do
 page:SetSize(size[1],size[2]);P.Layout(page)
 check(-v.activity.points[1].y+v.activity:GetHeight()<=page:GetHeight()-45,'feed and fixed footer do not overlap in either Olympus layout')
 for _,card in ipairs(v.features) do check(card:GetHeight()>=card.toggle:GetHeight()+4 and card.toggle:GetHeight()>=40 and card.toggle.Icon.ChatWardenIconBox.size==card.toggle:GetHeight(),'larger status artwork fits responsive compact dimensions') end
end
page:SetSize(326,360);P.Refresh(page)
C.Clear();A.Initialize();P.Refresh(page)
check(v.empty:IsShown() and #v.listView.items==0 and v.empty:GetText():find('No recent Warden activity',1,true),'empty panel explains what to expect without fabricated activity')
freshRecording();A.Initialize()
local signal=A.Add('compact:signal','mentions',{sender='Mention Friend',preview='A mention',timestamp=GetServerTime()+1})
local shield=A.Add('compact:shield','shield',{sender='Protected player',preview='Unwanted whisper',timestamp=GetServerTime()+2})
local chat=A.Add('compact:chat','messages',{sender='Chat player',action='redact',preview='Safe preview',timestamp=GetServerTime()+3})
units.target={guid='Player-Compact-FRIEND',name='Inspected Friend',class='PRIEST',level=30};C.ObserveUnit('target','INSPECT_READY',true)
local inspection=assert(C.Record('important_player','INSPECT_READY',{relationship='manual inspection'},units.target.guid,'observed'))
local milestone=assert(C.Record('level_change','PLAYER_LEVEL_UP',{before=29,after=30},nil,'observed'))
assert(C.Record('location','checkpoint',{},nil,'observed'))
indexed();local categories={}
for _,item in ipairs(v.listView.items) do if item.event then categories[item.wardenModule]=true;check(item.event.kind~='location','background observations excluded from compact recents') end end
check(categories.intel and categories.chronicle and #v.listView.items==5,'feed combines existing chat/signals/shield with local inspection and milestone evidence')
local row=v.rows[1];check(row.meta:IsShown() and row.meta:GetText()~='' and row.icon.ChatWardenIconBox.size==42 and row.icon.ChatWardenIconBox.y==-(row:GetHeight()-42)/2,'recent row timestamp is visible and larger module icon is vertically centered')
check(not row.icon.texture:find('WardenSmall.tga',1,true),'feed uses existing event artwork rather than module crests')
click(v.filters[2]);check(#v.listView.items==1 and v.listView.items[1]==chat,'Chat filter selects its own stream')
click(v.filters[3]);check(#v.listView.items==1 and v.listView.items[1]==signal,'Signals filter selects existing alert stream')
click(v.rows[1]);check(not A.EntryUnread(signal) and W.current=='mentions','compact click marks signal read and opens its original full view')
click(v.filters[4]);check(#v.listView.items==1 and v.listView.items[1]==shield,'Shield filter selects Shield activity')
click(v.filters[5]);check(#v.listView.items==1 and v.listView.items[1].event==inspection,'Intel filter surfaces original important-player evidence')
click(v.rows[1]);check(W.current=='intel' and W.pages.intel.selected==inspection.subject,'inspection compact entry opens exact player dossier')
click(v.filters[6]);check(#v.listView.items==1 and v.listView.items[1].event==milestone,'Chronicle filter selects milestone without background data')
click(v.filters[5],'RightButton');check(W.current=='intel','right-click filter provides direct module quick action')
local st=ns.ChronicleActivities.Request(C.Owner());while not st do ns.ChronicleActivities.Pump();st=ns.ChronicleActivities.Request(C.Owner()) end
InspectUnit=function(unit) nativeInspectTarget=unit end
P.Refresh(page);check(v.target:IsEnabled(),'Inspect target enabled for an available player')
click(v.target);check(nativeInspectTarget=='target' and W.current=='intel' and W.pages.intel.selected==units.target.guid,'Inspect target requests native inspection and opens the matching retained dossier')
local on=C.Active();click(v.features[4].toggle);check(W.current=='chronicle' and C.Active()==on,'Chronicle shortcut opens module without changing consent or recording')
local old=ns.DB.enabled;click(v.features[1].toggle);check(ns.DB.enabled~=old,'Chat status toggles existing filtering setting');click(v.features[1].toggle)
click(v.features[2].toggle,'RightButton');check(W.current=='shield','status right-click opens full module')
local C_Allowed=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end;P.Refresh(page)
check(#v.listView.items==0 and not v.open:IsEnabled() and not v.target:IsEnabled(),'lost membership hides feed and disables actions')
ns.Membership.Allowed=C_Allowed;P.Refresh(page)
units.target=nil;page.scripts.OnUpdate(page,1);check(not v.target:IsEnabled(),'target shortcut updates after target disappears')
units.target=units.player;P.Refresh(page);check(not v.target:IsEnabled(),'My target does not send the recorder into another-player dossiers');units.target=nil
local c=S.Character(C.Owner(),false);local events=c.events;local raw=events[#events]
-- Index only the recent tail; never synchronously walk an arbitrarily large ledger.
for n=1,2000 do events[#events+1]=raw end
local oldIpairs=ipairs;local walked=false;ipairs=function(t) if t==events then walked=true end;return oldIpairs(t) end
P.Entries('chronicle');check(not walked,'compact history lookup does not synchronously walk the raw ledger')
indexed();check(#P.Entries('chronicle')==1,'milestone survives two thousand later background observations')
ipairs=oldIpairs;for n=1,2000 do table.remove(events) end
check(forbiddenRegistrations==0,'compact rebrand adds no protected registrations')
compactChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().compactChecks,'failed':0,'nativeSizes':[[326,360],[744,480]],'historyIndexBudget':128,'maxFeedRows':100,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'compact-panel-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
