from pathlib import Path
import json,random
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];before=lua.globals().checks
lua.execute(r'''
K,R,E,O,B=ns.ChronicleCodec,ns.ChronicleRoute,ns.ChronicleEvidence,ns.ChronicleOlympus,ns.ChronicleBackup
clock=clock+100;freshRecording()
function route(x,y,a,b,z) return {format=1,mapID=37,worldMapID=0,points={{GetServerTime(),clock,x,y,a,b,z,1.123456789012345,7.000000000000003,GetServerTime(),clock,1}}} end
local raw=route(0,1,0,-1/math.huge,0);local packed=assert(K.Encode(raw));local round=assert(K.Decode(packed))
check(round.points[1][3]==0 and round.points[1][4]==1 and 1/round.points[1][6]==-math.huge,'real map edges, native zero and signed zero survive lossless codec')
check(round.worldMapID==0 and round.mapID==37,'UI map ID and native world ID remain separate')
check(round.points[1][8]==raw.points[1][8] and round.points[1][9]==raw.points[1][9],'facing and speed retain all double precision')
local valid=packed.data;packed.data=valid:sub(1,-5)..'AAAA';check(not K.Decode(packed),'route corruption rejected by checksum');packed.data=valid
packed.count=61;check(not K.Decode(packed),'route decoder rejects unbounded header before looping');packed.count=1
packed.lastElapsed=packed.lastElapsed+1;check(not K.Decode(packed),'route metadata must match raw packed values')
raw=route(false,false,123.12345678901234,-456.9876543210987,false);raw.mapID=nil
round=assert(K.Decode(assert(K.Encode(raw))))
check(round.points[1][3]==false and round.points[1][5]==raw.points[1][5] and round.points[1][6]==raw.points[1][6],'native-only coordinates preserve native axis order and missing UI values')
raw.points[1][5]=math.huge;check(not K.Encode(raw),'nonfinite native coordinates rejected')
raw=route(.1,.2,false,false,5);raw.worldMapID=nil;check(not K.Encode(raw),'height alone never masquerades as a native position')
local moving={format=1,mapID=37,points={}}
for i=1,60 do moving.points[i]={GetServerTime()+i,clock+i*2,.123456789012345+i*.000013,.987654321098765-i*.000017,false,false,false,false,7,GetServerTime()+i,clock+i*2,1} end
packed=assert(K.Encode(moving));round=assert(K.Decode(packed))
for i=1,60 do for j=1,12 do check(round.points[i][j]==moving.points[i][j],'moving route double roundtrip '..i..'/'..j) end end
routeRawBytes=#B.Encode(moving);routePackedBytes=#B.Encode(packed)
check(routePackedBytes<routeRawBytes,'packed moving route is smaller than the equivalent numeric tables')
-- Real collector lifecycle with readable native fixtures.
local map=37;local x,y=.123456789012345,.987654321098765;local ax,ay,z=123.12345678901234,-456.9876543210987,14.1234567890123
C_Map={GetBestMapForUnit=function(unit) check(unit=='player','route only asks for own map');return map end,
 GetPlayerMapPosition=function(id,unit) return {GetXY=function() return x,y end} end}
UnitPosition=function(unit) return ax,ay,z,0 end;GetPlayerFacing=function() return 1.25 end;GetUnitSpeed=function() return 0 end
freshRecording();for i=1,40 do clock=clock+2;R.Sample() end
check(R.Pending()==1 and #all('route_segment')==0,'stationary observations collapse into one pending run')
R.Flush();local event=all('route_segment')[1];round=assert(K.Decode(event.route))
check(round.points[1][12]==41 and round.points[1][11]-round.points[1][2]==80,'stationary run retains original endpoints and observation count')
for i=1,20 do clock=clock+2;x=x+.00003;ax=ax+.006;R.Sample() end
R.Flush();check(#all('route_segment')==2 and all('route_segment')[2].details.continued,'moving data continues same route without invented interpolation')
local firstSegment=all('route_segment')[2].details.segment
map=38;clock=clock+2;R.Sample();R.Flush()
check(all('route_segment')[3].details.segment~=firstSegment and all('route_segment')[3].details.gapBefore,'map transitions break route continuity explicitly')
local saved=#all('route_segment');local oldAt=GetServerTime();epoch=epoch-100;R.Sample();R.Flush()
check(#all('route_segment')==saved,'backward wall clock adds no backdated route sample');epoch=epoch+100
local native=UnitPosition;local mapgetter=C_Map.GetPlayerMapPosition
UnitPosition=function() return nil end;C_Map.GetPlayerMapPosition=function() return nil end
clock=clock+2;R.Sample();local gaps=#all('collection_gap');clock=clock+2;R.Sample()
check(#all('collection_gap')==gaps and gaps>0,'repeated coordinate unavailability creates one gap, never guessed zeroes')
UnitPosition=native;C_Map.GetPlayerMapPosition=mapgetter;clock=clock+2;R.Sample();R.Flush()
check(all('route_segment')[#all('route_segment')].details.gapBefore,'readable data after missing coordinates starts a new segment')
local ownGuid=UnitGUID;local reads=0;UnitGUID=function(unit) if unit=='player' then reads=reads+1;return reads<=1 and units.player.guid or 'Player-Changed-02' end;return ownGuid(unit) end
check(not R.Position(),'character identity change during coordinate read rejects sample');UnitGUID=ownGuid
local changing=0;C_Map.GetBestMapForUnit=function() changing=changing+1;return changing%2==1 and 37 or 38 end
check(not R.Position(),'map change during coordinate read rejects mismatched fractions');C_Map.GetBestMapForUnit=function() return map end
local secretFn=issecretvalue;issecretvalue=function(value) return value==424242 end
local nativePosition=UnitPosition;UnitPosition=function() return 424242,2,3,0 end
local safe=assert(R.Position());check(safe.point[5]==false and safe.point[6]==false and safe.mapID==map,'inaccessible native coordinates stay absent while readable UI position survives')
check(not S.PublicRow('wanted',{bounty=424242}),'public row validator also rejects inaccessible scalar values')
issecretvalue=secretFn;UnitPosition=nativePosition
C.SetEnabled(false);local attempts=R.diagnostics.attempts;R.Sample();E.Handle('LOOT_OPENED')
check(R.diagnostics.attempts==attempts,'no route API read after opt-out')
-- Existing scope retains its history but expanded capture never inherits consent.
local old=ns.DB.chronicle;old.schema=1;old.enabled=true;old.consentVersion=1;old.promptSeen=1
local retained=#ledger().events;C.Initialize()
check(not S.db.enabled and S.db.needsConsentUpgrade and #ledger().events==retained,'scope-one upgrade pauses recording and preserves old history')
ns.Workspace.Open('updates');C.Handle('PLAYER_ENTERING_WORLD',true,false);drain()
check(S.db.promptSeen==1 and not ns.RecordingConsentWindow:IsShown(),'Updates cannot consume the new recording prompt unseen')
ns.Workspace.window:Hide();drain()
check(ns.RecordingConsentWindow:IsShown() and S.db.promptSeen==S.CONSENT and not C.Active(),'new scope explanation appears after update screen closes')
ns.RecordingConsentWindow:Hide();check(not S.db.enabled,'closing updated scope never consents')
C.MaybePrompt(true);drain();check(ns.RecordingConsentWindow:IsShown(),'manual command reopens explanation after dismissal')
ns.RecordingConsentWindow:Hide();clock=clock+20;freshRecording()
-- Native observations use typed data, preserve source, and suppress unchanged reads.
local mounted=false;IsMounted=function() return mounted end;UnitIsDead=function() return false end
GetBuildInfo=function() return '1.60.1','70000','Oct 16 2026',160001 end;GetLocale=function() return 'enUS' end
UnitSex=function() return 2 end;GetXPExhaustion=function() return 345 end
local item=19019;local itemLink='|cffa335ee|Hitem:19019:123:456:0:0:0:-2:999:30|h[Example]|h|r'
GetInventoryItemID=function(unit,slot) return slot==16 and item or nil end
GetInventoryItemLink=function() return itemLink end
C_QuestLog={GetNumQuestLogEntries=function() return 1,1 end,GetInfo=function(i) return {questID=1234,title='A native quest',level=31,isHeader=false,frequency=1,suggestedGroup=3} end,
 GetQuestObjectives=function(id) return {{text='Wolves: 2/5',type='monster',finished=false,numFulfilled=2,numRequired=5}} end}
C_Reputation={GetNumFactions=function() return 1 end,GetFactionDataByIndex=function() return {factionID=72,name='Stormwind',isHeader=false,reaction=5,currentStanding=4321,currentReactionThreshold=3000,nextReactionThreshold=9000} end}
C_Container={GetContainerNumSlots=function(bag) return bag==0 and 1 or 0 end,GetContainerItemInfo=function() return {itemID=19019,stackCount=2,hyperlink=itemLink,isBound=true} end}
Enum={SpellBookSpellBank={Player=0}}
C_SpellBook={GetNumSpellBookSkillLines=function() return 1 end,GetSpellBookSkillLineInfo=function() return {itemIndexOffset=0,numSpellBookItems=1} end,
 GetSpellBookItemInfo=function() return {spellID=133,actionID=133,name='Fireball',subName='Rank 1',isPassive=false,isOffSpec=false} end}
GetBindLocation=function() return 'Goldshire' end
E.Start();for i=1,40 do E.Pump() end
check(#all('character_detail')==1 and all('character_detail')[1].details.restedXP==345,'character build and rested XP observed without inventing past gains')
check(#all('equipment_observed')==1 and all('equipment_observed')[1].details.itemString=='item:19019:123:456:0:0:0:-2:999:30','equipment keeps full native item payload without chat markup')
check(#all('quest_observed')==1 and #all('quest_objective')==1 and C.Statistics().quests==0,'quest baseline and objectives never imply a turn-in')
check(#all('reputation_observed')==1 and all('reputation_observed')[1].details.standing==4321,'reputation snapshot uses native standing and faction ID')
check(#all('inventory_observed')==1 and all('inventory_observed')[1].details.quantity==2,'bag snapshot keeps item count without acquisition inference')
check(#all('spell_observed')==1 and #all('spell_learned')==0,'existing spellbook snapshot is distinct from learning event')
local count=#ledger().events;E.Start();for i=1,40 do E.Pump() end
check(#ledger().events==count,'unchanged native snapshots do not duplicate on rescan')
mounted=true;E.Handle('PLAYER_MOUNT_DISPLAY_CHANGED');check(all('player_state')[#all('player_state')].details.mounted==true,'native mount state change recorded')
item=nil;E.Equipment('UNIT_INVENTORY_CHANGED',16);check(#all('equipment_change')==0,'unavailable equipment getter alone never proves removal')
E.Equipment('PLAYER_EQUIPMENT_CHANGED',16,false);check(#all('equipment_change')==1 and all('equipment_change')[1].details.hasCurrent==false,'explicit native equipment removal retained')
local bagGetter=C_Container.GetContainerItemInfo
C_Container.GetContainerItemInfo=function() return nil end
E.Bags('BAG_UPDATE_DELAYED');for i=1,10 do E.Pump() end
check(all('inventory_observed')[#all('inventory_observed')].details.hasCurrent==false,'documented empty bag slot retained without transaction inference')
C_Container.GetContainerItemInfo=bagGetter;E.Bags('BAG_UPDATE_DELAYED');for i=1,10 do E.Pump() end
check(all('inventory_observed')[#all('inventory_observed')].details.hasCurrent==true,'same item after empty slot is a new observation')
E.Handle('QUEST_ACCEPTED',1234);E.Handle('QUEST_REMOVED',1234);check(#all('quest_accepted')==1 and #all('quest_removed')==1 and C.Statistics().quests==0,'acceptance and removal never become guessed quest completion')
GetNumLootItems=function() return 1 end;GetLootSlotLink=function() return itemLink end;GetLootSlotInfo=function() return 123,'Example',3 end
E.Handle('LOOT_OPENED');check(#all('loot_offered')==1 and all('loot_offered')[1].details.quantity==3,'loot window saves offered item only')
E.Handle('LEARNED_SPELL_IN_SKILL_LINE',116);E.Handle('ACHIEVEMENT_EARNED',6)
check(#all('spell_learned')==1 and #all('achievement_earned')==1,'native learned spell and earned achievement IDs preserved')
E.Handle('LEARNED_SPELL_IN_TAB','fake');E.Handle('ACHIEVEMENT_EARNED',math.huge)
check(#all('spell_learned')==1 and #all('achievement_earned')==1,'invalid native IDs rejected')
check(not E.ItemString(itemLink,999),'item payload with conflicting item ID rejected')
ev('PLAYER_LEAVING_WORLD');local n=#ledger().events;E.Handle('LOOT_OPENED');E.Pump();check(#ledger().events==n,'no native snapshot reads during loading')
ev('PLAYER_ENTERING_WORLD',false,false)
-- Actual Olympus 1.2.4 getters and pushed callbacks; no private internal reads by ChatWarden.
clock=clock+20
function GetGuildInfo(unit) return units[unit] and units[unit].guild,'Mortal Applicant',7 end
wantedRows={};for i=1,12 do wantedRows[i]={guid='Player-Public-'..i,name='Wanted '..i,active=true,current=i*100,lifetimeKills=i,cycle=2} end
oly.Wanted.Rankings=function() return {month={{name='Slayer One',points=45,claims=3}},all={{guid='Player-Slayer-1',name='Slayer One',points=500,claims=9}}} end
oly.Wanted.GlobalSnapshot=function() return {rows={{guid='Player-Slayer-1',points=500,claims=9}}} end
oly.HonorsNet.Donors=function() return {all={'Donor One'},month={'Monthly Donor'}} end
oly.HonorsNet.ChurchTop=function() return {missionaries={'Missionary One'},apostles={'Apostle One'}} end
oly.Treasury={PublicShows=function() return true end};oly.Honors={FrameShipped=function() return true end}
oly.ArenaHome={RankingsPublic=function() return true end};oly.ArenaLedger={RankingView=function() return {rows={{rank=1,name='Arena One',rating=1234,wins=8,losses=2}}} end}
oly.FarkleTable={Best=function() return {{name='Bones One',games=12,won=4}} end}
local profiles=C.Statistics().profiles;local encounters=C.Statistics().encounters;local alerts=#ns.Activity.List('wanted')
O.Stop();O.Start();local snapshots=all('olympus_snapshot');local boards={};for _,e in ipairs(snapshots) do boards[e.snapshot.board]=e.snapshot end
for _,board in ipairs({'wanted','self','slayers.month','slayers.all','slayers.signed','donors.month','donors.all','church.missionaries','church.apostles','games.arena','games.bones'}) do check(boards[board]~=nil,'actual supported Olympus board archived: '..board) end
check(boards.wanted.parts==4 and boards.self.rows[1].values.rankIndex~=nil and boards.self.rows[1].values.frame=='lion-gold','all Wanted rows and raw own-profile fields preserved')
check(C.Statistics().profiles==profiles and C.Statistics().encounters==encounters and #ns.Activity.List('wanted')==alerts,'public archival creates no private profile, encounter or alert')
local snapshotCount=#snapshots;oly.Fire('WANTED_CHANGED');pump()
check(#all('olympus_snapshot')==snapshotCount,'unchanged pushed Wanted and ranking data create no history noise')
wantedRows[1].current=999;table.remove(wantedRows,12);oly.Fire('WANTED_CHANGED');pump()
local last=all('olympus_snapshot')[#all('olympus_snapshot')]
check(last.snapshot.kind=='wanted' and last.snapshot.mode=='delta' and #last.snapshot.rows==1 and #last.snapshot.removed==1,'pushed Wanted change stores only changed and removed rows')
oly.Treasury.PublicShows=function() return false end;oly.Fire('TREASURY_CHANGED');pump()
local missing=0;for _,e in ipairs(all('olympus_snapshot')) do if e.snapshot.mode=='unavailable' and e.snapshot.board:find('donors',1,true) then missing=missing+1 end end
check(missing==2,'public board permission closing is unavailable, not an empty ranking')
local previous=#all('olympus_snapshot');O.Save('wanted','wanted',{[1]={name='ok'},rogue='secret'},'WANTED_CHANGED')
check(#all('olympus_snapshot')==previous,'nonarray public payload rejected before partial writes')
local list=ns.RecordingUI.Query({kind='olympus_snapshot'});local rawlist=ns.RecordingUI.Query({kind='olympus_snapshot',raw=true})
check(#list<#rawlist and list[1].grouped,'default viewer groups archive parts; raw parts remain available')
local wanted;for _,e in ipairs(list) do if e.snapshot.board=='wanted' and e.snapshot.parts==4 then wanted=e end end
local blocks=ns.RecordingUI.Detail(wanted);local found=false;for _,block in ipairs(blocks) do if block.text:find('Wanted 12',1,true) then found=true end end
check(found,'grouped details expose every original public row, including last part')
-- Lossless routes + public archives + native snapshots all survive history export.
C.SetEnabled(false);local original=B.Encode(ledger().events);local originalCount=#ledger().events
local exported=assert(B.Create());for _,part in ipairs(exported.parts) do check(B.Validate(part)~=nil,'expanded archive backup validates') end
C.Clear();for i=#exported.parts,1,-1 do check(B.Restore(exported.parts[i]),'expanded archive backup restores in reverse part order') end
check(#ledger().events==originalCount and not S.db.enabled,'expanded restore retains all data without inheriting consent')
local restoredRoute=all('route_segment')[1];check(restoredRoute and K.Decode(restoredRoute.route)~=nil,'packed coordinate precision survives export and restore')
local changed=false
for _,part in ipairs(exported.parts) do
 local corruption=assert(B.Validate(part));corruption.clean=nil;corruption.partHash=nil
 for _,record in ipairs(corruption.records) do if record.event and record.event.route then record.event.route.sha256=string.rep('0',64);changed=true;break end end
 if changed then local raw=B.Encode(corruption);local text='OCW-HISTORY-1:'..ns.PackCrypto.Hex(ns.PackCrypto.SHA256(raw))..'\n'..ns.PackCrypto.Base64Encode(raw);check(not B.Restore(text),'valid outer checksum cannot smuggle corrupt packed route');break end
end
check(changed,'corruption check exercised an actual packed route')
clock=clock+100;C_Map=nil;UnitPosition=nil;freshRecording()
local startSeconds=C.Statistics().seconds
for i=1,20 do step(30) end
check(C.Statistics().seconds-startSeconds==600 and #all('time_span')==2 and #all('time_slice')==0,'ten minutes of measured idle time become two spans, not twenty log rows')
C.SetEnabled(false);local c=ledger();local owner=C.Owner()
for i=1,500 do S.Append(owner,{kind='time_slice',source='checkpoint',session=c.currentSession,at=GetServerTime()-600+i,elapsed=i,
 timeSource='server',evidence='observed',location={zone='Old Zone'},details={seconds=1,afk=i%4==0}});C.Statistics() end
for i=1,20 do S.Observe(owner,'Player-Stats-'..i,{name='Observed '..i},GetServerTime(),'PLAYER_TARGET_CHANGED',{});C.Statistics() end
local incremental=B.Encode(C.Statistics());C.Initialize()
check(B.Encode(C.Statistics())==incremental,'incremental long-history statistics match a full normalization and rebuild, including delayed events and new profiles')
check(E.diagnostics.errors==0 and C.diagnostics.errors==0 and forbiddenRegistrations==0,'expanded collectors have no swallowed errors or forbidden registration attempts')
''')
# Many difficult but valid double values, including subnormals, through the real codec.
random.seed(10303)
values=[5e-324,2.2250738585072014e-308,0.1,0.9999999999999999]+[random.random() for _ in range(120)]
for v in values:
    lua.globals().precise=v
    lua.execute("local r=route(precise,precise,precise,-precise,precise);local p=assert(K.Decode(assert(K.Encode(r))));check(p.points[1][3]==precise and p.points[1][6]==-precise,'difficult double preserved exactly')")
summary={'version':'1.0.3','assertions':lua.globals().checks-before,'failed':0,
 'routeRawBytes':lua.globals().routeRawBytes,'routePackedBytes':lua.globals().routePackedBytes,
 'nativeContracts':'synthetic fixtures; native availability requires live Forever validation','actualOlympusAPI':'1.2.4','liveWoWTested':False}
(out/'preservation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))

lua.execute(r'''
C_Map={GetBestMapForUnit=function() return 37 end,GetPlayerMapPosition=function() return {GetXY=function() return .4321234567890123,.6212345678901234 end} end}
UnitPosition=function() return -9456.123456789012,73.98765432109876,66.2,0 end
C.Clear();clock=clock+20;ns.OlympusConnection.Refresh(true);C.Handle('PLAYER_ENTERING_WORLD',false,false);C.SetEnabled(true)
R.Start();clock=clock+2;R.Sample();C.Flush();C.SetEnabled(false)
ns.Workspace.Open('recording');local p=ns.Workspace.pages.recording;p.filter={page=0,kind='route_segment'};p:SetView('events');p:Refresh(true)
click(p.list.rows[1])
''')
export=state['scene_scope']['export_scene']
(out/'scene-recording.json').write_text(json.dumps(export(lua,'workspace'),default=str),encoding='utf-8')
lua.execute("ns.Workspace.pages.recording:SetView('coverage')")
(out/'scene-coverage.json').write_text(json.dumps(export(lua,'workspace'),default=str),encoding='utf-8')
