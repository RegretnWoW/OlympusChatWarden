from pathlib import Path
import json,time,hashlib,statistics
out=Path(__file__).resolve().parent;root=out.parents[1]
host={'__file__':str(out/'test-integration.py')};exec(compile((out/'test-integration.py').read_text().split('count=0')[0],'city-host','exec'),host)
fixture=r'''
C,S,B=ns.Chronicle,ns.ChronicleStore,ns.ChronicleBackup
epoch=1800000000;clock=100;units={player={guid='Player-City-SELF',name='Recorder',class='MAGE',race='Human',guild='Olympus',level=60}}
function GetTime() return clock end;function GetServerTime() return epoch+math.floor(clock) end
function GetRealmName() return 'Fixture Realm' end;function IsLoggedIn() return true end
function UnitGUID(u) return units[u] and units[u].guid end;function UnitName(u) return units[u] and units[u].name end
function UnitFullName(u) return UnitName(u),'Fixture Realm' end
function UnitIsPlayer(u) return units[u]~=nil end;function UnitIsVisible(u) return units[u]~=nil end
function UnitClass(u) return '',units[u] and units[u].class end;function UnitRace(u) return '',units[u] and units[u].race end
function UnitLevel(u) return units[u] and units[u].level end;function UnitSex() return 2 end
function UnitFactionGroup() return 'Alliance' end;function GetGuildInfo(u) return units[u] and units[u].guild end
function GetRealZoneText() return 'Stormwind fixture' end;function GetSubZoneText() return 'Trade District' end
function IsInInstance() return false,'none' end
ns.DB.chronicle={schema=6,enabled=false,characters={}};C.Initialize();assert(C.SetEnabled(true))
local m=getmetatable(UIParent).__index;function m:SetHighlightTexture() end
function observe(n)
 local id=n%500+1;local unit=n%2==0 and 'target' or 'mouseover'
 units[unit]={guid='Player-City-'..id,name='Citizen '..id,class='WARRIOR',race='Human',guild=n%47==0 and 'Changed Guild' or 'Olympus',level=n%61==0 and 61 or 60}
 clock=100+n*.02;C.ObserveUnit(unit,n%2==0 and 'PLAYER_TARGET_CHANGED' or 'UPDATE_MOUSEOVER_UNIT',true)
end
function observeBatch() for n=1,10000 do observe(n) end end
function profilesBatch()
 local owner=C.Owner();local d={name='Profile citizen',class='WARRIOR',guild='Olympus',level=60,localSighting=true,encounter=false}
 for n=1,20000 do S.Observe(owner,'Player-City-PROFILE',d,epoch+100+math.floor(n/20),n%2==0 and 'PLAYER_TARGET_CHANGED' or 'UPDATE_MOUSEOVER_UNIT',{zone='Stormwind fixture',inInstance=false}) end
end
function digest()
 local c=S.Character(C.Owner(),false);for _,e in ipairs(c.events) do digestUpdate(B.Encode(e)) end
 local ids={};for id in pairs(c.profiles) do ids[#ids+1]=id end;table.sort(ids)
 for _,id in ipairs(ids) do digestUpdate(B.Encode(c.profiles[id])) end
 return #c.events,#ids,c.bytes
end
plates={};for n=1,60 do local plate=CreateFrame('Frame',nil,UIParent);plate.UnitFrame=CreateFrame('Frame',nil,plate)
 plate.UnitFrame.name=plate.UnitFrame:CreateFontString(nil,'OVERLAY');plate.UnitFrame.name:SetText('Citizen '..n);plate.UnitFrame.unit='nameplate'..n;plates[n]=plate
 units['nameplate'..n]={guid='Player-Plate-'..n,name='Citizen '..n,class='WARRIOR'}
end
C_NamePlate={GetNamePlates=function() return plates end};ns.DB.playerNames=true;ns.DB.nameplates=true
function plateBatch() for n=1,100 do ns.NameDisplays.Scan() end end
'''
results={}
for label,source in [('rc5',out/'baseline'),('release',root)]:
 host['root']=source;host['modules']=[n for n in (source/'OlympusChatWarden/OlympusChatWarden.toc').read_text().splitlines() if n.endswith('.lua')]
 samples=[]
 for repeat in range(3):
  lua=host['fresh']('modern',True);lua.execute(fixture);row={}
  for key in ['observeBatch','profilesBatch','plateBatch']:
   lua.execute('collectgarbage("collect");collectgarbage("stop")');before=lua.eval('collectgarbage("count")');at=time.perf_counter();lua.globals()[key]();row[key+'Seconds']=time.perf_counter()-at
   row[key+'AllocatedKiB']=lua.eval('collectgarbage("count")')-before;lua.execute('collectgarbage("restart");collectgarbage("collect")')
  h=hashlib.sha256();lua.globals().digestUpdate=lambda s:h.update(s.encode());row['events'],row['profiles'],row['estimatedBytes']=lua.globals().digest();row['canonicalSha256']=h.hexdigest();row['cleanedHostHeapKiB']=lua.eval('collectgarbage("count")')
  if label=='release':
   row['bindings']=lua.eval('ns.NameDisplays.BindingCount()');row['reusedBindings']=lua.eval('ns.NameDisplays.bindingStats.reused');row['seenPlayers']=lua.eval('ns.Chronicle.RuntimeCounts()')[0]
  samples.append(row);print(label,repeat,json.dumps(row),flush=True)
 results[label]=samples
for before,after in zip(results['rc5'],results['release']):
 assert before['canonicalSha256']==after['canonicalSha256'] and before['events']==after['events'] and before['estimatedBytes']==after['estimatedBytes'],'Optimization changed canonical collection/profile data'
 assert after['bindings']<=100 and after['seenPlayers']<=600 and after['reusedBindings']>=5900
digest=hashlib.sha256()
for p in sorted((root/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(p.name.encode());digest.update(p.read_bytes())
results.update(version='1.1.0',failed=0,repetitions=3,synthetic=True,actualForeverTest=False,luaSourceSha256=digest.hexdigest(),notes='Explicit GC boundaries; allocation samples stop GC. Host timings and memory are not native addon attribution. Identical event/profile digest required.')
(out/'city-summary.json').write_text(json.dumps(results,indent=2)+'\n');print('Matched city collection and nameplate tests passed')
