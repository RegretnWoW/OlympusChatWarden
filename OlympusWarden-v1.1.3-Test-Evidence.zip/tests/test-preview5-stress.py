from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'preview5-stress-host','exec'),scope)
lua=scope['lua'];lua.execute((out/'policy-fixture.lua').read_text());start=time.perf_counter()
lua.execute(r'''
local before=checks;local F,A,I,P,U,W=Preview5,ns.ChronicleActivities,ns.ChronicleIntelligence,ns.OlympusPanel,ns.WardenUI,ns.Workspace
local c=F.Fresh();local quest=F.Emit('quest_turnin',1,{questID=999},'QUEST_TURNED_IN')
local guid='Player-Sparse-ONE';F.Observe(2,guid,'Sparse Friend');local inspected=F.Emit('important_player',3,{relationship='manual inspection'},'INSPECT_READY',guid)
local raw=c.events
for n=1,200000 do
 raw[#raw+1]={id=F.owner..':raw'..n,kind='location',at=F.base+10+n,elapsed=10+n,source='checkpoint',character=F.owner,session=c.currentSession,timeSource='server',evidence='observed',details={},location=F.world}
end
c.sequence=200003
local st=A.Request(F.owner);check(not st,'large sparse history starts cooperative indexing')
local old=InCombatLockdown;InCombatLockdown=function() return true end
local processed=A.Progress();A.Pump();check(A.Progress()==processed,'large index pauses in combat');InCombatLockdown=old
local loops,maxStep,maxSeconds=0,0,0
while not st do
 local previous=A.Progress();local at=os.clock();A.Pump();maxSeconds=math.max(maxSeconds,os.clock()-at)
 local current=A.Progress();if current>0 then local delta=current-previous;maxStep=math.max(maxStep,delta);check(delta<=128,'history work bounded per frame') end
 loops=loops+1;assert(loops<3000);st=A.Request(F.owner)
end
check(loops>=1563 and maxStep==128,'large history is spread across more than fifteen hundred frames')
check(#st.intelligence.recent.chronicle==1 and st.intelligence.recent.chronicle[1].event==quest,'old meaningful milestone survives two hundred thousand newer raw observations')
check(#st.intelligence.recent.intel==1 and st.intelligence.recent.intel[1].event==inspected,'sparse important-player event remains indexed')
local previousIpairs=ipairs;local walked=0
ipairs=function(t) if t==raw then walked=walked+1 end;return previousIpairs(t) end
local list=P.Entries('chronicle');check(#list==1 and list[1].event==quest and walked==0,'compact redraw reads meaningful index without walking full history')
P.OpenRecord({wardenModule='intel',owner=F.owner,guid=guid,event=inspected});check(W.current=='intel' and W.pages.intel.selected==guid and walked==0,'old compact dossier link uses indexed evidence without raw traversal')
P.OpenRecord({wardenModule='chronicle',owner=F.owner,event=quest});check(W.current=='chronicle' and W.pages.chronicle.selected==quest.id and walked==0,'old compact milestone opens its exact highlight without raw traversal')
ipairs=previousIpairs
for n=1,250 do F.Emit('quest_turnin',200100+n,{questID=2000+n},'QUEST_TURNED_IN') end
st=F.Build();check(#st.intelligence.recent.chronicle==I.RECENT_LIMIT,'recent projection stores only a bounded set of event references')
check(st.intelligence.recent.chronicle[1].event.details.questID==2131 and st.intelligence.recent.chronicle[120].event.details.questID==2250,'bounded index contains newest meaningful records in chronological order')
check(st.intelligence.events[quest.id]==quest,'dropping an old recent reference never deletes original history')
U.Navigate('highlight',F.owner,quest.id,quest);check(W.pages.chronicle.currentRow.event==quest,'source navigation still reaches an event outside the recent projection')
local sequence=c.sequence;local first=raw[1];local tail=raw[#raw]
check(c.events==raw and raw[1]==first and raw[#raw]==tail and c.sequence==sequence and not C.Active(),'index and navigation do not modify retained history or consent')
-- Cache integrity includes array identity, not only count/tail; replacement must rebuild.
local replacement={};for n,e in ipairs(raw) do replacement[n]=e end;c.events=replacement
check(A.Request(F.owner)==nil,'equal-length replacement retaining its tail still invalidates the derived index')
W.Open('overview');U.Navigate('player',F.owner,guid,inspected);check(U.pending~=nil,'replacement lookup defers cooperatively')
c.events={};U.PumpNavigation();check(not U.pending,'replacing history during lookup cancels the pending link')
stressLoops=loops;stressMaxStep=maxStep;stressMaxSeconds=maxSeconds;stressChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().stressChecks,'failed':0,'rawBackgroundRecords':200000,'indexFrames':lua.globals().stressLoops,'maxRawRecordsPerFrame':lua.globals().stressMaxStep,'maxMeasuredFrameSeconds':round(lua.globals().stressMaxSeconds,5),'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'preview5-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
