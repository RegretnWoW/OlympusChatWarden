from pathlib import Path
import json,sys,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'1.1-startup-smoke','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local W,U,Q,A,I=ns.Workspace,ns.WardenUI,ns.WardenSearch,ns.ChronicleActivities,ns.ChronicleIntelligence
local function ready()
 local st=ns.ChronicleActivities.Request(C.Owner());local n=0
 while not st do ns.ChronicleActivities.Pump();n=n+1;assert(n<10000);st=ns.ChronicleActivities.Request(C.Owner()) end
 return st
end
check(ns.NAME=='Olympus Warden' and ns.VERSION=='1.1.1-preview8','display brand and private preview version')
check(S.VERSION==6 and S.CONSENT==5,'recording contract unchanged')
check(SLASH_OLYMPUSCHATWARDEN1=='/chatwarden' and SLASH_OLYMPUSCHATWARDEN2=='/ocw' and SLASH_OLYMPUSCHATWARDEN3=='/warden' and SLASH_OLYMPUSCHATWARDEN4=='/ow','new commands keep legacy aliases')
check(W.navigation.intel and W.navigation.chronicle and not W.navigation.capture and not W.navigation.rules and not W.navigation.packs and not W.navigation.reports,'five feature sections; chat utilities leave sidebar')
for _,id in ipairs({'messages','capture','rules','packs','reports'}) do
 W.Open(id);check(W.chatTabHost:IsShown() and #W.chatTabs==6,'ChatWarden utility and settings tabs remain inside the module: '..id)
end
W.Open('intel');check(not W.chatTabHost:IsShown(),'chat tabs do not leak into IntelWarden')
check(not C.Active(),'opening all views does not opt in')
units.target=nil;units.mouseover=nil;units.focus=nil;units.party1=nil;groupCount=0
freshRecording();ns.History.Initialize();ns.History.SetEnabled(true);local self=C.Owner():match('/(Player%-.+)$')
units.target={guid='Player-Test-ONE',name='Same Name',class='MAGE',level=20,guild='Olympus Reloaded',race='Human',faction='Alliance'};ev('PLAYER_TARGET_CHANGED')
units.target={guid='Player-Test-TWO',name='Same Name',class='WARRIOR',level=25,guild='Other Guild',race='Orc',faction='Horde'};clock=clock+130;ev('PLAYER_TARGET_CHANGED')
units.party1={guid='Player-Test-ROSTER',name='Distant Friend',class='PRIEST',level=30,guild='Olympus Reloaded'};groupCount=2;ev('GROUP_ROSTER_UPDATE')
units.player.level=35;ev('PLAYER_LEVEL_UP',35);ev('QUEST_TURNED_IN',4567,123,0);step(30)
check(C.SetPersonal('Player-Test-ONE','Trusted guide',true),'private note saved through existing API')
renderState=ready();local st=renderState
local rows=U.Players(st,'recent');check(#rows==3,'recent contacts include local observations and remote rosters')
check(rows[1].at>=rows[#rows].at,'recent contacts sort newest first')
local same=U.Players(st,'all','same name');check(#same==2 and same[1].id~=same[2].id,'same names stay separate by GUID')
check(#U.Players(st,'all','Other Guild')==1,'guild lookup searches saved facts')
check(#U.Players(st,'all','WARRIOR')==1,'class lookup searches saved facts')
check(#U.Players(st,'watch')==1,'watchlist uses personal metadata')
local beforeOwn=#U.Players(st,'all')
st.intelligence.players[self]={facts={},encounters={},evidence={},credits={own=0,pet=0,group=0,unattributed=0,incoming=0},zones={},scoreboards={},publicReports={}}
check(#U.Players(st,'all')==beforeOwn,'own player excluded from IntelWarden')
st.intelligence.players[self]=nil
local highlights=U.Highlights(st);check(#highlights>=2,'journal surfaces level and quest highlights')
local simple=U.ChronicleDetail(st,highlights[1]);local journalText='';for _,block in ipairs(simple) do journalText=journalText..block.text end
check(not journalText:find('Technical source',1,true) and journalText:find('Original record',1,true),'journal uses a readable milestone summary and links the detailed evidence')
local pvp=U.Profile(st,same[1]);local text='';for _,b in ipairs(pvp) do text=text..b.text end
check(text:find('unknown',1,true) and text:find('does not confirm',1,true),'profile keeps unknown killers and roster limits explicit')
W.Open('intel');local p=W.pages.intel;p:Refresh(true);check(#p.rows==3,'production Intel UI shows profiles')
p.selected='Player-Test-ONE';p:Refresh(true);check(p.currentRow and p.note:GetText()=='Trusted guide','selected profile shows saved note')
p.note:SetText('Unsaved draft');p.noteDirty=true;p:Refresh(true);check(p.note:GetText()=='Unsaved draft','refresh does not erase an unsaved note')
ns.ChronicleActivities.Clear();p:Refresh(true);check(p.note:GetText()=='Unsaved draft' and p.selected=='Player-Test-ONE','pending rebuild preserves selected profile and unsaved note')
ready();p:Refresh(true)
click(p.save);ready();p:Refresh(true);check(C.Profile('Player-Test-ONE').personal.note=='Unsaved draft','note editor commits through compatibility API')
W.Open('chronicle');p=W.pages.chronicle;p:Refresh(true);check(#p.rows>=2,'production journal displays recorded highlights')
click(p.list.rows[1]);check(p.currentRow and p.document.blocks,'journal selection opens details')
click(p.open);check(W.current=='recording' and W.pages.recording.selected~=nil,'journal opens original evidence')
W.Open('chronicle');p=W.pages.chronicle;p.mode='time';p:Activate();check(p.deep:IsShown() and not p.body:IsShown(),'time summaries remain available under ChronicleWarden')
W.Open('overview');check(W.pages.overview.cards[1].value:GetText()~='Reading...','home data overview uses existing measured history')
ns.ChatCapture.db.entries[#ns.ChatCapture.db.entries+1]={id=9876,sender='Same Name',original='A private capture example',event='CHAT_MSG_SAY',timestamp=GetServerTime()}
local function query(q)
 local job=Q.Begin(q);local n=0;while not Q.Pump(job,16) do n=n+1;assert(n<10000) end;return job
end
local j=query('Same Name');local groups={};for _,r in ipairs(j.results) do groups[r.group]=true end
check(groups.IntelWarden and groups.ChatWarden and groups.IntelWarden,'suite search combines profiles, capture and recorded events')
local types={};for _,r in ipairs(j.results) do if r.data.guid then types.profile=true elseif r.data.capture then types.capture=true elseif r.data.event then types.event=true end end
check(types.profile and types.capture and types.event,'module grouping retains profile, capture and event result navigation types')
check(j.done and not j.stale,'search completes without touching recording consent')
local matched;for _,r in ipairs(j.results) do if r.group=='IntelWarden' then matched=r;break end end
Q.Open(matched);ready();W.pages.intel:Refresh(true);check(W.current=='intel' and W.pages.intel.selected==matched.data.guid,'search opens exact GUID profile')
local tools=query('backup');check(tools.results[1]~=nil,'tool search includes backup destination')
local activeBefore=C.Active();query('nothing matches this');check(C.Active()==activeBefore,'search does not change collection')
ns.DB.alertsEnabled=true;ns.DB.olympusMuteSignal=true
ns.OlympusMuteSignal.Observe('OMuteShare','12345:1/1:v1;g:test','GUILD','SignalTester-TestRealm')
check(#ns.Activity.List('olympusmute')==1 and ns.Activity.Unread('alerts')>=1,'validated passive OlympusMute message joins SignalWarden')
ns.OlympusMuteSignal.Observe('OMuteShare','12346:1/1:v1;g:test','GUILD','SignalTester-TestRealm')
check(#ns.Activity.List('olympusmute')==1,'repeat sharing creates only one signal per sender/login')
ns.OlympusMuteSignal.Observe('OMuteShare','12347:1/1:invalid','GUILD','BadTester-TestRealm')
check(#ns.Activity.List('olympusmute')==1,'malformed sharing creates no signal')
W.Open('mentions');p=W.pages.mentions;p.mode='olympusmute';p:Activate();p:Refresh();check(#p.visible==1,'dedicated OlympusMute tab displays the signal')
click(p.rows[1]);check(not p.bookmark:IsShown() and not p.mute:IsShown(),'signal has no inappropriate chat actions')
ns.History.Flush();ns.History.Initialize();check(#ns.Activity.List('olympusmute')==1,'signal survives normal activity persistence')
ns.Activity.MarkCategory('alerts');check(ns.Activity.Unread('olympusmute')==0,'read state integrates with signal badge')
ns.DB.olympusMuteSignal=false
ns.OlympusMuteSignal.Observe('OMuteShare','12348:1/1:v1;g:test','GUILD','DisabledTester-TestRealm')
check(#ns.Activity.List('olympusmute')==1,'observation switch stops new signals')
ns.DB.olympusMuteSignal=true
local all=query('same');local stale=Q.Begin('same');C.Clear();for n=1,100 do if Q.Pump(stale) then break end end
check(stale.done and stale.stale,'clearing history cancels stale searches')
local beforePage=W.current;Q.Open(matched);check(W.current==beforePage,'cleared search result cannot reopen a stale player')
ready();W.Open('chronicle');p=W.pages.chronicle;p:Refresh(true);check(#p.rows==0,'journal clears old cached results after explicit Clear')
W.Open('intel');W.pages.intel:Refresh(true);check(#W.pages.intel.rows==0,'player directory clears old cached results')
check(not C.Active() and forbiddenRegistrations==0,'no unintended collection or protected-event registrations')
rebrandChecks=checks-before
''')
result={'version':'1.1.0','newAssertions':int(lua.globals().rebrandChecks),'baselineChronicleAssertions':100,'failed':0,'liveWoWTested':False,'seconds':round(time.perf_counter()-started,3)}
(out/'rebrand-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
