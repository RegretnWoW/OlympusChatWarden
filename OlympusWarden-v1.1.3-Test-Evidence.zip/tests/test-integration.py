from pathlib import Path

import json,sys,hashlib,zipfile,os

root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent

sys.path.insert(0,str(root/'.work/vendor-rc30'))

from lupa.lua51 import LuaRuntime

base=root/'.work/olympus-1.2.4-probe/source/Olympus'

prefix=(root/'.work/startup-rc41.py').read_text(encoding='utf-8').split('lua.globals().signedPack')[0]

prefix=prefix.replace("lua.execute(Path('.work/mock-ui.lua').read_text())", "lua.execute(Path('.work/mock-ui.lua').read_text())\nlua.execute(Path('.work/v1-mock.lua').read_text())")

prefix=prefix.split('modules=')[0]

modules=[n for n in (root/'OlympusChatWarden/OlympusChatWarden.toc').read_text().splitlines() if n.endswith('.lua')]

def fresh(mode='modern',consent=None,occupied=False,installation='existing',selection=None):

    state={};exec(compile(prefix,'existing-startup-host','exec'),state)

    lua=state['lua'];ns=state['ns']
    if os.environ.get('WARDEN_TEST_WATCHDOG'):lua.execute("local untilTime=os.clock()+15;debug.sethook(function() if os.clock()>untilTime then error(debug.traceback('fixture instruction watchdog')) end end,'',100000)")
    loader=lua.eval('function(s,n,...) assert(loadstring(s,n))(...) end')

    lua.execute('''

    clock=100;function GetTime() return clock end

    local m=getmetatable(UIParent).__index

    function m:SetDrawLayer(layer,sublevel) self.layer=layer;self.sublevel=sublevel end

    function m:CreateTexture(name,layer,template,sublevel) local t=CreateFrame('Texture',name,self);t.layer=layer;t.sublevel=sublevel;return t end

    function m:CreateFontString(name,layer,font) local t=CreateFrame('FontString',name,self);t.layer=layer;t.fontObject=font;return t end

    function m:SetFontObject(value) self.fontObject=value end

    function m:SetJustifyV(value) self.justifyV=value end

    function m:SetMaxLines(value) self.maxLines=value end

    function m:SetClampRectInsets(...) self.clampInsets={...} end

    C_AddOns={GetAddOnMetadata=function(name,key)

      if name=='OlympusChatWarden' and key=='Title' then return 'Olympus ChatWarden' end

      if name=='OtherAddon' and key=='Title' then return 'Another Addon' end

      if name=='Olympus' and key=='Version' then return installedOlympusVersion end

      if name=='Olympus' and key=='IconTexture' then return 'Interface\\AddOns\\Olympus\\media\\logo64' end

    end,IsAddOnLoaded=function(name) return name=='Olympus' or name=='OlympusChatWarden' end}

    nativeStyle='old';nativeWidth=326;nativeHeight=360;nativePages={};nativeHosts={};nativeLeftClicks=0

    forbiddenRegistrations=0;registrationAttempts={}

    local originalRegister=m.RegisterEvent

    function m:RegisterEvent(event)

      registrationAttempts[event]=(registrationAttempts[event] or 0)+1

      if event=='COMBAT_LOG_EVENT_UNFILTERED' then forbiddenRegistrations=forbiddenRegistrations+1;return end

      return originalRegister(self,event)

    end

    function m:HighlightText() self.highlighted=true end

    function m:RegisterForClicks(...) self.registeredClicks={...} end

    function m:GetScript(event) return self.scripts[event] end

    function click(button,mouse) assert(button and button.scripts.OnClick,'missing button');button.scripts.OnClick(button,mouse or 'LeftButton');drain() end

    ''')

    lua.globals().installedOlympusVersion='1.2.3' if mode=='legacy' else '1.2.4'

    if mode=='modern':

        lua.execute('''

        oly={L={API_CONSENT_LABEL='Another addon: %s'},db={},me='Rune Escape',events={},questions={},timers={},profileReads=0}

        member=true;rankName='Legionnaire';guild='Mudhutters';rankIndex=2

        function GetGuildInfo() return guild,rankName,rankIndex end

        oly.Fold=string.lower;oly.Cut=function(s,n) return s:sub(1,n) end;oly.Now=function() return clock end

        oly.Log=function() end

        oly.On=function(event,fn) oly.events[event]=oly.events[event] or {};table.insert(oly.events[event],fn) end

        oly.Fire=function(event,...) for _,fn in ipairs(oly.events[event] or {}) do fn(...) end end

        oly.After=function(delay,label,fn) table.insert(oly.timers,{delay=delay,fn=fn}) end

        function pump() local pending=oly.timers;oly.timers={};for _,t in ipairs(pending) do t.fn() end;drain() end

        oly.IsMember=function() return member end

        wantedRows={};oly.Wanted={Targets=function() return wantedRows end}

        oly.Consent={Register=function(spec) oly.questions[spec.key]=spec;return true end}

        oly.HonorsNet={Verified=function() return {frame='lion-gold',title='hero'} end,TitleText=function() return 'Hero of Olympus' end}

        oly.Roster={IsOfficer=function() return true end}

        ''')

        ui=(base/'UI.lua').read_text(encoding='utf-8')

        registration=ui[ui.index('local function Asset(value)'):ui.index('-- The bottom buttons share the window width:')]

        loader('''

        local _,ns=...

        local UI={};ns.UI=UI

        local API_SURFACES,TAB_BY_KEY,frames={},{},{}

        local API_SURFACE_LIMIT,apiSurfaceCount=1,0

        local TABS={{key='census'},{key='workshop'}}

        local main

        local function APISurfaceByOwner(owner) return API_SURFACES[owner:lower()] end

        local function AttachTabDefinition() error('Unexpected host materialization') end

        function UI.SelectTab(key)

          local spec=APISurfaceByOwner(key);assert(spec,'unregistered')

          if main then main:Hide();main:GetParent():Hide() end

          local host=nativeHosts[nativeStyle]

          if not host then

            host=CreateFrame('Frame',nativeStyle=='old' and 'OlympusFrame' or 'OlympusFrameHD',UIParent)

            host.style=nativeStyle;host.tabs={};host.apiSurfaceViews={};nativeHosts[nativeStyle]=host

            local other=CreateFrame('Button',nil,host);other.key='census';host.tabs[1]=other

            other:SetScript('OnClick',function() nativeLeftClicks=nativeLeftClicks+1 end)

          end

          host:Show()

          local page=nativePages[nativeStyle]

          if not page then

            page=CreateFrame('Frame',nil,host);page:SetSize(nativeWidth,nativeHeight)

            page.style=nativeStyle;page.tab=key;nativePages[nativeStyle]=page

            host.apiSurfaceViews[key]=page

            local tab=CreateFrame('Button',nil,host);tab.key=key;host.tabs[2]=tab

            tab:SetScript('OnClick',function() nativeLeftClicks=nativeLeftClicks+1;UI.SelectTab(key) end)

            spec.build(page,{style=nativeStyle,apiVersion=1})

          end

          main=page;page:Show();spec.refresh(page,{style=nativeStyle,apiVersion=1});return true

        end

        '''+registration,'@actual-Olympus-surface-registration','Olympus',lua.globals().oly)

        loader((base/'API.lua').read_text(encoding='utf-8'),'@Olympus/API.lua','Olympus',lua.globals().oly)

        lua.execute('local original=oly.API.Profile;oly.API.Profile=function(...) oly.profileReads=oly.profileReads+1;return original(...) end')

        if consent is not None:

            lua.globals().initialConsent=consent

            lua.execute("oly.db.apiAddons={olympuschatwarden={on=initialConsent,v=1}}")

        if occupied:

            lua.execute("local other=OlympusAPI.Register('OtherAddon');assert(other:RegisterSurface({label='Other',icon='Interface\\\\Icons\\\\INV_Misc_Map_01',build=function() end}))")

    lua.execute("local m=getmetatable(UIParent).__index;function m:UnregisterEvent(e) if self.events then self.events[e]=nil end end")
    if installation=='existing':lua.execute("OlympusChatWardenDB=OlympusChatWardenDB or {schema=11,welcomeSeen=1}")
    if installation=='new':lua.execute("OlympusChatWardenDB=nil")
    if selection is not None:
        lua.globals().testSelection=lua.table_from(selection)
        lua.execute("OlympusChatWardenDB=OlympusChatWardenDB or {schema=11,welcomeSeen=1};OlympusChatWardenDB.moduleSelection={version=1,selected=testSelection,onboardingDone=true}")
    for name in modules:loader((root/'OlympusChatWarden'/name).read_text(encoding='utf-8'),name,'OlympusChatWarden',ns)

    lua.execute('ns.Initialize();ns.Membership.InstallAccessGuards();ns.OlympusIntegration.Refresh();drain()')

    return lua



count=0

def run(lua,code):

    global count

    before=lua.globals().checks;lua.execute(code);count+=lua.globals().checks-before



lua=fresh()

run(lua,r'''

C,P,M,I=ns.OlympusConnection,ns.OlympusPanel,ns.Membership,ns.OlympusIntegration

check(C.state=='pending' and not M.Allowed(),'modern pending permission blocks membership')

check(M.method=='olympus-api' and not ns.Active(),'API presence disables name fallback')

check(C.SurfaceReady() and I.IsActive(),'native connection page available while blocked')

check(next(I.records)==nil,'no duplicate legacy launcher on native success')

check(C.OpenSurface(),'connection page opens before consent')

page=nativePages.old;v=page.warden

check(v and #P.pages==1 and v.identity~='','native page builds and identifies current player')

check(not v.open:IsEnabled() and v.notice:GetText():find('/oly privacy',1,true),'blocked page gives inline connection help and locks workspace action')

check(not v.features[1].toggle:IsEnabled(),'blocked protection controls stay disabled')

local before=#frames;C.OpenSurface();drain();check(#frames==before,'reopening native page reuses frames')

check(ns.ChatCapture.db.enabled==false,'capture stays off in test build')

local report=ns.Personal.SaveReport('blocked','Unchanged','');check(report==nil,'permission gate protects saved report actions')

oly.questions['api:olympuschatwarden'].set(true);drain()

check(C.state=='connected' and M.Allowed() and M.method=='olympus-api','granted Olympus membership allows guild without keyword')

check(v.open:IsEnabled() and v.features[1].toggle:IsEnabled(),'grant enables native actions without reload')

check(C.Profile().guild=='Mudhutters' and C.Profile().title=='Hero of Olympus','guild and title come from API')

check(v.profile==nil and v.profileRows==nil and v.connection==nil,'duplicate native profile and connection panels removed')

check(v.guardian==nil and v.logo.texture:find('Logo.tga',1,true),'native hero uses crest instead of Zeus')

check(v.logo.points[1].x>v.heading.points[1].x,'native crest sits to the right of heading')

ns.Workspace.Open('overview');drain();W=ns.Workspace

check(W.profileRows[1].value:GetText()=='Mudhutters','full workspace shows API guild')

check(W.profileRows[2].value:GetText()=='Legionnaire','full workspace shows actual guild rank only')

check(W.profileRows[3].value:GetText()=='Hero of Olympus','full workspace shows selected title')

check(W.profileRows[3].value:IsShown() and W.profileRows[3].label:IsShown(),'implemented selected title is shown')

local title=C.profile.title;C.profile.title=nil;W.Refresh()

check(not W.profileRows[3].value:IsShown() and not W.profileRows[3].label:IsShown(),'empty title row is completely hidden')

check(W.guardian:GetWidth()==184 and W.profile:GetHeight()==68,'empty title permits larger corner Zeus')

check(101-W.profile.points[1].y+W.profile:GetHeight()<W.height-W.guardian:GetHeight()+W.bottomOverhang,'larger Zeus clears both guild/rank rows')

C.profile.title=title;W.Refresh()

check(W.guardian:GetWidth()==150 and math.abs(W.guardian.points[1].x+150*27/1024)<.01,'title layout keeps the same gold edge alignment')

check(W.profileRows[1].value.maxLines==2 and W.profileRows[2].value.maxLines==2 and W.profileRows[3].value.maxLines==2,'sidebar profile values have two lines')

check(W.profile:GetParent()==W.guardian:GetParent(),'profile sits beside full-workspace Zeus in sidebar')

check(-W.profile.points[1].y>=520 and 101-W.profile.points[1].y+W.profile:GetHeight()<W.height-W.guardian:GetHeight()+W.bottomOverhang,'selected title clears navigation and corner artwork')

check(W.guardian.points[1].anchor==W.window and W.guardian.points[1].point=='BOTTOMLEFT' and W.guardian.points[1].relative=='BOTTOMLEFT' and math.abs(W.guardian.points[1].x+W.guardian:GetWidth()*27/1024)<.01 and math.abs(W.guardian.points[1].y+W.guardian:GetHeight()*21/1024)<.01,'artwork gold rails meet the outer panel trim')

check(W.window.clampInsets[1]==-5 and W.window.clampInsets[4]==-4,'screen clamping includes the visible artwork')

local sw,sh=UIParent:GetWidth(),UIParent:GetHeight();local custom=ns.DB.workspaceScale

UIParent:SetSize(1024,768);ns.DB.workspaceScale=nil;local fitted=W.Fit()

check(fitted*(W.width+2*W.leftOverhang)<=1024-26 and fitted*(W.height+2*W.bottomOverhang)<=768-26,'automatic fitting keeps the overhanging ornament within screen margins')

UIParent:SetSize(sw,sh);ns.DB.workspaceScale=custom;W.Fit()



check(W.olympusStatus:GetText()=='Olympus Connected' and W.olympusHint:GetText()=='Open Olympus','top bar shows connection with Olympus action')

check(I.Open(),'workspace Olympus action opens native page');drain()

check(nativeHosts.old:GetFrameStrata()=='DIALOG' and W.window:GetFrameStrata()=='HIGH','Olympus is focused above workspace')

check(I.Open(),'already-open Olympus can be focused without closing');drain()

check(nativeHosts.old:IsShown() and nativeHosts.old:GetFrameStrata()=='DIALOG','repeated Olympus focus leaves native window shown')

W.window:Hide();local beforeClicks=nativeLeftClicks

click(nativeHosts.old.tabs[2],'LeftButton')

check(nativeLeftClicks==beforeClicks+1 and not W.window:IsShown(),'left-click keeps native handler and compact view')

check(nativeHosts.old.tabs[2].registeredClicks[2]=='RightButtonUp','ChatWarden native tab accepts right clicks')

click(nativeHosts.old.tabs[2],'RightButton')

check(W.window:IsShown() and W.current=='overview' and W.window:GetFrameStrata()=='DIALOG','right-click opens and focuses full workspace')

check(nativeLeftClicks==beforeClicks+2,'native selection handler stays intact on right click')

check(nativeHosts.old.tabs[1].ChatWardenRightClick==nil,'other Olympus tabs stay untouched')

local originalClick=nativeHosts.old.tabs[2]:GetScript('OnClick');I.HookNativeTabRoot(nativeHosts.old)

check(originalClick==nativeHosts.old.tabs[2]:GetScript('OnClick'),'native right-click hook installs once')

local savedName=C.profile.name;C.profile.name='Rune Escape-ClassicBetaPvP';P.Refresh(page)

check(v.identity=='Rune Escape','compact header omits API realm suffix')

C.profile.name=savedName;P.Refresh(page)

local copy=C.Profile();copy.guild='tampered';check(C.Profile().guild=='Mudhutters','profile consumers receive copies')

check(C.profile.frame==nil,'symbolic frame IDs never become texture paths')

for i,expected in ipairs({'filtering','shield','mentions','capture'}) do check(v.features[i].feature==expected and not v.features[i].title,'icon-only control '..expected) end

click(v.features[1].toggle);check(ns.DB.enabled==false and v.features[1].state=='Paused','filter control updates actual master setting')

check(v.features[2].state=='Standby' and v.features[3].state=='Standby','master pause is reflected in dependent features')

click(v.features[1].toggle);check(ns.DB.enabled==true,'filter control resumes actual setting')

click(v.features[2].toggle);check(ns.DB.shield.enabled==false,'shield control uses actual Shield option')

click(v.features[2].toggle);check(ns.DB.shield.enabled==true,'shield control restores Shield option')

click(v.features[3].toggle);check(ns.DB.alertsEnabled==false and ns.Mentions.db.enabled,'Alerts pause preserves individual mention option')

click(v.features[3].toggle);check(ns.DB.alertsEnabled==true and ns.Mentions.db.enabled,'Alerts control resumes both alert types')

click(v.features[4].toggle);check(ns.ChatCapture.db.enabled==true and v.features[4].state=='Recording','capture icon starts actual recording')

click(v.features[4].toggle);check(ns.ChatCapture.db.enabled==false,'capture icon pauses actual recording')

ns.Activity.Add('native-mention','mentions',{sender='Other Player',event='CHAT_MSG_SAY',timestamp=1800000000,text='Self',preview='Self'},false);drain()

check(v.rows[1]:IsShown() and v.rows[1].item.id=='native-mention' and v.rows[1].preview:GetText()=='Mention','activity changes refresh native feed')

check(v.rows[1].ArtNormal and v.rows[1].ArtSelected and v.rows[1].icon,'activity reuses full-workspace themed row')

check(v.rows[1].unread:IsShown() and v.rows[1].unread.Wash and v.rows[1].unread.Gem,'native activity shows themed unread wash and gem')

check(v.rows[1].preview.wrap==false and v.rows[1].meta.shown==false,'compact rows keep metadata in tooltip')

local function CenteredIcon(row)

 local p=row.icon.points[1]

 return math.abs(-p.y+row.icon:GetHeight()/2-row:GetHeight()/2)<.01 and row.icon:GetWidth()<=24 and row.icon:GetHeight()<=24

end

check(CenteredIcon(v.rows[1]),'recent icon is centered after atlas fitting')

for _,category in ipairs({'messages','shield','wanted'}) do

 local data={sender='Icon Test',action='Warning'}

 if category=='wanted' then data.wanted={kind='encounter',guid='Player-Test-AA',name='Blood Fang',bounty=100,kills=1,cycle=1,via='target'} end

 ns.Activity.Add('native-icon-test',category,data,false);drain()

 check(CenteredIcon(v.rows[1]),'rebound '..category..' icon stays centered and inside 24px box')

 ns.Activity.Remove('native-icon-test');drain()

end



check(v.rows[1].meta:GetText():find('Say',1,true),'activity includes channel metadata')

v.rows[1]:GetScript('OnEnter')(v.rows[1]);check(v.rows[1].ArtSelected[1]:IsShown(),'activity hover uses blue selected artwork')

v.rows[1]:GetScript('OnLeave')(v.rows[1]);check(not v.rows[1].ArtSelected[1]:IsShown(),'activity hover restores base artwork')

check(ns.Activity.Unread('mentions')==1,'opening native overview does not read a message')

ctrl=false;click(v.rows[1]);check(ns.Workspace.current=='mentions','recent activity opens matching full feed')

check(ns.Activity.Unread('mentions')==0 and not v.rows[1].unread:IsShown(),'compact selection marks the opened entry read and removes its unread wash')

ns.Activity.Add('native-unrelated','messages',{sender='Unread Friend',action='Hidden'},false)

local combined=ns.Activity.Add('native-combined','messages',{sender='Combined Friend',action='Warning',preview='test'},false)

ns.Activity.Add('native-combined','mentions',{text='Self',mentionMatches={}},false)

ns.Activity.Add('native-combined','shield',{},false);drain();click(v.rows[1])

check(W.current=='mentions' and W.pages.mentions.selected==combined,'compact mixed-category selection opens exact entry')

check(combined.read.messages and combined.read.mentions and combined.read.shield and not ns.Activity.EntryUnread(combined),'compact click reads all categories of the selected entry')

check(ns.Activity.Unread('messages')==1 and not ns.Activity.Get('native-unrelated').read.messages,'compact click does not read unrelated activity')

ns.Activity.Remove('native-combined');ns.Activity.Remove('native-unrelated');drain()

check(ns.Personal.SaveRule('Other Player','Redacted'),'covered-name fixture uses a real personal rule')

P.Refresh(page);check(v.rows[1].covered,'native row covers matching name')

ctrl=true;click(v.rows[1]);check(v.rows[1].revealed and v.rows[1].title:GetText()=='Other Player','Ctrl-click reveals the actual name')

click(v.rows[1]);check(not v.rows[1].revealed and v.rows[1].covered,'second Ctrl-click covers the name again')

ctrl=false

check(v.tools==nil and v.toolsHeading==nil,'redundant open-a-view shortcuts removed')

click(v.open);check(ns.Workspace.current=='overview','primary action opens full workspace')

local reads=oly.profileReads

check(reads>0,'profile call counter observes real initial reads')

for i=1,40 do C.Refresh();P.Refresh(page) end

check(oly.profileReads==reads,'view refreshes do not poll profile data')

local frameCount=#frames

for i=1,30 do P.Refresh(page) end

check(#frames==frameCount,'native refresh has no frame growth')

nativeStyle='hd';nativeWidth=744;nativeHeight=480;C.OpenSurface();drain()

wide=nativePages.hd;check(#P.pages==2 and wide.warden,'old and HD layouts build independently')

check(wide.warden.features[4].points[1].y==wide.warden.features[1].points[1].y,'wide feature controls share one row')

check(v.features[4].points[1].y==v.features[1].points[1].y,'all four narrow feature controls share one row')

check(wide.warden.profile==nil and wide.warden.activity:GetWidth()==wide.warden.content:GetWidth(),'wide activity uses reclaimed profile width')

W.Open('settings');click(nativeHosts.hd.tabs[2],'RightButton');check(W.current=='overview' and W.window:GetFrameStrata()=='DIALOG','HD icon right-click opens full overview too')

check(v.scroll==nil and v.listView.scroll.parent==v.activity,'only recent activity scrolls')

check(v.hero:GetHeight()==58 and v.heading.points[1].x>=20 and -v.heading.points[1].y>=20,'compact hero keeps text away from its bevel')

check(v.activity.points[1].y==-92 and v.listView.scroll:GetHeight()>=3*54,'three complete activity rows fit default fixed stock viewport')

check(v.listView.scroll:GetHeight()>=170,'tighter toggle spacing reclaims eight pixels for recent activity')

check(-v.features[1].points[1].y-v.hero:GetHeight()==2 and -v.activity.points[1].y+v.features[1].points[1].y-v.features[1]:GetHeight()==2,'toggle row keeps only two pixels above and below')

check(CenteredIcon(wide.warden.rows[1]),'HD recent icon is centered after binding')



check(-v.features[4].points[1].y+v.features[4]:GetHeight()+6<=page:GetHeight()-48,'all four feature controls fit default narrow viewport')

check(v.open.points[1].point=='BOTTOMLEFT' and v.open.points[2].point=='BOTTOMRIGHT','workspace action is anchored outside scroll content')

for _,w in ipairs({280,310,326,480,600,744,814}) do

 page:SetSize(w,360);P.Refresh(page)

 for i,card in ipairs(v.features) do

  check(card:GetWidth()>=60 and card.points[1].x>=0 and card.points[1].x+card:GetWidth()<=v.content:GetWidth()+.01,'feature icon column stays inside width '..w..'/'..i)

 end

 check(v.content:GetWidth()==w-20,'content width follows page '..w)

 check(v.logo.points[1].x+v.logo:GetWidth()<v.hero:GetWidth() and v.heading.points[1].x+v.heading:GetWidth()<v.logo.points[1].x,'hero heading and crest stay separate at '..w)

 check(v.name==nil and v.heading:GetHeight()<=20,'single-line header reserves room for activity at '..w)

 check(v.rows[1].preview:GetWidth()>100 and -v.rows[1].preview.points[1].y+v.rows[1].preview:GetHeight()<=v.rows[1]:GetHeight()-8,'compact activity text stays inside row at '..w)

end

page:SetSize(326,360);P.Refresh(page)

for i=1,12 do ns.Activity.Add('scroll-test:'..i,'messages',{sender='Scroll Player '..i,event='CHAT_MSG_SAY',action='Warning'},false) end

P.Refresh(page)

check(#v.listView.items>=12 and #v.rows<8,'all recent alerts use a bounded virtual row pool')

local heroY=v.hero.points[1].y;local iconsY=v.features[1].points[1].y

v.listView.scroll:SetVerticalScroll(108);local anchored=v.rows[1].id

check(v.rows[1].id~='scroll-test:12' and v.listView.first==3,'activity list scrolls to older alerts')

ns.Activity.Add('new-while-scrolled','messages',{sender='Newest Player',action='Warning'},false);P.Refresh(page)

check(v.rows[1].id==anchored,'incoming alerts preserve the reader\'s scrolled position')

check(v.hero.points[1].y==heroY and v.features[1].points[1].y==iconsY,'scrolling does not move header or icon controls')

local poolFrames=#frames

for i=0,10 do v.listView.scroll:SetVerticalScroll(i*54) end

check(#frames==poolFrames,'scrolling reuses the row pool without frame growth')

v.listView.scroll:SetVerticalScroll(0)

member=false;oly.Fire('DATA_CHANGED');pump()

check(not M.Allowed() and C.state=='not-member' and ns.PacksSuspended,'Olympus membership loss suspends protection')

check(not wide.warden.open:IsEnabled(),'membership loss locks native actions')

check(C.SurfaceReady(),'connection page survives membership loss')

member=true;oly.Fire('DATA_CHANGED');pump()

check(M.Allowed() and not ns.PacksSuspended,'membership regain restores protection')

guild='Olympus XIV';oly.questions['api:olympuschatwarden'].set(false);drain()

check(not M.Allowed() and C.Profile()==nil and C.state=='refused','revocation clears profile and never falls back to guild name')

W.Refresh();check(W.profileRows[3].value:GetText()=='' and not W.profileRows[3].value:IsShown() and not W.profileRows[3].label:IsShown() and W.olympusStatus:GetText()=='Access Declined','revoked title clears full profile and connection updates')

check(not wide.warden.rows[1]:IsShown(),'revocation hides activity while retaining underlying history')

check(ns.Activity.Get('native-mention')~=nil,'permission loss preserves saved activity')

oly.questions['api:olympuschatwarden'].set(true);drain()

check(M.Allowed() and C.Profile().guild=='Olympus XIV','permission can be restored in the same session')

member=false;C.Invalidate();M.Refresh();drain()

check(not M.Allowed(),'guild-event invalidation rejects stale positive membership')

member=true;C.Invalidate();M.Refresh();drain()

check(M.Allowed(),'guild-event recheck restores valid membership')

check(#apiErrors==0,table.concat(apiErrors,'\n'))

combat=true;local beforeEnabled=ns.DB.enabled;local beforeView=ns.Workspace.current

click(v.features[1].toggle);check(ns.DB.enabled==beforeEnabled,'native feature toggle waits during combat')

click(v.open);check(ns.Workspace.current==beforeView,'native workspace opening waits during combat')

click(nativeHosts.old.tabs[2],'RightButton');check(ns.Workspace.current==beforeView,'native right-click waits during combat')

check(C.OpenSurface()==false,'native Olympus opening waits during combat');combat=false

''')



# Read errors and quotas deny stale membership and recover without a restart.

run(lua,r'''

local original=oly.API.Profile

oly.API.Profile=function() error('Synthetic read failure') end

C.Refresh(true);M.Refresh();drain()

check(C.state=='error' and not M.Allowed() and C.Profile()==nil,'API exception cannot leave stale allow')

oly.API.Profile=original;clock=clock+6;C.Refresh();drain()

check(M.Allowed(),'failed profile read recovers after retry interval')

clock=clock+11

for i=1,21 do C.Refresh(true) end

M.Refresh();drain();check(C.state=='busy' and not M.Allowed(),'rate limit is unavailable membership, not old cached allow')

clock=clock+11;C.Refresh();drain();check(M.Allowed(),'quota recovery restores membership')

oly.API.Profile=function() return {member='true',guild='Olympus XIV'} end

C.Refresh(true);M.Refresh();drain();check(not M.Allowed(),'malformed membership value denied')

oly.API.Profile=original;clock=clock+11;C.Refresh(true);drain()

local originalRegister=OlympusAPI.Register

check(select(2,originalRegister('OlympusChatWarden'))=='taken','native connection registered its name exactly once')

''')



run(lua,r'''

ns.OpenUpdates();drain();local notes=ns.Workspace.pages.updates

check(ns.InstalledUpdate.version=='1.0.3' and #ns.InstalledUpdate.cards==6,'preview notes show the installed build')

check(notes.releaseSubtitle:GetText()=='Your history, preserved','release notes show the current recording and backup highlights')

check(#ns.UpdateHistory==4 and ns.UpdateHistory[2].version=='1.0.2' and ns.UpdateHistory[3].version=='1.0.1' and ns.UpdateHistory[4].version=='1.0.0','all published history is retained')

check(notes.previousUpdate:IsEnabled() and not notes.nextUpdate:IsEnabled(),'current notes disable newer-page navigation')

local count=#frames;click(notes.previousUpdate)

check(notes.releaseIndex==2 and notes.noteCards[6]:IsShown() and notes.releaseTitle:GetText()=='Olympus ChatWarden 1.0.2','previous release has its six original highlights')

check(notes.noteCards[1].title:GetText()=='ChatWarden inside Olympus','original 1.0.2 content retained')

click(notes.previousUpdate);check(notes.releaseIndex==3 and notes.noteCards[1].title:GetText()=='Smarter filtering','1.0.1 page remains intact')

notes:SetView('tour');notes:SetView('notes');check(notes.releaseIndex==3,'tour preserves selected archive')

click(notes.previousUpdate)

check(notes.releaseIndex==4 and not notes.previousUpdate:IsEnabled() and notes.nextUpdate:IsEnabled(),'oldest release disables older navigation')

check(notes.noteCards[1].title:GetText()=='Incoming spelling and evasion matching','original 1.0.0 notes retained')

click(notes.nextUpdate);click(notes.nextUpdate);click(notes.nextUpdate)

check(notes.releaseIndex==1 and notes.noteCards[6]:IsShown() and notes.releasePosition:GetText()=='1 / 4','return to current release works')

check(#frames==count,'history navigation reuses frames')

check(ns.VERSION=='1.0.3' and ns.DB.updateSeen=='1.0.3','archive browsing cannot change installed version')

check(-notes.noteCards[6].points[1].y+notes.noteCards[6]:GetHeight()<-notes.githubNotes.points[1].y,'six notes clear footer action')

check(-notes.githubNotes.points[1].y+notes.githubNotes:GetHeight()<-notes.ShowUpdates.points[1].y,'footer clears checkbox')

check(ns.ChronicleStore.db.enabled==false and next(ns.ChronicleStore.db.characters)==nil,'existing integration tests never opt users in')

''')



# Compare every archived heading/description with the published ZIPs' note data.

reference=json.loads((out/'archived-update-notes.json').read_text(encoding='utf-8'))

for i,version in [(3,'1.0.1'),(4,'1.0.0')]:

    cards=lua.globals().ns.UpdateHistory[i].cards

    assert len(cards)==len(reference[version]['cards'])

    assert [[cards[j][1],cards[j][2]] for j in range(1,len(cards)+1)]==reference[version]['cards'],version

    count+=1



# Export actual UI state for the layout preview and repeatable geometry inspection.

lua.execute('''

ns.Activity.Add('preview-hidden','messages',{sender='Dark Atiesh',event='CHAT_MSG_WHISPER',timestamp=1800000000,action='Hidden'},false)

ns.Activity.Add('preview-hidden','shield',{},false)

ns.Activity.Add('preview-redacted','messages',{sender='Clasix Tv',event='CHAT_MSG_CHANNEL',channel='Trade',timestamp=1800000050,action='Redacted'},false)

ns.Activity.Add('preview-wanted','wanted',{sender='Blood Fang',channel='Encounter',preview='Target encounter. Olympus-listed bounty: 100 points.',timestamp=1800000060,

 wanted={kind='encounter',guid='Player-Test-ABC',name='Blood Fang',bounty=100,kills=3,cycle=2,zone='Elwynn Forest',via='target'}},false)

nativeStyle='old';C.OpenSurface();drain();ns.OlympusPanel.Refresh(nativePages.old)

ns.OlympusPanel.Refresh(nativePages.hd);C.profile.guild='Olympus Reloaded';C.profile.rank='Mortal Applicant';C.profile.title=nil;ns.Workspace.Open('alerts');ns.Workspace.pages.mentions.selected=ns.Activity.Get('preview-wanted');ns.Workspace.pages.mentions:Refresh();drain()

''')

def export_scene(lua,style):

    page=lua.globals().ns.Workspace.window if style in ('workspace','updates') else lua.globals().nativePages[style]

    frames=lua.globals().frames

    indices={str(frames[i]):i for i in range(1,len(frames)+1)}

    def index(o):return indices.get(str(o)) if o is not None else None

    descendants=[]

    def under(f):

        for _ in range(30):

            if str(f)==str(page):return True

            f=f['parent']

            if f is None:return False

        return False

    for i in range(1,len(frames)+1):

        f=frames[i]

        if not under(f):continue

        r={'id':i,'parent':index(f['parent']),'kind':f['kind'],'w':f['w'],'h':f['h'],'shown':f['shown'],'text':f['text'],'texture':f['texture'],'layer':f['layer'],'sublevel':f['sublevel'],'scale':f['scale'],'alpha':f['alpha'],'justify':f['justify'],'wrap':f['wrap'],'fontObject':str(f['fontObject']) if f['fontObject'] else None}

        for key in ['font','color','textColor','texCoord']:

            value=f[key];r[key]=[value[j] for j in range(1,len(value)+1)] if value is not None else None

        r['allPoints']=index(f['allPoints']);r['points']=[]

        points=f['points']

        if points:

            for j in range(1,len(points)+1):

                p=points[j];r['points'].append({'point':p['point'],'anchor':index(p['anchor']),'relative':p['relative'],'x':p['x'],'y':p['y']})

        descendants.append(r)

    return {'style':style,'root':index(page),'frames':descendants,'version':lua.globals().ns.VERSION}

(out/'scene-old.json').write_text(json.dumps(export_scene(lua,'old')),encoding='utf-8')

(out/'scene-hd.json').write_text(json.dumps(export_scene(lua,'hd')),encoding='utf-8')

(out/'scene-workspace.json').write_text(json.dumps(export_scene(lua,'workspace')),encoding='utf-8')

lua.execute('ns.OpenUpdates();drain()')

(out/'scene-updates.json').write_text(json.dumps(export_scene(lua,'updates')),encoding='utf-8')



for mode,consent,occupied in [('legacy',None,False),('restart',None,False),('modern',True,True),('modern',True,False),('modern',False,False)]:

    one=fresh(mode,consent,occupied)

    if mode=='legacy':run(one,"check(ns.Membership.Allowed() and ns.Membership.method=='local-guild-name' and not ns.OlympusConnection.modern,'older Olympus keeps local fallback');check(not ns.OlympusConnection.SurfaceReady(),'older Olympus has no native surface')")

    elif mode=='restart':run(one,"check(not ns.Membership.Allowed() and ns.OlympusConnection.state=='restart','modern metadata with missing API requires restart instead of fallback')")

    elif occupied:run(one,"check(ns.Membership.Allowed() and ns.OlympusConnection.surfaceState=='surface-full','occupied native slot preserves membership and workspace');ns.Workspace.Open('overview');drain();check(ns.Workspace.current=='overview','occupied slot retains full workspace')")

    elif consent is True:run(one,"check(ns.Membership.Allowed() and ns.OlympusConnection.Profile().name=='Rune Escape','saved consent reads an initial snapshot without waiting for callback');check(ns.OlympusConnection.SurfaceReady(),'saved consent registers native page')")

    else:run(one,"check(not ns.Membership.Allowed() and ns.OlympusConnection.state=='refused','saved refusal blocks modern protection');check(ns.OlympusConnection.SurfaceReady(),'saved refusal keeps connection page')")

    run(one,"check(#apiErrors==0,table.concat(apiErrors,'\\n'))")



# The integration patch must not modify filtering, author signatures, or artwork.

changed=[]

with zipfile.ZipFile(root/'OlympusChatWarden-v1.0.1.zip') as z:

    for name in z.namelist():

        current=root/name

        if current.read_bytes()!=z.read(name):changed.append(name)

    for name in z.namelist():

        if name.endswith('.tga') or name.endswith(('/Stock.lua','/ProtectionContext.lua','/PreferenceContext.lua','/PackData.lua','/TrustedPackKeys.lua','/Confidence.lua')):

            assert (root/name).read_bytes()==z.read(name),name

with zipfile.ZipFile(root/'OlympusChatWarden-RulePacks-v1.0.1.zip') as z:

    for name in z.namelist():

        relative=name if name.startswith('rule-packs/') else 'rule-packs/'+name

        assert (root/relative).read_bytes()==z.read(name),relative

summary={'version':'1.0.3','assertions':count,'failed':0,'liveWoWTested':False,'olympusVersion':'1.2.4','actualOlympusAPILoaded':True,'actualSurfaceRegistrationLoaded':True,'nativeWindowLifecycle':'synthetic host, production ChatWarden page','changedExistingAddonFiles':changed,'filteringAndSignedPacksUnchanged':True,'artworkUnchanged':True}

(out/'integration-summary.json').write_text(json.dumps(summary,indent=2)+'\n')

print(json.dumps(summary,indent=2))



