from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'trusted-recording-host','exec'),scope)
lua=scope['lua'];lua.globals().fixtureClock=time.perf_counter;started=time.perf_counter()
lua.execute(r'''
local before=checks;local A,I,B=ns.ChronicleActivities,ns.ChronicleIntelligence,ns.ChronicleBackup
C.Clear();local owner=C.Owner();local c=S.Character(owner,true);c.currentSession=owner..'/s1';c.sessionSequence=1
local world={inInstance=false,instanceType='none',zone='Stress zone'}
local function emit(kind,t,d,source,subject)
 return assert(S.Append(owner,{kind=kind,at=1800000000+t,elapsed=t,source=source or 'checkpoint',subject=subject,
 details=d or {},location=world,session=c.currentSession,timeSource='server',evidence='observed'}))
end
emit('recording_start',0,{},'control')
for n=1,20000 do
 local hi=n*30;emit('time_span',hi,{seconds=30,samples=1,firstAt=1800000000+hi-30,lastAt=1800000000+hi,firstElapsed=hi-30,lastElapsed=hi,afk=n%5==0})
 emit('native_event',hi,{recordType='pvp_counter_snapshot',lifetimeHK=n},'PLAYER_PVP_KILLS_CHANGED')
 emit('player_observed',hi,{name='Companion '..(n%500),encounter=true,localSighting=true},'PLAYER_TARGET_CHANGED','Player-Stress-'..(n%500))
end
local eventCount=#c.events;local bytes=c.bytes;local sequence=c.sequence;local rawEvents=c.events
local st,steps=nil,0;local maxPump=0
repeat
 local start=fixtureClock();A.Pump();maxPump=math.max(maxPump,fixtureClock()-start)
 st=A.Request(owner);steps=steps+1;assert(steps<10000)
until st
check(eventCount==60001 and steps>400,'large mixed history is indexed and summarized cooperatively')
check(st.intelligence.ready and #st.intelligence.heap==0 and not st.intelligence.rebuild,'derived interval finalization completes without a synchronous full-history finish')
check(st.intelligence.time.seconds==600000 and st.intelligence.time.afk==120000,'twenty thousand measured intervals retain exact totals and AFK overlap')
check(st.intelligence.time.nonAfk==480000 and st.intelligence.time.categories['open world']==600000,'non-AFK and location dimensions remain correctly scoped at scale')
local first=I.Player(st,'Player-Stress-1');check(first.recordedEncounters==40,'distinct long-separated sightings stay queryable per GUID')
local cached=true;for n=1,1000 do if I.Player(st,'Player-Stress-1')~=first then cached=false end end
check(cached,'one thousand player selections reuse their cached projection without rescanning history')
local original=st;local oldRanges=#st.intelligence.ranges
emit('native_event',600001,{recordType='pvp_counter_snapshot',lifetimeHK=20001},'PLAYER_PVP_KILLS_CHANGED')
local more=A.Request(owner);local ticks=0;while not more do A.Pump();ticks=ticks+1;more=A.Request(owner);assert(ticks<100) end
check(more==original and ticks<5 and #more.intelligence.ranges==oldRanges,'routine appended background record extends the shared index without rebuilding time history')
emit('time_span',600030,{seconds=30,samples=1,firstAt=1800600000,lastAt=1800600030,firstElapsed=600000,lastElapsed=600030,afk=false})
local newer=A.Request(owner);ticks=0;while not newer do A.Pump();ticks=ticks+1;newer=A.Request(owner);assert(ticks<100) end
check(newer==original and ticks<5 and newer.intelligence.time.seconds==600030,'a contiguous new span extends the time sweep without a full rescan')
-- A backdated insertion must produce a fresh deterministic view.
emit('level_change',50,{before=1,after=2},'PLAYER_LEVEL_UP')
local late=A.Request(owner);while not late do A.Pump();late=A.Request(owner) end
check(late~=original and late.intelligence.time.seconds==600030 and #late.intelligence.progression.levels==1,'out-of-order imports rebuild identity/activity/time projections from preserved evidence')
check(c.events==rawEvents and #c.events==eventCount+3 and c.bytes>bytes and c.sequence==sequence+3,'projections do not replace the original ledger or its accounting')
local scoped=I.Query(late,{guid='Player-Stress-1',kind='player_observed',limit=50})
check(#scoped==40 and scoped[1]==late.intelligence.events[scoped[1].id],'player queries return original evidence objects')
local owner2='Other Realm/Player-Other-SAME';local other=A.New(owner2)
assert(not next(I.Player(other,'Player-Stress-1').evidence),"another recording character cannot inherit this character player history")
C.Clear();A.Pump();local empty=A.Request(owner)
check(empty and not empty.intelligence and next(S.db.characters)==nil,'Clear discards pending/derived history at scale without leaving a second saved database')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'large history does not expand collection or native access')
stressRecords=eventCount;stressSteps=steps;stressMaxPump=maxPump;intelligenceStressChecks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().intelligenceStressChecks),'failed':0,'liveWoWTested':False,
 'rawRecords':int(lua.globals().stressRecords),'measuredIntervals':20000,'distinctPlayerGUIDs':500,
 'cooperativeSteps':int(lua.globals().stressSteps),'maxPumpHostSeconds':round(float(lua.globals().stressMaxPump),6),
 'elapsedHostSeconds':round(time.perf_counter()-started,3),'limits':'Synthetic host timing is not a native client frame-rate guarantee.'}
(out/'intelligence-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
