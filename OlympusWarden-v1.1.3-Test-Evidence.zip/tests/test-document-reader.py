from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'document-host','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local V,T=ns.Art,ns.Theme
local method=getmetatable(UIParent).__index;local measure=method.GetStringHeight
method.GetStringHeight=function(self)
 local size=self.font and self.font[2] or 16;local total=0
 for line in ((self.text or '')..'\n'):gmatch('(.-)\n') do total=total+math.max(1,math.ceil(#line*size*.6/math.max(1,self.w))) end
 return total*(size+3)
end
local panel=V.Panel(UIParent,0,0,500,300,'dark');local doc,scroll=V.Document(panel,10,-10,450,260)
local text=string.rep('A complete historical description should remain readable. ',120)..' END OF ORIGINAL DESCRIPTION'
doc:SetBlocks({{kind='title',text='A long recorded adventure'},{kind='body',text=text},{kind='body',text='Αθηνά 長い名前 '..string.rep('unbrokentoken',80)}})
check(doc:GetText():find('END OF ORIGINAL DESCRIPTION',1,true) and #doc.boxes[2]:GetText()==#text,'complete supported document remains present without UI truncation')
local expected=doc.boxes[2].measure:GetStringHeight()
check(doc.boxes[2]:GetHeight()>=expected+16 and doc:GetHeight()>scroll:GetHeight(),'wrapped multiline box has a full-line safety margin and expanded scroll child')
local max=doc:GetHeight()-scroll:GetHeight();local slider=scroll.ChatWardenGoldScroll
check(slider.maximumValue==max and slider:IsEnabled(),'gold scrollbar range updates explicitly from full document height')
scroll:SetVerticalScroll(max);scroll:SetWidth(250);local resize=scroll:GetScript('OnSizeChanged');resize(scroll)
check(doc:GetHeight()>max+scroll:GetHeight() and slider.maximumValue==doc:GetHeight()-scroll:GetHeight(),'narrower reader rewraps and extends its actual scrolling range')
doc:SetBlocks({{kind='body',text='Short text'}});check(scroll:GetVerticalScroll()==0 and slider.maximumValue==0,'shorter selection clamps obsolete scroll without hiding content')
local owned=#doc.boxes;doc:SetBlocks({{kind='body',text='Short text'}});check(#doc.boxes==owned,'document redraw reuses existing editors')
method.GetStringHeight=measure
ns.Workspace.Open('messages');local p=ns.Workspace.pages.messages
-- Existing review privacy suites cover original reveal; this pass makes no
-- hidden original available through a new hover/text field.
local row=V.Row(UIParent,0,function() end);row:Select(false);row.unread:Show()
check(row.ArtNormal and row.unread.Gem and not row.ArtSelected[1]:IsShown(),'unread crest marker is distinct from full selected frame')
row:Select(true);check(row.ArtSelected[1]:IsShown() and not row.ArtNormal[1]:IsShown(),'selection has full sapphire frame independent of unread state')
ns.Workspace.Open('overview');local home=ns.Workspace.pages.overview
home.search:SetText('No matching saved adventure');home:Search()
check(home.list.scroll:GetHeight()==72 and home.list.content:GetHeight()==72 and home.list.scroll.ChatWardenGoldScroll.maximumValue==0,'empty search resizes viewport and content together without stale blank scrolling')
check(not home.list.scroll.ChatWardenGoldScroll:IsShown(),'sparse Home highlights hide an unnecessary scrollbar')
documentChecks=checks-before
''')
result={'version':'1.1.0','failed':0,'assertions':int(lua.globals().documentChecks),'nativeGlyphMeasurement':False,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'document-reader-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
