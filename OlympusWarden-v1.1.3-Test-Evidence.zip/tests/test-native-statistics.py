from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'statistics-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local T,X=ns.ChronicleStatistics,ns.ChronicleCapture
local groups={[100]={1010,1011,1012,1013},[101]={2010}}
local values={[1010]='144',[1011]='1,234',[1012]='4 min 12 sec',[1013]='--',[2010]='0'}
local reads,discoveries=0,0
ACHIEVEMENT_FLAGS_ACCOUNT=131072
GetStatisticsCategoryList=function() discoveries=discoveries+1;return {100,101} end
GetCategoryInfo=function(id) return id==100 and 'Combat & duels' or 'Battlegrounds',-1 end
GetCategoryNumAchievements=function(id) return #groups[id] end
GetAchievementInfo=function(category,index)
 local id=index and groups[category][index] or category
 return id,'Native statistic '..id,0,false,nil,nil,nil,'Native description',id==1011 and ACHIEVEMENT_FLAGS_ACCOUNT or 0,nil,nil,false,false,nil,true
end
GetStatistic=function(id) reads=reads+1;return values[id] end
local function records() local out={};for _,e in ipairs(all('native_event')) do if e.details.recordType=='statistic_observed' then out[#out+1]=e end end;return out end
local function pump() drain();for n=1,100 do X.Pump() end end
freshRecording();pump()
check(T.ready and #T.catalog==5 and #T.categories==2,'native numeric IDs discovered through native statistics categories')
check(#records()==4,'one initial observation per readable statistic; unknown placeholder not fabricated as zero')
local e=T.Get(1010);check(e.details.displayValue=='144' and e.details.numericValue==144 and e.details.nativeScope=='unknown','native plain integer preserved with scope explicitly unknown')
e=T.Get(1011);check(e.details.displayValue=='1,234' and e.details.numericValue==nil and e.details.accountFlag==true and e.details.nativeScope=='unknown','localized formatting preserved; metadata account flag is not assumed statistic scope')
e=T.Get(1012);check(e.details.displayValue=='4 min 12 sec' and e.details.numericValue==nil,'non-numeric displayed values preserved without unit guesses')
e=T.Get(2010);check(e.details.numericValue==0,'a genuine native zero stays zero')
check(not T.Get(1013),'unavailable native placeholder creates no fictitious observation')
clock=clock+121;T.Request('QUEST_TURNED_IN');pump();check(#records()==4 and discoveries==1,'unchanged values create no duplicate records or repeated catalog scans')
values[1010]='147';clock=clock+121;T.Request('PVP_MATCH_COMPLETE');pump();e=T.Get(1010)
check(#records()==5 and e.details.numericValue==147 and not e.details.delta and not e.details.duelID,'changed total does not manufacture three events or a match attribution')
values[1010]='2';clock=clock+121;T.Request('DUEL_FINISHED');pump();e=T.Get(1010)
check(e.details.valueDecreased==true and not e.details.result and not e.details.reason,'counter decrease observed without guessing reset or duel result')
local date=e.at;values[1010]=nil;clock=clock+121;T.Request('BOSS_KILL');pump();e,available=T.Get(1010)
check(e and e.at==date and available==false,'temporarily unavailable total retains last dated native observation')
values[1010]='2';local count=#records();local oldDiscoveries=discoveries
C.SetEnabled(false);C.SetEnabled(true);pump()
check(#records()==count and discoveries==oldDiscoveries,'same-character resume restores native cache from ledger and suppresses unchanged baselines')
local n=reads;for i=1,100 do T.Request('QUEST_TURNED_IN');T.Pump() end
check(reads==n,'native event burst does not trigger unrestricted polling')
clock=clock+121;T.Pump();pump();check(reads>n and #records()==count,'pending meaningful checkpoint reads once after the throttle')
local packed=assert(ns.ChronicleBackup.PackSaved(S.db));local restored=assert(S.Normalize(packed))
check(ns.ChronicleBackup.Encode(restored.characters[C.Owner()].events)==ns.ChronicleBackup.Encode(S.Character(C.Owner(),false).events),'native statistics round-trip losslessly in existing saved chunks')
check(T.Numeric('1234')==1234 and T.Numeric('1.234')==nil and T.Numeric('1 234')==nil and T.Numeric('1,234')==nil and T.Numeric('12%')==nil,'numeric parser never guesses localized punctuation or units')
local originalGet=GetStatisticsCategoryList;GetStatisticsCategoryList=nil;T.Start();check(not T.ready and C.Active(),'unavailable statistic APIs do not stop other Chronicle recording');GetStatisticsCategoryList=originalGet
GetStatisticsCategoryList=function() return {} end
local locale=GetLocale;GetLocale=function() return 'empty-catalog' end;T.Start();pump()
check(T.ready and #T.catalog==0,'empty native statistics catalog supported without invented entries')
GetStatisticsCategoryList=originalGet;GetLocale=function() return 'bounded-catalog' end;T.MAX_STATISTICS=3;T.Start();pump()
check(#T.catalog==3 and not T.catalogComplete,'discovery limit is explicit and bounded')
T.MAX_STATISTICS=4096;GetLocale=locale
local oldGUID=units.player.guid;units.player.guid='Player-Statistics-OTHER';freshRecording();pump()
check(T.Get(1010).character==C.Owner(),'character switch binds native statistics to the current character only');units.player.guid=oldGUID
C.SetEnabled(false);local old=reads;T.Request('BOSS_KILL');pump();check(reads==old,'recording pause stops statistic getters')
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'native statistics preserve existing consent/schema and combat restrictions')
statisticChecks=checks-before;statisticReadCalls=reads;statisticCatalogCalls=discoveries
''')
summary={'version':'1.1.0','assertions':int(lua.globals().statisticChecks),'failed':0,'reads':int(lua.globals().statisticReadCalls),'catalogCalls':int(lua.globals().statisticCatalogCalls),'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'native-statistics-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
