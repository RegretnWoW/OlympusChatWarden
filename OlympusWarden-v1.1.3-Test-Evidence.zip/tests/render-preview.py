from pathlib import Path
import json,base64,sys,io
from PIL import Image
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
template=root/'.work/v102-release-polish/preview/updates.html'
s=template.read_text(encoding='utf-8')
s=s.replace('Olympus ChatWarden · Native panel','Olympus Warden · 1.1 preview')
s=s.replace('Layout preview from the production Lua frame tree and existing artwork.','Production Lua widget layout with illustrative local history.')
s=s.replace('Fixed panel sizes: 326 x 360 classic and 744 x 480 HD.','New branding, suite navigation and first history views.')
s=s.replace('r.y+i*lineH,r.w','r.y+(f.justifyV===\'MIDDLE\'?Math.max(0,(r.h-lines.length*lineH)/2):0)+i*lineH,r.w')
s=s.replace("let txt=f.text.replace(","let txt=f.text.replace(/\\|\\|/g,'|').replace(")
s=s.replace("if(f.texture){","if(typeof f.texture==='string'){")
s=s.replace("if(f.color){", "if(f.kind==='Line'&&f.fromPoint&&f.toPoint){const p=rect(f.parent);ctx.strokeStyle=f.color?`rgba(${f.color.slice(0,3).map(v=>Math.round(v*255)).join(',')},1)`:'#997447';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(p.x+f.fromPoint[0],p.y-f.fromPoint[1]);ctx.lineTo(p.x+f.toPoint[0],p.y-f.toPoint[1]);ctx.stroke();}if(f.color&&f.kind!=='Line'){")
s=s.replace("active.delete(id);memo.set(id,r);return r;", "const parent=by.get(f.parent);if(parent?.kind==='ScrollFrame'&&parent.scrollChild===id){r.y-=parent.verticalScroll||0;r.x-=parent.horizontalScroll||0;}active.delete(id);memo.set(id,r);return r;")
s=s.replace("ctx.translate(pad,pad);paint(scene.root);", "ctx.translate(pad,pad);paint(scene.root);window.renderGeometry=scene.frames.map(f=>({...f,rect:rect(f.id)}));")
s=s.replace('canvas.width=root.w+pad*2;canvas.height=rootHeight+pad*2;',"const displayScale=scene.style==='command-80'?.8:1;canvas.width=(root.w+pad*2)*displayScale;canvas.height=(rootHeight+pad*2)*displayScale;")
s=s.replace('ctx.translate(pad,pad);paint(scene.root);','ctx.scale(displayScale,displayScale);ctx.translate(pad,pad);paint(scene.root);')

# Match nested Frame:SetScale for the talent content, while presenting the root
# workspace at the preview's explicit display scale.
s=s.replace('function rect(id){', 'const scales=new Map();function effectiveScale(id){if(id===scene.root||!by.has(id))return 1;if(scales.has(id))return scales.get(id);const f=by.get(id);const value=(f.scale||1)*effectiveScale(f.parent);scales.set(id,value);return value;}function rect(id){')
s=s.replace('let w=f.w||0,h=f.h||0;', 'let w=(f.w||0)*effectiveScale(id),h=(f.h||0)*effectiveScale(id);')
s=s.replace('+(p.x||0)', '+(p.x||0)*effectiveScale(id)').replace('-(p.y||0)', '-(p.y||0)*effectiveScale(id)')
s=s.replace("let size=f.font?.[1]||12;", "let size=(f.font?.[1]||12)*effectiveScale(id);")
s=s.replace('p.x+f.fromPoint[0],p.y-f.fromPoint[1]', 'p.x+f.fromPoint[0]*effectiveScale(f.parent),p.y-f.fromPoint[1]*effectiveScale(f.parent)')
s=s.replace('p.x+f.toPoint[0],p.y-f.toPoint[1]', 'p.x+f.toPoint[0]*effectiveScale(f.parent),p.y-f.toPoint[1]*effectiveScale(f.parent)')
s=s.replace('ctx.lineWidth=2;', 'ctx.lineWidth=2*effectiveScale(f.parent);')

start=s.index("Promise.all(['updates']")
name=sys.argv[1];scene=json.loads((out/('scene-'+name+'.json')).read_text(encoding='utf-8'))
assets={}
for n in ['Controls','Guardian','Icons','Logo','Ornament','Panels','Status','Tabs']:
 assets[n]='data:image/png;base64,'+base64.b64encode((root/'OlympusChatWarden/Media/V5'/(n+'.png')).read_bytes()).decode()
for p in (root/'OlympusChatWarden/Media/Warden').glob('*.png'):
 assets[p.stem]='data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
for p in (root/'OlympusChatWarden/Media/Warden').glob('*.tga'):
 buffer=io.BytesIO();Image.open(p).save(buffer,format='PNG')
 assets[p.stem]='data:image/png;base64,'+base64.b64encode(buffer.getvalue()).decode()
for p in out.glob('*WardenSmall.png'):
 assets[p.stem]='data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
s=s[:start]+f'scenes=[{json.dumps(scene)}];const assets={json.dumps(assets)};'+"Promise.all(Object.entries(assets).map(([n,url])=>new Promise(resolve=>{let im=new Image();im.onload=()=>{imgs[n]=im;resolve()};im.src=url}))).then(()=>{refresh();window.renderDone=true});\n</script>"
(out/(name+'-preview.html')).write_text(s,encoding='utf-8')
print('Prepared '+name)
