from pathlib import Path
import json,ast
out=Path(__file__).resolve().parent;root=out.parents[1]
setup=(out/'test-city.py').read_text().split('results={}')[0];exec(compile(setup,'name-binding-host','exec'))
lua=host['fresh']('modern',True);lua.execute(fixture)
lua.execute(r'''
local N=ns.NameDisplays;N.Scan();assert(N.BindingCount()==60)
local bound=N.bindingStats.bound;N.Scan();assert(N.bindingStats.bound==bound and N.bindingStats.reused>=60)
units.nameplate1.guid='Player-Recycled-GUID';N.Scan();assert(N.bindingStats.bound==bound+1);bound=N.bindingStats.bound
local region=plates[1].UnitFrame.name;region.text='Changed without SetText hook';N.Scan()
assert(ns.RegionOriginal(region)=='Changed without SetText hook' and N.bindingStats.bound==bound+1);bound=N.bindingStats.bound
for _,f in ipairs(frames) do if f.events and f.events.NAME_PLATE_UNIT_REMOVED and f.scripts.OnEvent then f.scripts.OnEvent(f,'NAME_PLATE_UNIT_REMOVED','nameplate1') end end
drain();N.Scan();assert(N.bindingStats.bound>bound);bound=N.bindingStats.bound
ns.PolicyRevision=ns.PolicyRevision+1;N.Scan();assert(N.bindingStats.bound==bound+60)
local old=issecretvalue;issecretvalue=function(v) return v=='restricted label' or old and old(v) end
region.text='restricted label';assert(pcall(N.Scan));issecretvalue=old;region:SetText('Readable again');N.Scan();assert(ns.RegionOriginal(region)=='Readable again')
assert(N.BindingCount()<=100)
''')
result={'version':'1.1.0','failed':0,'guidRecycling':True,'unhookedNativeTextChanges':True,'generationRemoval':True,'policyChanges':True,'restrictedValues':True,'boundedBindings':True,'actualForeverTest':False}
(out/'name-bindings-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
