from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'city-safety','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local P,X=ns.WardenPerformance,ns.ChronicleCapture
local originalNow=P.Now;local clocks=0;P.Now=function() clocks=clocks+1;return clocks end
local object={f=function() return nil,'second',false end};P.Wrap(object,'f','test values');P.active=false
local a,b,c=object.f();check(a==nil and b=='second' and c==false and clocks==0,'disabled profiling preserves multiple results and reads no diagnostic clock')
P.active=true;P.stats={};a,b,c=object.f();check(a==nil and b=='second' and c==false and clocks==2,'enabled aggregate wrapper preserves exact results')
P.Now=originalNow;P.active=false;P.stats={}
freshRecording();local captureFrame
for _,f in ipairs(frames) do local update=f.scripts.OnUpdate;if update then for n=1,12 do local name,value=debug.getupvalue(update,n);if not name then break end;if value==X then captureFrame=f end end end end
check(captureFrame~=nil,'native capture scheduler can be exercised through its production frame')
for n=1,500 do X.Pump() end
ns.ChronicleEncounters.Stop();ns.ChronicleDuels.Stop()
local pump=X.Pump;local calls=0;X.Pump=function(...) calls=calls+1;return pump(...) end
for n=1,600 do captureFrame.scripts.OnUpdate(captureFrame,1/60) end
check(calls<=100 and calls>=80,'idle capture scheduling avoids per-frame pump work without removing schedulers')
local idleCalls=calls
local ran=false;X.Queue('immediate-native-work',function() ran=true end);captureFrame.scripts.OnUpdate(captureFrame,.001)
check(ran,'native queued enrichment wakes on the very next frame')
local pending=ns.ChronicleEncounters.Pending;ns.ChronicleEncounters.Pending=function() return true end
local prior=calls;captureFrame.scripts.OnUpdate(captureFrame,.001);check(calls==prior+1,'active inspection deadlines keep their original per-frame scheduling')
ns.ChronicleEncounters.Pending=pending
pending=ns.ChronicleDuels.Pending;ns.ChronicleDuels.Pending=function() return true end
prior=calls;captureFrame.scripts.OnUpdate(captureFrame,.001);check(calls==prior+1,'active duel/result windows keep their original per-frame scheduling')
ns.ChronicleDuels.Pending=pending
X.Pump=pump
local spelling=ns.Spelling;spelling.SetEnabled(true);local focus=GetCurrentKeyBoardFocus
GetCurrentKeyBoardFocus=function() return nil end
for n=1,100 do spelling.driver.scripts.OnUpdate(spelling.driver,.1) end
check(not spelling.ready and next(spelling.words)==nil,'no dictionary expansion while there is no eligible text entry')
local expected={};for _,word in ipairs({'friend','uncharacteristically','definitely','abcxyznonword'}) do expected[word]=spelling.KnownForFiltering(word) end
local edit=CreateFrame('EditBox',nil,UIParent);edit:SetText('freind');GetCurrentKeyBoardFocus=function() return edit end
local n=0;while not spelling.ready do spelling.driver.scripts.OnUpdate(spelling.driver,.1);n=n+1;assert(n<10000) end
check(spelling.ready and spelling.words.friend and spelling.Suggest('freind')[1]=='friend','normal spelling suggestions remain after first-use dictionary warmup')
for word,known in pairs(expected) do check(spelling.KnownForFiltering(word)==known,'incoming known-word protection unchanged across lazy expansion: '..word) end
GetCurrentKeyBoardFocus=focus;spelling.SetEnabled(false)
for n=1,1100 do clock=clock+.02;units.mouseover={guid='Player-Dense-'..n,name='Citizen '..n,class='MAGE',level=30};C.ObserveUnit('mouseover','UPDATE_MOUSEOVER_UNIT',true) end
local seen,limit=C.RuntimeCounts();check(seen==600 and limit==600,'recent-player dedup remains bounded after more than a thousand unique encounters')
local count=0;for _,e in ipairs(ledger().events) do if e.kind=='player_observed' and e.subject:find('Player-Dense-',1,true) then count=count+1 end end
check(count==1100,'bounded runtime bookkeeping does not remove a single unique historical encounter')
citySafetyChecks=checks-before;idleCaptureCalls=idleCalls
''')
result={'version':'1.1.0','failed':0,'assertions':lua.globals().citySafetyChecks,'capturePumpCallsPer600IdleFrames':lua.globals().idleCaptureCalls,'uniqueEncountersPreserved':1100,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'city-safety-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
