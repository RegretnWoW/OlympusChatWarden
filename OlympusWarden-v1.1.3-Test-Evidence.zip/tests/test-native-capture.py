from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];lua.execute(r'''
local baselineChecks=checks
X=ns.ChronicleCapture;L=ns.ChronicleLoadout;M=ns.ChronicleCombat;I=ns.ChronicleEncounters;B=ns.ChronicleBackup
function pump(n) for i=1,(n or 100) do X.Pump() end end
function native(kind) local a={};for _,e in ipairs(all('native_event')) do if e.details.recordType==kind then a[#a+1]=e end end;return a end
function captures(family) local a={};for _,e in ipairs(all('native_snapshot')) do if e.capture.family==family then a[#a+1]=e end end;return a end
C_SkillInfo={GetNumSkillLines=function() return 3 end,GetSkillLineInfo=function(i)
 if i==1 then return {skillID=171,name='Same localized name',isHeader=false,rank=50,maxRank=75} end
 if i==2 then return {skillID=164,name='Same localized name',isHeader=false,rank=60,maxRank=75} end
 return {skillID=99,name='Header',isHeader=true,rank=0,maxRank=0} end}
GetNumSkillLines=function() error('legacy must not be preferred') end
GetSkillLineInfo=function() error('legacy must not be preferred') end
UnitClass=function(unit) return 'Mage','MAGE',8 end
UnitRace=function(unit) return 'Human','Human',1 end
UnitSex=function() return 2 end
gearItem=19019;linkReady=true
GetInventoryItemID=function(unit,slot) return slot==16 and gearItem or nil end
GetInventoryItemLink=function(unit,slot) return slot==16 and gearItem and linkReady and ('|Hitem:'..gearItem..':123:456:0:0:0:-2:999:30|h[Weapon]|h') or nil end
GetInventoryItemTexture=function(unit,slot) return slot==16 and gearItem and 12345 or nil end
GetPVPLifetimeStats=function() return 100,8 end
GetPVPSessionStats=function() return 3,0 end;GetPVPYesterdayStats=function() return 7,1 end
C_PlayerInfo={GetNativeDisplayID=function() return 123 end,GetDisplayID=function() return 456 end}
freshRecording();pump()
local skills=all('skill_observed');check(#skills==2,'namespaced skills with duplicate localized names retain distinct IDs')
check(skills[1].details.skillID~=skills[2].details.skillID,'skill identity is numeric')
C_SkillInfo.GetSkillLineInfo=function(i) if i==1 then return {skillID=171,name='Renamed skill',isHeader=false,rank=51,maxRank=75} else return {skillID=164,name='Same localized name',isHeader=false,rank=60,maxRank=75} end end
C_SkillInfo.GetNumSkillLines=function() return 2 end
ev('SKILL_LINES_CHANGED');check(#all('skill_change')==1 and all('skill_change')[1].details.skillID==171,'renamed localized skill preserves numeric delta identity')
local gear=captures('gear')[1];check(gear and #gear.capture.values.slots==19,'coherent snapshot contains all native slots')
check(gear.capture.values.slots[16][2]=='present' and gear.capture.values.slots[16][4]:find(':123:456:',1,true),'full native enchant/gem payload preserved')
check(gear.capture.values.slots[1][2]=='empty','independent successful own getters establish empty slot')
local gcount=#captures('gear');L.Milestone('checkpoint','manual milestone');pump()
check(#captures('gear')==gcount,'unchanged gear deduplicates across milestones')
local milestone=all('loadout_observed')[#all('loadout_observed')]
check(milestone.details.gearRef==gear.details.contentID,'milestone links immutable content')
linkReady=false;L.Milestone('checkpoint','equipment');pump()
local pendingGear=captures('gear')[#captures('gear')]
check(pendingGear.capture.values.slots[16][2]=='pending' and pendingGear.capture.values.slots[16][3]==19019,'loading item keeps readable ID and explicit pending state')
linkReady=true;clock=clock+1;L.Milestone('checkpoint','equipment');pump()
check(#captures('gear')==gcount+1,'resolved identical gear reuses prior full snapshot')
local oldSecret=issecretvalue;issecretvalue=function(v) return v==424242 end
check(not X.Validate({format=1,family='appearance',values={guid=units.player.guid,displayID=424242}}),'nested inaccessible scalar rejected before hashing')
check(not X.Validate({format=1,family='appearance',values={guid=units.player.guid,accountPassword='no'}}),'unknown payload fields rejected')
local cyc={};cyc[1]=cyc;check(not X.Validate({format=1,family='appearance',values={customizations=cyc}}),'cyclic payload rejected')
issecretvalue=oldSecret
local counter=native('pvp_counter_snapshot')[1]
check(counter.details.lifetimeHK==100 and counter.details.lifetimeMaxRank==8 and counter.details.sessionDK==0,'Forever PvP tuple semantics retained')
M.Handle('PARTY_KILL',units.player.guid,'Creature-0-1-2-3-55-0001')
local kill=native('native_kill_credit')[1]
check(kill and kill.details.entityKind=='Creature' and kill.subject==nil,'NPC credit is not a player profile')
check(kill.details.credit=='self native credit','own native credit identified without claiming semantic last hit')
check(kill.details.gearRef and X.Find(kill.character,kill.details.gearRef),'kill links correctly dated known gear')
units.party1={guid='Player-Friend-02',name='Friendly Person',level=30,guild='Olympus Reloaded'}
M.Handle('PARTY_KILL',units.party1.guid,'Player-Enemy-03')
check(native('native_kill_credit')[2].details.credit=='group native credit','group kill never credited as own')
local n=#native('native_kill_credit');M.Handle('PARTY_KILL',424242,nil)
check(#native('native_kill_credit')==n,'missing victim creates no guessed kill')
units.pet={guid='Pet-0-1-2-3-55-01',name='Pet'};M.Handle('PARTY_KILL',units.pet.guid,'Creature-0-1-2-3-55-0002')
check(native('native_kill_credit')[3].details.credit=='current pet native credit','current pet credit remains separate')
n=#native('native_kill_credit');ev('PLAYER_XP_UPDATE','player');ev('LOOT_OPENED');ev('PLAYER_DEAD')
check(#native('native_kill_credit')==n,'XP loot and death never identify a kill')
M.Handle('ENCOUNTER_END',77,'Test Boss',1,5,0)
local encounter=native('encounter_ended')[1];check(encounter.details.success==0 and encounter.details.recordType=='encounter_ended','failed encounter retained without inventing wipe')
M.Handle('DUEL_FINISHED');check(native('duel_finished')[1].details.resultKnown==false,'duel finish never invents winner')
local inCombat=true;UnitAffectingCombat=function() return inCombat end
M.Handle('PLAYER_REGEN_DISABLED');M.Handle('UNIT_SPELLCAST_SUCCEEDED','player','Cast-1',133);M.Handle('UNIT_SPELLCAST_SUCCEEDED','player','Cast-2',133)
check(#native('own_spell_success_count')==0,'combat casts grouped pending session boundary')
clock=clock+9;inCombat=false;M.Handle('PLAYER_REGEN_ENABLED');pump()
check(native('own_spell_success_count')[1].details.count==2,'spell successes counted without hit or victim claim')
check(native('combat_ended')[1].details.combatSeconds==9,'measured combat boundary duration')
local reads=0
Enum=Enum or {};Enum.DamageMeterType={DamageDone=0}
C_DamageMeter={IsDamageMeterAvailable=function() return true end,GetAvailableCombatSessions=function() reads=reads+1;return {{sessionID=12}} end,
 GetCombatSessionFromID=function(id,kind) return {totalAmount=500,durationSeconds=10,combatSources={{sourceGUID=units.player.guid,name='Self',classFilename='MAGE',totalAmount=500,amountPerSecond=50,isLocalPlayer=true}}} end,
 GetCombatSessionSourceFromID=function() return {combatSpells={{spellID=133,totalAmount=500,amountPerSecond=50,overkillAmount=10,isAvoidable=false,isDeadly=false}}} end}
inCombat=true;X.Queue('meter-test',function() M.Meter('checkpoint') end);pump(10)
check(reads==0,'meter getters never run while combat is active')
inCombat=false;pump(100)
check(#native('damage_meter_source')==1 and #native('damage_meter_spell')==1,'post-combat source and spell aggregates copied')
local sources=#captures('meter');X.Queue('meter-test',function() M.Meter('checkpoint') end);pump(100)
check(#captures('meter')==sources,'identical meter updates do not duplicate objects')
M.Handle('DAMAGE_METER_RESET');X.Queue('meter-test',function() M.Meter('checkpoint') end);pump(100)
check(#captures('meter')>sources,'meter reset epoch disambiguates reused native session IDs')
C_PvP={GetScoreInfo=function(i) if i==1 then return {guid=units.player.guid,name='Self',killingBlows=2,honorableKills=8,deaths=1,damageDone=500,healingDone=0,honorLevel=8} end end}
GetNumBattlefieldScores=nil
M.Handle('PVP_MATCH_COMPLETE',1,600);pump(100)
check(#captures('scoreboard')==1 and captures('scoreboard')[1].capture.values.killingBlows==2,'final scoreboard works with native row reader without old count getter')
M.Handle('PVP_MATCH_ACTIVE');M.Handle('UPDATE_BATTLEFIELD_SCORE');pump(100)
check(#captures('scoreboard')==2 and captures('scoreboard')[2].capture.values.phase=='in-progress'
 and captures('scoreboard')[2].capture.values.matchSequence>captures('scoreboard')[1].capture.values.matchSequence,
 'new active match retains an explicitly in-progress observation under a new local sequence, never a proven fresh final result')
-- Native normal inspection: owned request with GUID checks and shared-cache race rejection.
function hooksecurefunc(name,hook) local old=_G[name];_G[name]=function(...) local a,b=old(...);hook(...);return a,b end end
NotifyInspect=function(unit) end;ClearInspectPlayer=function() end
CanInspect=function() return true end;UnitIsVisible=function() return true end
I.Start();I.Important('party1','control','party teammate');clock=clock+10;I.InspectPump();I.InspectReady(units.party1.guid)
check(#all('important_player')>=2,'friendly important player and owned inspect response retained')
local ip=all('important_player')[#all('important_player')]
check(ip.subject==units.party1.guid and ip.details.gearRef,'friendly gear bound to exact character GUID')
local og=X.Find(ip.character,ip.details.gearRef)
check(og.capture.values.guid==units.party1.guid and og.capture.values.slots[1][2]=='unavailable','nil inspected slot is unknown rather than confirmed empty')
clock=clock+70;I.Important('party1','control','encountered friend');clock=clock+10;I.InspectPump()
local before=#all('important_player');NotifyInspect('target');I.InspectReady(units.party1.guid)
check(#all('important_player')==before,'another addon request invalidates our shared inspect ownership')
C_FriendList={GetFriendInfo=function() return {guid='Player-Other-04',notes='DO NOT COPY'} end}
units.target={guid='Player-Stranger-04',name='Same Name'};before=#all('important_player');I.Observe('target','PLAYER_TARGET_CHANGED')
check(#all('important_player')==before,'same-name friend match without same GUID never qualifies passerby')
C_FriendList.GetFriendInfo=function() return {guid=units.target.guid,notes='DO NOT COPY'} end;I.Observe('target','PLAYER_TARGET_CHANGED')
check(#all('important_player')==before+1,'friend actually encountered qualifies by matching GUID')
local standing=3000
C_Reputation={GetNumFactions=function() return 1 end,GetFactionDataByIndex=function() return {factionID=72} end,
 GetFactionDataByID=function() return {factionID=72,name='Stormwind',currentStanding=standing,reaction=5} end,IsMajorFaction=function() return false end}
I.Reputation('control',72);standing=3025;I.Reputation('FACTION_STANDING_CHANGED',72)
check(native('reputation_standing_changed')[1].details.delta==25,'known standard standing baseline produces actual delta')
C_Reputation.IsMajorFaction=function() return true end;standing=10;I.Reputation('FACTION_STANDING_CHANGED',72)
check(native('reputation_standing_changed')[2].details.delta==nil,'renown reset never becomes guessed negative gain')
I.Handle('NEW_RECIPE_LEARNED',1234,1);I.Handle('TRADE_SKILL_ITEM_CRAFTED_RESULT',{itemID=765,quantity=2,hyperlink='|Hitem:765:0|h[Item]|h'})
check(native('recipe_learned')[1].details.recipeID==1234 and native('native_craft_result')[1].details.quantity==2,'native recipe/craft results preserved separately from cast start')
C_BarberShop={GetAvailableCustomizations=function() return {{id=1,chrModelID=77,options={{id=55,currentChoiceIndex=1,choices={{id=999}}}}}} end}
L.Handle('BARBER_SHOP_RESULT',false);check(#captures('barber')==0,'failed or cancelled barber session has no applied choices')
L.Handle('BARBER_SHOP_APPEARANCE_APPLIED');check(captures('barber')[1].capture.values.customizations[1][4]==999,'applied customization keeps stable choice ID rather than index')

-- Additional pinned structured contracts, with staged trait rejection.
C_ClassTalents={GetActiveConfigID=function() return 5 end}
local staged=false
C_Traits={ConfigHasStagedChanges=function() return staged end,GetConfigInfo=function() return {treeIDs={10}} end,
 GetTreeNodes=function() return {101,102} end,GetNodeInfo=function(config,id) return {currentRank=id==101 and 2 or 0,activeEntry={entryID=1000+id,rank=2}} end}
X.Queue('traits-test',function() L.Traits('control') end);pump(30)
local trait=captures('traits')[1]
check(trait and trait.capture.values.committed and #trait.capture.values.nodes==2,'committed active trait tree retains native IDs/ranks')
local tc=#captures('traits');staged=true;X.Queue('traits-test',function() L.Traits('control') end);pump(30)
check(#captures('traits')==tc,'staged talent edits never become committed history');staged=false
local itemLocationCalls=0
ItemLocation={CreateFromEquipmentSlot=function(self,slot) return {slot=slot} end}
C_Item={GetItemGUID=function(loc) itemLocationCalls=itemLocationCalls+1;return 'Item-0-1-2-345' end}
L.Milestone('control','item identity');pump(50)
check(itemLocationCalls>0 and captures('gear')[#captures('gear')].capture.values.itemGUIDs[16]=='Item-0-1-2-345','readable own item instance identity is portable text')
UnitStat=function(unit,i) return 10,20+i end;UnitArmor=function() return 100,123 end
UnitHealthMax=function() return 1000 end;UnitPowerMax=function() return 1200 end;UnitPowerType=function() return 0 end
GetInventoryItemDurability=function(slot) if slot==16 then return 40,100 end end
L.Milestone('control','stats');pump(50)
check(captures('stats')[1].capture.values.spirit==25,'full own effective stat block includes Spirit')
check(captures('gear_condition')[1].capture.values.slots[1][2]==40,'durability observed separately from stable gear hash')
C_EquipmentSet={CanUseEquipmentSets=function() return true end,GetEquipmentSetIDs=function() return {7} end,
 GetEquipmentSetInfo=function() return 'Healing set',123,7,false end,GetItemIDs=function() return {[16]=19019} end,
 GetIgnoredSlots=function() return {[1]=true} end}
X.Queue('sets-test',function() L.Sets('control') end);pump(50)
check(captures('equipment_set')[1].capture.values.name=='Healing set' and captures('equipment_set')[1].capture.values.isEquipped==false,'saved named set stays distinct from actually equipped gear')
GetBuildInfo=function() return '1.60.1','70425','Oct 16 2026',16001 end
C_MajorFactions={GetMajorFactionProgressionInfo=function(id) check(id==2800,'rank uses pinned Forever faction mapping');return {renownLevel=8,renownReputationEarned=50,renownLevelThreshold=100,maxLevel=14,weekNumber=1} end}
M.Rank('checkpoint');check(captures('rank')[1].capture.values.renownLevel==8,'Forever rank progression preserved in verified build mapping')
local ranks=#captures('rank');GetBuildInfo=function() return '1.60.1','99999' end;M.Rank('checkpoint')
check(#captures('rank')==ranks,'unknown new build never guesses a rank faction')
-- Post-event enrichment keeps a kill even if the unit disappears before inspection.
inCombat=true;units.target={guid='Player-Important-09',name='Important Enemy'}
M.Handle('PARTY_KILL',units.player.guid,units.target.guid);local beforeImportant=#all('important_player')
units.target=nil;inCombat=false;pump(80)
check(#all('important_player')==beforeImportant and native('native_kill_credit')[#native('native_kill_credit')].details.targetGUID=='Player-Important-09','despawned kill remains while unavailable appearance is not invented')
C_DeathRecap={HasRecapEvents=function(id) return id==99 end,GetRecapEvents=function() return {{event='SPELL_DAMAGE',spellId=133,spellName='Fireball',caster='Enemy',amount=500,timestamp=123}} end,GetRecapMaxHealth=function() return 1000 end}
M.Recap('checkpoint',99,units.player.guid)
check(captures('recap')[1].capture.values.rows[1][5]==500,'explicit native recap ID archives readable amount and event time')
local rc=#captures('recap');M.Recap('checkpoint',99,'Player-Unimportant-09')
check(#captures('recap')==rc,'unimportant meter subject does not create detailed recap archive')
local run=X.runID;local meterCount=#captures('meter');X.Start();pump(150)
check(X.runID~=run and #captures('meter')>meterCount,'transient meter IDs are scoped to unique collector runs across reload/loading restarts')
local detail=ns.RecordingUI.Detail(ip);local text='';for _,block in ipairs(detail) do text=text..block.text end
check(text:find('Saved gear data',1,true),'record browser renders linked native data')
C.SetEnabled(false)
local backup,err=B.Create();check(backup and backup.total>=1,err or 'typed snapshot backup created')
for _,part in ipairs(backup.parts) do local parsed,e=B.Validate(part);check(parsed,e or 'each part independently includes snapshot dependencies') end
local original=#ledger().events;local parts=backup.parts;C.Clear()
for i=#parts,1,-1 do local ok,err=B.Restore(parts[i]);check(ok,err or 'reverse-order multipart restore succeeds') end
check(#ledger().events==original,'duplicate snapshot dependencies restore idempotently')
check(not S.db.enabled,'restoring detailed records never inherits consent')
local nativeObject=captures('gear')[1];local broken={};for k,v in pairs(nativeObject) do broken[k]=v end
broken.details={contentID=string.rep('0',64),family='gear'}
check(not S.Event(broken,C.Owner()),'content hash mismatch rejected during schema validation')
check(not X.ValidActivity({recordType='native_kill_credit',attackerGUID=units.player.guid,targetGUID='Creature-0-1-2-3-55-1',entityKind='Player',credit='self native credit'}),'native credit entity kind mismatch rejected')
check(not X.ValidActivity({recordType='own_spell_success_count',spellID=133,count=-1,firstAt=1,lastAt=2}),'negative native spell count rejected')
check(not X.ValidActivity({recordType='reputation_standing_changed',factionID=72,beforeStanding=3,afterStanding=5,delta=200}),'mismatched reputation delta rejected')
local objectIndex=X.ObjectIndex(ledger().events)
local referenceEvent
for _,e in ipairs(ledger().events) do if e.kind=='loadout_observed' then referenceEvent=e;break end end
local ref=referenceEvent.details.gearRef;local object=objectIndex[ref];objectIndex[ref]=nil
check(not X.Dependencies(referenceEvent,objectIndex),'missing snapshot dependency cannot validate as a complete reference')
objectIndex[ref]=object
local savedDB=ns.DB.chronicle;savedDB.schema=2;savedDB.consentVersion=2;savedDB.enabled=true
C.Initialize();check(not S.db.enabled and S.db.needsConsentUpgrade and #ledger().events==original,'scope two upgrade preserves all history and requires expanded consent')
local attemptReads=reads;M.Handle('DAMAGE_METER_CURRENT_SESSION_UPDATED');L.Milestone('control','paused');pump()
check(reads==attemptReads,'paused native jobs make no getter calls')
for _,f in ipairs(frames) do if f.events then check(not f.events.COMBAT_LOG_EVENT_UNFILTERED and not f.events.COMBAT_LOG_EVENT,'no restricted raw combat event registered') end end
nativeChecks=checks-baselineChecks
''')
summary={'version':'1.0.3','assertions':lua.globals().nativeChecks,'failed':0,'nativeContracts':'pinned Forever 70425 fixtures; synthetic host','liveWoWTested':False}
(out/'native-capture-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
