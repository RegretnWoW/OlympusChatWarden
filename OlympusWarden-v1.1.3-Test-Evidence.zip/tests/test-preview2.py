from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;started=time.perf_counter()
h={'__file__':str(o/'test-ui-pass.py')};exec(compile((o/'test-ui-pass.py').read_text(),'preview 1 regression host','exec'),h);lua=h['l']
lua.execute(r'''
local before=checks;local L,T,G,X,C,S=ns.WardenLaunchers,ns.WardenTalents,ns.WardenDossier,ns.ChronicleCapture,ns.Chronicle,ns.ChronicleStore
GameTooltip=CreateFrame('GameTooltip',nil,UIParent)
function GameTooltip:SetOwner() end
function GameTooltip:AddLine(text) self.lines=self.lines or {};self.lines[#self.lines+1]=text end
L.Set('shopLauncher',true)
check(L.shop.background.atlas=='UI-HUD-MicroMenu-ButtonBG-Up' and L.shop.background.useAtlasSize,'shop uses the native stock background at its own atlas size')
check(L.shop.icon:GetWidth()==L.shop.icon:GetHeight() and L.shop.icon:GetWidth()<=StoreMicroButton:GetWidth()-10,'micro emblem stays square and inset')
L.shop:GetScript('OnMouseDown')(L.shop,'LeftButton');check(L.shop.pushedBackground:IsShown() and not L.shop.background:IsShown(),'stock pressed background is visible during press')
L.shop:GetScript('OnMouseUp')(L.shop,'LeftButton');check(not L.shop.pushedBackground:IsShown() and L.shop.background:IsShown(),'stock normal background returns on release')
StoreMicroButton:SetSize(44,28);StoreMicroButton:GetScript('OnSizeChanged')();check(L.shop.icon:GetWidth()==16 and L.shop.icon:GetHeight()==16,'micro layout follows a resized host without stretching')
Minimap:SetSize(240,240);ns.DB.wardenMinimapAngle=nil;L.Set('wardenMinimap',true)
local b=L.minimap;local point=b.points[1]
check(math.abs(point.x-134/math.sqrt(2))<.001 and math.abs(point.y-point.x)<.001,'new minimap default is upper right outside the actual map edge')
check(b.border.texture=='Interface\\Common\\RingBorder' and b.border.points[1].point=='CENTER' and b.icon.points[1].point=='CENTER','native ring and emblem share their center instead of a padded tracking sheet')
ns.DB.wardenMinimapAngle=180;L.Refresh();check(math.abs(b.x+134)<.001 and math.abs(b.y)<.001,'user-selected minimap angle is preserved')
Minimap:SetSize(300,200);Minimap:GetScript('OnSizeChanged')();check(math.abs(b.x+164)<.001,'map resizing updates the outside orbit without a polling worker')
check(not b:GetScript('OnUpdate'),'minimap position has no idle per-frame worker')
InspectFrame.ModeTabs=CreateFrame('Frame',nil,InspectFrame);InspectFrame.ModeTabs.Tabs={}
for n=1,3 do InspectFrame.ModeTabs.Tabs[n]=CreateFrame('Frame',nil,InspectFrame.ModeTabs) end
InspectFrame.InitializeModeTabLayout=function() end;L.inspect:Hide();L.inspect=nil;L.Set('inspectLauncher',true)
local tab=L.inspect
check(tab.template=='LargeSideTabButtonTemplate' and tab.icon.texture:find('IntelWarden.tga',1,true),'Inspect shortcut uses the native side-tab template with the Intel crest')
check(tab.points[1].anchor==InspectFrame.ModeTabs.Tabs[3] and tab.points[1].relative=='BOTTOMLEFT','Intel tab follows the last visible native tab')
InspectFrame.ModeTabs.Tabs[3]:Hide();InspectFrame:InitializeModeTabLayout()
check(tab.points[1].anchor==InspectFrame.ModeTabs.Tabs[2] and #InspectFrame.ModeTabs.Tabs==3,'native tab layout changes reposition the shortcut without changing native routing')
local selected=ns.Workspace.pages.intel.selected
tab:GetScript('OnMouseUp')(tab,'RightButton',true);tab:GetScript('OnMouseUp')(tab,'LeftButton',false)
check(ns.Workspace.pages.intel.selected==selected,'right-click and release outside do not navigate')
L.Set('inspectLauncher',false);check(not tab:IsShown(),'optional side tab can still be disabled independently')
local function fixture(unit)
 local tree={id=700,nodes={},groups={{1,'Beast Mastery'},{2,'Marksmanship'},{3,'Survival'}}};local id=1000
 for g=1,3 do for row=0,7 do for col=0,3 do
  id=id+1;tree.nodes[id]={id,(3000+(g-1)*4000+col*600)*unit,(1500+row*600)*unit,5,0,{{id+2000,id+3000,1001,1}},{},{g},true}
 end end end
 return tree
end
local nativeTree=fixture(1);local layout=assert(T.Layout({nativeTree}))
check(#layout.list==96 and layout.maxX+100>1076 and layout.maxY+105>264,'a dense three-branch native tree expands into scrollable dimensions')
for _,unit in ipairs({1,.0001}) do
 local plan=assert(T.Layout({fixture(unit)}));local readable=true
 for n,a in ipairs(plan.list) do for m=n+1,#plan.list do local b=plan.list[m]
  if math.abs(a.x-b.x)<57.99 and math.abs(a.y-b.y)<67.99 then readable=false end
 end end
 check(readable,'all native-unit and fractional-unit node/rank rectangles remain separated')
 check(plan.groups[2].x-plan.groups[1].x>=236 and plan.groups[3].x-plan.groups[2].x>=236,'branch headings have separate readable regions')
end
local holder=CreateFrame('Frame',nil,UIParent);local graph=T.Build(holder);graph.layout=layout;graph.selected={};graph.complete=false;graph.observed='synthetic observation';graph:Draw()
check(graph.width>1076 and graph.height>264 and graph.content.scale==1 and graph.zoomOut:IsEnabled(),'drawing retains scrollable bounds at the default whole-tree scale')
local clash=fixture(1);clash.nodes[1002][2]=clash.nodes[1001][2];clash.nodes[1002][3]=clash.nodes[1001][3]
check(T.Layout({clash})==nil,'coincident visible native positions fall back instead of inventing another layout')
preview2Tree=fixture(1)
-- A saved store begins a new session with no mutation revision.
local R,P=ns.RelayStore,ns.RelayTransport;local report=assert(R.New())
assert(R.Save(report.id,{module='suite',category='bug',title='Already submitted',description='Retained report fixture',steps=''}))
report.wire=assert(R.Encode(R.Payload(report,'')));report.checksum=R.Checksum(report.wire);report.state='received';R.revision=nil
local support=ns.RelayUI.Build(UIParent);support:SetView('mine')
check(#support.mine.list.items==1 and support.mine.list.items[1]==report,'My Reports populates existing submissions before any new mutation or submission')
support.mine.search:SetText('does not exist');check(#support.mine.list.items==0,'search still invalidates a revision-zero list')
support.mine.search:SetText('');check(#support.mine.list.items==1,'clearing search restores reports without submitting')
local developer=P.IsDeveloper;P.IsDeveloper=function() return true end
R.db.inbox={{key='sender/'..report.id,sender='Sender-Realm',wire=report.wire,checksum=report.checksum,state='New'}};R.revision=nil
support:SetView('inbox');check(#support.inbox.list.items==1,'Developer Inbox also populates without a new report')
P.IsDeveloper=developer
-- Missing exact links still get a native item-type tooltip/link; history is immutable.
GetItemInfo=function(arg) return 'Burnished Bracers','|Hitem:3211:0:0:0|h[Burnished Bracers]|h',2,nil,nil,nil,nil,nil,nil,12345 end
local gear=G.Build(holder,holder);local slots={};for n=1,19 do slots[n]={n,'unavailable',false,false} end
slots[9]={9,'pending',3211,false};local record={object={capture={values={slots=slots}}},at=1800000000,event={id='fixture'}}
gear.rows={record};gear.index=1;gear:Render();local wrist
for _,s in ipairs(gear.slots) do if s.slot==9 then wrist=s end end
check(wrist.itemName=='Burnished Bracers' and wrist.link==nil and wrist.baseLink=='item:3211:0:0:0','ID-only history resolves a typed native item link without altering original evidence')
local tooltipLink;local oldTooltip=GameTooltip.SetHyperlink;GameTooltip.SetHyperlink=function(_,link) tooltipLink=link end
wrist:GetScript('OnEnter')(wrist);check(tooltipLink==wrist.baseLink,'hover opens the native item tooltip instead of only the Wrists title')
local clicked;HandleModifiedItemClick=function(link) clicked=link end;G.ItemClick(wrist,'LeftButton')
check(clicked and clicked:find('item:3211:',1,true) and slots[9][4]==false,'standard modifier click links the explicitly labeled item type without changing saved history')
slots[9]={9,'present',3211,'item:3211:222:0:-7'};gear:Render();wrist:GetScript('OnEnter')(wrist)
check(tooltipLink=='item:3211:222:0:-7' and wrist.clickLink:find('item:3211:222:0:-7',1,true),'exact recorded modifiers always take priority over a base-item fallback')
GameTooltip.SetHyperlink=oldTooltip
GetItemInfo=function() end;C_Item=C_Item or {};C_Item.GetItemInfo=function() return 'Modern Bracers','|Hitem:3211:0|h[Modern Bracers]|h',2,nil,nil,nil,nil,nil,nil,54321 end
slots[9]={9,'pending',3211,false};gear:Render();check(wrist.itemName=='Modern Bracers' and wrist.icon.texture==54321,'modern item metadata recovers when an existing legacy shim returns nothing')
-- Cache completion is bounded and cannot cross identity, epoch or pause boundaries.
InspectFrame:Hide();freshRecording();clock=clock+600;units.target={guid='Player-Late-Links',name='Late Gear',class='WARRIOR',level=18}
local guid=units.target.guid;local ready=false;local linkReads=0
local notify=NotifyInspect;local requestCount=0;NotifyInspect=function(unit) requestCount=requestCount+1;return notify(unit) end
GetInventoryItemID=function(unit,slot) if unit=='target' and slot==9 then return 3211 end end
GetInventoryItemLink=function(unit,slot) if unit=='target' and slot==9 then linkReads=linkReads+1;if ready then return '|Hitem:3211:222:0:-7|h[Bracers]|h' end end end
GetInventoryItemTexture=function(unit,slot) if unit=='target' and slot==9 then return 12345 end end
local function latest() local rows=all('important_player');return rows[#rows] end
clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);local first=latest();local original=first.details.gearRef
check(X.Find(C.Owner(),original).capture.values.slots[9][2]=='pending','initial partial cache is retained honestly')
ready=true;clock=clock+.3;ns.ChronicleEncounters.InspectPump();local completed=latest()
check(completed.details.gearRef~=original and X.Find(C.Owner(),completed.details.gearRef).capture.values.slots[9][4]=='item:3211:222:0:-7' and requestCount==1,'later owned item cache completes the exact link without a second inspection request')
check(X.Find(C.Owner(),original).capture.values.slots[9][4]==false,'cache completion never rewrites the earlier snapshot')
local read=linkReads;clock=clock+1;ns.ChronicleEncounters.InspectPump();check(linkReads==read,'completed cache stops retry work')
clock=clock+10;ready=false;InspectFrame_Show('target');ev('INSPECT_READY',guid);read=linkReads
units.target.guid='Player-Another-Unit';clock=clock+.3;ns.ChronicleEncounters.InspectPump();check(linkReads==read,'recycled unit identity cancels cache completion before reading gear')
units.target.guid=guid;clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);read=linkReads;C.SetEnabled(false);clock=clock+.3;ns.ChronicleEncounters.InspectPump()
check(linkReads==read,'pausing recording cancels pending cache completion')
freshRecording();clock=clock+600;InspectFrame_Show('target');ev('INSPECT_READY',guid);read=linkReads
NotifyInspect('player');clock=clock+.3;ns.ChronicleEncounters.InspectPump();check(linkReads==read,'another native inspection cancels cache completion through its ownership epoch')
clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);read=linkReads
local enabled=ns.Modules.Enabled;ns.Modules.Enabled=function(id) return id~='intel' and enabled(id) end
clock=clock+.3;ns.ChronicleEncounters.InspectPump();check(linkReads==read,'disabling Intel cancels pending other-player reads while Chronicle remains enabled');ns.Modules.Enabled=enabled
clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);read=linkReads
for _,dt in ipairs({.3,.7,1.5}) do clock=clock+dt;ns.ChronicleEncounters.InspectPump() end
check(linkReads-read==3,'unavailable exact links get at most three bounded cache reads')
read=linkReads;clock=clock+10;ns.ChronicleEncounters.InspectPump();check(linkReads==read,'expired item-cache completion does no further read work')
C.SetEnabled(false)
preview2Checks=checks-before
''')
result={'version':'1.1.3-preview2','assertions':int(lua.globals().preview2Checks),'failed':0,'nativeClient':False,'talentFixtureNodes':96,'nativeSideTabMixinExercised':True,'seconds':time.perf_counter()-started}
(o/'preview2-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
