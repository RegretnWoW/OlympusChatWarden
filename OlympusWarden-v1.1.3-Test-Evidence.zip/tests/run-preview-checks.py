from pathlib import Path
import json,subprocess,sys,time,hashlib,os
o=Path(__file__).resolve().parent;r=o.parents[1];rows=[]
names=['test-release-113.py','test-preview2.py','test-dossier.py','test-relay-ui.py','test-hotfix-login.py','test-modules.py','test-module-isolation.py','test-module-collection.py','test-compact-panel.py','test-native-startup.py','test-closed-loading.py','test-startup-journal.py','test-archives.py','test-activities.py','test-intelligence.py','test-inspection-expansion.py','test-relay-transport.py','test-backup-tool.py','test-duels.py','test-scale-welcome.py']
for name in names:
 at=time.perf_counter();p=subprocess.run([sys.executable,'-X','utf8',str(o/name)],cwd=r,capture_output=True,text=True,encoding='utf-8',timeout=90,env={**os.environ,'WARDEN_TEST_WATCHDOG':'1'})
 (o/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8')
 rows.append({'suite':name,'exitCode':p.returncode,'seconds':time.perf_counter()-at});print(name,p.returncode,flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-4000:],flush=True)
 (o/'preview-suite-results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(x['exitCode']==0 for x in rows)
digest=hashlib.sha256()
for path in sorted((r/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(path.name.encode());digest.update(path.read_bytes())
(o/'preview-tests-source-sha256.txt').write_text(digest.hexdigest()+'\n')
