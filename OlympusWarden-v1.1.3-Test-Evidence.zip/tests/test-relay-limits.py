from pathlib import Path
import json,time
o=Path(__file__).resolve().parent
base=(o/'test-relay-transport.py').read_text();base=base[:base.index('start=time.perf_counter()')]
scope={'__file__':str(o/'test-relay-transport.py')};exec(compile(base,'isolated Relay fixtures','exec'),scope)
peer,check=scope['peer'],scope['check'];start=time.perf_counter()
l=peer('Reporter');l.execute(r'''
local S=ns.RelayStore
for n=1,200 do local r=assert(S.New());assert(S.Save(r.id,{module='relay',category='bug',title='Capacity '..n,description='Preserved original report '..n,steps=''})) end
capacityFirst=S.db.reports[1].id;capacityLast=S.db.reports[200].id
assert(not S.New());assert(#S.db.reports==200 and S.db.reports[1].id==capacityFirst and S.db.reports[200].id==capacityLast)
for n=1,20 do assert(S.Submit(S.db.reports[n].id,'')) end
assert(not S.Submit(S.db.reports[21].id,''));assert(S.db.reports[21].state=='draft')
local ok=S.Delete(S.db.reports[1].id,false);assert(not ok)
''')
check(True,'local and pending capacities refuse new work without eviction, and active report deletion is blocked')
b=peer('Olympus Wardn')
b.execute(r'''
local S,P=ns.RelayStore,ns.RelayTransport
for n=1,500 do
 local p={id='fixture-'..n,version='1.1.1-preview6',module='relay',category='bug',title='Original '..n,description='Independent report '..n,steps='',created='1800000000',diagnostics=''}
 local wire=assert(S.Encode(p));assert(S.Receive('fixture-classicbetapvp',p,wire,S.Checksum(wire)))
end
local p={id='fixture-overflow',version='1.1.1-preview6',module='relay',category='bug',title='Overflow',description='Must not evict reports.',steps='',created='1800000000',diagnostics=''}
local wire=assert(S.Encode(p));assert(not S.Receive('fixture-classicbetapvp',p,wire,S.Checksum(wire)))
assert(#S.db.inbox==500 and S.db.inbox[1].wire:find('Independent report 1',1,true))
local original=S.db.inbox[1].wire;assert(S.SetInboxState(S.db.inbox[1].key,'Fixed'));assert(S.db.inbox[1].wire==original)
''')
check(True,'full inbox refuses overflow and review state changes preserve original wire contents')
l=peer('Reporter');s=l.globals().ns.RelayStore
l.execute(r'''
local S=ns.RelayStore
local r=assert(S.New());assert(S.Save(r.id,{module='chronicle',category='recording',title='Long report',description=string.rep('d',3000),steps=string.rep('s',1600)}))
longID=r.id;assert(S.Submit(r.id,''))
''')
b=peer('Olympus Wardn');scope['drive'](l,b,90)
check(s.Find(l.globals().longID).state=='received','maximum description and steps transfer within the deadline')
b=peer('Olympus Wardn');b.execute(r'''
local P,S=ns.RelayTransport,ns.RelayStore
for n=1,2000 do
 local msg='H|1|flood-'..n..'|1|10|00000000'
 P.Handle('OWRelay1',msg,'WHISPER','Peer'..n..'-ClassicBetaPvP')
end
local count=0;for _ in pairs(P.incoming) do count=count+1 end
assert(count==4 and #P.outgoing<=48 and #S.db.inbox==0)
clock=clock+121;P.Pump();assert(next(P.incoming)==nil)
for n=1,1000 do P.Handle('OWRelay1',string.rep('x',n%241),'WHISPER','Unknown-ClassicBetaPvP') end
assert(#S.db.inbox==0)
''')
check(True,'incomplete-transfer flood and malformed messages stay bounded and expire without inbox writes')
l=peer('Reporter');l.execute(r'''
local S=ns.RelayStore;local r=assert(S.New());saved=OlympusWardenRelayDB
saved.reports[3]={id='hidden-original'};S.db=nil;S.Initialize()
assert(S.blocked and OlympusWardenRelayDB==saved and saved.reports[3].id=='hidden-original')
''')
check(True,'sparse or malformed saved arrays are retained for recovery instead of normalized destructively')
l=peer('Reporter');l.execute(r'''
local S=ns.RelayStore;local r=assert(S.New());r.fields.title='Privacy';r.fields.description='User text';r.fields.privateNote='DO_NOT_ATTACH';r.fields.history={secret='DO_NOT_ATTACH'}
local p=S.Payload(r,'');local wire=assert(S.Encode(p));assert(not wire:find('DO_NOT_ATTACH',1,true))
assert(S.Checksum('Wikipedia')=='11e60398')
''')
check(True,'field allowlist excludes unrelated data and integrity checksum matches an independent known vector')
l.execute(r'''
for n=1,25 do ns.RelayDiagnostics.Capture('Interface/AddOns/OlympusChatWarden/ChronicleLongFilename'..n..'.lua:999999999: private description') end
local snapshot=ns.RelayDiagnostics.Prepare();assert(#snapshot<=1800 and #ns.RelayDiagnostics.errors==20 and ns.RelayDiagnostics.Valid(snapshot))
''')
check(True,'maximum retained error locations still produce a bounded previewable diagnostic attachment')
result={'suite':'Relay capacity, long report and abuse bounds','assertions':scope['checks'],'failed':0,'nativeForever':False,'seconds':time.perf_counter()-start}
(o/'relay-limits-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
