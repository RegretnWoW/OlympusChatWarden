from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'duel-stress-host','exec'),scope)
lua=scope['lua'];lua.execute((out/'policy-fixture.lua').read_text());started=time.perf_counter()
lua.execute(r'''
local before=checks;local F,A,D=Preview5,ns.ChronicleActivities,ns.ChronicleDuels
F.Fresh();local guid='Player-Rival-STRESS';F.Observe(1,guid,'Historical Rival')
for n=1,5000 do
 local id=F.owner..'/duel/'..n;local at=n*10
 F.Native(at,'duel_session_request',{duelID=id,opponentGUID=guid,direction='outgoing',accepted=false},'control',guid)
 F.Native(at+1,'duel_session_start',{duelID=id,opponentGUID=guid,accepted=true},'DUEL_COUNTDOWN',guid)
 if n%3~=0 then F.Native(at+2,'duel_session_result',{duelID=id,opponentGUID=guid,accepted=true,resultKnown=true,result=n%3==1 and 'win' or 'loss'},'CHAT_MSG_SYSTEM',guid) end
 F.Native(at+3,'duel_session_end',{duelID=id,opponentGUID=guid,accepted=true,resultKnown=false},'DUEL_FINISHED',guid)
end
local st=A.Request(F.owner);check(not st,'large duel history begins cooperatively')
local loops,maxStep=0,0
while not st do local done=A.Progress();A.Pump();local after=A.Progress();maxStep=math.max(maxStep,after-done);loops=loops+1;st=A.Request(F.owner);assert(loops<100000) end
local h=D.History(st,guid)
check(h.total==5000 and h.wins==1667 and h.losses==1667 and h.unknown==1666,'all distinct outcomes preserved across five thousand sessions')
check(#h.rows==50 and h.rows[1].duel.id==F.owner..'/duel/5000','dossier recent-duel list bounded to newest fifty references')
check(#A.Query(st,{kind='duel_win',guid=guid,limit=50})==50,'verified victory filter uses distinct linked sessions')
check(#A.Query(st,{kind='duel_loss',guid=guid,limit=50})==50,'verified defeat filter works')
check(#A.Query(st,{kind='duel_unknown',guid=guid,limit=50})==50,'unknown filter remains separate')
check(maxStep<=128,'large duel rebuild obeys inherited record ceiling')
local ms=0;debugprofilestop=function() ms=ms+.1;return ms end
A.Clear();A.Request(F.owner);A.Pump();check(A.Progress()<128,'duel rebuild also obeys elapsed deadline');debugprofilestop=nil
local saved=ns.ChronicleBackup.Encode(F.c.events);local complete=F.Build()
for n=1,1000 do assert(D.History(complete,guid)==complete.duelPlayers[guid]) end
check(ns.ChronicleBackup.Encode(F.c.events)==saved,'derived head-to-head counters never rewrite the authoritative ledger')
-- A reload in the same recorder session still interrupts an open duel.
F.Fresh();local id=F.owner..'/duel/boundary'
F.Native(1,'duel_session_request',{duelID=id,opponentGUID=guid,direction='outgoing'},'control',guid)
F.Native(2,'duel_session_start',{duelID=id,opponentGUID=guid,accepted=true},'DUEL_COUNTDOWN',guid)
F.Emit('recording_start',3,{reason='ui-reload'},'PLAYER_ENTERING_WORLD')
F.Native(4,'duel_session_result',{duelID=id,opponentGUID=guid,accepted=true,resultKnown=true,result='win'},'CHAT_MSG_SYSTEM',guid)
st=F.Build();h=D.History(st,guid)
check(h.total==1 and h.unknown==1 and h.wins==0,'post-reload result cannot finish an interrupted older duel')
stressDuelChecks=checks-before;stressDuelLoops=loops;stressDuelMax=maxStep
''')
summary={'version':'1.1.0','assertions':int(lua.globals().stressDuelChecks),'sessions':5000,'recentDuelLimit':50,'maxRecordsPerBatch':int(lua.globals().stressDuelMax),'batches':int(lua.globals().stressDuelLoops),'failed':0,'seconds':round(time.perf_counter()-started,3),'liveWoWTested':False}
(out/'duel-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
