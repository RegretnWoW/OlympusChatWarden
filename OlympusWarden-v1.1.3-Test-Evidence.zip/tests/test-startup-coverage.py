from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'startup-coverage','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local Boot,B=ns.ChronicleStartup,ns.ChronicleBackup
freshRecording();local owner=C.Owner();local base=assert(B.PackSaved(S.db));base.duels=true;base.duelConsent=1
local function begin(source)
 ns.DB.chronicle=source;C.Initialize(true);Boot.Handle('PLAYER_ENTERING_WORLD');C.Handle('PLAYER_ENTERING_WORLD',false,true)
end
local function finish() local n=0;while S.loading do S.PumpLoad();n=n+1;assert(n<100000) end;while ns.ChronicleStartupJournal.Busy() do ns.ChronicleStartupJournal.Pump() end end
local function rows(kind) local out={};for _,e in ipairs(S.Character(owner,false).events) do if e.kind==kind then out[#out+1]=e end end;return out end
begin(base);local original=B.Encode(base);local at=C.Stamp();local tick=C.Tick();local oldZone=zone
Boot.Handle('QUEST_TURNED_IN',990101,500,200);Boot.Handle('QUEST_TURNED_IN',990101,500,200)
Boot.Handle('QUEST_ACCEPTED',990102);Boot.Handle('ACHIEVEMENT_EARNED',99101,false)
Boot.Handle('ENCOUNTER_START',99201,'Native Boss',1,5);Boot.Handle('ENCOUNTER_END',99201,'Native Boss',1,5,1)
Boot.Handle('PVP_MATCH_COMPLETE',1,300);Boot.Handle('DUEL_REQUESTED','Opponent name');Boot.Handle('DUEL_FINISHED')
check(Boot.diagnostics.captured==8 and B.Encode(base)==original,'consented payloads buffer without writing unvalidated input; duplicate turn-in coalesces')
clock=clock+20;zone='Different place';units.target={guid='Player-Wrong-NEW',name='Later target'};finish()
local found;for _,e in ipairs(rows('quest_turnin')) do if e.details.questID==990101 then found=e end end
check(found and found.at==at and found.elapsed==tick and found.location.zone==oldZone,'startup quest keeps event-time clock and location, never later state')
check(Boot.diagnostics.merged==8 and B.Encode(base)==original,'all eligible buffered records merge after atomic validation')
local function startupGap() local found;for _,e in ipairs(rows('collection_gap')) do if e.details.reason:find('Startup coverage',1,true) then found=e end end;return found end
local gap=startupGap();check(gap and gap.details.reason:find('partial',1,true),'unsupported startup routes/inspection/full duel sessions are explicitly recorded as a coverage gap')
local native=rows('native_event');local known=false;for _,e in ipairs(native) do if e.details.recordType=='duel_finished' then known=e.details.resultKnown==false end end
check(known,'startup duel delivery never invents a winner or combat/gear history')
local noConsent=assert(B.PackSaved(S.db));noConsent.enabled=false;begin(noConsent);Boot.Handle('QUEST_TURNED_IN',990103);finish()
check(Boot.diagnostics.captured==0 and Boot.diagnostics.merged==0,'opted-out recording never buffers')
local access=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end
ns.DB.chronicle=base;C.Initialize(true);Boot.Handle('PLAYER_ENTERING_WORLD')
ns.Membership.Allowed=access;C.promptReady=true;finish()
local unknown=startupGap();check(unknown and unknown.details.reason:find('unknown',1,true) and not unknown.details.firstAt,'late access retains an honest unknown coverage marker without inventing a start time')
base.enabled=true;base.duels=false;base.duelConsent=nil;begin(base);Boot.Handle('DUEL_REQUESTED','Opponent');Boot.Handle('DUEL_FINISHED');finish()
check(Boot.diagnostics.captured==0,'startup duel data requires separate valid duel consent')
ns.DB.enabled=false;begin(base);Boot.Handle('ACHIEVEMENT_EARNED',99997);ns.DB.enabled=true;finish()
check(Boot.diagnostics.captured==1 and startupGap()~=nil,'Chat pause cannot disable consented historical startup preservation')
begin(base);for n=1,1500 do Boot.Handle('ACHIEVEMENT_EARNED',990000+n) end
check(Boot.diagnostics.captured<=Boot.LIMIT and Boot.diagnostics.overflow>0,'temporary startup queue is strictly bounded and reports overflow')
finish();gap=startupGap();check(gap and gap.details.samples>0,'overflow survives as an explicit historical coverage gap')
local damaged=assert(B.PackSaved(S.db));damaged.characters[owner].eventChunks[#damaged.characters[owner].eventChunks]='broken'
local encoded=B.Encode(damaged);begin(damaged);Boot.Handle('ACHIEVEMENT_EARNED',99999);finish()
check(S.blocked and not S.db and ns.DB.chronicle==damaged and B.Encode(damaged)==encoded and ns.ChronicleStartupJournal.Count()==1,'failed validation retains staged observations separately and preserves the original archive')
begin(base);Boot.Handle('ACHIEVEMENT_EARNED',99998);C.Handle('PLAYER_LOGOUT')
check(S.blocked and ns.DB.chronicle==base and ns.ChronicleStartupJournal.Count()==2,'logout during validation preserves input and both deferred observation windows')
ns.DB.enabled=true;ns.DB.chronicle=base;C.Initialize();C.SetEnabled(false);startupCoverageChecks=checks-before
''')
result={'version':'1.1.1-preview8','failed':0,'assertions':lua.globals().startupCoverageChecks,'boundedRecords':1024,'boundedStructuralBytes':524288,'fullStartupCoverage':False,'partialCoverageReported':True,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'startup-coverage-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
