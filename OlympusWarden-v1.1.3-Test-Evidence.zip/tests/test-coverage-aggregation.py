from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'coverage-host','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local V,X,B=ns.ChronicleCoverage,ns.ChronicleCapture,ns.ChronicleBackup
freshRecording();for n=1,300 do X.Pump() end;V.Clear()
local initial=#all('collection_gap');for n=1,1000 do V.Note('Score reader','unavailable','No readable native rows') end
check(V.Pending()==1 and #all('collection_gap')==initial,'repeated failures aggregate in bounded transient interval')
local at=C.Stamp();clock=clock+31;V.Flush(false);local rows=all('collection_gap');local e=rows[#rows]
check(#rows==initial+1 and e.details.count==1000 and e.details.firstAt==at and e.details.lastAt==at,'one durable interval preserves failure count and actual first/last occurrence')
for n=1,200 do V.Note('Collector '..n,'failed','Typed source unavailable') end
check(V.Pending()<=32,'coverage categories have strict runtime bound');V.Flush(true)
local overflow=false;for _,row in ipairs(all('collection_gap')) do if row.details.family=='Additional collectors' and row.details.count>1 then overflow=true end end
check(overflow,'overflow sources are aggregated without storing raw payloads')
V.Clear();for n=1,210 do X.Queue('saturation-fixture:'..n,function() end) end
V.Flush(true);local found=false;for _,row in ipairs(all('collection_gap')) do if row.details.family=='Enrichment' and row.details.coverage=='saturated' then found=true end end
check(found,'bounded enrichment overflow is persistent rather than only diagnostic')
for n=1,300 do X.Pump() end
X.Queue('failure-fixture',function() error('private source payload must never be serialized') end);X.Pump();V.Flush(true)
local encoded=B.Encode(S.Character(C.Owner(),false).events)
check(encoded:find('A detail task failed',1,true) and not encoded:find('private source payload',1,true),'failed coroutine records generic gap without serializing error or player payload')
V.Note('Fixture','partial','Partial source evidence');C.SetEnabled(false)
check(V.Pending()==0,'recording boundary flushes and clears pending coverage')
initial=#all('collection_gap');V.Note('Disabled','failed','No consent');V.Flush(true)
check(#all('collection_gap')==initial and V.Pending()==0,'unconsented periods are not monitored')
coverageChecks=checks-before
''')
result={'version':'1.1.0','assertions':int(lua.globals().coverageChecks),'failed':0,'categoryLimit':32,'aggregateIntervalSeconds':30,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'coverage-aggregation-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
