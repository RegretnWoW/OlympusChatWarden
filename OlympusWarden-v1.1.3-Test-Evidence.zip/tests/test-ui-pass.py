from pathlib import Path
import json,time
o=Path(__file__).resolve().parent;r=o.parents[1];started=time.perf_counter()
h={'__file__':str(o/'test-preview5-talents.py')};exec(compile((o/'test-preview5-talents.py').read_text(),'native talent and inspection host','exec'),h);l=h['lua']
native=(o/'research/Blizzard_SharedXML--Mainline--SharedUIPanelTemplates.lua').read_text()
l.execute(native[native.index('SidePanelTabButtonMixin ='):native.index('function SidePanelTabButtonMixin:SetTabGlowAnimationPlaying')])
l.execute(r'''
local before=checks;local L,T,G,X,B=ns.WardenLaunchers,ns.WardenTalents,ns.WardenDossier,ns.ChronicleCapture,ns.ChronicleBackup
local m=getmetatable(UIParent).__index
function m:SetAtlas(atlas,useSize) self.atlas=atlas;self.useAtlasSize=useSize end
function m:SetDesaturated(value) self.desaturated=value end
C_Texture={GetAtlasInfo=function() return {width=64,height=69} end}
GetAppropriateTooltip=function() return GameTooltip end
SOUNDKIT=SOUNDKIT or {};SOUNDKIT.IG_CHARACTER_INFO_TAB=1;PlaySound=PlaySound or function() end
local nativeCreate=CreateFrame
function CreateFrame(kind,name,parent,template)
 local f=nativeCreate(kind,name,parent,template)
 if template=='LargeSideTabButtonTemplate' then
  for k,v in pairs(SidePanelTabButtonMixin) do f[k]=v end
  f.Icon=f:CreateTexture(nil,'ARTWORK');f.SelectedTexture=f:CreateTexture(nil,'OVERLAY');f:OnLoad()
  f:SetScript('OnMouseDown',f.OnMouseDown);f:SetScript('OnMouseUp',f.OnMouseUp)
 end
 return f
end
function m:GetHorizontalScroll() return self.hs or 0 end;function m:SetHorizontalScroll(value) self.hs=value end
function m:CreateLine() return CreateFrame('Line',nil,self) end
function m:SetStartPoint(point,parent,x,y) assert(type(parent)=='table' and type(x)=='number' and type(y)=='number');self.from={x,y} end
function m:SetEndPoint(point,parent,x,y) assert(type(parent)=='table' and type(x)=='number' and type(y)=='number');self.to={x,y} end
function m:SetThickness(value) self.thickness=value end
check(ns.DB.shopLauncher==false and ns.DB.inspectLauncher==false and ns.DB.wardenMinimap==false,'all native launchers start off for existing installs')
local filter=ns.CanRead;local secrets={};local oldSecret=issecretvalue
issecretvalue=function(v) return secrets[v]==true end
local label=CreateFrame('FontString',nil,UIParent);label.text='unreadable initial';secrets[label.text]=true
ns.TrackRegion(label,'tooltips',nil,nil,{tooltip=true,preserveAlpha=true})
check(ns.RegionOriginal(label)==nil,'first secret string is never retained or returned as original text')
label:SetText('Public tooltip');check(ns.RegionOriginal(label)=='Public tooltip','secret-to-public SetText recovers without comparing a cached secret')
secrets['Public tooltip']=true;label:SetText('New public tooltip');check(ns.RegionOriginal(label)=='New public tooltip','previously cached value is rechecked before comparison')
label.text='native secret refresh';secrets[label.text]=true;ns.TrackRegion(label,'tooltips',nil,nil,{tooltip=true,preserveAlpha=true})
check(ns.RegionOriginal(label)==nil and not ns.RegionBindingCurrent(label),'native C-style text replacement clears unsafe binding')
label:SetText('Readable again');check(ns.RegionBindingCurrent(label),'binding recovers after repeated secret/public reuse')
issecretvalue=oldSecret
ns.Workspace.Open('overview');local home=ns.Workspace.pages.overview
check(home.chronicle==nil and home.intel==nil,'redundant header shortcuts are removed')
ns.Workspace.Open('settings');local settings=ns.Workspace.pages.settings
check(settings.shopLauncher and settings.inspectLauncher and settings.wardenMinimap,'all three options appear in CommandWarden shared settings')
StoreMicroButton=CreateFrame('Button',nil,UIParent);StoreMicroButton:SetSize(30,36)
local nativeClicks=0;local native=function() nativeClicks=nativeClicks+1 end;StoreMicroButton:SetScript('OnClick',native)
L.Set('shopLauncher',true);check(L.shop and L.shop:IsShown() and StoreMicroButton:GetScript('OnClick')==native,'shop overlay preserves original native handler and geometry')
click(L.shop);check(ns.Workspace.current=='overview' and nativeClicks==0,'shop shortcut opens CommandWarden without clicking the shop')
L.Set('shopLauncher',false);check(not L.shop:IsShown(),'turning replacement off immediately restores original shop hit target')
local combat=InCombatLockdown;InCombatLockdown=function() return true end;L.Set('shopLauncher',true)
check(L.deferred and not L.shop:IsShown(),'protected-parent changes defer in combat')
InCombatLockdown=combat;ev('PLAYER_REGEN_ENABLED');check(L.shop:IsShown(),'deferred option applies after combat');L.Set('shopLauncher',false)
Minimap=CreateFrame('Frame',nil,UIParent);Minimap:SetSize(140,140)
function m:RegisterForDrag(...) self.dragButtons={...} end
function m:GetCenter() return 400,300 end
L.Set('wardenMinimap',true)
check(L.minimap and L.minimap:IsShown() and L.minimap.icon.texture==L.shop.icon.texture,'minimap shortcut shares subdued shop emblem in its own native circle')
click(L.minimap);check(ns.Workspace.current=='overview','minimap left click opens CommandWarden')
click(L.minimap,'RightButton');check(ns.Workspace.current=='settings','minimap right click opens settings')
GetCursorPosition=function() return 500,300 end
L.minimap:GetScript('OnDragStart')();L.minimap:GetScript('OnUpdate')()
check(ns.DB.wardenMinimapAngle==0,'dragging saves angle around the minimap')
L.minimap:GetScript('OnDragStop')();check(not L.minimap:GetScript('OnUpdate'),'drag work stops on release')
L.Set('wardenMinimap',false);check(not L.minimap:IsShown() and not L.minimap:GetScript('OnUpdate'),'disabled minimap shortcut is hidden with no active drag worker')
units.target={guid='Player-Shortcut-NEW',name='Shortcut Friend',class='MAGE',race='Human',level=60};freshRecording();clock=clock+600
local guid=units.target.guid
check(not C.Profile(guid),'new shortcut target starts with no retained profile')
check(L.OpenIntel('target',true) and InspectFrame.unit=='target','explicit shortcut opens actual Blizzard Inspect for a new player')
ev('INSPECT_READY',guid)
for n=1,100 do step(.02) end
check(C.Profile(guid) and ns.Workspace.current=='intel' and ns.Workspace.pages.intel.selected==guid,'new response opens its exact Intel dossier')
L.Set('inspectLauncher',true);L.Refresh()
check(L.inspect and L.inspect:IsShown() and L.inspect.guid==guid,'optional inspection button uses the native inspected unit GUID')
units.target.guid='Player-Changed-SHORTCUT';local selected=ns.Workspace.pages.intel.selected
L.inspect:GetScript('OnMouseUp')(L.inspect,'LeftButton',true);drain();check(ns.Workspace.pages.intel.selected==selected,'inspection button rejects a recycled unit before navigation')
units.target.guid=guid;L.Set('inspectLauncher',false);check(not L.inspect:IsShown(),'inspection button hides again when disabled')
InspectFrame:Hide();units.target={guid='Player-Geometry-ONE',name='Tree Friend',class='MAGE',level=60};freshRecording();clock=clock+600;guid=units.target.guid
Constants={TraitConsts={INSPECT_TRAIT_CONFIG_ID=-1}}
local partial=false;local calls=0
C_Traits={HasValidInspectData=function() return true end,GenerateInspectImportString=function() return 'ExactNativeExport' end,
 GetConfigInfo=function(config) assert(config==-1);return {ID=config,treeIDs={700}} end,
 GetTreeNodes=function() local out={};for n=101,112 do out[#out+1]=n end;return out end,
 GetGroupDisplayInfoByTreeID=function() return {{groupID=1,treeID=700,displayName='Arcane',orderIndex=1},{groupID=2,treeID=700,displayName='Fire',orderIndex=2},{groupID=3,treeID=700,displayName='Frost',orderIndex=3}} end,
 GetNodeInfo=function(config,id)
  calls=calls+1;local n=id-101;local group=math.floor(n/4)+1;local rank=(id==101 or id==105) and 2 or 0
  return {ID=id,posX=(group-1)*420,posY=(n%4)*90,maxRanks=3,type=0,isVisible=true,groupIDs={group},entryIDs={id+1000},
   visibleEdges=n%4<3 and {{targetNode=id+1,type=1,visualStyle=1,isActive=false}} or {},currentRank=rank,
   activeEntry=rank>0 and {entryID=id+1000,rank=rank} or nil} end,
 GetEntryInfo=function(config,entry) return {definitionID=entry+1000,type=1} end,
 GetDefinitionInfo=function(id) return {spellID=id+1000} end}
C_Spell={GetSpellInfo=function(id) return {spellID=id,name='Talent '..id,iconID=888} end}
C_SpecializationInfo={GetInspectSpecialization=function() return 1491 end}
local function inspect() clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);return all('important_player')[#all('important_player')] end
local e=inspect();local traits=X.Find(C.Owner(),e.details.traitRef);local values=traits.capture.values
check(values.layoutRefs and #values.layoutRefs==2 and #values.choices==2,'full native tree is stored in bounded content-deduplicated chunks alongside dated selections')
local layouts=0;for _,v in ipairs(all('native_snapshot')) do if v.capture.values.layoutTree then layouts=layouts+1 end end
local again=inspect();local now=0;for _,v in ipairs(all('native_snapshot')) do if v.capture.values.layoutTree then now=now+1 end end
check(now==layouts and again.details.traitRef==e.details.traitRef,'repeated inspection reuses unchanged tree geometry and build objects')
local job=G.Request(C.Owner());while not job.done do G.Pump(job) end
local p=G.BuildTalents(UIParent);p:Show();p:SetProfile(C.Owner(),{id=guid,title='Tree Friend'});for n=1,30 do p.scripts.OnUpdate(p) end
check(p.tree:IsShown() and not p.choicesScroll:IsShown(),'full graph replaces card list when native geometry is recorded')
local shown=0;local zero=0;local selectedRanks=0
for _,node in ipairs(p.tree.nodes) do if node:IsShown() then shown=shown+1;if node.rankText=='0/3' then zero=zero+1 elseif node.rankText=='2/3' then selectedRanks=selectedRanks+1 end end end
check(shown==12 and zero==10 and selectedRanks==2,'tree includes all native nodes, confirmed unselected ranks and exact saved ranks')
check(#p.tree.lines==9 and #p.tree.headers==3,'native prerequisite connections and three branch headings are presented')
check(p.tree.trees[1].nodes[101][2]==0 and p.tree.trees[1].nodes[105][2]==420,'separate branches retain exact native horizontal positions')
local callsBefore=calls;p:Render();check(calls==callsBefore,'historical rendering makes no native config or inspection reads')
local refs=values.layoutRefs;local missing=job.objects[refs[1]];job.objects[refs[1]]=nil;p:Render()
check(not p.tree:IsShown() and p.choicesScroll:IsShown(),'incomplete restored geometry falls back to known selected talents')
job.objects[refs[1]]=missing
local clone={};for k,v in pairs(values) do clone[k]=v end;clone.choicesComplete=false
check(p.tree:Present(clone,job.objects,'fixture observation'),'partial selection can use exact recorded geometry')
local unknown=0;for _,node in ipairs(p.tree.nodes) do if node:IsShown() and node.rankText=='?/3' then unknown=unknown+1 end end
check(unknown==10,'partial inspection never presents missing ranks as confirmed zero')
local node=missing.capture.values.layoutNodes[1];local old=node[2];node[2]='invalid'
check(not T.Validate(missing.capture.values),'malformed historical coordinates are rejected');node[2]=old
local reads=calls;C.SetEnabled(false);local backup=assert(B.Create());local ref=e.details.traitRef
for _,part in ipairs(backup.parts) do check(B.Validate(part)~=nil,'text backup validates each layout-containing part independently') end
C.Clear();for n=#backup.parts,1,-1 do check(B.Restore(backup.parts[n])==true,'out-of-order full text restore retains optional tree evidence') end
job=G.Request(C.Owner());while not job.done do G.Pump(job) end
local restored=X.Find(C.Owner(),ref);local trees=T.Projection(restored.capture.values,job.objects)
check(trees and #trees==1 and calls==reads,'full saved tree rebuilds offline after backup/restore without scanning a player')
check(S.VERSION==6 and S.CONSENT==5 and not C.Active(),'saved identity, consent and pause state are retained')
uiPassChecks=checks-before
''')
result={'version':'1.1.3-preview2','assertions':int(l.globals().uiPassChecks),'failed':0,'nativeClient':False,'secretValues':'unreadable-value simulation; native secret-string engine remains a client retest','talents':'native positions, edges, branches, ranks, deduplication, partial and missing evidence, backup/restore','seconds':time.perf_counter()-started}
(o/'ui-pass-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
