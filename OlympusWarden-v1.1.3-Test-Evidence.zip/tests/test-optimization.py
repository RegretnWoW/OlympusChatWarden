from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'performance-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.globals().oldStore=(out/'preview5-baseline/OlympusChatWarden/ChronicleStore.lua').read_text(encoding='utf-8')
lua.globals().oldBackup=(out/'preview5-baseline/OlympusChatWarden/ChronicleBackup.lua').read_text(encoding='utf-8')
lua.execute(r'''
local before=checks;local B,A,I,G,Q,P=ns.ChronicleBackup,ns.ChronicleActivities,ns.ChronicleIntelligence,ns.WardenDossier,ns.WardenSearch,ns.WardenPerformance
freshRecording();units.target={guid='Player-Perf-ONE',name='Perf Friend',class='MAGE',level=60};C.ObserveUnit('target','PLAYER_TARGET_CHANGED',true)
local owner=C.Owner();local c=S.Character(owner,false)
for n=1,1500 do
 clock=clock+1;C.Record(n%10==0 and 'quest_turnin' or 'player_state',n%10==0 and 'QUEST_TURNED_IN' or 'checkpoint',
  n%10==0 and {questID=n,rewardXP=100} or {afk=false})
end
local X=ns.ChronicleCapture;local guid=units.target.guid
local slots={};for n=1,19 do slots[n]={n,'empty',false,false} end;slots[5]={5,'present',1001,'item:1001:123:0:-4'}
local gear=assert(X.Store('gear',{guid=guid,slots=slots},'INSPECT_READY'))
local talents=assert(X.Store('traits',{guid=guid,exportString='Original_Native_Export',specializationID=1491,
 choices={{700,101,1101,2,2101,3101}},choicesComplete=true,nodesRead=1,nodesTotal=1},'INSPECT_READY'))
X.Record('important_player','INSPECT_READY',{relationship='manual inspection',gearRef=gear,gearObservedAt=C.Stamp(),traitRef=talents,traitObservedAt=C.Stamp()},guid,false)
for n=1,20 do X.Store('scoreboard',{guid=guid,name='Perf Friend',runID='report-not-match',matchSequence=1,rowIndex=1,killingBlows=n,deaths=0},'UPDATE_BATTLEFIELD_SCORE') end
check(C.SetPersonal(guid,'Private performance fixture',true),'private notes and watch state saved in fixture')
local authoritative=B.Encode(S.db.characters);local raw=c.events;local rawCount=#raw
local oldNS=setmetatable({},{__index=ns});assert(loadstring(oldStore))('OlympusChatWarden',oldNS);assert(loadstring(oldBackup))('OlympusChatWarden',oldNS)
local packed=assert(B.PackSaved(S.db));local previous=assert(oldNS.ChronicleBackup.PackSaved(S.db))
check(B.Encode(packed)==B.Encode(previous),'optimized saving emits byte-identical bounded chunks for the same ledger')
local clean=assert(S.Normalize(packed));local prior=assert(oldNS.ChronicleStore.Normalize(packed))
check(B.Encode(clean)==B.Encode(prior),'streaming load exactly matches the Preview 5 canonical normalized database')
check(c.events==raw and B.Encode(S.db.characters)==authoritative,'normalization never mutates the authoritative input')
local savedEncoding=B.Encode(packed);local decode=B.DecodeChunk;local weak=setmetatable({},{__mode='v'});local index,aliveMax=0,0
B.DecodeChunk=function(text)
 collectgarbage('collect');local alive=0;for _ in pairs(weak) do alive=alive+1 end;aliveMax=math.max(aliveMax,alive)
 local records=decode(text);if records then index=index+1;weak[index]=records end;return records
end
check(S.Normalize(packed)~=nil and aliveMax<=1,'temporary chunk containers can be reclaimed while validated records become authoritative without a second retained copy')
B.DecodeChunk=decode
check(B.Encode(packed)==savedEncoding,'streaming validation keeps every original packed byte unchanged')
for _,position in ipairs({1,math.ceil(#packed.characters[owner].eventChunks/2),#packed.characters[owner].eventChunks}) do
 local bad=assert(B.PackSaved(S.db));bad.characters[owner].eventChunks[position]='invalid chunk';local snapshot=B.Encode(bad)
 check(not S.Normalize(bad) and B.Encode(bad)==snapshot,'corrupt early/middle/late chunks reject atomically without consuming recovery data')
end
local interrupted=0;B.DecodeChunk=function(text) interrupted=interrupted+1;if interrupted==3 then error('synthetic interruption') end;return decode(text) end
local ok=pcall(S.Normalize,packed);B.DecodeChunk=decode
check(not ok and B.Encode(packed)==savedEncoding and c.events==raw,'interrupted load leaves both packed input and live ledger intact')
local unknown={schema=7,characters=packed.characters};check(not S.Normalize(unknown) and unknown.characters==packed.characters,'unknown future schema is never destructively migrated')
local reload=packed
for n=1,3 do reload=assert(B.PackSaved(assert(S.Normalize(reload)))) end
check(B.Encode(S.Normalize(reload))==B.Encode(clean),'three save/reload cycles preserve canonical events, profiles, gear, talents and reports')
-- A fake monotonic clock makes batch expiry deterministic.
local ms=0;debugprofilestop=function() ms=ms+.04;return ms end
A.Clear();A.Request(owner);A.Pump();local done,total=A.Progress()
check(done>0 and done<128 and total==rawCount,'history yields on elapsed deadline before its record ceiling')
local loops=0;local st
repeat A.Pump();st=A.Request(owner);loops=loops+1;assert(loops<10000) until st
check(st.intelligence.events==st.events,'activity and Intel share one event lookup without copying records')
check(I.Player(st,guid).tier==1 and #I.Player(st,guid).scoreReports==1 and not I.Player(st,guid).confirmedKillingBlows,'tiers and report-refresh uncertainty survive the optimized index')
local profile=I.Player(st,guid);check(profile.watch and profile.note=='Private performance fixture','profile annotations are preserved')
local j=Q.Begin('quest');local processed=j.processed;Q.Pump(j);check(j.processed-processed<128 and not j.done,'suite search obeys elapsed deadline')
local dossier=G.Request(owner);local cursor=dossier.cursor;G.Pump(dossier);check(dossier.cursor-cursor<128,'dossier indexing obeys elapsed deadline')
local combat=InCombatLockdown;InCombatLockdown=function() return true end;cursor=dossier.cursor;G.Pump(dossier);check(dossier.cursor==cursor,'combat still pauses indexing');InCombatLockdown=combat
check(not P.active and next(P.stats)==nil,'profiling is off and stores no measurements by default')
P.Slash('start');A.Clear();A.Request(owner);A.Pump();check(P.active and P.stats['history index'].calls==1,'opt-in profiling records a bounded aggregate')
P.Slash('stop');check(not P.active and next(P.stats)==nil,'stopping profiling releases session measurements without writing saved telemetry')
debugprofilestop=nil
local function build(who)
 local state;repeat A.Pump();state=A.Request(who) until state;return state
end
st=build(owner)
for n=1,4 do
 local who='Perf Realm/Player-Cache-'..n;local character=S.Character(who,true);character.currentSession=who..'/s1';character.sessionSequence=1
 S.Append(who,{kind='quest_turnin',at=1800000000+n,elapsed=n,source='QUEST_TURNED_IN',session=character.currentSession,timeSource='server',evidence='observed',location={},details={questID=n}})
 build(who);local count=0;for _ in pairs(A.caches) do count=count+1 end;check(count<=2,'derived character LRU stays bounded while all original characters remain saved')
end
check(#S.Character(owner,false).events==rawCount and build(owner).processed==rawCount,'evicted indexes rebuild from complete original history')
-- Hidden pages relinquish projections, with IDs and user choices retained.
ns.Workspace.Open('intel');local p=ns.Workspace.pages.intel;p.owner=owner;p.mode='all';p.selected=guid;p:Activate();p:Refresh(true)
local row=p.rows;for n=1,5 do p:Refresh(true) end;check(p.rows==row,'unchanged selection/page refresh reuses the player result array')
local selected=p.selected;p:Hide();check(not p.state and not p.rowState and not p.rows and #p.list.items==0 and p.selected==selected,'hidden Intel page releases projections while retaining selection ID')
for _,r in ipairs(p.list.rows) do check(not r.item,'hidden virtual rows retain no original player record') end
p:Show();p:Activate();p:Refresh(true);check(p.selected==guid and p.currentRow.id==guid,'reopening restores the exact dossier from retained history')
local stats=ns.WardenUI.PlayerStats(p.state);check(stats.watch>=1,'cached statistics retain watch membership')
C.SetPersonal(guid,nil,false);check(ns.WardenUI.PlayerStats(p.state).watch==stats.watch-1,'private annotation edits invalidate cached statistics')
local refresh=p.Refresh;local hiddenRefresh=0;p.Refresh=function(...) hiddenRefresh=hiddenRefresh+1;return refresh(...) end
ns.Workspace.window:Hide();ns.Workspace.Refresh();check(hiddenRefresh==0,'closed Warden ignores queued full-page refreshes');p.Refresh=refresh
local compact=CreateFrame('Frame',nil,UIParent);compact:SetSize(326,360);compact:Show();ns.OlympusPanel.Build(compact)
local compactRefresh=ns.OlympusPanel.Refresh;local panelCalls=0;ns.OlympusPanel.Refresh=function(...) panelCalls=panelCalls+1;return compactRefresh(...) end
compact.IsVisible=function() return false end;ns.OlympusPanel.Queue();drain();check(panelCalls==0,'Olympus parent-hidden surfaces do not refresh through queued activity notifications')
ns.OlympusPanel.Refresh=compactRefresh
local made=0;local list=ns.Art.ScrollingList(UIParent,0,0,200,150,50,function(parent) made=made+1;return CreateFrame('Button',nil,parent) end,function(row,item) row.item=item end)
list:SetItems({});check(made==0,'an empty virtual list allocates no unused row widgets')
list:SetItems({{id='one'},{id='two'}});check(made==2,'only rows with data allocate reusable widgets')
list:SetItems({});check(made==2 and not list.rows[1].item,'clearing releases bound records without allocating replacement rows')
local Btext;C.SetEnabled(false);Btext=assert(B.Create());for _,part in ipairs(Btext.parts) do check(B.Validate(part)~=nil,'standard backups validate all optimized evidence') end
check(S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'schema, consent and protected-event safeguards retained')
optimizationChecks=checks-before;decodedChunks=index;maxDecodedAlive=aliveMax
''')
summary={'version':'1.1.0','assertions':lua.globals().optimizationChecks,'failed':0,'packedBytesMatchPreview5':True,'canonicalNormalizationMatchesPreview5':True,'decodedChunks':lua.globals().decodedChunks,'maxPriorDecodedRecordsAlive':lua.globals().maxDecodedAlive,'liveWoWTested':False,'seconds':round(time.perf_counter()-started,3)}
(out/'optimization-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
