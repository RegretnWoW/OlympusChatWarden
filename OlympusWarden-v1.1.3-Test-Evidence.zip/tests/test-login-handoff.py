from pathlib import Path
import json
o=Path(__file__).resolve().parent;r=o.parents[1]
h={'__file__':str(r/'.work/v111-release/smoke.py')};exec(compile((r/'.work/v111-release/smoke.py').read_text(),'login host','exec'),h);l=h['lua']
l.execute(r'''
local M=ns.Modules
freshRecording();local original=assert(ns.ChronicleBackup.PackSaved(S.db))
-- The native event dispatcher can snapshot its recipients before invoking
-- handlers. Registration during a callback cannot recover that same event.
function nativeEvent(event,...)
 local handlers={}
 for _,f in ipairs(frames) do if f.events and f.events[event] and f.scripts.OnEvent then handlers[#handlers+1]={f,f.scripts.OnEvent} end end
 for _,entry in ipairs(handlers) do entry[2](entry[1],event,...) end
 drain()
end
member=false;ns.OlympusConnection.Invalidate();ns.Membership.Refresh();M.Reconcile()
M.worldReady=nil;ns.DB.chronicle=original;ns.Initialize();drain()
assert(not ns.Membership.Allowed(),'permission is unresolved before world entry')
-- Access resolves during the always-on Core world-entry callback, after the
-- recorder was excluded from this event's original recipient list.
member=true;ns.OlympusConnection.Invalidate();nativeEvent('PLAYER_ENTERING_WORLD',true,false)
local pumps=0;while S.loading do S.PumpLoad();pumps=pumps+1;assert(pumps<10000) end
local c=ledger();local before=c and #c.events or 0
units.target={guid='Player-Login-New',name='Login Friend',realm='Test Realm',class='MAGE',level=15}
nativeEvent('PLAYER_TARGET_CHANGED');nativeEvent('QUEST_TURNED_IN',987655,30,40)
local found=false;for _,e in ipairs(c.events) do if e.kind=='quest_turnin' and e.details.questID==987655 then found=true end end
proof={active=C.Active(),status=C.Status(),worldRemembered=M.worldReady==true,permission=ns.Membership.Allowed(),loading=S.loading,eventCountBefore=before,eventCountAfter=#c.events,newProfile=c.profiles['Player-Login-New']~=nil,questRecorded=found}
''')
result=dict(l.globals().proof.items());print(json.dumps(result,indent=2));(o/'login-handoff-before.json').write_text(json.dumps(result,indent=2)+'\n')
