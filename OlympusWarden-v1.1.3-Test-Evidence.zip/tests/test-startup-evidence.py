from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'startup-evidence-host','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local Boot,B=ns.ChronicleStartup,ns.ChronicleBackup
freshRecording();local owner=C.Owner();local source=assert(B.PackSaved(S.db))
local function begin(base) ns.DB.chronicle=base;C.Initialize(true);Boot.Handle('PLAYER_ENTERING_WORLD');C.Handle('PLAYER_ENTERING_WORLD',false,true) end
local function finish() for n=1,100000 do if not S.loading then return end;S.PumpLoad() end;error('load deadline') end
begin(source);local original=B.Encode(source);local at=C.Stamp();local tick=C.Tick();local originalZone=zone
local payload={{creatureID=888,creatureName='Startup Boss',remainingHealthPercent=12.5}}
Boot.Handle('ENCOUNTER_END',998,'Startup encounter',1,5,0,payload)
Boot.Handle('QUEST_LOOT_RECEIVED',990,'item:555',2);Boot.Handle('QUEST_CURRENCY_LOOT_RECEIVED',990,22,5)
Boot.Handle('ENCOUNTER_LOOT_RECEIVED',998,555,'item:555',1)
payload[1].creatureName='Later name';clock=clock+15;zone='Later zone';finish()
check(Boot.diagnostics.merged==5 and B.Encode(source)==original,'new native rows buffer and merge without mutating unvalidated history')
local parent,child,item,currency,loot
for _,e in ipairs(S.Character(owner,false).events) do
 if e.details.recordType=='encounter_ended' and e.details.encounterID==998 then parent=e
 elseif e.details.recordType=='boss_status_observed' and e.details.encounterID==998 then child=e
 elseif e.details.recordType=='quest_item_received' then item=e
 elseif e.details.recordType=='quest_currency_received' then currency=e
 elseif e.details.recordType=='encounter_loot_delivery' then loot=e end
end
check(child and child.details.encounterRef==parent.id and child.details.creatureName=='Startup Boss','startup boss copy retains its original identity and validated parent ID')
check(item and currency and loot and item.at==at and child.at==at and item.elapsed==tick and child.location.zone==originalZone,'new startup records retain actual clocks/place rather than later world state')
check(loot.details.scope=='recipient unknown' and not loot.subject,'startup merge does not upgrade unknown loot recipient')
local saved=assert(B.PackSaved(S.db));local clean=assert(S.Normalize(saved))
check(B.Encode(clean.characters[owner].events)==B.Encode(S.Character(owner,false).events),'new startup evidence and parent references survive save/reload')
source.enabled=false;begin(source);Boot.Handle('QUEST_LOOT_RECEIVED',990,'item:555',2);finish()
check(Boot.diagnostics.captured==0,'startup receipts require current independent prior consent')
startupEvidenceChecks=checks-before
''')
result={'version':'1.1.0','assertions':int(lua.globals().startupEvidenceChecks),'failed':0,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'startup-evidence-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
