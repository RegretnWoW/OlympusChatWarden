from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(),'recorder-baseline','exec'),state)
lua=state['lua'];before=lua.globals().checks
lua.execute(r'''
B,R=ns.ChronicleBackup,ns.RecordingUI
function button(text,parent)
 for _,f in ipairs(frames) do
  if f:GetObjectType()=='Button' and f.GetText and f:GetText()==text and (not parent or f:GetParent()==parent) then return f end
 end
end
function envelope(data)
 local raw=B.Encode(data);return 'OCW-HISTORY-1:'..ns.PackCrypto.Hex(ns.PackCrypto.SHA256(raw))..'\n'..ns.PackCrypto.Base64Encode(raw)
end
function dataOf(text)
 local data=assert(B.Validate(text));data.clean=nil;data.partHash=nil;return data
end
check(forbiddenRegistrations==0 and registrationAttempts.COMBAT_LOG_EVENT_UNFILTERED==nil,'startup never attempts a protected combat registration, including nonthrowing forbidden APIs')
freshRecording();C.SetEnabled(false)
local c=ledger();local owner=C.Owner();local stamp=GetServerTime()+1
for i=1,210 do
 check(S.Append(owner,{kind='location',source='ZONE_CHANGED',session=c.currentSession,at=stamp+i,elapsed=i+.25,
  timeSource='server',evidence='observed',location={zone=i%2==0 and 'Elwynn Forest' or 'Westfall'},details={reason='test '..i}})~=nil,'valid paged event '..i)
end
for i=1,90 do S.Observe(owner,'Player-Export-'..i,{name='Person '..i,realm='Other Realm',class='MAGE',localSighting=true},stamp+i,'PLAYER_TARGET_CHANGED',{zone='Elwynn Forest'}) end
local noteProfile=c.profiles['Player-Export-1'];noteProfile.personal={note='Personal UTF8 note: caf\195\169',watch=true};c.bytes=c.bytes+S.Size(noteProfile.personal)
local other=S.Character('Other Realm/Player-Other-10',true);other.currentSession='Other Realm/Player-Other-10/s1';other.sessionSequence=1
S.Append('Other Realm/Player-Other-10',{kind='location',source='ZONE_CHANGED',session=other.currentSession,at=stamp+500,elapsed=1,timeSource='local-clock',evidence='observed',location={zone='Durotar'},details={}})
local page,more,total=R.Query({});check(#page==50 and more and total>210 and page[1].character=='Other Realm/Player-Other-10','all-character merge shows newest records without a full copy')
local second=R.Query({page=1});local ids={};for _,e in ipairs(page) do ids[e.id]=true end
for _,e in ipairs(second) do check(not ids[e.id],'pagination does not repeat event '..e.id) end
local filtered=R.Query({owner=owner,kind='location',search='Westfall'});check(#filtered==50 and filtered[1].location.zone=='Westfall','character kind and literal search filters combine')
local literal=R.Query({search='[.*]'});check(#literal==0,'search treats pattern characters literally')
local timeFiltered=R.Query({since=stamp+499});check(#timeFiltered==1,'timestamp filter excludes older events')
local tail,moreTail=R.Query({page=4});check(#tail>0 and #tail<50 and not moreTail,'older pages can reach all saved events')
local blocks=R.Detail(page[1]);check(#blocks>=7 and blocks[3].text:find('local-clock',1,true),'details distinguish local clock and source')
check(not S.db.enabled,'browsing data never opts into recording')
ns.Workspace.Open('recording');drain();local view=ns.Workspace.pages.recording
view:SetRecordMode('all') -- This suite inspects background records deliberately.
check(ns.Workspace.current=='recording' and view:IsShown(),'Recording is a separate sidebar page')
check(#view.list.rows<=9 and #view.list.items==50,'viewer creates a bounded row pool')
click(view.list.rows[1]);check(view.selected==view.list.items[1].id,'click opens source details without changing notification read state')
click(button('Older 50',view.events));check(view.filter.page==1,'older control reaches next history page')
click(button('Newer 50',view.events));check(view.filter.page==0,'newer control returns to latest history')
local rows=#frames;for i=1,15 do view:Refresh(true) end;check(#frames==rows,'repeated viewer refresh reuses UI frames')
local lock=InCombatLockdown;InCombatLockdown=function() return true end
local snapshot,err=B.Create();check(not snapshot and err:find('combat',1,true),'backup creation defers during combat')
view:Refresh(true);InCombatLockdown=lock;view:Refresh(true)
snapshot=assert(B.Create());check(snapshot.total>1,'larger history exports as multiple parts')
local eventsBefore=C.Statistics().events;local profilesBefore=C.Statistics().profiles
for i,text in ipairs(snapshot.parts) do
 check(#text<=B.TEXT_LIMIT,'backup part fits text input '..i)
 local p=assert(B.Validate(text));check(p.index==i and p.total==snapshot.total and p.batch==snapshot.batch,'part carries common identity and counts '..i)
end
local firstPart=dataOf(snapshot.parts[1]);local originalPart=snapshot.parts[1]
C.Clear();check(next(S.db.characters)==nil,'clear prepares an empty restore target')
check(#view.list.items==0 and view.selected==nil and view.snapshot==nil and view.backupBox:GetText()=='','explicit clear also removes viewer selections and export text')
-- Import in reverse order, then repeat it: restoration must be idempotent.
for i=#snapshot.parts,1,-1 do local ok,message=B.Restore(snapshot.parts[i]);check(ok,message) end
check(C.Statistics().events==eventsBefore and C.Statistics().profiles==profilesBefore,'every event and profile returns after a full backup round trip')
check(S.Character('Other Realm/Player-Other-10',false)~=nil,'cross-character history restores with the same realm/GUID scope')
check(C.Profile('Player-Export-1').personal.note=='Personal UTF8 note: caf\195\169' and C.Profile('Player-Export-1').personal.watch,'UTF8 notes and watch flags survive text round trip')
check(not S.db.enabled and not C.Active(),'restore never starts recording or inherits consent')
for _,text in ipairs(snapshot.parts) do check(B.Restore(text),'duplicate part is accepted without duplicating events') end
check(C.Statistics().events==eventsBefore,'idempotent imports keep event totals')
local restored=0;for _ in pairs(S.db.lastRestore.parts) do restored=restored+1 end
check(restored==snapshot.total,'restore progress reaches complete across reverse and duplicate parts')
check(ledger().events[1].restored==true,'restored events are labelled as user backup data')
C.Initialize();check(ledger().events[1].restored and C.Profile('Player-Export-1').restored,'restore provenance survives reload')
local restored=0;for _ in pairs(S.db.lastRestore.parts) do restored=restored+1 end
check(restored==snapshot.total,'restore progress survives reload')
local detail=R.Detail(ledger().events[1]);local marked=false;for _,b in ipairs(detail) do if b.text:find('not an independent observation',1,true) then marked=true end end
check(marked,'viewer explains imported history is not independent verification')
local count=C.Statistics().events;local unchanged=B.Encode(ledger().events)
check(not B.Restore(originalPart:sub(1,-4)),'truncated backup rejected')
check(not B.Restore(originalPart:gsub('OCW%-HISTORY%-1','OCW-HISTORY-99')),'unsupported backup header rejected')
check(not B.Restore(string.rep('x',33001)),'oversized input rejected without touching history')
check(not B.Restore('return {evil=function() end}'),'executable SavedVariables text is not accepted')
local bad=dataOf(originalPart);bad.records[1].event.details.reason='different'
check(not B.Restore(envelope(bad)),'conflicting duplicate ID rejects the whole part')
check(B.Encode(ledger().events)==unchanged and C.Statistics().events==count,'failed imports are transactional')
bad=dataOf(originalPart);bad.records[1].event.details={evil='unknown vocabulary'}
check(not B.Restore(envelope(bad)),'unknown event fields rejected')
bad=dataOf(originalPart);bad.records[1].event.evidence='inferred'
check(not B.Restore(envelope(bad)),'unsupported evidence is not accepted as an observation')
bad=dataOf(originalPart);bad.records[1].event.character='Another/Player-Fake-01'
check(not B.Restore(envelope(bad)),'foreign event ownership rejected')
bad=dataOf(originalPart);bad.records[1].event.schema=99
check(not B.Restore(envelope(bad)),'future event schema rejected without overwriting current data')
local active=assert(C.SetEnabled(true));check(not B.Restore(originalPart),'restore requires recording paused')
C.SetEnabled(false)
view:SetView('backup');check(view.backupMode=='file' and view.fileBackup:IsShown() and not view.textBackup:IsShown(),'complete file backup is the default');click(view.textModeButton);click(button('Create text backup',view.textBackup));check(view.snapshot and #view.backupBox:GetText()>0,'visible backup control creates copyable text')
click(button('Next part',view.textBackup));check(view.part==2,'visible next-part control advances stable export')
view.backupBox:SetText(originalPart);click(button('Restore this part',view.textBackup))
check(view.restoreArmed==originalPart,'first restore click validates and asks for confirmation')
click(button('Restore this part',view.textBackup));check(view.restoreArmed==nil and not S.db.enabled,'second click commits while leaving recording off')
view:SetView('events');view:Refresh(true)
local complete,asyncError
check(B.Begin(function(value,err) complete=value;asyncError=err end),'asynchronous export starts')
check(B.job~=nil and not complete,'export yields to the game rather than completing on the click')
check(not B.Begin(function() end),'only one export job can run at once')
drain();check(complete and not asyncError and not B.job,'cooperative export completes with a full snapshot')
local cancelled=false;B.Begin(function() cancelled=true end);B.Cancel();drain()
check(not cancelled and not B.job,'cancel drops the unfinished export without touching history')
local changedError;B.Begin(function(value,err) changedError=err end);S.revision=S.revision+1;drain()
check(changedError and changedError:find('History changed',1,true),'export rejects concurrent history changes rather than silently mixing snapshots')
check(C.Statistics().events>=eventsBefore,'cancelled or invalidated export retains every saved event')
check(C.diagnostics.errors==0,'recording and UI checks produce no collector errors')
''')
# Independent fresh-install consent flows, including delayed permission/combat.
for choice in ['enable','dismiss','combat','permission','already-enabled']:
    host=state['host'];fresh=host['fresh']('modern',choice!='permission')
    fresh.globals().choice=choice
    fresh.execute(r'''
    S,C=ns.ChronicleStore,ns.Chronicle
    function date(fmt,at) return os.date(fmt,at) end
    function GetRealmName() return 'Test Realm' end;function UnitGUID() return 'Player-Consent-01' end
    function IsLoggedIn() return true end
    check(not S.db.enabled and S.db.promptSeen==nil,'new installation has no implicit recording choice')
    local original=InCombatLockdown
    if choice=='combat' then InCombatLockdown=function() return true end end
    if choice=='already-enabled' then C.SetEnabled(true) end
    C.Handle('PLAYER_ENTERING_WORLD',true,false);drain()
    if choice=='permission' then
      check(not ns.RecordingConsentWindow,'Olympus permission remains authoritative before prompt')
      oly.questions['api:olympuschatwarden'].set(true);drain()
    elseif choice=='combat' then
      check(not ns.RecordingConsentWindow,'first prompt defers during combat')
      InCombatLockdown=original;C.MaybePrompt();drain()
    elseif choice=='already-enabled' then
      check(not ns.RecordingConsentWindow and S.db.enabled,'existing opt-in is preserved without a new prompt');return
    end
    local p=ns.RecordingConsentWindow
    check(p and p:IsShown() and not S.db.enabled,'eligible first login visibly explains opt-in while recording stays off')
    local text=choice=='enable' and 'Enable recording' or 'Not now';local selected
    for _,f in ipairs(frames) do if f:GetObjectType()=='Button' and f.GetText and f:GetText()==text and f:GetParent()==p then selected=f end end
    check(selected~=nil,'explicit consent choice exists');click(selected)
    check((choice=='enable')==S.db.enabled,'only explicit Enable recording consents')
    check(not p:IsShown() and S.db.promptSeen==S.CONSENT,'choice dismisses prompt and is remembered')
    C.Initialize();C.Handle('PLAYER_ENTERING_WORLD',false,true);drain();check(not p:IsShown(),'choice persists across UI reload')
    check(forbiddenRegistrations==0,'consent flow never probes restricted registration')
    ''')
    if choice=='enable':
        export_source=state['export_source'].replace("page=lua.globals().ns.Workspace.window if style in ('workspace','updates') else lua.globals().nativePages[style]", "page=lua.globals().ns.RecordingConsentWindow if style=='consent' else lua.globals().ns.Workspace.window if style in ('workspace','updates') else lua.globals().nativePages[style]")
        consent_scope={};exec(compile(export_source,'consent-scene-export','exec'),consent_scope)
        (out/'scene-consent.json').write_text(json.dumps(consent_scope['export_scene'](fresh,'consent'),default=str))
    # checks accumulate independently in each fresh host.
    lua.globals().checks+=fresh.globals().checks
summary={'version':'1.0.3','assertions':lua.globals().checks-before,'failed':0,
         'backupFormat':'non-executable, SHA256 checked, multipart, transactional merge',
         'automaticHistoryExpiry':False,'restrictedCombatRegistrationAttempts':0,'liveWoWTested':False}
(out/'recording-ui-backup-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
scene_scope=state['scene_scope'];export=scene_scope['export_scene']
(out/'scene-recording.json').write_text(json.dumps(export(lua,'workspace'),default=str))
lua.execute("ns.Workspace.pages.recording:SetView('backup');ns.Workspace.pages.recording.backupBox:SetText('Your history backup text appears here. Copy every numbered part.')")
(out/'scene-backup.json').write_text(json.dumps(export(lua,'workspace'),default=str))
print(json.dumps(summary,indent=2))
