from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'release-polish-host','exec'),scope);lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local W,V,G=ns.Workspace,ns.Art,ns.WardenDossier
local methods=getmetatable(UIParent).__index;function methods:SetDesaturated(value) self.desaturated=value end
local order={'overview','chronicle','intel','messages','mentions','shield','relay'}
local previous=-1
for _,id in ipairs(order) do local b=W.navigation[id];local y=-(b.y or b.points[1].y)
 check(y>previous and b:GetHeight()==62 and b.Icon.ChatWardenIconBox.size==60 and math.max(b.Icon:GetWidth(),b.Icon:GetHeight())==(id=='relay' and 52.5 or 60),'navigation order, larger hit area and matched crest footprint preserve module IDs: '..id);previous=y
 b:GetScript('OnClick')();check(W.current==id,'reordered button opens its original module')
end
W.Open('activity');local p=W.pages.activity
local consent=ns.ChronicleStore.db.consentVersion;local duel=ns.ChronicleStore.db.duels
ns.DB.enabled=true;W.Refresh()
for _,card in ipairs(p.cards) do
 local texture=card.toggle.Icon.texture;local badge=card.toggle.StateMark
 check(card.title.x==card.detail.x and card.detail:GetHeight()>=24 and card.detail.wrap==false,'status labels share alignment and cannot wrap one word to a clipped line')
 for n=1,4 do
  W.ToggleFeature(card.feature);W.Refresh();p:Refresh(true)
  local on=W.FeatureEnabled(card.feature)==true
  check(card.toggle.Icon.texture==texture and card.toggle.Icon.ChatWardenArt.atlas:find('WardenSmall',1,true),'toggling never substitutes legacy artwork')
  check(card.toggle.StateMark==badge and badge.label:GetText()==(on and 'ON' or 'OFF'),'state badge is explicit and reused')
  card.toggle:GetScript('OnLeave')(card.toggle)
  check(card.toggle.Icon:GetAlpha()==(on and 1 or .35),'mouse leave preserves paused dimming')
 end
end
for name,brand in pairs({enabled='ChatWarden',enabledOff='ChatWarden',shieldActive='ShieldWarden',shieldOff='ShieldWarden',captureOff='ChatWarden',mentionsOff='SignalWarden'}) do
 check(ns.WardenBrand.Icon(name)==brand,'legacy status alias resolves to current module crest')
end
ns.DB.enabled=false;W.Refresh();check(W.filterStatus:GetText()=='Filtering: OFF' and W.filterButton.StateMark.label:GetText()=='OFF','top bar uses current crest and literal off state')
W.Open('mentions');check(W.pageIcon.desaturated==true,'paused feature header is dimmed')
W.Open('chronicle');check(W.pageIcon.desaturated==false and W.pageIcon:GetWidth()==72,'ordinary module restores full-color enlarged crest')
check(W.tabHost.x>=W.pageIcon.ChatWardenIconBox.x+W.pageIcon:GetWidth()+10 and W.heading.x==W.tabHost.x,'page title and tabs sit beside large artwork')
W.Open('overview');local home=W.pages.overview
check(home.heroTitle.x==home.heroSummary.x and home.heroSummary.y==-54 and home.heroSummary:GetParent():GetHeight()==96,'hero identity shares alignment inside taller banner')
check(ns.ChronicleStore.db.consentVersion==consent and ns.ChronicleStore.db.duels==duel,'visual controls never change Chronicle or duel consent')
local host=CreateFrame('Frame',nil,W.canvas);local talents=G.BuildTalents(host);talents.rows={{at=1800000000}};talents.index=1
local choices={};for n=1,25 do choices[n]={n,n,n,n%3+1,false,false} end
talents:RenderChoices({choices=choices,choicesComplete=true})
local maximum=talents.choicesContent:GetHeight()-talents.choicesScroll:GetHeight();talents.choicesScroll:SetVerticalScroll(maximum)
local last=talents.choiceCards[25];local top=-(last.y or last.points[1].y)-maximum
check(top>=0 and top+last:GetHeight()<=talents.choicesScroll:GetHeight(),'last historical talent row is fully reachable at the bottom')
check(last.name:GetHeight()>=22 and last.rank:GetHeight()>=20 and last.rank:GetText()=='Rank '..choices[25][4],'talent name and recorded rank get full line height')
releasePolishChecks=checks-before
''')
result={'version':'1.1.0','failed':0,'assertions':int(lua.globals().releasePolishChecks),'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'release-polish-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
