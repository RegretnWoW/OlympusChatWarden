from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
host={'__file__':str(out/'test-integration.py')};exec(compile((out/'test-integration.py').read_text().split('count=0')[0],'reviewed-native-host','exec'),host)
lua=host['fresh']('modern',True)
cases=r'''
X=ns.Wanted;C=ns.OlympusConnection;A=ns.Activity;W=ns.Workspace
units={};sounds={};toasts={}
function UnitIsPlayer(unit) return unit=='player' or units[unit] and units[unit].player==true or false end
function UnitGUID(unit) return unit=='player' and 'Player-Home-01' or units[unit] and units[unit].guid end
function UnitCanAttack(_,unit) return units[unit] and units[unit].attackable==true or false end
function GetRealZoneText() return 'Elwynn Forest' end
function PlaySound(id,channel) sounds[#sounds+1]={id,channel} end
local realToast=ns.ShowWantedToast
ns.ShowWantedToast=function(item) toasts[#toasts+1]=item end
local function wantedEvent(event) for _,f in ipairs(frames) do if f.events and f.events[event] then f.scripts.OnEvent(f,event) end end;drain() end
local function fixture()
 units={};clock=clock+61
 wantedRows={{guid='Player-Home-AA',name='Blood Fang',active=true,current=100,lifetimeKills=3,cycle=2},
  {guid='Player-Home-BB',name='Silent Fox',active=true,current=0,lifetimeKills=4,cycle=1},
  {guid='Player-Other-CC',name='Twin Name-OtherRealm',active=true,current=20,lifetimeKills=1,cycle=1},
  {guid='Player-Home-DD',name='Same Name',active=true,current=5,lifetimeKills=1,cycle=1},
  {guid='Player-Home-EE',name='Same Name',active=true,current=6,lifetimeKills=1,cycle=1}}
 X.Initialize();X.Refresh(true);drain()
end
check(X.db.enabled and X.db.encounters and X.db.chatIndicators and X.db.badges,'Wanted feed defaults enabled')
check(not X.db.sound and not X.db.toast and X.db.cooldown==300,'sound and toast off; five-minute cooldown')
check(X.Active() and X.count==0,'actual Olympus empty Wanted snapshot is ready')
fixture()
check(X.count==5 and X.state=='ready','real GetWanted imports listed snapshots including zero-bounty kills')
check(#X.Find('BLOOD FANG is here')==1,'case-insensitive exact full-name mention')
check(#X.Find('blood is here')==0,'first name alone never guesses Wanted identity')
check(#X.Find('Blood Fangling')==0 and #X.Find('NotBlood Fang')==0,'name boundaries avoid substring matches')
check(#X.Find('Blood Fang-OtherRealm')==0,'wrong realm suffix cannot match a bare local alias')
check(#X.Find('Twin Name')==0 and #X.Find('Twin Name-OtherRealm')==1,'cross-realm identity requires supplied realm')
check(#X.Find('Same Name')==0,'ambiguous full-name alias is skipped')
check(#X.Find('|Hitem:123|hBlood Fang|h')==0,'item-link label is not player evidence')
check(#X.Find('|Hspell:123|hBlood Fang|h')==0,'spell-link label is not player evidence')
check(#X.Find('|Hplayer:Blood Fang|hBlood Fang|h')==1,'visible player-link name can match')
check(#X.Find('Blood|TInterface\Icons\test:16|t Fang')==0,'texture payload cannot join a full name')
check(#X.Find('|TInterface\Blood Fang:16|t')==0,'texture payload cannot manufacture a mention')
local playerFlag,attackFlag=UnitIsPlayer,UnitCanAttack
UnitIsPlayer=function() return 1 end;UnitCanAttack=function() return 1 end
units.target={guid='Player-Home-AA'}
check(X.ObserveUnit('target')~=nil,'Classic numeric unit flags are normalized safely')
UnitIsPlayer,UnitCanAttack=playerFlag,attackFlag;units={};X.last={}
local count=#A.List('wanted')
units.target={guid='Player-Home-AA',player=false,attackable=true};wantedEvent('PLAYER_TARGET_CHANGED')
check(#A.List('wanted')==count,'NPC GUID is not treated as a player encounter')
units.target={guid='Player-Home-AA',player=true,attackable=false};wantedEvent('PLAYER_TARGET_CHANGED')
check(#A.List('wanted')==count,'friendly unit cannot trigger an encounter')
units.target={guid='Player-Home-UNKNOWN',player=true,attackable=true};wantedEvent('PLAYER_TARGET_CHANGED')
check(#A.List('wanted')==count,'same-looking unknown GUID cannot trigger an encounter')
units.target={guid='Player-Home-AA',player=true,attackable=true};wantedEvent('PLAYER_TARGET_CHANGED')
local encounter=A.List('wanted')[1]
check(#A.List('wanted')==count+1 and encounter.wanted.kind=='encounter','target event creates Wanted encounter')
check(encounter.wanted.name=='Blood Fang' and encounter.wanted.zone=='Elwynn Forest' and encounter.wanted.via=='target','encounter retains source and local zone')
check(encounter.wanted.bounty==100 and encounter.wanted.kills==3 and encounter.wanted.cycle==2,'encounter freezes Olympus bounty metadata')
check(A.EventLabel(encounter)=='Wanted Encounter','encounter has its own event label')
units.mouseover=units.target;wantedEvent('UPDATE_MOUSEOVER_UNIT');wantedEvent('PLAYER_TARGET_CHANGED')
check(#A.List('wanted')==count+1,'target and mouseover share per-player encounter cooldown')
check(#sounds==0 and #toasts==0,'default encounter emits no sound or toast')
check(#A.List('messages')==0 and #A.List('mentions')==0 and #A.List('shield')==0,'Wanted encounters stay out of other category feeds')
'''
lua.execute(cases+'\n'+(out/'wanted-cases.lua').read_text(encoding='utf-8'))
summary={'version':'1.0.3','assertions':lua.globals().checks,'failed':0,'actualOlympusWantedAPI':True,'liveWoWTested':False}
(out/'wanted-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
