from pathlib import Path
import json,time
out=Path(__file__).resolve().parent;root=out.parents[1]
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'rc-loading-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local normalize=S.Normalize
freshRecording();C.Record('quest_turnin','QUEST_TURNED_IN',{questID=781});C.SetEnabled(false)
local source=ns.ChronicleBackup.PackSaved(S.db)
local clock,combat=debugprofilestop,InCombatLockdown
local function scheduled(timer,inCombat)
 ns.DB.chronicle=source;debugprofilestop=timer;InCombatLockdown=function() return inCombat end
 S.Normalize=function(db,checkpoint) for n=1,400 do checkpoint('saved chunks',1) end;return normalize(db) end
 S.Initialize(true);S.PumpLoad();local n=S.loadProgress.chunks;S.CancelLoad();return n
end
check(scheduled(function() return 0 end,false)==128,'fast clock uses bounded available work beyond the old eight-resume cap')
check(scheduled(nil,false)==8,'absent profiling clock keeps conservative eight-resume fallback')
local t=0;check(scheduled(function() t=t+1;return t end,false)==4,'outside combat pump yields at four millisecond target')
t=0;check(scheduled(function() t=t+1;return t end,true)==2,'combat retains two millisecond target')
S.Normalize=normalize;debugprofilestop=clock;InCombatLockdown=combat
ns.DB.chronicle=source;C.Initialize(true)
local total=0;for _,c in pairs(source.characters) do total=total+#c.eventChunks+#c.profileChunks end
check(S.loadProgress.totalChunks==total and total>0,'progress denominator counts original event and profile chunks')
check(C.Status():find(' / '..total..' chunks (0%)',1,true),'loading status shows checked chunks and percentage')
local print=ns.Print;local message;ns.Print=function(v) message=v end;C.Handle('PLAYER_ENTERING_WORLD',false,true)
C.MaybePrompt(true)
check(C.promptAfterLoad==true and message:find('will open when validation finishes',1,true),'requested explanation queues while loading')
check(not message:find('Olympus access',1,true),'loading does not imply missing Olympus permission')
while S.loading do S.PumpLoad() end
drain()
check(C.promptAfterLoad==nil and ns.RecordingConsentWindow and ns.RecordingConsentWindow:IsShown(),'queued explanation opens when world and validated history are ready')
check(not S.db.enabled,'viewing explanation never grants recording consent')
check(S.loadProgress.chunks==total,'completed progress checks every saved chunk')
ns.Print=print;ns.RecordingConsentWindow:Hide();rcLoadingChecks=checks-before
''')
result={'version':'1.1.0','assertions':int(lua.globals().rcLoadingChecks),'failed':0,'seconds':round(time.perf_counter()-started,3),'liveClientTest':False}
(out/'rc-loading-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
