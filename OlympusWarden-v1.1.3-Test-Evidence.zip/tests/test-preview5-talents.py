from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-manual-inspect.py')};exec(compile((out/'test-manual-inspect.py').read_text(encoding='utf-8'),'talent-native-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local I,X,G=ns.ChronicleEncounters,ns.ChronicleCapture,ns.WardenDossier
InspectFrame:Hide();units.target=nil;units.party1=nil;freshRecording();clock=clock+600
local guid='Player-Readable-TALENTS';units.target={guid=guid,name='Readable Friend',class='MAGE',level=60}
Constants={TraitConsts={INSPECT_TRAIT_CONFIG_ID=-1}}
local count,invalid,export=5,false,'OriginalNativeBuild';local nodesRead=0
C_ClassTalents={GetActiveConfigID=function() error('must not read recorder talent config') end}
C_Traits={HasValidInspectData=function() return true end,GenerateInspectImportString=function() return export end,
 GetConfigInfo=function(id) assert(id==-1);return {ID=id,treeIDs={700}} end,
 GetTreeNodes=function(tree) assert(tree==700);local t={};for n=1,count do t[n]=100+n end;return t end,
 GetNodeInfo=function(config,id) assert(config==-1);nodesRead=nodesRead+1
  if invalid and id==102 then return nil end
  return {ID=id,currentRank=id==105 and 0 or 1,activeEntry=id~=105 and {entryID=id+1000,rank=2} or nil} end,
 GetEntryInfo=function(config,entry) assert(config==-1);return {definitionID=entry+1000} end,
 GetDefinitionInfo=function(id) return {spellID=id+1000} end}
C_SpecializationInfo={GetInspectSpecialization=function() return 1491 end}
GetSpecializationInfoByID=function(id) return id,'Native Specialization',nil,777 end
C_Spell={GetSpellInfo=function(id) return {spellID=id,name='Native Talent '..id,iconID=888} end}
local function inspect() clock=clock+10;InspectFrame_Show('target');ev('INSPECT_READY',guid);return all('important_player')[#all('important_player')] end
local e=inspect();local hash=e.details.traitRef;local obj=X.Find(C.Owner(),hash);local v=obj.capture.values
check(#v.choices==4 and v.choicesComplete and v.nodesRead==5 and v.nodesTotal==5,'owned native inspect config captures selected entries only with full bounded node coverage')
check(v.choices[1][1]==700 and v.choices[1][2]==101 and v.choices[1][3]==1101 and v.choices[1][4]==2 and v.choices[1][5]==2101 and v.choices[1][6]==3101,'snapshot retains exact tree, node, entry, rank, definition and spell IDs')
check(v.exportString==export and v.specializationID==1491,'readable choices preserve full original export and specialization')
local p=G.BuildTalents(UIParent);p:Show();p:SetProfile(C.Owner(),{id=guid,title='Readable Friend'})
for n=1,20 do p.scripts.OnUpdate(p) end
check(p.choiceCards[1].name:GetText()=='Native Talent 3101' and p.choiceCards[1].rank:GetText():find('Rank 2',1,true),'readable names icons and recorded ranks are displayed')
check(p.choiceCards[1].icon.texture==888 and p.detail:GetText():find('Native Specialization',1,true),'native ID metadata resolves without a retail lookup table')
check(p.export:GetText()=='OriginalNativeBuild' and p.select.enabled,'original export remains copyable')
C_Spell.GetSpellInfo=function() return {spellID=9999,name='Wrong metadata'} end;GetSpellInfo=nil;p:Render()
check(p.choiceCards[1].name:GetText()=='Talent name unavailable' and p.choiceCards[1].spell==3101,'mismatched spell metadata has an honest readable fallback while preserving the exact saved spell ID')
invalid=true;e=inspect();v=X.Find(C.Owner(),e.details.traitRef).capture.values
check(not v.choicesComplete and #v.choices==3,'missing nodes produce explicitly partial coverage')
count=600;invalid=false;nodesRead=0;e=inspect();v=X.Find(C.Owner(),e.details.traitRef).capture.values
check(v.nodesRead==256 and nodesRead==256 and v.nodesTotal==600 and #v.choices<=80 and not v.choicesComplete,'large configs have a strict per-response budget and selected-entry limit')
export=string.rep('A',4900);e=inspect();v=X.Find(C.Owner(),e.details.traitRef).capture.values
check(v.exportString==export and X.Validate(obj.capture)~=nil,'size limit never truncates the native export')
check(not v.choicesComplete and #v.choices<80,'oversized readable projection shrinks with an explicit partial marker')
Constants=nil;count=5;export='ExportOnly';e=inspect();v=X.Find(C.Owner(),e.details.traitRef).capture.values
check(v.exportString==export and not v.choices,'missing native inspect constant retains export-only evidence; no own-config fallback')
local j=G.Request(C.Owner());while not j.done do G.Pump(j) end;p.index=1;p:SetProfile(C.Owner(),{id=guid,title='Readable Friend'});p.scripts.OnUpdate(p)
check(p.choicesEmpty:GetText():find('Inspect the player again',1,true) and not p.choiceCards[1].shown,'old export-only records clearly explain how to obtain readable choices')
Constants={TraitConsts={INSPECT_TRAIT_CONFIG_ID=-1}};local fn=C_Traits.GetEntryInfo
local total=#all('important_player');C_Traits.GetEntryInfo=function(...) units.target.guid='Player-Changed-OWNER';return fn(...) end
clock=clock+10;InspectFrame_Show('target');I.InspectReady(guid)
check(#all('important_player')==total,'target changes inside a talent getter reject the entire inspection observation')
units.target.guid=guid;C_Traits.GetEntryInfo=fn
local malformed={format=1,family='traits',values={guid=guid,choices={{700,101,1101,2,false,3101}},choicesComplete=true,nodesRead=1,nodesTotal=1}}
check(not X.Validate(malformed),'spell without its definition link is rejected')
malformed.values.choices={{700,101,1101,2,2101,3101},{700,101,1101,2,2101,3101}}
check(not X.Validate(malformed),'duplicate selected nodes are rejected')
local B=ns.ChronicleBackup;C.SetEnabled(false);local backup=assert(B.Create())
for _,part in ipairs(backup.parts) do check(B.Validate(part)~=nil,'standard backup validates readable historical selections') end
C.Clear();for n=#backup.parts,1,-1 do check(B.Restore(backup.parts[n])==true,'standard restore preserves extended trait objects') end
v=X.Find(C.Owner(),hash).capture.values
check(#v.choices==4 and v.choices[1][6]==3101 and v.exportString=='OriginalNativeBuild','reload-style restore preserves exact choices and original evidence hash')
check(S.VERSION==6 and S.CONSENT==5 and not C.Active(),'existing identity, schema, consent and paused state remain intact')
talentChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().talentChecks,'failed':0,'nodeReadBudget':256,'selectedEntryLimit':80,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'preview5-talents-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
