from pathlib import Path
import json,subprocess,sys,time,hashlib,os
o=Path(__file__).resolve().parent;r=o.parents[1]
rows=json.loads((o/'preview-suite-results.json').read_text())
assert len(rows)==16 and all(x['exitCode']==0 for x in rows)
name='test-scale-welcome.py';at=time.perf_counter()
p=subprocess.run([sys.executable,'-X','utf8',str(o/name)],cwd=r,capture_output=True,text=True,encoding='utf-8',timeout=60,env={**os.environ,'WARDEN_TEST_WATCHDOG':'1'})
(o/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8');print(p.stdout+p.stderr,flush=True)
rows.append({'suite':name,'exitCode':p.returncode,'seconds':time.perf_counter()-at,'isolatedRerun':True,'fixtureInstructionWatchdog':True})
(o/'preview-suite-results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert p.returncode==0
digest=hashlib.sha256()
for path in sorted((r/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(path.name.encode());digest.update(path.read_bytes())
(o/'preview-tests-source-sha256.txt').write_text(digest.hexdigest()+'\n')
