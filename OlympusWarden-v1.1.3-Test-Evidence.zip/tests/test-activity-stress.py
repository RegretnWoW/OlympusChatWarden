from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recording-host','exec'),state)
lua=state['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local A,B=ns.ChronicleActivities,ns.ChronicleBackup
C.Clear();stressOwner=C.Owner();stressCharacter=S.Character(stressOwner,true);local c=stressCharacter
c.currentSession=stressOwner..'/s1';c.sessionSequence=1
local place={inInstance=true,instanceType='raid',instanceID=409,instanceName='Molten Core',zone='Molten Core'}
local function emit(kind,t,d,source,subject,location)
 return assert(S.Append(stressOwner,{kind=kind,source=source or 'checkpoint',details=d or {},session=c.currentSession,
 at=1800010000+t,elapsed=t,timeSource='server',evidence='observed',location=location or place,subject=subject}))
end
local members={};for i=1,39 do
 members[i]='Player-Raid-'..i
 emit('player_observed',i,{name='Companion '..i,realm='Raid Realm',encounter=false,localSighting=false},'GROUP_ROSTER_UPDATE',members[i])
end
for run=1,100 do
 local t=run*1000
 emit('recording_start',t,{},'control')
 emit('instance_enter',t+1)
 emit('group_roster',t+2,{members=members,knownMembers=39,sameGuildMembers=20},'GROUP_ROSTER_UPDATE')
 for boss=1,5 do
  local at=t+boss*100
  emit('native_event',at,{recordType='encounter_started',encounterID=boss,name='Raid Boss '..boss,difficultyID=9},'ENCOUNTER_START')
  for trash=1,70 do emit('money_change',at+trash,{before=1000,after=1001,delta=1},'PLAYER_MONEY') end
  emit('native_event',at+80,{recordType='encounter_ended',encounterID=boss,name='Raid Boss '..boss,difficultyID=9,success=boss%2},'ENCOUNTER_END')
 end
 emit('time_span',t+600,{seconds=599,samples=20,firstAt=1800010000+t+1,lastAt=1800010000+t+600,firstElapsed=t+1,lastElapsed=t+600})
 emit('instance_exit',t+700);emit('recording_stop',t+701,{},'control')
end
stressEvents=#c.events;stressBytes=c.bytes;stressSequence=c.sequence
check(stressEvents>36000,'stress ledger includes 100 raid segments and more than 36000 raw records')
A.Request(stressOwner);A.Pump(1);local progress,total=A.Progress()
check(progress==1 and total==stressEvents,'caller budget processes one record rather than the entire history in a frame')
local originalCombat=InCombatLockdown;InCombatLockdown=function() return true end;A.Pump(128)
check(A.Progress()==1,'combat pauses cooperative indexing');InCombatLockdown=originalCombat
local iterations=0;local st
while not st do A.Pump();iterations=iterations+1;st=A.Request(stressOwner);assert(iterations<1000) end
check(iterations>250 and iterations<400,'full history is processed across bounded update steps')
check(#A.Query(st,{kind='raid',limit=1000})==100,'all 100 raids remain separately addressable')
check(#A.Query(st,{kind='group',limit=1000})==100,'recording boundaries keep social segments separate')
local p=A.Player(st,members[1]);check(p.listedRaidSegments==100,'player query finds the same 100 associated raid segments')
check(p.bossResultsWhileListed==500 and p.successResultsWhileListed==300 and p.failureResultsWhileListed==200,'500 source-reported boss results remain correctly scoped while meter is absent')
check(p.performance==nil and p.confirmedBossParticipation==nil,'large history never fills missing performance or attendance with zero')
check(c.sequence==stressSequence and c.bytes==stressBytes and #c.events==stressEvents,'indexing neither doubles saved data nor edits ledger accounting')
local firstSummary=p
local reused=true;for i=1,100 do if A.Player(st,members[1])~=firstSummary then reused=false end end
check(reused,'one hundred repeated dossier queries reuse the cached aggregate')
local function digest(state)
 local parts={}
 for _,a in ipairs(state.activities) do
  local row={a.id,a.kind,a.status,tostring(a.measuredSeconds)}
  for _,t in ipairs(a.attempts) do row[#row+1]=t.id..':'..t.outcome end
  parts[#parts+1]=table.concat(row,'/')
 end
 return table.concat(parts,'\n')
end
local original=digest(st)
-- Append during a rebuild must not starve the index or fabricate completion.
A.Clear();A.Request(stressOwner);A.Pump(16)
emit('money_change',102000,{before=1,after=2,delta=1},'PLAYER_MONEY')
repeat A.Pump();st=A.Request(stressOwner) until st
check(st.processed==#c.events and digest(st)==original,'append during rebuild is caught up without restarting the full scan')
-- A later import can be earlier in chronology; a partly extended cache is discarded safely.
emit('money_change',102001,{before=2,after=3,delta=1},'PLAYER_MONEY');A.Request(stressOwner);A.Pump(1)
emit('player_observed',1500,{name='Renamed during first run',encounter=false,localSighting=false},'PLAYER_TARGET_CHANGED',members[1])
A.Pump();repeat st=A.Request(stressOwner);if not st then A.Pump() end until st
check(st.processed==#c.events and #A.Query(st,{kind='raid',limit=1000})==100,'out-of-order import during indexing does not duplicate activities')
local incremental=digest(st);A.Clear();repeat st=A.Request(stressOwner);if not st then A.Pump() end until st
check(digest(st)==incremental,'clean and interrupted incremental rebuilds agree exactly')
check(A.Name(st,members[1],1800011600)=='Renamed during first run','earlier imported identity is used only after its actual observation time')
check(A.Name(st,members[1],1800011400)=='Companion 1 - Raid Realm','earlier aliases remain historically correct')
-- Another recording character has an independent namespace even with the same companion GUID.
local other='Other Realm/Player-Other-CHAR';local oc=S.Character(other,true)
assert(S.Append(other,{kind='group_roster',source='GROUP_ROSTER_UPDATE',details={members={members[1]},knownMembers=1,sameGuildMembers=0},
 session=other..'/s1',at=1900000000,elapsed=10,timeSource='server',evidence='observed',location={}}))
local otherState
repeat otherState=A.Request(other);if not otherState then A.Pump() end until otherState
check(A.Player(otherState,members[1]).listedRaidSegments==0 and #otherState.activities==1,'another character cannot inherit raid history or identities')
-- UI pagination, evidence pagination and source selection operate on this exact stress view.
ns.Workspace.Open('recording');local host=ns.Workspace.pages.recording;host:SetView('activities');local view=host.activities
view.owner=stressOwner;view.filter={kind='raid',page=0};view:Refresh(true)
check(#view.list.items==50 and view.older:IsEnabled() and not view.newer:IsEnabled(),'activity list paginates rather than rendering all history')
click(view.older);view:Refresh(true);check(#view.list.items==50 and not view.older:IsEnabled() and view.newer:IsEnabled(),'second activity page includes remaining 50 segments')
click(view.list.rows[1]);click(view.peopleMenu)
check(#view.peopleMenu.MenuRows==40 and view.peopleMenu.Menu:GetHeight()<=252,'40-person roster selector has a bounded scroll viewport')
ns.Art.CloseMenus();check(#view.sources<=51,'source selector creates at most 50 evidence choices per page')
local displayed=view.document:GetText();check(displayed:find('Individual participation: unknown',1,true) and displayed:find('DPS, HPS',1,true),'large raid view makes absent participation and performance explicit')
check(not S.db.enabled and forbiddenRegistrations==0,'stress browser adds neither consent nor restricted collectors')
-- Preserve the same rendered activity scene for review without opening the game.
local methods=getmetatable(UIParent).__index
function methods:GetStringHeight()
 local size=self.font and self.font[2] or 14;local lines=0
 for line in ((self.text or '')..'\n'):gmatch('(.-)\n') do lines=lines+math.max(1,math.ceil(#line*size*.53/math.max(1,self.w or 100))) end
 return lines*(size+3)
end
view:Refresh(true)
activityStressChecks=checks-before
''')
metrics={'version':'1.0.3','assertions':int(lua.globals().activityStressChecks),'failed':0,
 'rawRecords':int(lua.globals().stressEvents),'raidSegments':100,'companions':39,'bossResults':500,
 'elapsedHostSeconds':round(time.perf_counter()-start,4),'liveWoWTested':False,
 'limits':'Synthetic host timing is not a live Forever frame-rate or load-time guarantee.'}
(out/'activity-stress-summary.json').write_text(json.dumps(metrics,indent=2)+'\n',encoding='utf-8');print(json.dumps(metrics,indent=2))
scene=state['scene_scope']['export_scene'](lua,'workspace')
for f in scene['frames']:
 if f['kind']=='EditBox' and f.get('h',0)>34: f['wrap']=True
(out/'scene-activities.json').write_text(json.dumps(scene,default=str),encoding='utf-8')
