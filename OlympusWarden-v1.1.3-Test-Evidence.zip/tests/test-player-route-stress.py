"""Four-hour raid: own movement continues, no background other-player coordinate reads."""
from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];started=time.perf_counter();lua.execute(r'''
local beforeChecks=checks
local B,K=ns.ChronicleBackup,ns.ChronicleCodec
local otherReads=0;local ownReads=0;local visible=false
IsInRaid=function() return true end;groupCount=40;inside=false;zone='Elwynn Forest'
UnitIsVisible=function(u) return visible and units[u]~=nil end
units.target=nil;units.mouseover=nil;units.focus=nil
units.raid1=units.player;units.party1=nil;units.party2=nil
for i=2,40 do units['raid'..i]={guid='Player-RaidFixture-'..i,name='Companion '..i,level=30,class='MAGE',guild='Olympus Reloaded'} end
C_Map={GetBestMapForUnit=function(u) if u~='player' then otherReads=otherReads+1 end;return 37 end,
 GetPlayerMapPosition=function(id,u)
  if u~='player' then otherReads=otherReads+1 end
  return {GetXY=function() return .1+clock*.0000001,.9-clock*.0000001 end}
 end}
UnitPosition=function(u) if u~='player' then otherReads=otherReads+1;return 1,2,0,0 end;ownReads=ownReads+1;return clock*.017,-clock*.013,0,0 end
freshRecording();for i=1,200 do ns.ChronicleCapture.Pump() end
local start=clock;local owner=C.Owner();visible=true
local initialOtherReads=otherReads
for i=1,7200 do step(2) end
C.SetEnabled(false)
check(ns.ChroniclePlayerRoute==nil,'no continuous collector exists in four-hour fixture')
check(otherReads==initialOtherReads and otherReads==0,'four hours of raid frames issue zero other-player coordinate reads')
check(#all('player_route')==0 and #all('player_route_gap')==0,'no new other-player track/gap records')
check(#all('group_roster')==1 and #all('group_roster')[1].details.members==39,'raid membership history remains intact')
check(C.Statistics().profiles==39,'all other raid identities remain available')
check(C.Statistics().encounters==0,'remote roster does not become 39 personal sightings')
check(C.Statistics().seconds==14400,'measured own world time still covers four hours')
local own=0;local records=0
for _,e in ipairs(all('route_segment')) do
 local decoded=assert(K.Decode(e.route));records=records+1
 for _,p in ipairs(decoded.points) do
  assert(p[5]==p[2]*.017 and p[6]==-p[2]*.013,'own native axes changed')
  own=own+p[12]
 end
end
check(own==7201 and ownReads==7201,'initial plus 7200 two-second samples continue without collateral damage')
check(C.Statistics().ownRouteSamples==own,'own route statistics match decoded observations')
check(C.Statistics().playerRouteSamples==0 and C.Statistics().playerRouteBytes==0,'fresh history has zero legacy movement storage')
for i=2,40 do check(C.Profile('Player-RaidFixture-'..i)~=nil,'raid profile retained '..i) end
local count=#ledger().events;local bytes=ledger().bytes;local representation=assert(B.PackSaved(S.db));encodedSavedBytes=#B.Encode(representation)
ns.DB.chronicle=representation;C.Initialize()
check(#ledger().events==count and ledger().bytes==bytes,'four-hour own routes and group history survive chunked reload')
local s=S.Storage()
check(s.ownRouteBytes+s.playerIntelBytes+s.playerRouteBytes+s.otherBytes==s.bytes,'stress storage buckets reconcile')
check(s.playerIntelBytes>0 and s.ownRouteBytes>0 and s.playerRouteBytes==0,'own and Intel history remain without extra movement')
check(not S.db.enabled and C.diagnostics.errors==0,'paused state and error-free recorder survive reload')
ownRouteSamples=own;ownRouteRecords=records;playerRouteStressChecks=checks-beforeChecks
''')
summary={'version':'1.0.3','assertions':int(lua.globals().playerRouteStressChecks),'failed':0,'seconds':round(time.perf_counter()-started,3),'modeledHours':4,'otherRosterPlayers':39,'backgroundOtherPlayerPositionReads':0,'newOtherPlayerRouteRecords':0,'ownRouteSamples':int(lua.globals().ownRouteSamples),'ownRouteRecords':int(lua.globals().ownRouteRecords),'typedWholeSavedContainerBytes':int(lua.globals().encodedSavedBytes),'liveWoWTested':False,'limits':'Synthetic Lua5.1 host; encoded bytes are not disk/RAM/FPS measurements. Own axes checked after lossless decoding.'}
(out/'player-route-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
