from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'test-manual-inspect.py')};exec(compile((out/'test-manual-inspect.py').read_text(encoding='utf-8'),'scheduling-native-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local I,X=ns.ChronicleEncounters,ns.ChronicleCapture
InspectFrame:Hide();units.target=nil;units.mouseover=nil;units.party1=nil;units.party2=nil;groupCount=0;freshRecording();clock=clock+600
local notify=NotifyInspect;local calls={};NotifyInspect=function(unit) calls[#calls+1]={unit=unit,guid=UnitGUID(unit)};return notify(unit) end
local group=I.Group;I.Group=function(source) local co=coroutine.create(function() group(source) end);while coroutine.status(co)~='dead' do local ok,err=coroutine.resume(co);assert(ok,err) end end
units.party1={guid='Player-Schedule-ONE',name='Party One',class='MAGE',level=30}
units.party2={guid='Player-Schedule-TWO',name='Party Two',class='PRIEST',level=30};groupCount=3
I.Group('GROUP_ROSTER_UPDATE');I.Group('GROUP_ROSTER_UPDATE');I.InspectPump()
check(#calls==1 and calls[1].guid==units.party1.guid,'party teammates enter one deduplicated normal inspection queue')
I.InspectReady(units.party1.guid);clock=clock+6;I.InspectPump();I.InspectReady(units.party2.guid)
check(#calls==2 and calls[2].guid==units.party2.guid,'global spacing allows the next eligible teammate without duplicate requests')
local function lastGear(guid)
 local ref;for _,e in ipairs(all('important_player')) do if e.subject==guid and e.details.gearRef then ref=e.details.gearRef end end;return ref
end
local firstGear=lastGear(units.party1.guid);assert(firstGear)
clock=clock+70;I.Group('GROUP_ROSTER_UPDATE');I.InspectPump()
check(#calls==2,'repeated group observations inside per-player backoff do not reinspect')
clock=clock+I.AUTO_BACKOFF;I.Group('GROUP_ROSTER_UPDATE');I.Group('GROUP_ROSTER_UPDATE');I.InspectPump();I.InspectReady(units.party1.guid)
clock=clock+6;I.InspectPump();I.InspectReady(units.party2.guid)
check(#calls==4,'a later eligible observation can refresh each teammate once after backoff')
check(lastGear(units.party1.guid)==firstGear,'unchanged gear refresh shares its immutable content object')
-- An actual manual Inspect remains responsive inside automatic backoff.
units.target=units.party1;clock=clock+1;InspectFrame_Show('target');ev('INSPECT_READY',units.target.guid)
check(#calls==5 and InspectFrame:IsShown(),'manual Inspect is never blocked by automatic backoff')
local e=all('important_player')[#all('important_player')]
check(e.subject==units.target.guid and e.details.relationship=='manual inspection','manual refresh saves exact GUID and user intent')
units.mouseover={guid='Player-Schedule-FRIEND',name='Bookmark Friend',class='WARRIOR',level=30}
I.Important('mouseover','control','personal bookmark');clock=clock+6;I.InspectPump()
check(#calls==5,'automatic inspection yields while native Inspect remains open')
InspectFrame:Hide();clock=clock+6;I.InspectPump();I.InspectReady(units.mouseover.guid)
check(#calls==6 and calls[6].guid==units.mouseover.guid,'queued eligible player proceeds after the user closes native Inspect')
-- Raid eligibility uses normal unit GUIDs, without sweeping arbitrary players.
local oldRaid=IsInRaid;IsInRaid=function() return true end;groupCount=1
units.raid1={guid='Player-Schedule-RAID',name='Raid One',class='ROGUE',level=30};clock=clock+6
I.Group('GROUP_ROSTER_UPDATE');I.InspectPump();I.InspectReady(units.raid1.guid)
check(#calls==7 and calls[7].guid==units.raid1.guid,'raid teammate uses the same bounded inspection path');IsInRaid=oldRaid
local initial=#calls;units.target={guid='Player-Schedule-CASUAL',name='Casual Visitor'}
I.Observe('target','PLAYER_TARGET_CHANGED');clock=clock+6;I.InspectPump()
check(#calls==initial,'ordinary unimportant targets do not start routine inspection')
ns.Chronicle.SetEnabled(false);clock=clock+600;I.Group('GROUP_ROSTER_UPDATE');I.Important('target','control','personal bookmark');I.InspectPump()
check(#calls==initial,'paused recording prevents automatic inspection requests')
check(forbiddenRegistrations==0 and S.CONSENT==5,'inspection scheduling preserves consent and protected API boundaries')
NotifyInspect=notify;schedulingChecks=checks-before
''')
summary={'version':'1.1.0','assertions':lua.globals().schedulingChecks,'failed':0,'automaticPerPlayerBackoffSeconds':300,'globalRequestSpacingSeconds':5,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'preview5-scheduling-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
