from pathlib import Path
import json,time,zipfile,hashlib
o=Path(__file__).resolve().parent;r=o.parents[1];start=time.perf_counter()
source=(o/'test-relay-transport.py').read_text().split('start=time.perf_counter()')[0]
h={'__file__':str(o/'test-relay-transport.py')};exec(compile(source,'Relay peer fixtures','exec'),h)
peer,drive=h['peer'],h['drive'];cases=[]
def strict(l):
    l.execute(r'''
    function UnitName() return characterName:match('^(%S+) (.+)$') end;UnitFullName=UnitName
    C_ChatInfo.SendAddonMessage=function(prefix,wire,channel,target)
      if target:find('%-ClassicBetaPvP$') then return 3 end
      sent[#sent+1]={prefix=prefix,wire=wire,channel=channel,target=target,at=clock};return 0
    end
    ''')
baseline=r/'OlympusWarden-v1.1.1-preview4.zip'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='d630614b8656653610fc8f35e4bf5f0158a0a72d364e857e7d2e2e6c4fbc1b3a'
with zipfile.ZipFile(baseline) as z:old_transport=z.read('OlympusChatWarden/RelayTransport.lua').decode()
old=peer('Olympus Wardn');strict(old)
old.execute('return assert(loadstring(...))',old_transport)('OlympusChatWarden',old.globals().ns)
old.execute('ns.RelayTransport.Initialize()')
old_id=h['send_report'](old);drive(old,old,seconds=35,split_sender=True)
assert old.globals().ns.RelayStore.Find(old_id).state=='pending' and len(old.globals().ns.RelayStore.db.inbox)==0
cases.append('verified Preview 4 reproduces pending with strict native targets')
# Upgrade the pending report in place; preserve the exact frozen wire and ID.
old_wire=old.globals().ns.RelayStore.Find(old_id).wire
current=(r/'OlympusChatWarden/RelayTransport.lua').read_text()
old.execute('return assert(loadstring(...))',current)('OlympusChatWarden',old.globals().ns)
old.execute('ns.RelayTransport.Initialize()');old.globals().clock+=31
assert old.globals().ns.RelayTransport.Try(old_id) is True
drive(old,old,seconds=35,split_sender=True)
assert old.globals().ns.RelayStore.Find(old_id).state=='received' and len(old.globals().ns.RelayStore.db.inbox)==1
assert old.globals().ns.RelayStore.Find(old_id).wire==old_wire
cases.append('Preview 5 delivers original waiting report without a duplicate')
for name in ['Olympus Wardn','Rune Escape']:
    for selftest in [False,True]:
        l=peer(name);strict(l);l.globals().selftest=selftest
        l.execute('''
        local S,P=ns.RelayStore,ns.RelayTransport
        assert(P.IsDeveloper())
        assert(P.WhisperTarget(P.LocalName())==characterName,'local full name must route without its realm')
        assert(P.WhisperTarget(characterName..'-ClassicBetaPvP')==characterName)
        assert(P.WhisperTarget(characterName:gsub(' ','-')..'-ClassicBetaPvP')==characterName,'native split surname normalizes before routing')
        assert(P.WhisperTarget('Example Friend-OtherRealm')=='Example Friend-OtherRealm','never strip a foreign realm')
        report=assert(S.New());if selftest then report.selfTestReceiver=P.LocalIdentity() end
        assert(S.Save(report.id,{module='relay',category='delivery',title='Routing check',description='Synthetic native routing fixture.',steps=''}))
        assert(S.Submit(report.id,''));assert(report.state~='received','API acceptance alone is not delivery')
        ''')
        drive(l,l,seconds=35,split_sender=True)
        l.execute('''
        local S,P=ns.RelayStore,ns.RelayTransport
        assert(report.state=='received' and #S.db.inbox==1,'real protocol handlers must reach one final receipt')
        local wire=S.db.inbox[1].wire
        for _,msg in ipairs(sent) do assert(not msg.target:find('%-ClassicBetaPvP$'),'every HELLO/data/control route uses the native whisper target') end
        P.Handle(P.PREFIX,'H|1|'..report.id..'|'..math.ceil(#report.wire/P.CHUNK)..'|'..#report.wire..'|'..report.checksum,'WHISPER',characterName..'-ClassicBetaPvP')
        assert(#S.db.inbox==1 and S.db.inbox[1].wire==wire,'duplicate handshake never duplicates report')
        S.db=nil;S.Initialize();assert(S.Find(report.id).state=='received' and #S.db.inbox==1,'local submitted and incoming records persist through store reinitialization')
        ''');cases.append(name+(' self-test' if selftest else ' normal report'))
# A real received body without a final acknowledgement must remain pending.
a=peer('Example Reporter');b=peer('Olympus Wardn');strict(a);strict(b)
rid=h['send_report'](a)
drive(a,b,seconds=35,drop=lambda p,m:p==b and m.wire.startswith('A|'))
assert a.globals().ns.RelayStore.Find(rid).state=='pending' and len(b.globals().ns.RelayStore.db.inbox)==1
a.globals().clock+=31;assert a.globals().ns.RelayTransport.Try(rid) is True
drive(a,b,seconds=35)
assert a.globals().ns.RelayStore.Find(rid).state=='received' and len(b.globals().ns.RelayStore.db.inbox)==1
cases.append('lost acknowledgement and idempotent retry')
h={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'UI host','exec'),h)
l=h['fresh']('modern',True)
l.execute('''
local W,S=ns.Workspace,ns.RelayStore
W.Open('relay');local p=W.pages.relay
assert(not p.send:IsEnabled() and p.sendReason:GetText():find('Enter a title',1,true))
p:Preview();assert(not p.send:IsEnabled() and p.sendReason:GetText():find('Enter a title',1,true))
p.title:SetText('Example');p.description:SetText('A synthetic report.');p:Preview()
assert(p.send:IsEnabled() and p.sendReason:GetText():find('Ready',1,true))
p.description:SetText('A real change.');assert(p.send:IsEnabled() and not p.previewWire)
p:SetView('mine');assert(p.heroTitle:GetText()=='My Reports')
p:SetView('diagnostics');assert(p.heroTitle:GetText()=='Advanced Support Tools')
W.Open('overview');local home=W.pages.overview;home:Refresh(true)
assert(home.stateLabels[2]:GetText()=='Adventure recording')
assert(home.states[2]:GetText():find('opt in to start',1,true),'no consent is distinct from module disable')
assert(home.heroSummary:GetText():find('optional modules running',1,true))
assert(#home.list.items>=1 and home.list.items[1].data.page=='recording','empty dashboard has a useful recording shortcut')
assert(not ns.Chronicle.Active(),'UI polish does not opt into recording')
''');cases.append('review clarity and recording consent empty state')
# Model a wider native font than the default fixture, then build the sidebar.
l=h['fresh']('modern',True)
l.execute('''
local methods=getmetatable(UIParent).__index
local original=methods.GetStringWidth
function methods:GetStringWidth() return #(self.text or '')*(self.font and self.font[2] or 16)*.75 end
ns.Workspace.Open('overview')
for _,b in pairs(ns.Workspace.navigation) do
 assert(b.Caption:GetStringWidth()<=b.Caption:GetWidth()-4,'complete native label fits beside its crest')
 assert(b.Icon.ChatWardenIconBox.size==60,'crest stays enlarged')
end
methods.GetStringWidth=original
''');cases.append('wide native font fits full sidebar labels')
l=h['fresh']('modern',True,installation='new')
l.execute('''
assert(ns.DB.chatCapture.enabled==false and ns.ChatCapture.db.enabled==false,'new install Chat Capture defaults off')
ns.Modules.Preset(true);assert(ns.DB.chatCapture.enabled==false,'Full Suite does not grant chat-capture consent')
ns.Modules.Set('chat',false);ns.Modules.Set('chat',true)
assert(ns.ChatCapture.db.enabled==false,'module switching leaves capture off')
ns.ChatCapture.SetOption('enabled',true)
ns.Modules.Set('chat',false);ns.Modules.Set('chat',true)
assert(ns.DB.chatCapture.enabled==true and ns.ChatCapture.db.enabled==true,'an explicit existing capture choice is preserved')
ns.ChatCapture.SetOption('enabled',false);ns.ChatCapture.Initialize()
assert(ns.ChatCapture.db.enabled==false,'reinitialization keeps a saved off choice')
''');cases.append('Chat Capture defaults off and preserves explicit choices')
l=h['fresh']('modern',True)
l.execute('''
Settings={RegisterCanvasLayoutCategory=function(frame,name) return {name=name,ID=1} end,
 RegisterAddOnCategory=function() end,RegisterCanvasLayoutSubcategory=function(parent,frame,name) return {name=name,ID=2} end}
local methods=getmetatable(UIParent).__index;function methods:SetNumeric(value) self.numeric=value end
local subcategories=0;local native=Settings.RegisterCanvasLayoutSubcategory
Settings.RegisterCanvasLayoutSubcategory=function(...) subcategories=subcategories+1;return native(...) end
ns.BuildOptions('general');ns.BuildOptions('chronicle');ns.BuildOptions('shield')
assert(subcategories==0,'only the unified Olympus Warden native category remains')
assert(ns.OptionsPanel and ns.ChronicleOptionsPanel and ns.ShieldOptionsPanel,'feature preferences remain available inside Warden')
ns.OpenChronicleOptions();assert(ns.Workspace.mounted==ns.ChronicleOptionsPanel,'recording settings still open in the suite')
Settings.RegisterCanvasLayoutSubcategory=native
''');cases.append('one native settings entry with retained embedded preferences')
l.execute('''
local B=ns.WardenBrand
GameTooltip=CreateFrame('Frame');GameTooltip.NumLines=function() return 3 end
GameTooltipTextLeft1=CreateFrame('FontString');GameTooltipTextLeft1:SetText('123.4 MB OlympusChatWarden')
GameTooltipTextLeft2=CreateFrame('FontString');GameTooltipTextLeft2:SetText('12.3 MB OtherOlympusChatWardenPlugin')
GameTooltipTextLeft3=CreateFrame('FontString');GameTooltipTextLeft3:SetText('3.2 MB OtherAddon')
GameTooltipTextRight1=CreateFrame('FontString');GameTooltipTextRight1:SetText('12.34%')
B.UsageTooltip()
assert(GameTooltipTextLeft1:GetText()=='123.4 MB Olympus Warden','only the usage label changes')
assert(GameTooltipTextLeft2:GetText()=='12.3 MB OtherOlympusChatWardenPlugin')
assert(GameTooltipTextLeft3:GetText()=='3.2 MB OtherAddon' and GameTooltipTextRight1:GetText()=='12.34%')
local hook=hooksecurefunc;local hooked=0
function MainMenuBarPerformanceBarFrame_OnEnter() end
hooksecurefunc=function(name,fn) assert(name=='MainMenuBarPerformanceBarFrame_OnEnter' and fn==B.UsageTooltip);hooked=hooked+1 end
B.usageTooltipHooked=nil;assert(B.InstallUsageTooltip());assert(B.InstallUsageTooltip());assert(hooked==1,'native tooltip hook installs once')
hooksecurefunc=hook
''');cases.append('native performance tooltip display name without changing metrics or other addons')
result={'version':'1.1.1-preview6','failed':0,'scenarios':cases,'nativeClientTested':False,'seconds':time.perf_counter()-start}
(o/'preview5-polish-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
