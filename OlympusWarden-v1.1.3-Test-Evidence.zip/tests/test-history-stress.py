from pathlib import Path
import json,time,struct,hashlib,base64,os
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'recorder-baseline','exec'),state)
lua=state['lua'];metrics={}
def measure(name,fn):
 start=time.perf_counter();r=fn();metrics[name]=round(time.perf_counter()-start,4);return r
def packed_route(start):
 previous={};raw=[b'OCWR',bytes([60])]
 for i in range(60):
  at=start+i*2;point=[at,at-1800000000,.123456789+i*.000017,.87654321-i*.000013,False,False,False,False,7,at,at-1800000000,1]
  for j,v in enumerate(point):
   if v is False:raw.append(bytes([9]));continue
   value=struct.pack('>d',v);old=previous.get(j);prefix=0
   if old:
    while prefix<8 and value[prefix]==old[prefix]:prefix+=1
   raw.append(bytes([prefix])+value[prefix:]);previous[j]=value
 data=b''.join(raw)
 return lua.table_from(dict(format=2,mapID=37,count=60,data=base64.b64encode(data).decode(),sha256=hashlib.sha256(data).hexdigest(),firstAt=start,lastAt=start+118,firstElapsed=start-1800000000,lastElapsed=start+118-1800000000,observations=60))
lua.globals().makePackedRoute=packed_route
lua.execute(r'''
local beforeChecks=checks
C.Clear();C.SetEnabled(true);C.SetEnabled(false)
owner=C.Owner();c=ledger();baseAt=1800001000
function append(kind,at,details,route,subject,source)
 return S.Append(owner,{kind=kind,source=source or 'checkpoint',session=c.currentSession,at=at,elapsed=at-1800000000,
 timeSource='server',evidence='observed',details=details,location={zone='Stress test zone'},route=route,subject=subject})
end
startCount=#c.events;startProfiles=S.Statistics(owner).profiles
function fillHistory(day1,day2)
 for day=day1,day2 do
  local start=baseAt+day*86400
  for segment=0,119 do
   local route=makePackedRoute(start+segment*120)
   assert(append('route_segment',route.lastAt,{segment=owner..':route:'..day..':'..segment,pointCount=60},route))
  end
  for i=1,48 do
   local at=start+i*300
   assert(append('time_span',at,{seconds=300,samples=10,firstAt=at-300,lastAt=at,firstElapsed=at-300-1800000000,lastElapsed=at-1800000000}))
  end
  for i=1,100 do
   local guid='Player-Stress-'..((day*100+i)%2000)
   assert(append('native_event',start+100+i,{recordType='native_kill_credit',attackerGUID='Player-Home-01',targetGUID=guid,entityKind='Player',credit='self native credit'},nil,guid,'PARTY_KILL'))
  end
 end
end
function fillProfiles()
 for i=1,2000 do S.Observe(owner,'Player-Stress-'..i,{name='Observed player '..i,level=30},baseAt,'PLAYER_TARGET_CHANGED',{}) end
end
function serializeSaved(db)
 local out={};local function emit(v)
  if type(v)=='table' then out[#out+1]='{';for k,item in pairs(v) do out[#out+1]='[';emit(k);out[#out+1]=']=';emit(item);out[#out+1]=',' end;out[#out+1]='}'
  elseif type(v)=='string' then out[#out+1]=string.format('%q',v)
  elseif type(v)=='number' then out[#out+1]=string.format('%.17g',v)
  elseif type(v)=='boolean' then out[#out+1]=v and 'true' or 'false'
  else error('unsupported trusted fixture value') end
 end
 out[#out+1]='return ';emit(db or ns.DB.chronicle);return table.concat(out)
end
stressBaseChecks=beforeChecks
''')
print('Building 180-day / 720-hour moving-route history',flush=True)
for month in range(6):
 measure('month_'+str(month+1)+'_ingest_seconds',lambda m=month:lua.globals().fillHistory(m*30,m*30+29))
 print('Month',month+1,'ingested',flush=True)
measure('profiles_seconds',lua.globals().fillProfiles)
lua.execute('c.revision=(c.revision or 0)+1') # Force an actual scan, not the incremental cache.
measure('statistics_rebuild_seconds',lambda:lua.execute('stats=S.Statistics(owner)'))
measure('statistics_cached_seconds',lambda:lua.execute('for i=1,1000 do assert(S.Statistics(owner)==stats) end'))
measure('ui_first_and_older_page_seconds',lambda:lua.execute("local a,more=ns.RecordingUI.Query({owner=owner,page=0});check(#a==50 and more,'first page bounded for large history');local b=ns.RecordingUI.Query({owner=owner,page=100});check(#b==50,'older page available')"))
lua.execute(r'''
check(#c.events==startCount+180*(120+48+100),'all months retained with no rolloff')
check(stats.seconds==180*4*3600 and stats.selfNativeCredits==18000,'time and native credit totals survive long history')
check(stats.profiles==startProfiles+2000 and stats.combatPlayers==2000,'large profile and evidence counts accurate')
check(S.Storage().events==#c.events,'large-history diagnostics match records')
local first,last
for _,e in ipairs(c.events) do if e.route then first=first or e;last=e end end
check(ns.ChronicleCodec.Decode(first.route) and ns.ChronicleCodec.Decode(last.route),'independently packed first/last moving routes decode exactly')
largeEventCount=#c.events;largeEstimatedBytes=c.bytes
''')
print('Serializing and loading trusted synthetic SavedVariables fixture',flush=True)
saved=measure('savedvariables_serialize_seconds',lua.globals().serializeSaved)
metrics['serializedLuaBytes']=len(saved.encode('utf-8'))
lua.globals().trustedSavedVariables=saved
# The plain table form exposes the standard Lua5.1 constant-table boundary.
measure('monolithic_lua_compile_seconds',lambda:lua.execute('plainFn,plainError=loadstring(trustedSavedVariables)'))
metrics['monolithicFixtureLoadSucceeded']=lua.globals().plainFn is not None
metrics['monolithicFixtureCompilerMessage']=lua.globals().plainError
lua.execute("plainFn=nil;plainError=nil;trustedSavedVariables=nil;collectgarbage('collect')")
del saved
measure('bounded_chunks_pack_seconds',lambda:lua.execute('savedRepresentation=assert(ns.ChronicleBackup.PackSaved(S.db))'))
saved=measure('bounded_chunks_serialize_seconds',lambda:lua.globals().serializeSaved(lua.globals().savedRepresentation))
metrics['chunkedSerializedLuaBytes']=len(saved.encode('utf-8'))
lua.globals().trustedSavedVariables=saved
measure('savedvariables_lua_load_seconds',lambda:lua.execute('loaded=assert(loadstring(trustedSavedVariables))()'))
measure('normalize_loaded_history_seconds',lambda:lua.execute('normalized=assert(S.Normalize(loaded))'))
lua.execute("check(#normalized.characters[owner].events==largeEventCount,'large chunked SavedVariables reload preserves every event');check(normalized.characters[owner].bytes==largeEstimatedBytes,'large reload rebuilds size estimate consistently');check(#loaded.characters[owner].eventChunks>1000,'large saved representation uses bounded opaque chunks');loaded=nil;normalized=nil;trustedSavedVariables=nil;savedRepresentation=nil;collectgarbage('collect')")
del saved
metrics['largeEvents']=int(lua.globals().largeEventCount);metrics['estimatedRetainedBytes']=int(lua.globals().largeEstimatedBytes)
metrics['routeSamples']=180*120*60;metrics['modeledDays']=180;metrics['modeledRecordedHours']=720
# Multipart text backup/restore is benchmarked separately at a declared smaller
# scale, rather than pretending thousands of manual parts are a practical backup.
print('Benchmarking multipart text backup/restore with linked objects',flush=True)
lua.execute(r'''
C.Clear();C.SetEnabled(true)
X=ns.ChronicleCapture;B=ns.ChronicleBackup
local hash=X.Store('appearance',{guid='Player-Home-01',raceID=1,sex=2,exact=false},'control')
for i=1,2000 do clock=clock+1;assert(X.Record('important_player','control',{relationship='test teammate',appearanceRef=hash,appearanceObservedAt=GetServerTime()},'Player-Stress-1',false)) end
C.SetEnabled(false);textEventCount=#ledger().events
''')
measure('text_backup_seconds',lambda:lua.execute('backup=assert(B.Create())'))
lua.execute('textPartCount=backup.total;C.Clear()')
measure('text_reverse_restore_seconds',lambda:lua.execute("for i=#backup.parts,1,-1 do local ok,err=B.Restore(backup.parts[i]);assert(ok,err) end"))
lua.execute("check(#ledger().events==textEventCount,'stress text restore has all linked records and no duplicate object events');check(not S.db.enabled,'stress restore never enables collection');check(backup.total>10,'multipart benchmark spans many independent parts');stressChecks=checks-stressBaseChecks")
metrics['textEvents']=int(lua.globals().textEventCount);metrics['textParts']=int(lua.globals().textPartCount)
summary={'version':'1.0.3','assertions':int(lua.globals().stressChecks),'failed':0,'metrics':metrics,'liveWoWTested':False,
 'limits':'Synthetic Lua5.1 host timings, not WoW startup/UI FPS or a guarantee for unlimited datasets. Full-file reload tested at 180 modeled days; multipart text tested separately at 2000 linked records. No expiry added.'}
(out/'history-stress-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
