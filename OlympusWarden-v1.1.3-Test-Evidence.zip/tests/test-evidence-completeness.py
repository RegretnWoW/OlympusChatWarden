from pathlib import Path
import json,time
out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(),'completeness-host','exec'),scope)
lua=scope['lua'];started=time.perf_counter()
lua.execute(r'''
local before=checks;local X,M,T,B=ns.ChronicleCapture,ns.ChronicleCombat,ns.ChronicleTransitions,ns.ChronicleBackup
freshRecording();local function pump() for n=1,250 do X.Pump() end end;pump()
local function native(kind) local out={};for _,e in ipairs(all('native_event')) do if e.details.recordType==kind then out[#out+1]=e end end;return out end
local function scores() local out={};for _,e in ipairs(all('native_snapshot')) do if e.capture.family=='scoreboard' then out[#out+1]=e end end;return out end
GetInstanceInfo=function() return 'Warsong fixture','pvp',1,'Battleground',10,0,false,489 end
local flags=1;local hasGUID=true;local readable=true
GetNumBattlefieldScores=function() return 1 end
C_PvP={GetScoreInfo=function(i) if not readable then return end;return {guid=hasGUID and 'Player-Objective-ONE' or nil,name='Runner',killingBlows=0,deaths=0,damageDone=100,healingDone=0,stats={{pvpStatID=901,pvpStatValue=flags}}} end}
M.Handle('PVP_MATCH_ACTIVE');M.Handle('UPDATE_BATTLEFIELD_SCORE');pump()
local row=scores()[#scores()];local report=row.capture.values.matchSequence
check(row and row.capture.values.phase=='in-progress' and row.capture.values.objectives[1][2]==1,'in-progress scoreboard retained before match completion')
local count=#scores();M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(#scores()==count,'unchanged in-progress observation coalesces')
flags=2;M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(#scores()==count+1,'changed objective retained during play')
hasGUID=false;M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(not scores()[#scores()].capture.values.guid,'missing GUID is not donated by a same-name target')
M.Handle('PVP_MATCH_COMPLETE',1,500);pump();row=scores()[#scores()]
check(row.capture.values.matchSequence==report and row.capture.values.phase=='completion observation','observed active and completion rows share provisional context but retain phase')
local completion=#native('pvp_match_complete');readable=false;M.Handle('PVP_MATCH_ACTIVE');M.Handle('PVP_MATCH_COMPLETE',0,100);pump()
check(#native('pvp_match_complete')==completion+1 and #scores()==count+3,'completion survives missing final scoreboard; earlier rows retained')
readable=true;hasGUID=true;M.Handle('PVP_MATCH_ACTIVE');M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(scores()[#scores()].capture.values.matchSequence>report,'consecutive same-instance battlegrounds have distinct local sequences')
local old=C_PvP.GetScoreInfo;C_PvP.GetScoreInfo=function(i) local value=old(i);M.Handle('PVP_MATCH_ACTIVE');return value end
count=#scores();M.Handle('UPDATE_BATTLEFIELD_SCORE');pump();check(#scores()==count,'native epoch changes while copying reject stale data');C_PvP.GetScoreInfo=old
-- Boss payload is copied synchronously, with an exact parent ledger reference.
local payload={{creatureID=123,creatureName='Native Boss',remainingHealthPercent=2.5},{creatureID=124,creatureName='Second Boss',remainingHealthPercent=0}}
M.Handle('ENCOUNTER_END',901,'Encounter',1,5,0,payload);payload[1].remainingHealthPercent=99
local bosses=native('boss_status_observed');local e=bosses[#bosses-1];local ends=native('encounter_ended');local parent=ends[#ends]
check(e.details.remainingHealthPercent==2.5 and e.details.encounterRef==parent.id and e.source=='ENCOUNTER_END','native boss health copied at delivery and linked to original encounter boundary')
check(bosses[#bosses].details.remainingHealthPercent==0 and parent.details.bossStatusComplete==true,'confirmed zero boss health is preserved and not treated as absent')
M.Handle('ENCOUNTER_END',902,'No status',1,5,1);parent=native('encounter_ended')[#native('encounter_ended')]
check(parent.details.success==1 and parent.details.bossStatusComplete==false and parent.details.bossStatusReadCount==0,'native victory survives missing optional payload without invented boss facts')
local rows,total,complete=T.Bosses({{creatureID=123,remainingHealthPercent=101},{creatureName='Name only'}})
check(#rows==2 and not complete and not rows[1].remainingHealthPercent,'invalid percentage stays unavailable while readable identity is retained')
local many={};for n=1,75 do many[n]={creatureID=n,creatureName='Boss '..n,remainingHealthPercent=50} end
rows,total,complete=T.Bosses(many);check(#rows==40 and total==75 and complete==false,'boss payload work is bounded with explicit total and partial status')
-- Structured receipts preserve native delivery, never a guessed acquisition cause.
local link='|cffa335ee|Hitem:12345::::::::60:::::::::|h[Fixture item]|h|r'
T.Handle('QUEST_LOOT_RECEIVED',990,link,2);T.Handle('QUEST_LOOT_RECEIVED',990,link,2)
local receipts=native('quest_item_received');e=receipts[#receipts]
check(#receipts==2 and e.details.itemID==12345 and e.details.quantity==2 and e.details.questID==990 and e.details.itemString:find('item:12345',1,true)==1,'distinct native receipts retain item string, quantity and quest without content dedup losing deliveries')
check(e.details.evidenceClass=='native-event' and not e.details.gearRef,'receipt is native evidence without unrelated configuration')
T.Handle('QUEST_CURRENCY_LOOT_RECEIVED',990,200,15);e=native('quest_currency_received')[1]
check(e.details.currencyID==200 and e.details.quantity==15 and e.details.questID==990,'structured currency reward retained separately from balance snapshots')
T.Handle('ENCOUNTER_LOOT_RECEIVED',901,12345,link,1,'Someone Else','MAGE');e=native('encounter_loot_delivery')[1]
check(e.details.scope=='recipient unknown' and not e.subject and not e.details.name and e.details.outcomeScope=='recipient-unknown','recipient-less encounter event never claims own acquisition or parses optional names as players')
count=#native('quest_item_received');T.Handle('QUEST_LOOT_RECEIVED',990,'invalid',1);T.Handle('QUEST_LOOT_RECEIVED',990,link,-1)
check(#native('quest_item_received')==count,'malformed reward item and quantity rejected')
local prior=issecretvalue;issecretvalue=function(v) return v==424242 end;T.Handle('QUEST_LOOT_RECEIVED',990,link,424242)
check(#native('quest_item_received')==count,'restricted quantity cannot be treated as confirmed receipt');issecretvalue=prior
-- Own configuration references cannot leak into other-player evidence.
GetInventoryItemID=function(u,slot) if u=='player' and slot==1 then return 555 end end
GetInventoryItemLink=function(u,slot) if u=='player' and slot==1 then return 'item:555' end end
GetInventoryItemTexture=function() return nil end
local guid=UnitGUID('player');local gear=ns.ChronicleLoadout.Gear('player',guid,'control')
if gear then X.refs.gear={hash=gear,at=C.Stamp()} end
e=X.Record('important_player','control',{relationship='fixture'},'Player-Other-ONE');check(not e.details.gearRef,'other player record excludes observer configuration references')
-- Event and actual read timing remain distinct when delayed gear changes.
local trigger=C.Stamp();local tick=C.Tick();ns.ChronicleLoadout.Milestone('BOSS_KILL','fixture boundary');clock=clock+5;pump()
local observed;for _,v in ipairs(all('loadout_observed')) do if v.details.reason=='fixture boundary' then observed=v end end
check(observed and observed.details.triggerAt==trigger and observed.details.observedAt==C.Stamp() and observed.details.triggerElapsed==tick and observed.details.triggerGUID==guid,'queued configuration keeps original trigger identity/date and actual read date')
ns.ChronicleCoverage.Flush(true)
local packed=assert(B.PackSaved(S.db));local restored=assert(S.Normalize(packed))
check(B.Encode(restored.characters[C.Owner()].events)==B.Encode(S.Character(C.Owner(),false).events),'new scoreboard, receipt, boss, coverage and provenance fields survive canonical chunked save/reload')
count=#native('quest_item_received');C.SetEnabled(false);T.Handle('QUEST_LOOT_RECEIVED',990,link,1)
check(#native('quest_item_received')==count,'paused recording does not collect native reward payloads')
check(forbiddenRegistrations==0,'no raw combat logging or chat receipt parser added')
completenessChecks=checks-before
''')
result={'version':'1.1.0','assertions':int(lua.globals().completenessChecks),'failed':0,'actualForeverTest':False,'seconds':time.perf_counter()-started}
(out/'evidence-completeness-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
