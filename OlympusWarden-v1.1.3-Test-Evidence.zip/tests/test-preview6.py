from pathlib import Path
import json,time,hashlib,zipfile
o=Path(__file__).resolve().parent;r=o.parents[1];start=time.perf_counter();cases=[]
h={'__file__':str(o/'test-relay-transport.py')};exec(compile((o/'test-relay-transport.py').read_text().split('start=time.perf_counter()')[0],'Relay fixtures','exec'),h)
peer,drive=h['peer'],h['drive']
baseline=r/'OlympusWarden-v1.1.1-preview5.zip'
assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='c3c854f06cdad3f27aba4f7722cd0ecf96cdbc853252b0c2fc82eaba73bd22c2'
with zipfile.ZipFile(baseline) as z:old_transport=z.read('OlympusChatWarden/RelayTransport.lua').decode()
l=peer('Olympus Wardn');l.execute('C_ChatInfo.AreOutgoingAddonChatMessagesRestricted=function() return true end')
l.execute('return assert(loadstring(...))',old_transport)('OlympusChatWarden',l.globals().ns);l.execute('ns.RelayTransport.Initialize()')
rid=h['send_report'](l);drive(l,l,seconds=30)
assert len(l.globals().sent)==0 and l.globals().ns.RelayStore.Find(rid).state=='pending'
wire=l.globals().ns.RelayStore.Find(rid).wire
l.execute('return assert(loadstring(...))',(r/'OlympusChatWarden/RelayTransport.lua').read_text())('OlympusChatWarden',l.globals().ns)
l.execute('ns.RelayTransport.Initialize()');l.globals().clock+=31;assert l.globals().ns.RelayTransport.Try(rid) is True
drive(l,l,seconds=30)
assert l.globals().ns.RelayStore.Find(rid).state=='received' and len(l.globals().ns.RelayStore.db.inbox)==1
assert l.globals().ns.RelayStore.Find(rid).wire==wire
assert l.globals().ns.RelayTransport.lastSendDetail.restricted=='yes'
cases.append('Preview 5 preflight reproduced; Preview 6 retries exact report using native result')
for mode in ['false','enum','throw','opaque','legacy_nil','legacy_true','advisory_throw']:
    l=peer('Olympus Wardn');l.globals().testMode=mode
    l.execute('''
    local original=C_ChatInfo.SendAddonMessage
    Enum={SendAddonMessageResult={Success=0,InvalidTarget=3}}
    C_ChatInfo.AreOutgoingAddonChatMessagesRestricted=function() if testMode=='advisory_throw' then error('query error') end;return true end
    C_ChatInfo.SendAddonMessage=function(...)
      nativeCalls=(nativeCalls or 0)+1
      if testMode=='false' then return false elseif testMode=='enum' then return 3
      elseif testMode=='throw' then error('PRIVATE_API_ERROR') elseif testMode=='opaque' then return 'PRIVATE_RESULT' end
      original(...);if testMode=='legacy_nil' then return nil elseif testMode=='legacy_true' then return true else return 0 end
    end
    local readable=ns.Readable;ns.Readable=function(v) if v=='PRIVATE_RESULT' then return false end;return readable(v) end
    ''')
    rid=h['send_report'](l);l.globals().ns.RelayTransport.Pump()
    report=l.globals().ns.RelayStore.Find(rid);detail=l.globals().ns.RelayTransport.DeliveryDetail()
    assert l.globals().nativeCalls==1 and 'PRIVATE' not in detail
    if mode in ['false','enum','throw','opaque']:
        assert report.state=='pending' and 'readiness request' in report.status and report.wire
        if mode=='enum': assert 'InvalidTarget (3)' in report.status
    else:
        assert report.state=='sending';drive(l,l,seconds=30);assert report.state=='received'
cases.append('native refusals, exceptions, inaccessible results and legacy successes remain honest')
h={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'context fixtures','exec'),h)
keys=['chat','chronicle','intel','shield','alerts'];mat=[]
for bits in range(32):
    selection={k:bool(bits&(1<<n)) for n,k in enumerate(keys)}
    l=h['fresh']('modern',True,selection=selection)
    l.execute('''
    local M,P=ns.Modules,ns.OlympusPanel
    function GetRealmName() return 'Test Realm' end
    function UnitFullName() return 'Fixture Character','Test Realm' end;UnitName=UnitFullName
    function UnitGUID(unit) return unit=='player' and 'Player-Fixture-01' or nil end
    local request,owner,profile,character=ns.ChronicleActivities.Request,ns.Chronicle.Owner,ns.Chronicle.Profile,ns.ChronicleStore.Character
    if not M.Enabled('history') then
      ns.ChronicleActivities.Request=function() error('disabled historical request') end
      ns.Chronicle.Owner=function() error('disabled owner lookup') end
      ns.ChronicleStore.Character=function() error('disabled character lookup') end
    end
    if not M.Enabled('intel') then ns.Chronicle.Profile=function() error('disabled dossier lookup') end end
    local page=CreateFrame('Frame',nil,UIParent);page:SetSize(326,360);P.Build(page);local v=page.warden
    local visible=0;for _,card in ipairs(v.features) do if card:IsShown() then visible=visible+1;assert(card.toggle:GetWidth()>=40) end end
    local expected=0;for _,id in ipairs(M.order) do if M.Enabled(id) then expected=expected+1 end end
    assert(visible==expected,'cards follow exact module selection')
    for _,b in ipairs(v.filters) do if b.filter~='all' then local module=b.filter=='signals' and 'alerts' or b.filter;assert(b:IsShown()==M.Enabled(module),'filters follow module ownership') end end
    if not M.Enabled('intel') then assert(v.target:GetText()=='Command') end
    if expected==0 then
      ns.Activity.Add('disabled-old-alert','mentions',{sender='Retained Friend',preview='Old retained alert',timestamp=1800000000})
      P.Refresh(page);assert(#v.listView.items==0 and v.activityHeading:GetText():find('0 unread',1,true),'disabled retained streams cannot produce phantom unread activity')
    end
    if M.Enabled('intel') and not M.Enabled('chronicle') then assert(v.features[4].state~='On','Intel cannot claim personal recording is on') end
    if M.Enabled('history') then
      ns.ChronicleStore.loading={};P.Refresh(page);assert(v.empty:GetText():find('Loading retained history',1,true))
      ns.ChronicleStore.loading=nil;page.scripts.OnUpdate(page,1);assert(not v.historyLoading,'empty-history loading completion still refreshes without a new event')
    end
    for n=1,4 do page.scripts.OnUpdate(page,1) end
    page:Hide();page.scripts.OnUpdate(page,10);page:Show()
    ns.ChronicleActivities.Request,ns.Chronicle.Owner,ns.Chronicle.Profile,ns.ChronicleStore.Character=request,owner,profile,character
    local function Menu() local t={items={}}
      function t:CreateButton(label,fn) local b=Menu();b.label=label;b.fn=fn;self.items[#self.items+1]=b;return b end
      function t:CreateTitle(label) self.items[#self.items+1]={title=label} end
      function t:CreateDivider() end
      return t
    end
    local function Buttons(t) local out={};for _,item in ipairs(t.items) do if item.label then out[item.label]=item end end;return out end
    local root=Menu();ns.ChatReports.BuildMenu(nil,root,{name='Other Friend',server='Test Realm',chatFrame=UIParent})
    assert(#root.items==1 and root.items[1].label=='Olympus Warden','single branded parent preserves original native menu')
    local buttons=Buttons(root.items[1]);assert((buttons['Report missed filter']~=nil)==M.Enabled('chat'))
    assert((buttons['Shield for 15 minutes']~=nil)==M.Enabled('shield'),'Shield action is independent of Chat')
    local portrait=Menu();ns.ChatReports.BuildMenu(nil,portrait,{name='Other Friend',server='Test Realm'})
    assert(not Buttons(portrait.items[1])['Report missed filter'],'general native contexts get no chat actions')
    local self=Menu();ns.ChatReports.BuildMenu(nil,self,{name='Fixture Character',server='Test Realm',chatFrame=UIParent});assert(#self.items==0)
    if buttons['Shield for 15 minutes'] then
       M.Set('chat',false);ns.DB.enabled=false;buttons['Shield for 15 minutes'].fn()
       assert(#ns.Shield.List()==1,'Shield works with Chat paused or disabled')
       M.Set('shield',false);local count=#ns.Shield.List();buttons['Shield for 15 minutes'].fn();assert(#ns.Shield.List()==count and not M.Selected('shield'),'stale action cannot reactivate Shield')
    end
    if M.Enabled('chat') then
      v.filter='chat';P.Refresh(page);M.Set('chat',false);P.Refresh(page);assert(v.filter=='all','disabled selected filter falls back to All')
    end
    ''');mat.append(selection)
cases.append('32 module combinations: independent contextual actions, adaptive panel and cold history isolation')
# Exact clicked message, late hyperlink and unavailable IDs retain manual fallback.
l=h['fresh']('modern',True)
l.execute('''
local C=ns.ChatReports
function GetRealmName() return 'Test Realm' end
function UnitFullName() return 'Self Person','Test Realm' end;UnitName=UnitFullName
local function Menu() local t={items={}};function t:CreateButton(label,fn) local b=Menu();b.label=label;b.fn=fn;self.items[#self.items+1]=b;return b end;function t:CreateTitle() end;return t end
local function Action(root,name) for _,b in ipairs(root.items[1].items) do if b.label==name then return b.fn end end end
local first=C.Capture('CHAT_MSG_SAY','first message','Similar One',301)
local second=C.Capture('CHAT_MSG_SAY','second message','Similar Two',302)
local original=ns.OpenReport;local draft
ns.OpenReport=function(_,_,d) draft=d end
C.OnClick(UIParent,'player:Similar One:301','', 'RightButton')
local one=Menu();C.BuildMenu(nil,one,{name='Similar One',chatFrame=UIParent})
C.OnClick(UIParent,'player:Similar Two:302','', 'RightButton')
local two=Menu();C.BuildMenu(nil,two,{name='Similar Two',chatFrame=UIParent})
Action(one,'Report missed filter')();assert(draft.original=='first message')
Action(two,'Report missed filter')();assert(draft.original=='second message')
C.OnClick(UIParent,'player:Similar One:0','', 'RightButton')
local missing=Menu();C.BuildMenu(nil,missing,{name='Similar One',chatFrame=UIParent});Action(missing,'Report missed filter')()
assert(draft.selection=='manual' and not draft.original,'unknown message never auto-selects another recent line')
local late=Menu();C.BuildMenu(nil,late,{name='Similar Two',chatFrame=UIParent})
C.OnClick(UIParent,'player:Similar Two:302','', 'RightButton');Action(late,'Report missed filter')();assert(draft.original=='second message')
ns.OpenReport=original
assert(not ns.RelayTransport.Busy() and #ns.RelayStore.db.reports==0,'local feedback never submits a Relay report')
local native=Menu();local whisper=function() end;native:CreateButton('Native whisper',whisper)
C.BuildMenu(nil,native,{name='Similar One',chatFrame=UIParent})
assert(#native.items==2 and native.items[1].fn==whisper and native.items[2].label=='Olympus Warden','Blizzard actions are retained beside one additive parent')
function UnitFullName(unit) if unit=='target' then return 'Similar','One' end;return 'Self','Person' end;UnitName=UnitFullName
function GetNormalizedRealmName() return 'TestRealm' end
C.OnClick(UIParent,'player:Similar-One-TestRealm:301','', 'RightButton')
local split=Menu();C.BuildMenu(nil,split,{name='Similar',surname='One',server='TestRealm',chatFrame=UIParent})
ns.OpenReport=function(_,_,d) draft=d end;Action(split,'Report missed filter')();assert(draft.original=='first message','split surnames resolve only the matching full identity')
ns.ChatCapture.SetOption('enabled',true)
ns.ChatCapture.Record('CHAT_MSG_SAY','captured first','Similar One',301)
local openCapture,openBookmark=ns.OpenCapturePlayer,ns.OpenCaptureBookmark
ns.OpenCapturePlayer=function() captureFallback=true end;ns.OpenCaptureBookmark=function() end
C.OnClick(UIParent,'player:Similar One:301','', 'RightButton');local captured=Menu();C.BuildMenu(nil,captured,{name='Similar One',chatFrame=UIParent})
Action(captured,'Bookmark this message')();assert(#ns.ChatCapture.db.bookmarks==1)
C.OnClick(UIParent,'player:Similar Two:302','', 'RightButton');local uncaptured=Menu();C.BuildMenu(nil,uncaptured,{name='Similar Two',chatFrame=UIParent})
Action(uncaptured,'Bookmark this message')();assert(#ns.ChatCapture.db.bookmarks==1 and captureFallback,'missing capture never bookmarks another line')
ns.OpenCapturePlayer,ns.OpenCaptureBookmark=openCapture,openBookmark
local session=ns.SessionTime;local now=session();ns.SessionTime=function() return now+C.MAX_AGE+1 end
Action(one,'Report missed filter')();assert(draft.selection=='manual' and not draft.original,'expired temporary records require explicit manual selection')
ns.SessionTime=session;ns.OpenReport=original
''');cases.append('accurate clicked messages, rapid menus, late links and manual fallback')
result={'version':'1.1.1-preview6','failed':0,'scenarios':cases,'contextConfigurations':len(mat),'nativeClientTested':False,'seconds':time.perf_counter()-start}
(o/'preview6-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
