from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
state={'__file__':str(out/'test-chronicle.py')}
exec(compile((out/'test-chronicle.py').read_text(encoding='utf-8'),'baseline','exec'),state)
lua=state['lua'];lua.execute(r'''
local before=checks
local R,G=ns.RecordingUI,ns.CollectionGuide
freshRecording();C.SetEnabled(false)
ns.Workspace.Open('recording');local view=ns.Workspace.pages.recording;view:SetView('coverage')
check(view.coverageList and #view.coverageList.items>=40,'clickable collection catalog includes all defined families even before values arrive')
check(#view.coverageList.rows<=12,'catalog uses a bounded scrollable row pool')
check(view.collectionSelected=='time','collection opens on readable recording/time explanation')
local known={}
for _,topic in ipairs(view.coverageList.items) do
 check(not known[topic.key],'catalog has unique key '..topic.key);known[topic.key]=true
 view:SelectCollection(topic.key)
 local headings={};local body=''
 for _,b in ipairs(view.coverageDocument.blocks) do if b.kind=='heading' then headings[b.text]=true end;body=body..b.text..'\n' end
 check(headings['What is saved'] and headings['When it records'] and headings['Illustrative example'] and headings.Limits and headings['Where to find it'],'complete explanation for '..topic.key)
 check(#body>250 and view.collectionSelected==topic.key,'specific nonempty detail for '..topic.key)
end
check(known.gear and known.traits and known.combat and known['Native kill credit'] and known.Skills and known.olympus,'important preservation areas have explicit collection topics')
view.coverageList:SetItems(view.coverageList.items,true)
click(view.coverageList.rows[2])
check(view.collectionSelected==view.coverageList.items[2].key,'actual row click opens its details')
click(view.statusHelp)
check(view.view=='coverage' and view.collectionSelected=='time','recording metric click works without hover')
view:SetView('events')
click(view.countHelp)
check(view.view=='coverage' and view.collectionSelected=='storage','event paging metric opens storage/count explanation')
local framesBefore=#frames;for i=1,20 do view:Refresh(true) end
check(#frames==framesBefore,'catalog refresh reuses existing rows and detail blocks')
view:SelectCollection('Player encounter locations');local details=view.coverageDocument:GetText()
check(details:find('two-minute',1,true) and details:find('never substitute',1,true),'encounter explanation preserves dedup and attribution boundary')
view:SelectCollection('gear');details=view.coverageDocument:GetText()
check(details:find('nineteen',1,true) and details:find('later inspection',1,true),'gear explanation names actual data and timing limit')
view:SelectCollection('Native kill credit');details=view.coverageDocument:GetText()
check(details:find('actor and target GUIDs',1,true) and details:find('not automatically a PvP win',1,true),'credit wording avoids unsupported victory claims')
view:SelectCollection('storage');details=view.coverageDocument:GetText()
check(details:find('Historical player tracks and gaps',1,true) and details:find('not measured disk',1,true),'size description explains retained legacy data and estimate boundary')
check(not S.db.enabled,'clicking explanations never enables recording')
view:SetView('backup')
check(view.backupMode=='file' and view.fileBackup:IsShown() and not view.textBackup:IsShown(),'complete-file method is the default backup view')
local path=view.savedFilePath:GetText()
check(path:find('WTF/Account/',1,true) and path:find('OlympusChatWarden.lua',1,true),'complete saved-file path is copyable')
local text=view.fileGuide:GetText()
check(text:find('fully close WoW',1,true) and text:find('safety copy',1,true) and text:find('replaces all',1,true),'file guide explains saving, restore safety and replacement scope')
click(view.textModeButton)
check(view.backupMode=='text' and view.textBackup:IsShown() and not view.fileBackup:IsShown(),'history-only text merge requires a deliberate mode choice')
click(view.fileModeButton)
check(view.backupMode=='file' and view.fileBackup:IsShown(),'file backup can be reopened without making a text snapshot')
check(view.snapshot==nil and not ns.ChronicleBackup.job,'browsing file backups creates no expensive text snapshot')
local popupBefore=ns.RecordingConsentWindow
ns.BuildChronicleOptions();ns.OpenChronicleOptions()
local settings=ns.ChronicleOptionsPanel
click(settings.statsHelp)
check(ns.Workspace.current=='recording' and view.view=='coverage' and view.collectionSelected=='storage','settings statistics open persistent explanation')
local doc=view.coverageDocument
doc:SetBlocks({{text='Plain text'}})
check(doc.boxes[1].scripts.OnEnter==nil,'recycled blocks remove obsolete hover help')
local topics=R.CollectionItems(C.Statistics(),ns.ChronicleStore.Storage())
local unknown=G.Describe({key='Unexpected diagnostic',status='Source reported an error.'})
check(unknown[#unknown].text=='Source reported an error.','unrecognized diagnostics show original status without invented data')
collectionGuideChecks=checks-before
''')
summary={'version':'1.0.3','assertions':int(lua.globals().collectionGuideChecks),'failed':0,'liveWoWTested':False,'coverage':'all catalog items, native click callbacks, defaults, retention and bounded refresh'}
(out/'collection-guide-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
