# Olympus ChatWarden v0.9.0-rc9

## Olympus integration in rc9

Olympus 1.2.1 is optional. In ChatWarden Settings, check **Use Olympus tab
instead of minimap icon**, then open the Olympus guild window once. A gold
ChatWarden crest tab appears on the left, below the large guild portrait.
Left-click it for Review messages; right-click it for ChatWarden settings.
It opens ChatWarden's existing window and does not select a guild data page.

The minimap icon hides only after a supported Olympus window is attached.
Turn integration off to hide the guild tab and restore your minimap preference.
With Olympus absent, disabled or unavailable, the minimap preference remains
in effect. Both old and HD Olympus layouts, including their basic-frame
fallbacks, are supported. The choice persists across reloads; open Olympus
once again after reloading to create its launcher.

Install by replacing only the OlympusChatWarden folder. Olympus remains a
separate installed addon. No edits to its files are needed.

Live checks: enable integration; open Olympus; click the new tab and try
right-click; close/reopen Olympus; switch guild layouts if your client offers
both; move the window and check the tab stays attached. Turn integration off
and confirm the minimap preference returns. Re-enable and reload. Check the
left crest remains clear of the large portrait and lower native tabs.

Offline constructor tests use the source files you supplied; visual placement
and input still need confirmation in the game.

## Retained rc8 changes and live testing

- Contractions such as you've, I've, we've and they've stay intact. The engine
  does not treat the suffix after an internal apostrophe as a separate word.
- Ambiguous short pronoun forms e, em and ve require an explicit declaration.
  Casual wording such as “spend em right the first time” remains visible.
- Clear character race/portal and barber customization wording stays visible,
  including all five messages in the supplied rc7 export. Only those matching
  terms are exempted; separate qualifying matches still apply.
- Each category has its own sensitivity dropdown. Choose Default, Off,
  Selective, Balanced, Broad or All listed terms. Reports retain the category
  choices at message capture, and Review shows each match's score and minimum.
- Repository and reporting links use the renamed OlympusChatWarden repository.
- Olympus integration is now attached automatically when enabled; see the
  instructions above. The real layout still needs live visual testing.

rc7's overlap/input fixes, crest artwork, racial-ability guard and body-label
capitalization are retained. Existing ChatWarden settings, reports and rules
persist. Quit WoW, replace the code folder and restart; keep SavedVariables.

Quick live checks: test the exported messages under All listed terms, then use
Configure categories to mix main Selective with gender All listed terms and
institutional Balanced. Check a literal term and a scored phrase in each group,
turn a category Off, change the main preset, and reload to confirm persistence.
Recheck overlapping windows, preview controls, both barber labels and chat
casing. Test the Olympus launcher and minimap transition as described above.

This is the end-user release candidate. Developer report pages, diagnostic
commands and the click-to-reveal popup have been removed. User reports can be
exported for future filter tuning.

## Per-category sensitivity

Open Settings with `/ocw`, then **Configure categories**, or use
`/ocw categories` directly. Each wording group has a dropdown:

| Choice | Effect |
| --- | --- |
| Default (main preset) | Follows your main sensitivity selection. |
| Off | Disables this built-in category. |
| Selective | Accepts phrase scores of 85 or higher. |
| Balanced | Accepts phrase scores of 65 or higher. |
| Broad | Accepts phrase scores of 40 or higher. |
| All listed terms | Broad phrase scoring plus that category's expanded literal words. |

For example, main Selective + gender All listed terms covers standalone LGBT
while other categories remain selective. Change the main preset and only the
categories set to Default follow it. Explicit choices persist across reloads.
Categories with no expanded literal catalog still use Broad phrase scoring
when set to All listed terms.

Built-in Male/Female wording replacements apply in every enabled label preset;
Off disables them. Personal phrase rules still apply independently of category
switches and presets. Exceptions and coverage still apply.

## Wording replacements

With the Body-label replacements category enabled, Body 1 / Body Type 1 becomes
**Male** and Body 2 / Body Type 2 becomes **Female**, displayed in subdued gray. Plural labels become
males/Males/MALES or females/Females/FEMALES according to source casing; listed colon, number-sign, one/two and Roman-number variants are
also supported. Substitutions apply across all presets to supported chat,
bubbles, dialogue and barber labels/tooltips, subject to coverage and exceptions.
A separate unrelated match may still hide the message.

The original message remains in Review. Replacement wording is not a clickable
redaction and does not enter the filter again. This prevents replacement loops
and keeps All listed terms from covering its own replacement text.

To add your own: open My reports & phrase rules, choose My phrase rules, click
New rule, enter an exact phrase, select **Replace with text**, enter the desired
replacement, and save. Match phrases use 3–120 printable English characters;
replacement text uses 1–120 printable English characters without markup or
line breaks. Rules can be edited, disabled or removed and persist across reloads.
A Keep visible personal rule can also override a built-in body-type replacement.

Test tonight: chat with both labels; barber hover tooltips and visible labels;
category/coverage off; one custom replacement; reload persistence. Barber checks
are automated fixtures, so confirm its real layout on your client.

## New name and installation

**Olympus ChatWarden** — Your chat. Your preferences.

This build installs as `OlympusChatWarden` and stores its own account-wide
settings in `OlympusChatWardenDB`. It starts fresh with Broad sensitivity; it
does not import settings, rules or reports from previous addon names.

1. Exit WoW completely.
2. Remove the previous `OlympusGuildFilter` and `ForeverTextRedactor` code
   folders from `Interface/AddOns` so only one filter runs.
3. Replace the existing `OlympusChatWarden` code folder with the ZIP's
   **OlympusChatWarden** folder in `Interface/AddOns`. Do not nest it inside
   another folder. Keep your SavedVariables files to retain ChatWarden settings.
4. Confirm the TOC is `Interface/AddOns/OlympusChatWarden/OlympusChatWarden.toc`.
5. Enable **Olympus ChatWarden** and start WoW. Use `/ocw` for settings.

No legacy importer is included. Old saved files can remain; ChatWarden does not
read them. Its own settings, saved reports and personal rules persist normally
across logout and reload.

The preset names remain **Selective, Balanced, Broad, All listed terms**.
Existing categories, presets, inline reveal and reports are retained, with
the targeted eligibility fixes and replacement capitalization above. The gold crest remains the approved artwork.

**Send feedback** beside Export reports shows the reporting link and copy
instructions. `/ocw feedback` opens the same window. Nothing is sent
automatically; saving a report does not train the filter.

Project: https://github.com/RegretnWoW/OlympusChatWarden

Report: https://github.com/RegretnWoW/OlympusChatWarden/issues

The GitHub links now use the OlympusChatWarden repository. Check identifying
details before posting a public report.

## First-launch introduction and optional tutorials

The first login opens a small, dismissible introduction explaining what the
addon does, how to read filtered messages and how to correct a miss. **Got it**
closes it. You can also go directly to Settings or How filtering works. It keeps
your selected preset and enable/disable state. It waits out combat or a hidden
UI and stays dismissed across reloads on the account.

Reopen the introduction with `/ocw welcome`. Open the full guide with **Help /
guide** in Settings, `/ocw help`, or `/ocw tutorial`. Choose a topic freely; no
sequence is required. Reading tutorials does not alter rules or preferences.

### Confidence in plain language

Confidence is a rule score from 0 to 100 for how strongly the wording matches
your filter preferences. Nearby wording can change phrase scores when context
is enabled. It does not measure a person's intent or provide a probability.

Filtering has two steps:

1. Does the match meet its category preset's minimum? If not, it stays visible.
2. If accepted, what action does the score call for?

| Accepted match score | Result |
| --- | --- |
| 40–64 | Warning; all words remain visible |
| 65–84 | Redact matched words |
| 85–100 | Hide the message; keep its original in Review |

For example, a phrase scoring 80 is redacted in Broad (minimum 40) and Balanced
(minimum 65), but stays visible in Selective (minimum 85). All listed terms literal entries
normally use score 80 without requiring context. Ambiguous short pronouns e, em and ve
need a declaration; clear gameplay/customization contexts are exempted.
Categories, coverage and exceptions still apply. Explicit personal rules use the
action you select. An independent stronger match can still hide the message.

**Why filtered?** in Review shows confidence as match strength and the matched
wording. For more examples, choose Confidence explained in the in-game guide.

## Read and reveal messages

| Result | What happens |
| --- | --- |
| Visible | The original message is shown. |
| Warning | A gold `[!]` appears on the same line; words remain readable. |
| Replaced | Matching words become your chosen alternative in subdued gray. |
| Redacted | Matched words become black bars; the rest of the message stays visible. |
| Hidden | The message is hidden and its original is available in **Review messages**. |

Click black bars in chat to reveal the matched wording in subdued gray in that
same line. Click the revealed words again to restore the bars. Each chat
occurrence has its own toggle. No separate window opens.

In supported dialogue and the preview, click the redacted text area to
reveal its matched words; click the same area again to cover them. **Reset
preview**, a policy change or a new pooled message resets those UI reveals.
Bubble text is filtered where the client exposes it; bubble click-to-reveal is not promised.
Revealing text does not add an exception or change filtering for future messages.

Left-click the minimap crest or use `/ocw inbox` to open Review. Select a message
and read its original. **Report a problem** saves feedback; **Dismiss** removes
only that item from this session's inbox. **Clear** requires a second click and
leaves saved reports intact. Source filtering is a dropdown.

## Choose sensitivity and coverage

| Preset | Behavior |
| --- | --- |
| Broad | Includes weaker phrase matches. This remains the default for a fresh install. |
| Balanced | Uses the standard phrase threshold. |
| Selective | Filters stronger matches and leaves more borderline wording visible. |
| All listed terms | Literal listed-word redaction, with the short-pronoun and gameplay guards described above. |

All listed terms is an explicit choice above the phrase modes. It retains the same 309
entries and variants, including common words and short forms; ordinary use of
listed wording is also redacted. Category switches, exceptions and explicit
personal overrides still apply. Independent stronger matches can still hide a
message. The three phrase presets retain their existing context behavior.

Use **Where to filter** and **Configure categories** in settings to choose coverage and
categories. Player-chat coverage includes raid warnings and instance chat.
**Use context clues** affects phrase scoring; most All listed terms entries
need no context. Short-pronoun declarations and gameplay guards
apply even when phrase context scoring is off. The complete vocabulary is in
`VOCABULARY.md`.

## Report a miss or a wrong result

For a missed player message, right-click the player's name in chat and choose
**Report missed filter**. Check the captured original. If that exact line is no
longer available, choose a recent message from the dropdown or paste it yourself.
You can also open the manual form with `/ocw report`.

For a filtered message, open **Review messages**, select it and choose **Report
a problem**. Then:

1. Choose **Missed by the filter**, **Should have stayed visible**, or **Needed a
   different action**.
2. Choose the wanted action where applicable and optionally add a short note.
3. Click **Save report**.

Reports are saved locally and survive `/reload`. A report alone leaves your
personal rules unchanged. There is one destination; you do not need a developer
report page.

### Correct your own filter

To apply a correction immediately, explicitly check **Also apply a personal
phrase rule** and enter exact words from the original before saving. The chosen
wanted action becomes that phrase's personal action. The combined save either
succeeds completely or leaves both stores unchanged.

Alternatively, open **My reports & phrase rules**, select a report and choose
**Make a rule**. Enter the phrase, choose its action, and save. **New rule** lets
you create one directly. Rules accept 3–120 printable English characters, match
whole phrases and remain active across sensitivity changes. You can edit,
disable or delete them. Delete requires a second click.

A **Keep visible** rule corrects an overlapping match. Separate stronger matches
in the same message can still filter it. Deleting a report keeps its rules;
deleting or disabling a rule restores the built-in behavior for that phrase.

### Share reports for tuning

Open **My reports** and click **Export reports**, or use `/ocw export`.
Choose all reports or missed messages only, click **Select all**, press Ctrl+C,
and paste the export into the conversation where you want to share it.

Exports include original text, wanted action, notes, matched rules, settings and
addon/rule versions. Captured reports freeze those details when the message was
observed. Pasted examples are marked `report-save` and describe analysis under
the settings used when reporting; they do not claim an observed original action.

Dedicated player-name, GUID, class and channel fields are omitted. Message text
and notes can still identify people, so check them before sharing. Nothing is
sent automatically. The entire personal rule list is not exported; a matching
personal rule can appear among that report's match details.

## Useful commands

| Command | Opens or changes |
| --- | --- |
| `/ocw` | Settings |
| `/ocw help` / `/ocw tutorial` | Optional in-game guide |
| `/ocw welcome` | First-launch introduction |
| `/ocw commands` | Command list |
| `/ocw inbox` | Session message review |
| `/ocw reports` | My saved reports |
| `/ocw rules` | My phrase rules |
| `/ocw report` | Report a missed message |
| `/ocw export` | All user reports for copying |
| `/ocw export misses` | Missed-message reports for copying |
| `/ocw preview` | Display preview under your current settings |
| `/ocw categories` | Independent category sensitivity dropdowns |
| `/ocw pack gender all` | All listed terms only for the gender category |
| `/ocw preset all` | All listed terms literal filtering |
| `/ocw preset broad` | Broad phrase filtering |
| `/ocw on` / `/ocw off` | Enable or pause filtering |
| `/ocw rescan` | Reapply supported dialogue and bubble filtering |
| `/ocw status` | Current version, preset and saved-item counts |

The `/chatwarden` alias remains. Existing chat redactions remain clickable when you
pause filtering; new messages use the paused state. Coverage, category and
exception commands are available in `/ocw commands`.

## Retention and compatibility

Session Review keeps up to 200 entries or 1 MiB and evicts oldest entries when
full. It resets on reload. Recent raw chat for name-menu reporting stays in RAM
for up to 10 minutes, 500 entries or 512 KiB. A saved report clips originals to
8,192 bytes and notes to 1,000 bytes without splitting UTF-8 characters. Clipped
reports are marked; a clipped original cannot create a rule through that form.

The unified saved store allows 200 reports or 1 MiB of compact JSON, whichever
comes first, and 200 personal rules. Full saved storage asks you to export and
remove a report; it does not silently discard existing saved reports.

Chat reveal retains up to 4,096 matched occurrences or 1 MiB for the session.
Evicted occurrences are covered again where the display can be updated. Native
chat lines keep their order, colors, metadata and scroll position. If a custom
chat display cannot update the line, the addon directs you to Review instead.
Protected or inaccessible game text remains untouched.

## Before public release

Automated validation covers filtering, report persistence/export, inline toggles,
pooled bubbles and window input/layers using a simulated client. A live WoW
check is still needed. Use your normal font size and UI scale:

- On first login, check the introduction, dismiss it and `/reload` to confirm it stays dismissed. Reopen `/ocw help` and try each topic.
- Open `/ocw preview`. Reveal and re-cover the redaction example. Click Reset
  preview and Review messages repeatedly, close Preview, and check other buttons.
- Reveal and re-cover one chat redaction, scroll away and back, and check a long
  wrapping message. A warning should stay on the same line.
- Save a miss, save an optional phrase rule, `/reload`, and check both in My
  reports/rules. Export and check that the wanted action and original are right.
- Open Review, My reports and a report form together. Bring each forward and
  use its dropdowns and scrollbars. Check that no controls from a rear window
  overlap it.

This package is a release candidate; it has not been publicly published.
