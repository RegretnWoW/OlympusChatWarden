-- Private-testing candidates, not a political classification or verified WoW corpus.
-- Generated spelling/plural combinations are explicitly proposed variants.
local _, ns = ...
ns.StockRules, ns.RuleMeta = {}, {}
ns.PackNames = {"labels", "reproductive", "language", "institutional", "slogans", "broad"}
local function Add(pack, score, phrase, origin)
    if ns.RuleMeta[phrase] then return end
    ns.StockRules[#ns.StockRules + 1] = phrase
    ns.RuleMeta[phrase] = {id = pack .. ":" .. phrase, pack = pack, base = score,
        origin = origin or "proposed test candidate", version = 1}
end
local function List(pack, score, text)
    for phrase in text:gmatch("[^\n]+") do Add(pack, score, phrase) end
end
for _, phrase in ipairs(ns.StarterRules) do
    Add(phrase:find("body type", 1, true) and "labels" or "reproductive", 95, phrase, "user-requested starter")
end
for _, prefix in ipairs({"body type", "body types"}) do
    for _, suffix in ipairs({"one", "two", "i", "ii", "a", "b"}) do Add("labels", 92, prefix .. " " .. suffix) end
    for _, suffix in ipairs({"1", "2"}) do
        Add("labels", 92, prefix .. ": " .. suffix)
        Add("labels", 92, prefix .. " #" .. suffix)
    end
end
for _, prefix in ipairs({"birthing", "pregnant", "gestational", "menstruating", "lactating"}) do
    for _, suffix in ipairs({"person", "people", "parent", "parents", "individual", "individuals"}) do
        Add("reproductive", 90, prefix .. " " .. suffix)
    end
end
List("reproductive", 88, [[chest feeding
chest feeder
chest feeders
chest-feeder
chest-feeders
chestfed
chest-fed
chest fed
person who menstruates
people who menstruate
person who gives birth
people who give birth
person giving birth
people giving birth
person who can become pregnant
people who can become pregnant
person capable of pregnancy
people capable of pregnancy
person with a uterus
people with uteruses
uterus owner
uterus owners
pregnancy-capable person
pregnancy-capable people
pregnancy capable person
pregnancy capable people]])
List("language", 82, [[assigned male at birth
assigned female at birth
sex assigned at birth
gender assigned at birth
assigned sex at birth
assigned gender at birth
preferred pronouns
personal pronouns
chosen pronouns
pronoun preference
pronoun preferences
pronoun sharing
share your pronouns
state your pronouns
include your pronouns
what are your pronouns
use my pronouns
respect my pronouns
respect their pronouns
pronouns in your bio
pronouns in your profile
pronouns in your signature
gender-neutral language
gender neutral language
gender-inclusive language
gender inclusive language
gender-affirming language
gender affirming language
gender-neutral terms
gender neutral terms
gender-inclusive terms
gender inclusive terms
gender-neutral pronouns
gender neutral pronouns
gender-inclusive pronouns
gender inclusive pronouns
inclusive language
inclusive terminology
inclusive wording
bias-free language
bias free language
bias-free communication
bias free communication
person-first language
person first language
people-first language
people first language
identity-first language
identity first language
non-gendered language
non gendered language
gendered language
degendered language]])
for _, stem in ipairs({"gender affirming", "gender-affirming", "gender inclusive", "gender-inclusive", "gender neutral", "gender-neutral"}) do
    Add("language", 72, stem)
    for _, suffix in ipairs({"care", "policy", "policies", "education", "guidelines"}) do Add("language", 80, stem .. " " .. suffix) end
end
List("institutional", 82, [[diversity equity and inclusion
diversity, equity, and inclusion
diversity, equity and inclusion
diversity equity inclusion
equity diversity and inclusion
equity, diversity, and inclusion
equity, diversity and inclusion
diversity and inclusion
diversity & inclusion
equity and inclusion
equity & inclusion
diversity and equity
diversity & equity
inclusion and belonging
diversity equity inclusion and belonging
diversity, equity, inclusion, and belonging
equity-centered communication
equity centered communication
equity-centered approach
equity centered approach
anti-racist policy
antiracist policy
anti-racism training
antiracism training
anti-racist education
antiracist education
anti-oppression training
anti oppression training
anti-oppressive practice
anti oppressive practice
intersectional feminism
intersectional approach
intersectional lens
intersectional analysis
systemic oppression
structural oppression
systems of oppression
systems of privilege
unconscious bias training
implicit bias training
check your privilege
examine your privilege
acknowledge your privilege
unpack your privilege
dismantle the patriarchy
smash the patriarchy
dismantle systemic racism
decolonize the curriculum
decolonise the curriculum
decolonize your mind
decolonise your mind]])
for _, stem in ipairs({"diversity", "equity", "inclusion", "dei", "belonging"}) do
    for _, suffix in ipairs({"training", "initiative", "initiatives", "officer", "office", "committee", "council", "framework", "strategy", "statement", "workshop", "audit", "goals"}) do
        Add("institutional", 74, stem .. " " .. suffix)
    end
end
List("slogans", 85, [[love is love
trans rights are human rights
women's rights are human rights
no human is illegal
no person is illegal
silence is violence
silence is complicity
representation matters
diversity is our strength
diversity is a strength
our strength is our diversity
equity over equality
equity not equality
equality is not equity
there is no planet b
the future is female
believe all women
believe survivors
protect trans kids
protect trans youth
protect queer youth
normalize pronouns
normalise pronouns
respect people's pronouns
respect everyone's pronouns
end the gender binary
beyond the gender binary
break the gender binary
gender is a spectrum
gender is a social construct
gender is socially constructed
sex is a spectrum
abolish the patriarchy
abolish gender roles
challenge gender norms
challenge gender stereotypes]])
-- Deliberately ambiguous: aggressive mode catches these; other modes need context.
List("broad", 45, [[safe space
safe spaces
brave space
brave spaces
inclusive space
inclusive spaces
inclusive environment
inclusive environments
inclusive community
inclusive communities
inclusive culture
inclusive cultures
inclusive practice
inclusive practices
inclusive representation
diverse representation
authentic representation
equitable access
equitable outcomes
equitable outcome
equitable treatment
equity lens
equity lenses
social justice
racial justice
gender justice
environmental justice
climate justice
restorative justice
transformative justice
centering voices
centring voices
center marginalized voices
centre marginalised voices
center marginalized perspectives
centre marginalised perspectives
lived experience
lived experiences
unconscious bias
implicit bias
structural inequality
systemic inequality
power imbalance
power imbalances
power dynamics
power structures
cultural appropriation
performative allyship
active allyship
intersectional perspective
decolonial perspective
privilege awareness
microaggression training
microaggressions training]])
-- Limited source-checked terminology; sources support usage only, never ideology.
for _, phrase in ipairs({"bias-free communication", "inclusive language", "gender-neutral language"}) do
    if ns.RuleMeta[phrase] then ns.RuleMeta[phrase].origin = "Microsoft style guide; variant where noted in SOURCES.md" end
end
for _, phrase in ipairs({"equity-centered communication", "equity-centered approach", "person-first language"}) do
    if ns.RuleMeta[phrase] then ns.RuleMeta[phrase].origin = "CDC communication guides; variant where noted in SOURCES.md" end
end
ns.OptionalCandidates = ns.StockRules
