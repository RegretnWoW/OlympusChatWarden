local _, ns = ...
ns.StarterRules = {
    -- User-requested examples and narrowly scoped English test candidates.
    -- These are literal test rules, not claims about intent or WoW content.
    "body type 1", "body type 2", "body types 1", "body types 2",
    "birthing person", "birthing people", "birthing parent", "birthing parents",
    "pregnant person", "pregnant people", "chestfeeding", "chest-feeding",
}
-- Optional candidates; NOT loaded into active rules automatically.
ns.OptionalCandidates = {
    "chest feeding", "chest feeder", "chest feeders",
    "pregnant individual", "pregnant individuals", "gestational parent",
    "gestational parents", "menstruating person", "menstruating people",
    "person who menstruates", "people who menstruate",
    "assigned male at birth", "assigned female at birth",
    "gender affirming", "gender-affirming", "gender inclusive", "gender-inclusive",
    "gender neutral", "gender-neutral", "inclusive language",
    "diversity equity and inclusion", "diversity, equity, and inclusion",
}

-- Cosmetic terminology substitutions. Originals remain in local Review.
ns.BodyReplacementText = {}
for _, spec in ipairs({{"male", "males", {"1", "one", "i"}}, {"female", "females", {"2", "two", "ii"}}}) do
    for _, prefix in ipairs({"body type", "body types"}) do
        local replacement = prefix == "body types" and spec[2] or spec[1]
        for _, suffix in ipairs(spec[3]) do ns.BodyReplacementText[prefix .. " " .. suffix] = replacement end
        local n = spec[3][1]
        ns.BodyReplacementText[prefix .. ": " .. n] = replacement
        ns.BodyReplacementText[prefix .. " #" .. n] = replacement
    end
end
-- Classic barber tooltips use the shorter "Body 1" / "Body 2" labels.
-- Numeric-only aliases avoid treating ordinary "body I ..." prose as a label.
for number, replacement in ipairs({"male", "female"}) do
    for _, separator in ipairs({" ", ": ", " #"}) do
        ns.BodyReplacementText["body" .. separator .. number] = replacement
    end
end
local bodyPhrases = {}
for phrase in pairs(ns.BodyReplacementText) do bodyPhrases[#bodyPhrases + 1] = phrase end
ns.BodyReplacements = assert(ns.Engine.Compile(bodyPhrases))
