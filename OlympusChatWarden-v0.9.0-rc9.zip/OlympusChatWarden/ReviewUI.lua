local _, ns = ...
local R, T = ns.Review, ns.Theme
local window, listTitle, details, detailScroll, rows, previous, nextPage, pageText, sourceDropdown
local reportButton, correctButton, reasonButton, detailTitle, footer, savedButton, empty
local selected, page, filter, query, showReasons = nil, 1, "all", "", false
local queued, clearArmed = false, false
local PAGE_SIZE = 9
local function Plain(text) return (text or ""):gsub("|", "||") end
local function Text(parent, font, x, y, width, value)
    local label = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    label:SetPoint("TOPLEFT", x, y); label:SetWidth(width); label:SetJustifyH("LEFT")
    label:SetText(value or ""); T.Light(label); return label
end
local function Button(parent, text, width, x, y, click)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width, 24); button:SetPoint("TOPLEFT", x, y); button:SetText(text)
    button:SetScript("OnClick", click); return button
end
local function Saved(entry)
    if not entry or not entry.reportID then return nil end
    for _, record in ipairs(ns.Personal.reports) do if record.id == entry.reportID then return record end end
end
function R.Filtered(kind, needle)
    local result = {}
    needle = (needle or ""):lower()
    for i = #R.entries, 1, -1 do
        local entry = R.entries[i]
        local haystack = (R.Source(entry) .. " " .. (entry.event or "") .. " " .. (entry.panel or "") .. " " .. entry.original):lower()
        if (kind == "all" or kind == entry.kind) and (needle == "" or haystack:find(needle, 1, true)) then result[#result + 1] = entry end
    end
    return result
end
function R.DetailText(entry, reasons)
    if not entry then
        return "Select a message on the left to read its original.\n\nReport a problem if it should have stayed visible or needed a different action.\n\nDismiss removes a message from this session inbox. It does not change your rules or saved reports.\n\nFor a missed message, use Report a missed message above, or right-click the player's name in chat."
    end
    local lines = {R.Source(entry), R.TimeLabel(entry), "\nORIGINAL MESSAGE", entry.original}
    if entry.truncated then lines[#lines + 1] = "[Long original shortened in session history]" end
    lines[#lines + 1] = "\nFILTER RESULT"
    lines[#lines + 1] = T.Label(T.Actions, entry.action)
    if entry.rendered then lines[#lines + 1] = entry.rendered
    elseif entry.action == "Hidden" then lines[#lines + 1] = "The message was hidden. Its original is kept above."
    elseif entry.action == "Replaced" then lines[#lines + 1] = "Matching wording was replaced with gray alternative text. Its original is kept above."
    elseif entry.action == "Warning" then lines[#lines + 1] = "The message remained visible with a warning."
    else lines[#lines + 1] = "Matched words became black bars. You can reveal them in game." end
    local record = Saved(entry)
    if record then
        lines[#lines + 1] = "\nSAVED REPORT"
        lines[#lines + 1] = ({["Correct match"] = "Looks right", ["False positive"] = "Should have stayed visible",
            ["Wrong action"] = "Needed a different action"})[record.feedback] or record.feedback
        lines[#lines + 1] = "Wanted: " .. T.Label(T.Actions, record.expectedAction)
        if record.note and record.note ~= "" then lines[#lines + 1] = record.note end
    end
    if reasons then
        lines[#lines + 1] = "\nWHY IT WAS FILTERED"
        local preset = ({maximum = "All listed terms", aggressive = "Broad", balanced = "Balanced", strict = "Selective"})[entry.preset] or "Unknown"
        lines[#lines + 1] = "Main preset when received: " .. preset
        lines[#lines + 1] = "Confidence: " .. (entry.confidence or "Unknown") .. " match strength"
        for i, match in ipairs(entry.matches) do
            local explanation = match.pack == "personal" and "Your saved phrase rule."
                or match.id and match.id:find("maximum:", 1, true) == 1 and "Listed word in Maximum."
                or (match.pack == "guild" or match.pack == "creator") and "Name with nearby insulting or teasing wording."
                or "Phrase matched an enabled category."
            lines[#lines + 1] = i .. ". " .. (match.phrase or "Matched wording") .. " - " .. explanation
            if match.threshold then lines[#lines + 1] = "Category: " .. (match.pack or "unknown") .. "; score " .. (match.score or 0) .. "; minimum " .. match.threshold end
        end
        if entry.matchCount > #entry.matches then lines[#lines + 1] = "First " .. #entry.matches .. " of " .. entry.matchCount .. " matches shown." end
        lines[#lines + 1] = "\nA report saves your feedback. Only an explicitly saved personal phrase rule changes filtering."
    end
    return table.concat(lines, "\n")
end
local function UpdateDetails(resetScroll)
    local entry = R.Get(selected)
    if details then
        details:SetText(Plain(R.DetailText(entry, showReasons))); details:SetCursorPosition(0); details:ClearFocus()
        if resetScroll then detailScroll:SetVerticalScroll(0) end
        detailTitle:SetText(entry and ("Original message  |  " .. entry.action) or "Message review")
        reportButton:SetEnabled(entry ~= nil); correctButton:SetEnabled(entry ~= nil); reasonButton:SetEnabled(entry ~= nil)
        reasonButton:SetText(showReasons and "Hide details" or "Why filtered?")
        footer:SetText(entry and Saved(entry) and "Report saved. Open My reports to review or export it."
            or "Review history lasts this session. Saved reports and personal phrase rules survive reload.")
    end
end
local function Select(entry)
    selected = entry and entry.id or nil; showReasons = false
    if entry then entry.read = true end
    UpdateDetails(true)
end
function ns.RefreshReview()
    if ns.MinimapButton then
        local unread = R.Unread()
        ns.MinimapButton.Count:SetText(unread > 99 and "99+" or unread > 0 and tostring(unread) or "")
    end
    if not window or not window:IsShown() then return end
    local visible = R.Filtered(filter, query)
    local pages = math.max(1, math.ceil(#visible / PAGE_SIZE)); page = math.min(page, pages)
    local selectedVisible = not selected
    for _, entry in ipairs(visible) do if entry.id == selected then selectedVisible = true end end
    if not selectedVisible or selected and not R.Get(selected) then Select(nil) end
    listTitle:SetText("Recent matches  |  " .. #visible .. " shown  |  " .. R.Unread() .. " new")
    savedButton:SetText("My reports (" .. #ns.Personal.reports .. ")")
    pageText:SetText("Page " .. page .. " / " .. pages)
    previous:SetEnabled(page > 1); nextPage:SetEnabled(page < pages)
    empty:SetShown(#visible == 0)
    empty:SetText(#R.entries == 0 and "No filtered messages yet.\n\nMessages appear here as the filter catches them."
        or "No messages match this source or search.\n\nTry All sources or clear the search.")
    for i, row in ipairs(rows) do
        local entry = visible[(page - 1) * PAGE_SIZE + i]; row.entry = entry
        if entry then
            local snippet = entry.original:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
                :gsub("|H.-|h(.-)|h", "%1"):gsub("|T.-|t", ""):gsub("[\r\n]", " ")
            row.label:SetText(Plain((entry.read and "" or "NEW  ") .. entry.action .. "  |  " .. R.Source(entry)))
            row.preview:SetText(Plain(snippet)); T.RowState(row, entry.id == selected, entry.action)
        end
        row:SetShown(entry ~= nil)
    end
    UpdateDetails(false)
end
function ns.QueueReviewRefresh()
    if queued then return end
    queued = true
    local function Refresh() queued = false; ns.RefreshReview() end
    if C_Timer and C_Timer.After then C_Timer.After(0, Refresh) else Refresh() end
end
function ns.OpenReview()
    if not window then
        window = T.Window("OlympusChatWardenInbox", UIParent, 940, 640)
        ns.ReviewWindow = window; T.Title(window, "Olympus ChatWarden"); T.Crest(window)
        T.Gold(Text(window, "GameFontNormalLarge", 78, -30, 720, "Review messages"))
        T.Muted(Text(window, "GameFontHighlightSmall", 78, -49, 720, "Read the original and help improve the filter.  v" .. ns.VERSION))
        local toolbar = T.Panel(window, 14, -70, 912, 44)
        Text(toolbar, "GameFontHighlightSmall", 10, -15, 50, "Source")
        local sources = {}; for _, choice in ipairs(T.Sources) do if choice[1] ~= "manual" then sources[#sources + 1] = choice end end
        sourceDropdown = T.Dropdown(toolbar, 57, -9, 157, sources, function() return filter end, function(value)
            filter = value; page = 1; Select(nil); ns.RefreshReview()
        end)
        local search = CreateFrame("EditBox", nil, toolbar, "SearchBoxTemplate")
        search:SetSize(225, 24); search:SetPoint("TOPLEFT", 230, -10); search:SetAutoFocus(false); search:SetMaxLetters(128)
        search:SetScript("OnTextChanged", function(self)
            if SearchBoxTemplate_OnTextChanged then SearchBoxTemplate_OnTextChanged(self) end
            query = self:GetText() or ""; page = 1; Select(nil); ns.QueueReviewRefresh()
        end)
        search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        Button(toolbar, "Report a missed message", 190, 472, -10, function() ns.OpenReport(nil) end)
        savedButton = Button(toolbar, "Saved reports", 145, 672, -10, function() ns.OpenPersonal("reports") end)
        local clear = Button(toolbar, "Clear", 73, 827, -10, function()
            if clearArmed then R.Clear(); Select(nil); clearArmed = false; window.ClearHistoryButton:SetText("Clear")
            else clearArmed = true; window.ClearHistoryButton:SetText("Confirm") end
        end)
        window.ClearHistoryButton = clear
        T.Tooltip(clear, "Clear session history", "Removes the messages in this review inbox. Saved reports are kept.")
        window:SetScript("OnHide", function() clearArmed = false; clear:SetText("Clear") end)
        local list = T.Panel(window, 14, -122, 350, 444)
        listTitle = Text(list, "GameFontHighlightSmall", 12, -12, 326)
        empty = T.Muted(Text(list, "GameFontHighlight", 18, -68, 314))
        rows = {}
        for i = 1, PAGE_SIZE do
            local row = CreateFrame("Button", nil, list)
            row:SetSize(332, 42); row:SetPoint("TOPLEFT", 9, -34 - (i - 1) * 44)
            row.background = row:CreateTexture(nil, "BACKGROUND"); row.background:SetAllPoints()
            row.label = Text(row, "GameFontHighlightSmall", 12, -6, 309); row.label:SetWordWrap(false)
            row.preview = T.Muted(Text(row, "GameFontHighlightSmall", 12, -23, 309)); row.preview:SetWordWrap(false)
            T.SkinRow(row); row:SetScript("OnClick", function(self) Select(self.entry); ns.RefreshReview() end)
            rows[i] = row
        end
        previous = Button(window, "Previous", 94, 14, -577, function() page = math.max(1, page - 1); Select(nil); ns.RefreshReview() end)
        nextPage = Button(window, "Next", 94, 270, -577, function() page = page + 1; Select(nil); ns.RefreshReview() end)
        pageText = Text(window, "GameFontHighlightSmall", 121, -583, 145)
        local header = T.Panel(window, 376, -122, 550, 34)
        detailTitle = T.Gold(Text(header, "GameFontNormal", 12, -10, 360))
        reasonButton = Button(header, "Why filtered?", 130, 409, -5, function() showReasons = not showReasons; UpdateDetails(true) end)
        local paper = T.Panel(window, 376, -159, 550, 407, true)
        detailScroll = CreateFrame("ScrollFrame", nil, paper, "UIPanelScrollFrameTemplate")
        detailScroll:SetPoint("TOPLEFT", 16, -16); detailScroll:SetPoint("BOTTOMRIGHT", -32, 16)
        details = CreateFrame("EditBox", nil, detailScroll); ns.ReviewDetails = details
        details:SetMultiLine(true); details:SetAutoFocus(false); details:SetFontObject(ChatFontNormal); T.Ink(details)
        details:SetSize(498, 500); detailScroll:SetScrollChild(details)
        local writing = false
        local measure = details:CreateFontString(nil, "OVERLAY")
        measure:SetFontObject(ChatFontNormal); measure:SetWordWrap(true); measure:SetWidth(498); measure:Hide()
        details:SetScript("OnTextChanged", function(self, userInput)
            if userInput and not writing then
                writing = true; self:SetText(Plain(R.DetailText(R.Get(selected), showReasons))); writing = false
            end
            local _, lines = (self:GetText() or ""):gsub("\n", "\n"); measure:SetText(self:GetText() or "")
            self:SetHeight(math.max(375, (lines + 3) * 18, measure.GetStringHeight and measure:GetStringHeight() + 40 or 0))
        end)
        details:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        detailScroll:SetScript("OnSizeChanged", function(_, width)
            if width and width > 0 then details:SetWidth(width - 4); measure:SetWidth(width - 4); details:SetText(details:GetText() or "") end
        end)
        correctButton = Button(window, "Dismiss", 145, 376, -577, function()
            if selected then R.Remove(selected); Select(nil); ns.RefreshReview() end
        end)
        T.Tooltip(correctButton, "Dismiss this message", "Removes it from the session inbox. Saved reports and phrase rules are kept.")
        reportButton = Button(window, "Report a problem", 185, 531, -577, function()
            local entry = R.Get(selected); if entry then ns.OpenReport(entry, "False positive") end
        end)
        Button(window, "My rules", 86, 726, -577, function() ns.OpenPersonal("rules") end)
        Button(window, "Settings", 100, 826, -577, function() SlashCmdList.OLYMPUSCHATWARDEN("options") end)
        footer = T.Muted(Text(window, "GameFontHighlightSmall", 18, -615, 898))
        window:SetScript("OnShow", ns.RefreshReview); Select(nil)
    end
    local width = UIParent.GetWidth and UIParent:GetWidth() or 1000
    local height = UIParent.GetHeight and UIParent:GetHeight() or 700
    if width and height and width > 0 and height > 0 then window:SetScale(math.min(1, (width - 30) / 940, (height - 30) / 640)) end
    T.ShowWindow(window); ns.RefreshReview()
end
function ns.ToggleReview()
    if window and window:IsShown() then window:Hide() else ns.OpenReview() end
end

local function PositionMinimap()
    local button = ns.MinimapButton
    if not button or not Minimap then return end
    local angle = math.rad(ns.DB.minimapAngle or 225)
    local rx = (Minimap:GetWidth() or 140) / 2 + 8
    local ry = (Minimap:GetHeight() or 140) / 2 + 8
    button:ClearAllPoints(); button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * rx, math.sin(angle) * ry)
end
function ns.BuildMinimap()
    if InCombatLockdown and InCombatLockdown() then return end
    if not ns.DB or not Minimap or (Minimap.IsForbidden and Minimap:IsForbidden()) then return end
    if not ns.MinimapButton then
        local button = CreateFrame("Button", "OlympusChatWardenMinimap", Minimap)
        ns.MinimapButton = button
        button:SetSize(31, 31); button:SetFrameStrata("MEDIUM")
        button:SetFrameLevel(Minimap:GetFrameLevel() + 6)
        T.MinimapCrest(button)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp"); button:RegisterForDrag("LeftButton")
        button.Count = Text(button, "GameFontNormalSmall", 18, -20, 28)
        button.Count:SetTextColor(1, 0.25, 0.15)
        button:SetScript("OnClick", function(_, mouse)
            if mouse == "RightButton" and SlashCmdList.OLYMPUSCHATWARDEN then SlashCmdList.OLYMPUSCHATWARDEN("options")
            else ns.ToggleReview() end
        end)
        button:SetScript("OnEnter", function(self)
            if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:SetText("Olympus ChatWarden - Review inbox")
            GameTooltip:AddLine(#R.entries .. " stored / " .. R.Unread() .. " unread", 1, 1, 1)
            GameTooltip:AddLine("Left-click: review  |  Right-click: options\nDrag: move around minimap", 1, 1, 1, true); GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
        local function Drag()
            if not GetCursorPosition then return end
            local x, y = GetCursorPosition(); local cx, cy = Minimap:GetCenter(); local scale = Minimap:GetEffectiveScale()
            if not x or not y or not cx or not cy or not scale or scale <= 0 then return end
            x, y = x / scale - cx, y / scale - cy
            local angle
            if math.atan2 then angle = math.atan2(y, x)
            elseif x == 0 then angle = y >= 0 and math.pi / 2 or -math.pi / 2
            else angle = math.atan(y / x); if x < 0 then angle = angle + math.pi end end
            ns.DB.minimapAngle = math.deg(angle) % 360; PositionMinimap()
        end
        button:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", Drag) end)
        button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil); Drag() end)
    end
    PositionMinimap(); ns.MinimapButton:SetShown(ns.DB.minimap ~= false
        and not (ns.OlympusIntegration and ns.OlympusIntegration.IsActive())); ns.RefreshReview()
end
