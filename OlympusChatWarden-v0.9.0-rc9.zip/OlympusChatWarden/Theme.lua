local _, ns = ...
local T = {}
ns.Theme = T
T.Icon = "Interface\\AddOns\\OlympusChatWarden\\Media\\IconScroll.tga"
local windows, registered, focusHooks = {}, {}, setmetatable({}, {__mode = "k"})
local restacking, focusRevision = false, 0
local pendingFocus, deferred = {}, {}
local deferFrame
local function AfterClick(callback)
    if C_Timer and C_Timer.After then C_Timer.After(0, callback); return end
    deferred[#deferred + 1] = callback
    if not deferFrame then deferFrame = CreateFrame("Frame") end
    deferFrame:SetScript("OnUpdate", function(self)
        self:SetScript("OnUpdate", nil)
        local callbacks = deferred; deferred = {}
        for _, fn in ipairs(callbacks) do fn() end
    end)
end
local function QueueFocus(root)
    if pendingFocus[root] then return end
    local revision = focusRevision
    pendingFocus[root] = true
    AfterClick(function()
        pendingFocus[root] = nil
        -- An OnClick may open a different window or close this one. Do not
        -- steal focus back from that action when the deferred callback runs.
        if revision == focusRevision and root:IsShown() then T.FocusWindow(root) end
    end)
end

local function WindowFrames(root)
    local frames = {}
    local function Collect(frame, offset)
        frames[#frames + 1] = {frame = frame, offset = offset}
        if frame.IsMouseEnabled and frame:IsMouseEnabled() and not focusHooks[frame] then
            focusHooks[frame] = true
            -- Only hook existing input surfaces. Mouse hooks on decorative frames
            -- can enable their hit tests; the full-window NineSlice would then
            -- swallow clicks above our controls. Keep passive layers passive.
            -- Changing frame levels while a button is pressed can invalidate
            -- its native click target. Wait until OnMouseUp/OnClick finish.
            frame:HookScript("OnMouseUp", function() QueueFocus(root) end)
            frame:HookScript("OnDragStop", function() QueueFocus(root) end)
        end
        for _, child in ipairs({frame:GetChildren()}) do
            if child:GetFrameStrata() ~= "TOOLTIP" and not (child.IsForbidden and child:IsForbidden())
                and not (child.IsProtected and child:IsProtected()) then
                local relative = math.max(1, child:GetFrameLevel() - frame:GetFrameLevel())
                Collect(child, offset + relative)
            end
        end
    end
    Collect(root, 0)
    -- Native portrait/border templates reserve offsets of 400–510. Preserve
    -- their ordering without carrying those large gaps into every window.
    local levels, seen, ranks = {}, {}, {}
    for _, item in ipairs(frames) do
        if not seen[item.offset] then seen[item.offset] = true; levels[#levels + 1] = item.offset end
    end
    table.sort(levels)
    for i, level in ipairs(levels) do ranks[level] = i - 1 end
    for _, item in ipairs(frames) do item.offset = ranks[item.offset] end
    return frames, #levels - 1
end

-- Keep complete window trees in separate, bounded level ranges. Raising only
-- the root lets an older window's nested controls draw through the new window.
function T.FocusWindow(root)
    if restacking or not registered[root] then return end
    focusRevision = focusRevision + 1
    restacking = true
    for i, frame in ipairs(windows) do
        if frame == root then table.remove(windows, i); break end
    end
    windows[#windows + 1] = root
    local ok, errorMessage = pcall(function()
        local level = 20
        for _, window in ipairs(windows) do
            local frames, highest = WindowFrames(window)
            -- A complete focused window belongs to a higher strata than every
            -- background window, including native decoration and nested text.
            -- This prevents lower controls from piercing its opaque backing.
            local strata = window == root and "DIALOG" or "HIGH"
            for _, item in ipairs(frames) do
                if item.frame:GetFrameStrata() ~= strata then item.frame:SetFrameStrata(strata) end
                if item.frame:GetFrameLevel() ~= level + item.offset then item.frame:SetFrameLevel(level + item.offset) end
            end
            level = level + highest + 4
        end
    end)
    restacking = false
    if not ok and geterrorhandler then geterrorhandler()(errorMessage) end
end
function T.RegisterWindow(frame)
    if registered[frame] then return end
    frame:Hide(); frame:SetFrameStrata("DIALOG")
    -- Explicit focus management keeps the full tree together. Native automatic
    -- raising on mouse-down would bypass the safe, deferred click lifecycle.
    if frame.SetToplevel then frame:SetToplevel(false) end
    registered[frame] = true; windows[#windows + 1] = frame
    frame:HookScript("OnShow", function() T.FocusWindow(frame) end)
    frame:HookScript("OnHide", function()
        if windows[#windows] ~= frame then return end
        for i = #windows - 1, 1, -1 do
            if windows[i]:IsShown() then T.FocusWindow(windows[i]); break end
        end
    end)
end
function T.ShowWindow(frame)
    if frame:IsShown() then T.FocusWindow(frame) else frame:Show() end
end
T.Sources = {{"all", "All sources"}, {"player", "Player chat"}, {"npc", "NPC chat"},
    {"bubble", "Chat bubbles"}, {"quest", "Quests"}, {"gossip", "NPC dialogue"},
    {"barber", "Barber shop"}, {"talkingHead", "Talking heads"}, {"demo", "Preview test"},
    {"manual", "Other / pasted text"}}
T.Actions = {{"Unchanged", "Keep visible"}, {"Warning", "Show with a warning"},
    {"Redacted", "Redact matched words"}, {"Hidden", "Hide the message"}}
T.RuleActions = {{"Unchanged", "Keep visible"}, {"Warning", "Show with a warning"},
    {"Redacted", "Redact matched words"}, {"Hidden", "Hide the message"}, {"Replaced", "Replace with text"}}
local function Parchment(texture)
    if C_Texture and C_Texture.GetAtlasInfo and texture.SetAtlas
        and C_Texture.GetAtlasInfo("QuestBG-Parchment") then
        texture:SetAtlas("QuestBG-Parchment")
    elseif not texture:SetTexture("Interface\\QuestFrame\\QuestBG") then
        texture:SetTexture("Interface\\LFGFrame\\UI-LFG-BACKGROUND-QUESTPAPER")
    end
end
function T.Ink(text)
    text:SetTextColor(0.18, 0.12, 0.065, 1)
    if text.SetShadowColor then text:SetShadowColor(0, 0, 0, 0) end
    return text
end
function T.Gold(text) text:SetTextColor(1, 0.82, 0.39, 1); return text end
function T.Light(text) text:SetTextColor(0.89, 0.86, 0.78, 1); return text end
function T.Muted(text) text:SetTextColor(0.64, 0.65, 0.61, 1); return text end
function T.Heading(text) T.Ink(text); text:SetTextColor(0.37, 0.20, 0.075, 1); return text end
function T.Label(choices, value)
    if value == "Replaced" then return "Replace with text" end
    for _, choice in ipairs(choices) do if choice[1] == value then return choice[2] end end
    return value and tostring(value) or ""
end

-- The same Blizzard metal/portrait frame used by the official Olympus window.
function T.Window(name, parent, width, height)
    local ok, frame = pcall(CreateFrame, "Frame", name, parent, "PortraitFrameTemplate")
    if not ok or not frame then frame = CreateFrame("Frame", name .. "Basic", parent, "BasicFrameTemplateWithInset") end
    frame:SetSize(width, height); frame:SetPoint("CENTER"); frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true); frame:SetMovable(true); frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving); frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    if frame.CloseButton then frame.CloseButton:SetScript("OnClick", function() frame:Hide() end) end
    if UISpecialFrames then UISpecialFrames[#UISpecialFrames + 1] = frame:GetName() end
    T.SkinWindow(frame); T.RegisterWindow(frame); return frame
end
function T.Title(frame, text)
    if frame.SetTitle then frame:SetTitle(text)
    elseif frame.TitleText then frame.TitleText:SetText(text)
    elseif frame.TitleContainer and frame.TitleContainer.TitleText then frame.TitleContainer.TitleText:SetText(text) end
end
function T.SkinWindow(frame, top, bottom)
    -- Native dialog textures include transparency. Fill their interior so a
    -- lower window cannot show through header/footer gaps or dark panels.
    local backing = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
    backing:SetPoint("TOPLEFT", 6, -6); backing:SetPoint("BOTTOMRIGHT", -6, 6)
    backing:SetColorTexture(0.055, 0.05, 0.04, 1); frame.OlympusBacking = backing
    if frame.SetBackdrop then
        frame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true,
            tileSize = 32, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})
        frame:SetBackdropColor(0.48, 0.48, 0.48, 1); frame:SetBackdropBorderColor(0.62, 0.62, 0.62, 1)
    end
    if frame.Inset then frame.Inset:Hide() end
    local dark = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
    dark:SetPoint("TOPLEFT", 6, -60); dark:SetPoint("BOTTOMRIGHT", -6, 26)
    dark:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    dark:SetVertexColor(0.34, 0.34, 0.34, 1); frame.OlympusDark = dark
    if top then
        local paper = frame:CreateTexture(nil, "BACKGROUND", nil, 2)
        paper:SetPoint("TOPLEFT", 8, -top); paper:SetPoint("BOTTOMRIGHT", -8, bottom or 46)
        Parchment(paper); frame.OlympusPaper = paper
    end
end
function T.Crest(frame, x, y, size)
    local portrait = frame.portrait or frame.Portrait
        or (frame.PortraitContainer and frame.PortraitContainer.portrait)
    if portrait then
        portrait:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
        portrait:SetTexCoord(0, 1, 0, 1)
        local portraitParent = portrait:GetParent() or frame
        local crest = frame.OlympusCrest or portraitParent:CreateTexture(nil, "OVERLAY", nil, 1)
        frame.OlympusCrest = crest
        crest:ClearAllPoints(); crest:SetPoint("CENTER", portrait, "CENTER")
        crest:SetSize(portrait:GetWidth() * 0.80, portrait:GetHeight() * 0.80)
        crest:SetTexture(T.Icon); crest:SetTexCoord(0, 1, 0, 1)
        return crest
    end
    local badge = CreateFrame("Frame", nil, frame)
    badge:SetSize(size or 44, size or 44); badge:SetPoint("TOPLEFT", x or 18, y or -10)
    local scale = (size or 44) / 31
    local background = badge:CreateTexture(nil, "BACKGROUND")
    background:SetSize(20 * scale, 20 * scale); background:SetPoint("TOPLEFT", 7 * scale, -5 * scale)
    background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    local crest = badge:CreateTexture(nil, "ARTWORK")
    crest:SetAllPoints(background); crest:SetTexture(T.Icon); crest:SetTexCoord(0, 1, 0, 1)
    local border = badge:CreateTexture(nil, "OVERLAY")
    border:SetSize(53 * scale, 53 * scale); border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    frame.OlympusCrest, frame.OlympusCrestBorder = crest, border
    return crest
end
function T.MinimapCrest(button)
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetSize(20, 20); background:SetPoint("TOPLEFT", 7, -5)
    background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    button:SetNormalTexture(T.Icon)
    local icon = button:GetNormalTexture()
    icon:ClearAllPoints(); icon:SetSize(20, 20); icon:SetPoint("TOPLEFT", 7, -5)
    icon:SetTexCoord(0, 1, 0, 1)
    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53); border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    button.OlympusCrestBorder = border
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
end
function T.Panel(parent, x, y, width, height, paper)
    local panel = CreateFrame("Frame", nil, parent, "InsetFrameTemplate")
    panel:SetFrameLevel(parent:GetFrameLevel() + 1)
    panel:SetPoint("TOPLEFT", x, y); panel:SetSize(width, height)
    if paper then
        local texture = panel:CreateTexture(nil, "BACKGROUND", nil, 2)
        texture:SetPoint("TOPLEFT", 3, -3); texture:SetPoint("BOTTOMRIGHT", -3, 3)
        Parchment(texture); panel.OlympusPaper = texture
    end
    return panel
end
-- Shared styling for preview and report windows.
function T.Inset(parent, region)
    local fill = parent:CreateTexture(nil, "BACKGROUND", nil, 2)
    fill:SetPoint("TOPLEFT", region, "TOPLEFT", -8, 8)
    fill:SetPoint("BOTTOMRIGHT", region, "BOTTOMRIGHT", 8, -8)
    Parchment(fill); return fill
end
function T.Tooltip(owner, title, description)
    owner:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetText(title)
        GameTooltip:AddLine(description, 0.9, 0.9, 0.85, true); GameTooltip:Show()
    end)
    owner:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
end

-- Native radio dropdown, with a list fallback for clients lacking DropdownButton.
function T.Dropdown(parent, x, y, width, choices, getValue, setValue)
    local ok, dropdown = pcall(CreateFrame, "DropdownButton", nil, parent, "WowStyle1DropdownTemplate")
    local native = ok and dropdown and dropdown.SetupMenu
    if not native then
        if ok and dropdown then dropdown:Hide() end
        dropdown = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    end
    dropdown:SetSize(width, 26); dropdown:SetPoint("TOPLEFT", x, y)
    local popup
    function dropdown:Refresh()
        local label = T.Label(choices, getValue())
        if native then self:SetDefaultText(label); self:GenerateMenu()
        else self:SetText(label .. "  v"); if popup then popup:Hide() end end
    end
    local function Choose(value) setValue(value); dropdown:Refresh() end
    local function Generate(_, root)
        for _, choice in ipairs(choices) do
            root:CreateRadio(choice[2], function(value) return getValue() == value end, Choose, choice[1])
        end
    end
    if native then dropdown:SetupMenu(Generate)
    else
        dropdown:SetScript("OnClick", function(self)
            if MenuUtil and MenuUtil.CreateContextMenu then MenuUtil.CreateContextMenu(self, Generate); return end
            if not popup then
                popup = CreateFrame("Frame", nil, self, "BackdropTemplate")
                popup:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -2)
                popup:SetFrameStrata("TOOLTIP")
                popup:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 32, edgeSize = 12,
                    insets = {left = 3, right = 3, top = 3, bottom = 3}})
                popup.items = {}
                self:HookScript("OnHide", function() popup:Hide() end); popup:Hide()
            end
            if popup:IsShown() then popup:Hide(); return end
            popup:SetSize(width, #choices * 24 + 8)
            -- Report actions and recent-message choices can change while the
            -- form is reused. Reuse controls, but refresh their current values.
            for i, choice in ipairs(choices) do
                local item = popup.items[i]
                if not item then
                    item = CreateFrame("Button", nil, popup); popup.items[i] = item
                    item:SetSize(width - 8, 24); item:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 24)
                    item:SetNormalFontObject(GameFontHighlightSmall)
                    item:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
                    item:SetScript("OnClick", function(control) Choose(control.value); popup:Hide() end)
                end
                item.value = choice[1]; item:SetText(choice[2]); item:Show()
            end
            for i = #choices + 1, #popup.items do popup.items[i]:Hide() end
            popup:Show()
        end)
    end
    dropdown:Refresh(); return dropdown
end
function T.SkinRow(row)
    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    local highlight = row:GetHighlightTexture(); if highlight then highlight:SetAlpha(0.25) end
    row.stripe = row:CreateTexture(nil, "ARTWORK")
    row.stripe:SetWidth(3); row.stripe:SetPoint("TOPLEFT", 0, -2); row.stripe:SetPoint("BOTTOMLEFT", 0, 2)
end
function T.RowState(row, selected, action)
    row.background:SetColorTexture(selected and 0.26 or 0.09, selected and 0.22 or 0.09,
        selected and 0.12 or 0.09, selected and 0.95 or 0.48)
    T.Light(row.label)
    if action == "Hidden" then row.stripe:SetColorTexture(0.78, 0.22, 0.17, 1)
    elseif action == "Redacted" then row.stripe:SetColorTexture(0.88, 0.57, 0.19, 1)
    else row.stripe:SetColorTexture(0.69, 0.64, 0.31, 1) end
end
