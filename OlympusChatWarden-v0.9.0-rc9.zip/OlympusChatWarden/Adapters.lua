local _, ns = ...
local states = setmetatable({}, {__mode = "k"})
local installedFrames = setmetatable({}, {__mode = "k"})
local buttons = setmetatable({}, {__mode = "k"})
local chatInstalled, scanQueued, resetPending = false, false, false
local nextReviewKey, nextChatRevealKey = 0, 0

local function PreviewState(region, action)
    local label = ns.DemoStatuses and ns.DemoStatuses[region]
    if label then
        label:SetText(({Unchanged = "Visible - no active match", Warning = "Warning - text remains visible",
            Redacted = "Redacted words - click to reveal", Replaced = "Replaced wording - shown in gray", Hidden = "Hidden - original is in Review messages",
            Revealed = "Revealed - click again to redact", Disabled = "Visible - filtering is disabled for this area",
            Unavailable = "Text unavailable"})[action] or action)
    end
end

local function RecordUI(region, state, matches)
    if not ns.Review or #matches == 0
        or (region.IsVisible and not region:IsVisible()) or not state.source then return end
    local source = state.source()
    if not source then return end
    local signature = tostring(ns.Interaction) .. ":" .. tostring(ns.PolicyRevision)
        .. ":" .. (source.kind or "ui") .. ":" .. tostring(source.questID or "")
        .. ":" .. (source.questTitle or "") .. ":" .. (source.npc or "")
    if state.logRaw == state.raw and state.logSignature == signature and ns.Review.Get(state.logID) then return state.logID end
    nextReviewKey = nextReviewKey + 1
    local id = ns.Review.Add(state.raw, matches, source, "ui:" .. nextReviewKey)
    if id then state.logRaw, state.logSignature, state.logID = state.raw, signature, id end
    return id
end

local function SafeRegion(region)
    return region and region.GetText and region.GetParent and region.SetAlpha
        and not (region.IsForbidden and region:IsForbidden())
end

local function CanChange(region, state)
    if state.bubble then
        local parent = region:GetParent()
        return ns.BubbleSafe and ns.BubbleSafe(state.bubble)
            and not (region.IsForbidden and region:IsForbidden())
            and parent and not (parent.IsForbidden and parent:IsForbidden())
            and not (parent.IsProtected and parent:IsProtected())
    end
    return not (InCombatLockdown and InCombatLockdown())
end

local function RestoreBubble(state)
    if state.bubble and state.bubbleHidden then
        state.bubble:SetAlpha(state.bubbleAlpha)
        state.bubbleHidden = false
    end
end
local function Write(region, state, text)
    if not ns.CanRead(text) then return end
    state.display = text
    if region:GetText() == text then return end
    state.writing = true
    region:SetText(text)
    state.writing = false
end
local function Restore(region, state)
    Write(region, state, state.raw)
    region:SetAlpha(state.alpha)
    RestoreBubble(state)
end

local function Apply(region, state)
    if not CanChange(region, state) then return end
    if not ns.CanRead(state.raw) then
        state.action = "Unavailable"
        PreviewState(region, "Unavailable")
        if state.cover then state.cover:Hide() end
        if state.warning then state.warning:Hide() end
        Restore(region, state)
        return
    end
    local active = ns.Active(state.scope)
    if active and state.bubble and ns.BubbleAllowed then active = ns.BubbleAllowed(state.raw) end
    local matches = active and ns.Find(state.raw) or {}
    if #matches == 0 then
        state.revealed = false
        state.action = not ns.Active(state.scope) and "Disabled" or "Unchanged"
        PreviewState(region, state.action)
        if state.cover then state.cover:Hide() end
        if state.warning then state.warning:Hide() end
        Restore(region, state)
        return
    end
    local retained = RecordUI(region, state, matches)
    local action = ns.MatchAction(matches)
    if action == "Hidden" and not retained then action = "Warning" end
    state.action = action
    PreviewState(region, action)
    if state.warning then state.warning:Hide() end
    if action == "Replaced" then
        state.revealed = false
        if state.cover then state.cover:Hide() end
        Write(region, state, ns.RenderRedacted(state.raw, matches, region))
        region:SetAlpha(state.alpha); RestoreBubble(state); state.matches = matches
        return
    end
    if action ~= "Redacted" then
        state.revealed = false
        if state.cover then state.cover:Hide() end
        Write(region, state, action == "Warning" and ns.RenderWarning(state.raw) or state.raw)
        region:SetAlpha(action == "Hidden" and 0 or state.alpha)
        if state.bubble and action == "Hidden" then
            local alpha = state.bubble:GetAlpha()
            if not state.bubbleHidden or alpha > 0 then state.bubbleAlpha = alpha end
            state.bubbleHidden = true; state.bubble:SetAlpha(0)
        else RestoreBubble(state) end
        state.matches = matches
        return
    end
    if not state.cover then
        -- Transparent click target; only the inline Bar textures conceal words.
        local cover = CreateFrame("Button", nil, region:GetParent())
        cover:SetAllPoints(region)
        if cover.SetFrameLevel and region:GetParent().GetFrameLevel then
            cover:SetFrameLevel(region:GetParent():GetFrameLevel() + 1)
        end
        cover:SetScript("OnClick", function()
            if not CanChange(region, state) then return end
            state.revealed = not state.revealed
            Apply(region, state)
        end)
        cover:SetScript("OnEnter", function(self)
            if not GameTooltip then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(state.revealed and "Click to redact again" or "Click to reveal the matched words")
            GameTooltip:Show()
        end)
        cover:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
        state.cover = cover; ns.Stats.uiBlocks = ns.Stats.uiBlocks + 1
    end
    state.matches = matches
    RestoreBubble(state)
    Write(region, state, state.revealed and ns.RenderRevealed(state.raw, matches, region)
        or ns.RenderRedacted(state.raw, matches, region))
    state.action = state.revealed and "Revealed" or "Redacted"
    PreviewState(region, state.action)
    region:SetAlpha(state.alpha)
    state.cover:SetAlpha(1); state.cover:Show()
end

-- Bubble polling/source capture must read the original, not our texture markup.
function ns.RegionOriginal(region)
    local state = states[region]
    return state and state.raw or region:GetText()
end

function ns.TrackRegion(region, scope, sourceProvider, bubble)
    if not SafeRegion(region) then return end
    if bubble then
        if not ns.BubbleSafe(bubble) then return end
    elseif InCombatLockdown and InCombatLockdown() then return end
    if region.GetObjectType and region:GetObjectType() ~= "FontString" then return end
    local parent = region:GetParent()
    if not parent or (parent.IsForbidden and parent:IsForbidden())
        or (parent.IsProtected and parent:IsProtected()) then return end
    local state = states[region]
    if not state then
        state = {scope = scope, raw = region:GetText(), alpha = region:GetAlpha(), revealed = false, source = sourceProvider}
        state.bubble, state.bubbleAlpha = bubble, bubble and bubble:GetAlpha()
        states[region] = state
        hooksecurefunc(region, "SetText", function(_, text)
            if state.writing then return end
            if not ns.CanRead(text) then
                state.raw, state.revealed = nil, false
            elseif state.raw ~= text then
                state.raw, state.revealed = text, false
            end
            Apply(region, state)
        end)
    else
        if sourceProvider then state.source = sourceProvider end
        local text = region:GetText()
        if not ns.CanRead(text) then state.raw, state.revealed = nil, false
        elseif state.raw ~= text and state.display ~= text then state.raw, state.revealed = text, false end
    end
    Apply(region, state)
end

function ns.ResetBubbleRegion(region)
    local state = states[region]
    if not state or not state.bubble then return end
    if not CanChange(region, state) then return end
    Restore(region, state)
    if state.cover then state.cover:Hide() end
    if state.warning then state.warning:Hide() end
    state.raw, state.matches, state.logRaw, state.logSignature, state.logID = nil, nil, nil, nil, nil
    state.display = nil
    state.revealed = false
end

function ns.RefreshUI(reset)
    for region, state in pairs(states) do
        if reset then state.revealed = false end
        Apply(region, state)
    end
    if ns.RefreshBarber then ns.RefreshBarber() end
end

function ns.ScanUI()
    -- Narrative text only. Never enumerate arbitrary UI, objectives, names,
    -- quest-choice buttons, or combat frames.
    for _, name in ipairs({"QuestInfoDescriptionText", "QuestInfoRewardText", "QuestProgressText", "GreetingText"}) do
        local regionName = name
        ns.TrackRegion(_G[name], "dialogue", function()
            local isLog = (regionName == "QuestInfoDescriptionText" or regionName == "QuestInfoRewardText")
                and QuestInfoFrame and QuestInfoFrame.questLog
            return ns.UIReviewSource(regionName == "GreetingText" and "gossip" or "quest", regionName, isLog)
        end)
    end
    local gossip = GossipFrame
    local scroll = gossip and gossip.GreetingPanel and gossip.GreetingPanel.ScrollBox
    if scroll and scroll.GetFrames then
        for _, frame in ipairs(scroll:GetFrames()) do
            ns.TrackRegion(frame.GreetingText, "dialogue", function() return ns.UIReviewSource("gossip", "Gossip greeting") end)
        end
    end
    if TalkingHeadFrame and TalkingHeadFrame.TextFrame then
        ns.TrackRegion(TalkingHeadFrame.TextFrame.Text, "talkingHead", function() return ns.UIReviewSource("talkingHead", "Talking-head caption") end)
    end
end

function ns.QueueScan(reset)
    resetPending = resetPending or reset
    if scanQueued then return end
    scanQueued = true
    local function Run()
        scanQueued = false
        ns.ScanUI()
        ns.RefreshUI(resetPending)
        resetPending = false
    end
    if C_Timer and C_Timer.After then C_Timer.After(0, Run) else Run() end
end

local function BarberLabel(button)
    if InCombatLockdown and InCombatLockdown() then return end
    local sexes = Enum and Enum.UnitSex
    if not sexes or not button.ClearTooltipLines or not button.AddTooltipLine then return end
    local original
    if button.sexID == sexes.Male then original = BODY_1
    elseif button.sexID == sexes.Female then original = BODY_2 end
    if not ns.CanRead(original) then return end
    local matches = ns.Active("barber") and ns.Find(original) or {}
    local action = #matches > 0 and ns.MatchAction(matches) or nil
    local redacted = action == "Redacted"
    local replaced = action == "Replaced"
    local data = buttons[button]
    if not data then
        data = {}; buttons[button] = data
        hooksecurefunc(button, "SetBodyType", BarberLabel)
    end
    if not data.badge and (redacted or replaced) and not (InCombatLockdown and InCombatLockdown()) then
        local badge = CreateFrame("Button", nil, button)
        badge:SetSize(80, 17)
        badge:SetPoint("TOP", button, "BOTTOM", 0, -3)
        local texture = badge:CreateTexture(nil, "BACKGROUND")
        texture:SetAllPoints()
        texture:SetColorTexture(0, 0, 0, 1)
        local label = badge:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        label:SetAllPoints(); label:SetTextColor(0.69, 0.71, 0.73)
        badge:SetScript("OnClick", function()
            if InCombatLockdown and InCombatLockdown() then return end
            if data.match and data.match.replacement then return end
            data.revealed = not data.revealed; BarberLabel(button)
        end)
        ns.Theme.Tooltip(badge, "Reveal body-type label", "Click to reveal the label. Click again to redact it.")
        data.texture, data.label = texture, label
        data.badge = badge
    end
    if data.original ~= original or data.revision ~= ns.PolicyRevision then data.revealed = false end
    data.original, data.match, data.revision = original, matches[1], ns.PolicyRevision
    if #matches > 0 and ns.Review and not (button.IsVisible and not button:IsVisible()) then
        local signature = original .. ":" .. tostring(ns.Interaction) .. ":" .. tostring(ns.PolicyRevision)
        if data.logSignature ~= signature or not ns.Review.Get(data.logID) then
            nextReviewKey = nextReviewKey + 1
            data.logID = ns.Review.Add(original, matches, ns.UIReviewSource("barber", "Body-type tooltip"), "barber:" .. nextReviewKey)
            if data.logID then data.logSignature = signature end
        end
    end
    if action == "Hidden" and not (data.logID and ns.Review.Get(data.logID)) then action = "Warning" end
    button:ClearTooltipLines()
    if action ~= "Hidden" then
        button:AddTooltipLine(replaced and ns.RenderRedacted(original, matches) or redacted and (data.revealed and ns.RenderRevealed(original, matches)
            or ns.RenderRedacted(original, matches))
            or action == "Warning" and ns.RenderWarning(original) or original, HIGHLIGHT_FONT_COLOR)
    end
    if data.badge then
        data.texture:SetShown(redacted and not data.revealed)
        data.label:SetText(replaced and ns.RenderRedacted(original, matches, data.label) or original)
        data.label:SetShown(replaced or data.revealed)
        data.badge:SetShown(redacted or replaced)
        data.badge:EnableMouse(redacted)
    end
    -- Restrict visible-label handling to the known sex-selector buttons.
    -- Track originals so pooled buttons and disabling coverage restore correctly.
    local nativeLabel = false
    for _, region in ipairs(button.GetRegions and {button:GetRegions()} or {}) do
        if region.GetObjectType and region:GetObjectType() == "FontString" then
            local raw = ns.RegionOriginal(region)
            if ns.CanRead(raw) and (#ns.BodyReplacements:Find(raw) > 0 or raw == BODY_1 or raw == BODY_2) then
                nativeLabel = true
                ns.TrackRegion(region, "barber", function() return ns.UIReviewSource("barber", "Body-type label") end)
            end
        end
    end
    if nativeLabel and replaced and data.badge then data.badge:Hide() end
end

function ns.RefreshBarber()
    if InCombatLockdown and InCombatLockdown() then return end
    local frame = BarberShopFrame
    local pool = frame and frame.sexButtonPool
    if pool and pool.EnumerateActive then
        for button in pool:EnumerateActive() do BarberLabel(button) end
    end
end

local npcEvents = {"CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_WHISPER", "CHAT_MSG_MONSTER_EMOTE"}
local playerEvents = {"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_CHANNEL", "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
    "CHAT_MSG_RAID_WARNING", "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER"}
local npcLookup = {}
for _, event in ipairs(npcEvents) do npcLookup[event] = true end

function ns.ChatFilter(frame, event, message, ...)
    if not ns.Active(npcLookup[event] and "npc" or "chat") or not ns.CanRead(message) then return false end
    local matches = ns.Find(message)
    if #matches == 0 then return false end
    local action = ns.MatchAction(matches)
    local source, key = ns.ChatReviewSource(event, ...)
    local lineKey = key
    if not lineKey then
        -- Some clients omit a readable line ID. Each render still needs an
        -- independent reveal state even for identical messages in one tick.
        nextChatRevealKey = nextChatRevealKey + 1
        lineKey = "chat-render:" .. nextChatRevealKey
    end
    key = key or ns.ChatFallbackKey(event, message, source)
    local frameName = frame and frame.GetName and ns.SafeString(ns.SafeCall(frame.GetName, frame), 128) or tostring(frame)
    local revealKey = lineKey .. ":" .. (frameName or "chat") .. ":" .. tostring(ns.PolicyRevision)
    local rendered = action == "Hidden" and "[Hidden - original available in review inbox]"
        or ns.RenderRedacted(message, matches, frame, true, revealKey)
    if action == "Warning" then rendered = ns.RenderWarning(message) end
    local retained
    if ns.Review then
        local preview = action == "Hidden" and rendered or ns.Engine.Render(message, matches, function(original, match)
            return match.replacement or (match.score >= 65 and "[redacted]" or original)
        end)
        if action == "Warning" then preview = "[!] " .. message end
        retained = ns.Review.Add(message, matches, source, key, preview)
    end
    ns.Stats.chatMatches = ns.Stats.chatMatches + #matches
    -- Fail open if an original could not be retained for review.
    if action == "Hidden" then return retained ~= nil end
    return false, rendered, ...
end

function ns.InstallAdapters()
    if not chatInstalled then
        local register = ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter or ChatFrame_AddMessageEventFilter
        if type(register) == "function" then
            for _, event in ipairs(playerEvents) do register(event, ns.ChatFilter) end
            for _, event in ipairs(npcEvents) do register(event, ns.ChatFilter) end
            chatInstalled = true
        end
    end
    ns.ChatReveal.Install()
    local barber = BarberShopFrame
    if barber and not installedFrames[barber] and type(barber.UpdateSex) == "function" then
        hooksecurefunc(barber, "UpdateSex", ns.RefreshBarber)
        barber:HookScript("OnShow", ns.RefreshBarber)
        installedFrames[barber] = true
    end
    local gossip = GossipFrame
    if gossip and not installedFrames[gossip] then
        if type(gossip.RegisterFontString) == "function" then
            hooksecurefunc(gossip, "RegisterFontString", function(_, region)
                if SafeRegion(region) and region:GetParent() and region:GetParent().GreetingText == region then
                    ns.TrackRegion(region, "dialogue", function() return ns.UIReviewSource("gossip", "Gossip greeting") end)
                end
            end)
        end
        if type(gossip.Update) == "function" then
            hooksecurefunc(gossip, "Update", function() ns.QueueScan(false) end)
        end
        gossip:HookScript("OnShow", function() ns.QueueScan(true) end)
        installedFrames[gossip] = true
    end
end

function ns.MakeDemo()
    if InCombatLockdown and InCombatLockdown() then
        ns.Print("Open Filter preview after combat so it can apply your settings."); return
    end
    if not ns.Demo then
        local T = ns.Theme
        local demo = T.Window("OlympusChatWardenDemo", UIParent, 680, 424)
        T.Title(demo, "Olympus ChatWarden"); T.Crest(demo)
        local function Text(parent, x, y, width, value, font)
            local text = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
            text:SetPoint("TOPLEFT", x, y); text:SetWidth(width); text:SetJustifyH("LEFT")
            text:SetText(value); T.Light(text); return text
        end
        T.Gold(Text(demo, 78, -30, 575, "Filter preview", "GameFontNormalLarge"))
        T.Muted(Text(demo, 78, -50, 575, "Uses your current sensitivity, categories and coverage settings."))
        ns.DemoStatuses, ns.DemoExamples = {}, {}
        local examples = {{"Warning example", "We found a safe space near the inn."}, {"Redaction example", "An inclusive language guide visits the village."},
            {"Hide example", "Body Type 1 and birthing person"}}
        for i, spec in ipairs(examples) do
            local row = T.Panel(demo, 14, -82 - (i - 1) * 84, 652, 76)
            T.Gold(Text(row, 12, -10, 180, spec[1], "GameFontNormal"))
            local status = T.Muted(Text(row, 194, -12, 442, ""))
            local text = Text(row, 14, -39, 612, spec[2], "GameFontHighlight")
            ns.DemoStatuses[text] = status; ns.DemoExamples[i] = text
        end
        ns.DemoLow, ns.DemoText, ns.DemoHigh = ns.DemoExamples[1], ns.DemoExamples[2], ns.DemoExamples[3]
        T.Muted(Text(demo, 18, -344, 646, "Click redacted text to reveal its matched words; click again to redact. Hidden originals stay in Review."))
        local reset = CreateFrame("Button", nil, demo, "UIPanelButtonTemplate")
        reset:SetSize(140, 24); reset:SetPoint("BOTTOMLEFT", 18, 34); reset:SetText("Reset preview")
        reset:SetScript("OnClick", function() ns.RefreshUI(true) end)
        local review = CreateFrame("Button", nil, demo, "UIPanelButtonTemplate")
        review:SetSize(160, 24); review:SetPoint("BOTTOMLEFT", 170, 34); review:SetText("Review messages")
        review:SetScript("OnClick", ns.OpenReview)
        ns.Demo = demo
    end
    ns.Theme.ShowWindow(ns.Demo)
    for i, region in ipairs(ns.DemoExamples) do
        local index = i
        ns.TrackRegion(region, "dialogue", function() return {kind = "demo", panel = "Preview example " .. index} end)
    end
    ns.RefreshUI(true)
end

