-- An optional wording category, not a classifier for identities or people.
local _, ns = ...
table.insert(ns.PackNames, 3, "gender")
ns.RULE_VERSION = "stock-4-guild-1-creator-1-tuning-1-gender-1"
ns.GenderRuleChanges = {moved = 0, added = 0}

-- Give one toggle ownership of the existing gender/pronoun phrases. Keep their
-- scores and source notes; saved reports retain their original captured IDs.
for _, phrase in ipairs(ns.StockRules) do
    local meta = ns.RuleMeta[phrase]
    if (meta.pack == "language" or meta.pack == "slogans")
        and (phrase:find("gender", 1, true) or phrase:find("pronoun", 1, true)
            or phrase:find("assigned", 1, true) and phrase:find("at birth", 1, true)
            or phrase == "sex is a spectrum") then
        meta.pack, meta.id = "gender", "gender:" .. phrase
        meta.version = (meta.version or 1) + 1
        ns.GenderRuleChanges.moved = ns.GenderRuleChanges.moved + 1
    end
end
local function Add(phrase)
    if ns.RuleMeta[phrase] then return end
    ns.StockRules[#ns.StockRules + 1] = phrase
    ns.RuleMeta[phrase] = {id = "gender:" .. phrase, pack = "gender", base = 82,
        origin = "user-requested gender/pronoun wording preference; literal test candidate", version = 1}
    ns.GenderRuleChanges.added = ns.GenderRuleChanges.added + 1
end
for _, phrase in ipairs({"gender pronoun", "gender pronouns", "gender-pronoun", "gender-pronouns",
    "preferred gender pronoun", "preferred gender pronouns", "gender pronoun preference",
    "gender pronoun preferences", "gender-neutral wording", "gender neutral wording",
    "gender nuetral", "gender-nuetral", "gender nuetral language", "gender-nuetral language",
    "pronoun declaration", "pronoun declarations", "my pronouns are", "our pronouns are",
    "pronouns:"}) do Add(phrase) end

-- No standalone LGBT/LGBTQ abbreviations, identity labels, ordinary gender or
-- pronoun words, or individual he/she/they pronouns are added as triggers.
