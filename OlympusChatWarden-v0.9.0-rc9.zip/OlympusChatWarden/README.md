# Olympus ChatWarden

**Your chat. Your preferences.**

Version 0.9.0-rc9 — public-beta candidate, pending live testing.

Personal text filtering and wording replacements for player chat, accessible
bubbles and supported narrative/interface text. Choose categories, coverage and
Selective, Balanced, Broad or All listed terms sensitivity. Broad is the default.

Black bars are clickable redactions in supported chat: reveal in subdued gray,
then click again to cover. Gray replacement wording is a direct substitution;
Body 1 / Body Type 1 becomes male and Body 2 / Body Type 2 becomes female
when enabled. Originals
remain available in Review. Add your own replacements in My phrase rules.

rc8 fixes contraction fragments and casual em, extends gameplay guards for
portal/race and barber discussions, and adds independent category sensitivity.
Use /ocw categories for Default, Off or one of the four presets per group.
Captured reports preserve those choices. Existing ChatWarden data is retained.

Enable **Use Olympus tab instead of minimap icon** in Settings, then open
Olympus once. A ChatWarden crest tab appears under its upper-left portrait.
Left-click opens Review; right-click opens Settings. Turning the option off
restores your minimap preference. Olympus 1.2.1 is optional and its files need
no edits. Missing integration keeps the minimap preference active. Both old
and HD layouts are supported; live placement still needs testing.

## Install

Exit WoW. Remove the previous addon code folders so only one filter runs.
Extract OlympusChatWarden into Interface/AddOns and enable Olympus ChatWarden.
New installs use OlympusChatWardenDB settings. Upgrading from rc5 retains
ChatWarden's own settings, rules and reports. No old-name importer is included.

Use `/ocw` for Settings, `/ocw help` for the optional tutorials, and
`/ocw welcome` to reopen the first-launch introduction. `/chatwarden` is an alias.

## Reports

Save a missed or incorrect result, export it, and use Send feedback to copy
the GitHub reporting link. Reports are local until you manually share them;
saving one does not train the filter. Review identifying details before posting.

Project: https://github.com/RegretnWoW/OlympusChatWarden

Reports: https://github.com/RegretnWoW/OlympusChatWarden/issues

This is an independent addon with no
claim of official guild or Blizzard endorsement.

See QUICKSTART-v0.9.0-rc9.md for full instructions and live checks. Offline tests
use a simulated client; they do not establish live WoW rendering compatibility.
