# Creator preset source notes — researched 2026-10-07

Sources establish that a spelling or title is used; they do not establish intent, frequency,
endorsement, or an objective reason to filter it. Scores were selected as tester preferences.

| Source | Supported use | Evidence quality |
|---|---|---|
| https://www.twitch.tv/zackrawrr | Zackrawrr channel spelling | Channel URL itself |
| https://www.youtube.com/@AsmonTV | AsmonTV / Asmongold TV channel | Official channel identity |
| https://dotesports.com/streaming/news/asmongold-takes-issue-with-players-stealing-his-name-in-wow | Asmongold, Asmon, Zackrawrr, Asmongler, Asmonfresh | Reported historical character-name attempts; article has a refreshed page date |
| https://knowyourmeme.com/memes/people/asmongold | Asmonbald | Documented nickname, not a rule about how every use should be read |
| https://www.reddit.com/r/Asmongold/comments/hs2o23 | Asmonmald, Asmonbald | Observed community use; not independently verified official aliases |
| https://steamcommunity.com/discussions/forum/12/569291110057400097/ | Asmonroach | Observed community use |
| https://www.reddit.com/r/Asmongold/comments/1idcyyt | Baldmongold | Observed community use |
| https://www.reddit.com/r/videos/comments/1ui7dej/asmongold_is_a_coward/ | Asmonmold | Observed community use |
| https://www.reddit.com/r/AshesofCreation/comments/vc6kd6 | Asmongo / Asmongus | Unverified community report of character names; contextual candidates only |
| https://www.reddit.com/r/Asmongold/comments/1kz5tbi | Asmongold247 | Community report of alternate channel spelling |
| https://asmongame.com/ | Selected fan titles including Roach King, Lord Baldimort, Baldfather and Baron von Baldness | Fan-authored creative titles, not evidence of common or official nicknames; all require a separate creator reference |

Spacing, punctuation, leetspeak, r-count and Zakrawr variants are proposed test candidates,
not additional verified identities. Generic titles require creator context and generic first
names/appearance nouns are not standalone rules. The stock source list remains readable.
