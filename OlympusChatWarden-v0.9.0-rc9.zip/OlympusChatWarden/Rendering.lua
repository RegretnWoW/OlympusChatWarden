-- Inline bars and readable subdued text share the exact same match ranges.
local _, ns = ...
local measure
function ns.BarText(original, owner)
    local fontOwner = owner and owner.GetFont and owner or ChatFontNormal
    local path, size, flags
    if fontOwner and fontOwner.GetFont then path, size, flags = fontOwner:GetFont() end
    size = ns.SafeNumber(size) or 14
    local height = math.max(8, math.floor(size * 0.8 + 0.5))
    if not measure and UIParent and UIParent.CreateFontString then
        measure = UIParent:CreateFontString(nil, "OVERLAY"); measure:Hide()
    end
    if measure then
        if ns.CanRead(path) and measure.SetFont then measure:SetFont(path, size, ns.CanRead(flags) and flags or "")
        elseif ChatFontNormal then measure:SetFontObject(ChatFontNormal) end
    end
    -- Keep whitespace between individual bars so long phrases wrap naturally.
    return (original:gsub("%S+", function(word)
        local width
        if measure and measure.GetStringWidth then measure:SetText(word); width = ns.SafeNumber(measure:GetStringWidth()) end
        width = math.max(6, math.ceil(width or #word * size * 0.55))
        return "|TInterface\\AddOns\\OlympusChatWarden\\Media\\Bar:" .. height .. ":" .. width .. ":0:0|t"
    end))
end
local function ColorTracker(text)
    local pieces, offsets, offset, index, color = ns.Engine.Segments(text), {}, 0, 1, ""
    for i, piece in ipairs(pieces) do offsets[i] = offset; offset = offset + #piece.text end
    return function(first)
        while pieces[index] and offsets[index] < first - 1 do
            local piece = pieces[index]
            if not piece.editable then
                if piece.text:match("^|c%x%x%x%x%x%x%x%x$") then color = piece.text
                elseif piece.text == "|r" then color = "" end
            end
            index = index + 1
        end
        return color
    end
end
function ns.GrayText(original, owner, restoreColor)
    local gray = "|cffb0b5bb"
    if owner and owner.GetTextColor then
        local ok, r, g, b = pcall(owner.GetTextColor, owner)
        r, g, b = ns.SafeNumber(r), ns.SafeNumber(g), ns.SafeNumber(b)
        if ok and r and g and b and (r + g + b) / 3 < 0.5 then gray = "|cff535960" end
    end
    return gray .. original .. "|r" .. (restoreColor or "")
end
function ns.RenderRedacted(text, matches, owner, links, key)
    local colorAt = ColorTracker(text)
    return ns.Engine.Render(text, matches, function(original, match)
        local color = colorAt(match.first)
        if match.replacement then return ns.GrayText(match.replacement, owner, color) end
        if match.score < 65 then return original end
        if links then return ns.Marker(original, match, owner, key, color) end
        return ns.BarText(original, owner)
    end)
end
function ns.RenderRevealed(text, matches, owner)
    local colorAt = ColorTracker(text)
    return ns.Engine.Render(text, matches, function(original, match)
        local color = colorAt(match.first)
        return match.replacement and ns.GrayText(match.replacement, owner, color)
            or match.score >= 65 and ns.GrayText(original, owner, color) or original
    end)
end
function ns.RenderWarning(text) return "|cffffbb22[!]|r " .. text end
