# Olympus ChatWarden — 0.9.0-rc9

- Adds optional Olympus 1.2.1 integration. Enable **Use Olympus tab instead of
  minimap icon** in Settings, then open Olympus once to attach the crest tab
  below its upper-left guild portrait.
- Left-click opens Review; right-click opens ChatWarden Settings. Both portrait
  layouts and Basic fallbacks are supported without changing Olympus's tabs.
- Hides the minimap icon once a compatible launcher attaches. Turning the option
  off restores your saved minimap preference. Missing or incompatible Olympus
  windows leave that preference active.
- Handles lazy window creation, late loading, repeated opens and combat deferral.
- Retains rc8's independent category presets and captured category settings.
- Retains contraction and ambiguous short-pronoun fixes, bounded gameplay
  exceptions, body-label casing, inline reveal, window stacking and user reports.
- Keeps the approved crest and OlympusChatWarden repository/reporting links.
- Preserves existing ChatWarden settings, personal rules and saved reports.

The install contains ChatWarden only. Integration checks use constructor code
from the supplied Olympus 1.2.1 source in a simulated client. Live tab placement,
clicks, both layouts, window overlap, barber labels and report export still need
in-game testing before public release.
