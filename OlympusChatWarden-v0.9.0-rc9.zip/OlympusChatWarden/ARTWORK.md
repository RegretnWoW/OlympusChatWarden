# Artwork in v0.9.0-rc9

The minimap, addon metadata and window portraits share `Media/IconScroll.tga`.
It is the exact approved antique-gold crest with the large ivory scroll,
mechanically resized from the supplied transparent PNG to a 256x256 RGBA TGA.
No artwork was regenerated or repainted. The full supplied PNG is included in
the validation kit. The texture path explicitly names the TGA in the current
OlympusChatWarden folder.

The minimap button now uses native circular WoW chrome: a 31px button, 20px full
crest, dark minimap background and MiniMap-TrackingBorder overlay. The border
file includes transparent padding; it is positioned using the standard native
53px layout. The click target, review count and saved drag position are retained.

Native menu portrait coordinates are reset to the full image. A separate crest
texture draws at 80% of the portrait's dimensions, centered inside the existing
metal circle. The crest now belongs to the portrait's own frame and draws on
an overlay sublayer above its native background, which previously covered it.
Fallback panels also use native circular chrome. This frames the
approved art through UI code while keeping its source pixels unchanged.

`Media/Bar.tga` is opaque black for inline word redaction. Only the current
crest and word-bar textures are shipped; obsolete icon/stamp files are removed.

Panels use game-supplied quest parchment, native portrait/metal frames, dark
insets, gold headings and standard WoW controls. Personal controls share the
same theme. No Blizzard texture files are redistributed.

The approved crest is an Olympus-inspired interpretation referencing the
user's guild addon, https://github.com/dnl-gentile/olympus-addon. Reference art
belongs to its owners. This community addon claims no endorsement from that
project, guild leadership, Asmongold or Blizzard.

Transparent alpha, uncompressed TGA encoding, package references and converted
pixels were checked. The shared window theme now has an opaque inner backing.
Live WoW rendering still needs checking.
