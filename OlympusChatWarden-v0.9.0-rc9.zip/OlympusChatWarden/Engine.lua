-- Pure Lua 5.1-compatible Aho-Corasick phrase matcher. No WoW API dependencies.
local _, ns = ...
local Engine = {}
ns.Engine = Engine
Engine.MAX_RULES = 20000
Engine.MAX_PHRASE = 120
Engine.MAX_TEXT = 32768
Engine.MAX_RULE_BYTES = 300000
Engine.MAX_CANDIDATES = 1024

local function Word(byte)
    return byte and ((byte >= 48 and byte <= 57) or (byte >= 65 and byte <= 90)
        or (byte >= 97 and byte <= 122) or byte == 95 or byte >= 128)
end
local function Boundary(text, position, before)
    -- An apostrophe within a word is not the start of another whole word.
    -- Keep trailing possessive boundaries (Olympus's) and quoted 'LGBT' usable.
    if before then
        if text:sub(position, position) == "'" and Word(text:byte(position - 1)) then return false end
        if text:sub(position - 2, position) == "’" and Word(text:byte(position - 3)) then return false end
    end
    if not Word(text:byte(position)) then return true end
    -- Common UTF-8 punctuation is not a word letter. Keep all other non-ASCII
    -- bytes conservative so phrases cannot match inside accented words.
    for _, punctuation in ipairs({"“", "”", "‘", "’", "—", "–", "…"}) do
        local part = before and text:sub(position - #punctuation + 1, position)
            or text:sub(position, position + #punctuation - 1)
        if part == punctuation then return true end
    end
    return false
end

local function Validate(rules, minimum)
    if type(rules) ~= "table" then return nil, "Rules must be a list." end
    local result, seen, totalBytes = {}, {}, 0
    for _, phrase in ipairs(rules) do
        if type(phrase) ~= "string" then return nil, "Every rule must be text." end
        phrase = phrase:match("^%s*(.-)%s*$"):lower()
        if #phrase > 0 then
            if #phrase < minimum or #phrase > Engine.MAX_PHRASE then
                return nil, "Each phrase must contain " .. minimum .. "-120 ASCII characters."
            end
            if phrase:find("[^ -~]") or phrase:find("|", 1, true) then
                return nil, "Use printable English/ASCII phrases without WoW markup (|)."
            end
            if not seen[phrase] then
                seen[phrase] = true
                result[#result + 1] = phrase
                totalBytes = totalBytes + #phrase
                if #result > Engine.MAX_RULES then return nil, "Maximum 20,000 unique phrases." end
                if totalBytes > Engine.MAX_RULE_BYTES then return nil, "Rule text budget exceeded (300,000 bytes)." end
            end
        end
    end
    return result
end
function Engine.Validate(rules) return Validate(rules, 3) end

local function Compile(rules, minimum)
    local clean, err = Validate(rules, minimum)
    if not clean then return nil, err end
    local nodes = {{next = {}, fail = 1}}
    for id, phrase in ipairs(clean) do
        local state = 1
        for i = 1, #phrase do
            local byte = phrase:byte(i)
            local nextState = nodes[state].next[byte]
            if not nextState then
                nextState = #nodes + 1
                nodes[nextState] = {next = {}, fail = 1}
                nodes[state].next[byte] = nextState
            end
            state = nextState
        end
        nodes[state].output = id
    end
    local queue, first = {}, 1
    for _, state in pairs(nodes[1].next) do queue[#queue + 1] = state end
    while first <= #queue do
        local state = queue[first]
        first = first + 1
        for byte, child in pairs(nodes[state].next) do
            local failure = nodes[state].fail
            while failure ~= 1 and not nodes[failure].next[byte] do failure = nodes[failure].fail end
            nodes[child].fail = nodes[failure].next[byte] or 1
            local f = nodes[child].fail
            nodes[child].outputLink = nodes[f].output and f or nodes[f].outputLink
            queue[#queue + 1] = child
        end
    end
    return setmetatable({nodes = nodes, rules = clean}, {__index = Engine})
end
function Engine.Compile(rules) return Compile(rules, 3) end
-- Author-owned Maximum vocabulary includes short tokens such as Mx and ey.
-- Personal phrases and exceptions continue to use the original 3-character API.
function Engine.CompileLiteral(rules) return Compile(rules, 1) end

function Engine:FindPlain(text, allCandidates)
    local normalized, state, best, candidates = text:lower(), 1, {}, {}
    for i = 1, #normalized do
        local byte = normalized:byte(i)
        while state ~= 1 and not self.nodes[state].next[byte] do state = self.nodes[state].fail end
        state = self.nodes[state].next[byte] or 1
        local outputState = state
        while outputState do
            local id = self.nodes[outputState].output
            if id then
                local start = i - #self.rules[id] + 1
                if Boundary(normalized, start - 1, true) and Boundary(normalized, i + 1, false) then
                    if allCandidates then
                        if #candidates >= Engine.MAX_CANDIDATES then return {}, "candidate budget exceeded" end
                        candidates[#candidates + 1] = {first = start, last = i, rule = id}
                    end
                    if not best[start] or best[start].last < i then
                        best[start] = {first = start, last = i, rule = id}
                    end
                end
            end
            outputState = self.nodes[outputState].outputLink
        end
    end
    if allCandidates then return candidates end
    local matches, i = {}, 1
    while i <= #text do
        if best[i] then
            matches[#matches + 1] = best[i]
            i = best[i].last + 1
        else
            i = i + 1
        end
    end
    return matches
end

-- Preserve existing hyperlinks, textures/atlases, colors, and escaped pipes.
-- Phrases split by markup do not match in this first version.
function Engine.Segments(text)
    local pieces, start, i = {}, 1, 1
    local function Emit(last, editable)
        if last >= start then pieces[#pieces + 1] = {text = text:sub(start, last), editable = editable} end
        start = last + 1
    end
    while i <= #text do
        if text:sub(i, i) == "|" then
            local code, last = text:sub(i + 1, i + 1)
            if code == "H" then
                local h1 = text:find("|h", i + 2, true)
                last = h1 and text:find("|h", h1 + 2, true)
                last = last and last + 1
            elseif code == "T" or code == "A" then
                last = text:find(code == "T" and "|t" or "|a", i + 2, true)
                last = last and last + 1
            elseif code == "c" and text:sub(i + 2, i + 9):match("^%x%x%x%x%x%x%x%x$") then
                last = i + 9
            elseif code == "r" or code == "|" then
                last = i + 1
            end
            -- Unknown/malformed escapes: leave the rest unchanged, fail open.
            if not last then last = #text end
            Emit(i - 1, true)
            Emit(last, false)
            i = last + 1
        else
            i = i + 1
        end
    end
    Emit(#text, true)
    return pieces
end

function Engine:Find(text, allCandidates)
    if type(text) ~= "string" or #text > Engine.MAX_TEXT then return {}, "unsupported" end
    local matches, offset = {}, 0
    for _, piece in ipairs(Engine.Segments(text)) do
        if piece.editable then
            local found, err = self:FindPlain(piece.text, allCandidates)
            if err then return {}, err end
            for _, match in ipairs(found) do
                if allCandidates and #matches >= Engine.MAX_CANDIDATES then return {}, "candidate budget exceeded" end
                matches[#matches + 1] = {first = offset + match.first, last = offset + match.last, rule = match.rule,
                    segmentFirst = offset + 1, segmentLast = offset + #piece.text}
            end
        end
        offset = offset + #piece.text
    end
    return matches
end

function Engine.Render(text, matches, makeMarker)
    if #matches == 0 then return text end
    local parts, cursor = {}, 1
    for _, match in ipairs(matches) do
        parts[#parts + 1] = text:sub(cursor, match.first - 1)
        parts[#parts + 1] = makeMarker(text:sub(match.first, match.last), match)
        cursor = match.last + 1
    end
    parts[#parts + 1] = text:sub(cursor)
    return table.concat(parts)
end
