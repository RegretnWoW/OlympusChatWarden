-- Optional plain-language help and a once-per-account welcome introduction.
local _, ns = ...
local T = ns.Theme
local welcome, tutorial, body, scroll, measure, tabs
local pageID, loginReady, queued, deferFrame = "basics", false, false
local pages = {
    {id = "basics", title = "Start here", text = [[WHAT IS OLYMPUS CHATWARDEN?

It filters wording you choose to avoid in player chat and supported game text. Built-in categories cover selected terminology, Olympus-directed insults and creator-directed teasing. Choose which categories and text areas you want in Settings.

WHAT WILL I SEE?

Visible: the message stays as written.
Warning: a gold [!] appears on the same line. You can still read every word.
Redacted: matched words become black bars. The rest of the message stays readable.
Replaced: selected wording becomes alternative text in subdued gray. Built-in labels change Body Type 1 to Male and Body Type 2 to Female, matching the original capitalization.
Hidden: the message disappears from chat. Its original is kept in Review messages.

READ A REDACTION

Click the bars to reveal the matched words in subdued gray, in that same line. Click those words again to restore the bars. This does not change how future messages are filtered.

READ A HIDDEN MESSAGE

Left-click the minimap crest or type /ocw inbox. Select a message to read its original. Dismiss clears just that item from the session inbox. Saved reports stay in My reports.

TRY IT SAFELY

Use Filter preview in Settings, or /ocw preview. It uses your current categories, coverage and sensitivity. An example may stay visible when its category is off or your preset needs a stronger match. Click Reset preview to cover revealed examples again.

SHORTCUTS

/ocw opens Settings. /ocw inbox opens Review. /ocw help reopens this guide. /ocw feedback shows the reporting link. Right-click the minimap crest for Settings.

OLYMPUS GUILD WINDOW

Enable Use Olympus tab instead of minimap icon in Settings, then open Olympus once. A ChatWarden crest tab appears on its upper-left side below the guild portrait. Left-click opens Review; right-click opens Settings. Turning integration off restores your minimap preference. Olympus is optional; without it your minimap preference stays active.]]},
    {id = "confidence", title = "Confidence explained", text = [[CONFIDENCE MEANS MATCH STRENGTH

The addon gives a matching phrase a rule score from 0 to 100. It uses built-in phrase rules and, when enabled, nearby wording. The score measures how strongly the wording fits your filtering rules. It does not measure a person's intent or provide a statistical probability.

FIRST: DOES THE MATCH QUALIFY?

Your category's sensitivity sets the minimum score. A category set to Default follows the main preset. A match below its minimum stays visible. Coverage switches, disabled categories and exceptions can also prevent filtering.

THEN: WHAT ACTION DOES IT GET?

40-64: lower match strength -> warning. Every word remains visible.
65-84: medium match strength -> redact the matched words.
85-100: higher match strength -> hide the message and keep its original in Review.

EXAMPLE: A PHRASE SCORES 80

Broad accepts scores of 40 or more: the phrase is redacted.
Balanced accepts 65 or more: the same phrase is redacted.
Selective accepts 85 or more: that phrase stays visible.

WHAT DOES CONTEXT CHANGE?

Nearby wording can raise or lower a built-in phrase's score. A discussion or quotation can receive a different result from using the phrase directly. Name-based insult rules look for directed wording, rather than treating every mention of a guild or creator as an insult. These are limited rules and can make mistakes.

IF SEVERAL THINGS MATCH

The strongest accepted match determines the message's action. Several weak matches are not simply added into a total score. Separate strong matches can still hide a message even when you allow one phrase.

YOUR OWN RULES

A replacement rule displays your replacement text in gray and does not filter that replacement again. Body-type label substitutions apply across presets when the Body-label replacements category is enabled.

An explicit personal phrase rule applies the action you selected, across sensitivity presets. Coverage and exceptions still apply. Use Why filtered? in Review to see the matched wording and confidence level.]]},
    {id = "presets", title = "Choose a preset", text = [[BROAD

Minimum score: 40. Accepts weaker phrase matches, which may show warnings. This is the fresh-install default. Use it when you want wider coverage.

BALANCED

Minimum score: 65. Accepts medium and higher phrase matches. Try it if Broad catches too many borderline phrases.

SELECTIVE

Minimum score: 85. Accepts stronger phrase matches only. More borderline wording stays visible. A higher minimum makes this phrase preset more selective.

ALL LISTED TERMS

Also redacts whole listed words even when their surrounding sentence is ordinary or positive. It includes common words and short forms, so everyday chat can contain more bars. Choose it deliberately if you want those words covered whenever they appear.

All listed terms literal entries normally receive a redaction score of 80 without needing context. Ambiguous short pronouns e, em and ve require an explicit declaration. Contractions such as you've stay intact. Clear racial-ability/stat, character portal and barber-customization discussions remain visible; separate matching terms can still be filtered. Active categories and exceptions still apply. Independent stronger phrase matches can still hide a message.

CHOOSE WHERE AND WHAT

Where to filter selects player chat, NPC chat, dialogue, accessible bubbles and other supported text. Open Configure categories to choose a sensitivity for each wording group. Default follows the main preset; Off disables that category. Explicit category presets stay fixed when you change the main preset. For example, use Selective as the main preset and All listed terms only for one category. Changing these controls does not erase your saved reports or personal rules.

Body-label replacements apply in every enabled category preset; choose Off to disable them. Personal phrase rules still apply across presets and category switches. Exceptions and coverage still apply.

USE CONTEXT CLUES

This switch lets phrase modes consider nearby wording. Turning it off can change both warnings and hiding. Literal preferences stay active; short-pronoun and gameplay guards still apply.

MAKE ONE CORRECTION

If one phrase bothers you, make a personal phrase rule instead of changing every category. Choose Keep visible, Warning, Redact matched words or Hide the message. A separate stronger match in the same message can still filter it.]]},
    {id = "reports", title = "Fix misses / mistakes", text = [[THE FILTER MISSED A MESSAGE

Right-click the player's name in chat and choose Report missed filter. Check the original, choose what should happen, add an optional note and click Save report. If the exact message is unavailable, pick a recent message or paste it with /ocw report.

THE FILTER GOT A RESULT WRONG

Open Review messages, select the message and click Report a problem. Choose Should have stayed visible or Needed a different action, then save.

A REPORT ALONE SAVES FEEDBACK

Saving a report does not automatically teach the filter. It keeps an example for you to review or share. Captured reports retain the decision, rules and settings from when that message was observed.

APPLY A PERSONAL FIX NOW

Explicitly check Also apply a personal phrase rule and enter exact words from the original. The action you chose becomes that phrase's action. Or open My reports, select an example, choose Make a rule and save the rule yourself.

In My phrase rules, choose Replace with text and enter 1-120 printable English characters as the replacement. Gray replacement text is alternate wording, not clickable reveal text. Clickable black bars hide originals until you reveal them.

Rules accept 3-120 printable English characters and match whole phrases. You can edit, disable or delete them. Deleting a report keeps its phrase rules.

SEND EXAMPLES FOR FUTURE TUNING

Open My reports and click Export reports, or type /ocw export. Click Select all, press Ctrl+C and paste it into a GitHub issue. Use Send feedback beside Export reports, or /ocw feedback, to copy the reporting link. Reports are public on GitHub. Saving them does not train the filter. Nothing is sent automatically. Check message text and notes before sharing; they may identify people.

WHAT SURVIVES RELOAD?

Preferences, saved reports and personal rules stay on your account. The session Review inbox and recent-chat capture reset. Save important examples as reports before reloading.]]},
}
ns.HelpPages = pages
local function Label(parent, text, x, y, width, font, paper)
    local label = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
    label:SetPoint("TOPLEFT", x, y); label:SetWidth(width); label:SetJustifyH("LEFT"); label:SetText(text)
    if paper then T.Ink(label) else T.Light(label) end
    return label
end
local function Button(parent, text, x, y, width, fn)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width, 24); button:SetPoint("TOPLEFT", x, y); button:SetText(text); button:SetScript("OnClick", fn)
    return button
end
local function Fit(window)
    local w, h = UIParent:GetWidth(), UIParent:GetHeight()
    if w and h and w > 30 and h > 30 then
        window:SetScale(math.min(1, (w - 30) / window:GetWidth(), (h - 30) / window:GetHeight()))
    end
end
local function Page(id)
    for _, page in ipairs(pages) do if page.id == id then return page end end
end
local function SetPage(id)
    local page = Page(id) or pages[1]; pageID = page.id
    tutorial.Heading:SetText(page.title)
    body:SetText(page.text); body:SetCursorPosition(0); body:ClearFocus()
    scroll:SetVerticalScroll(0)
    for i, tab in ipairs(tabs) do tab:SetEnabled(pages[i].id ~= pageID) end
end
function ns.OpenTutorial(requestedPage)
    if not ns.DB then return end
    if not tutorial then
        tutorial = T.Window("OlympusChatWardenGuide", UIParent, 780, 620)
        ns.TutorialWindow = tutorial; T.Title(tutorial, ns.NAME); T.Crest(tutorial)
        tutorial.Heading = T.Gold(Label(tutorial, "How filtering works", 78, -30, 670, "GameFontNormalLarge"))
        T.Muted(Label(tutorial, "Choose a topic. Reading this guide leaves your settings and rules unchanged.", 78, -50, 670))
        local navigation = T.Panel(tutorial, 14, -76, 752, 42); tabs = {}
        for i, page in ipairs(pages) do
            local id = page.id
            tabs[i] = Button(navigation, page.title, 10 + (i - 1) * 185, -9, 175, function() SetPage(id) end)
        end
        local paper = T.Panel(tutorial, 14, -126, 752, 428, true)
        scroll = CreateFrame("ScrollFrame", nil, paper, "UIPanelScrollFrameTemplate")
        scroll:SetSize(700, 390); scroll:SetPoint("TOPLEFT", 18, -18)
        body = CreateFrame("EditBox", nil, scroll); ns.TutorialText = body
        body:SetMultiLine(true); body:SetAutoFocus(false); body:SetFontObject(ChatFontNormal); T.Ink(body)
        body:SetSize(696, 390); scroll:SetScrollChild(body)
        measure = body:CreateFontString(nil, "OVERLAY"); measure:SetFontObject(ChatFontNormal)
        measure:SetWordWrap(true); measure:SetWidth(696); measure:Hide()
        body:SetScript("OnTextChanged", function(self, userInput)
            if userInput then self:SetText(Page(pageID).text); return end
            measure:SetText(self:GetText() or "")
            local _, lines = (self:GetText() or ""):gsub("\n", "\n")
            self:SetHeight(math.max(390, (lines + 3) * 18, measure:GetStringHeight() + 30))
        end)
        body:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        Button(tutorial, "Try preview", 18, -569, 145, ns.MakeDemo)
        Button(tutorial, "Settings", 175, -569, 130, function() SlashCmdList.OLYMPUSCHATWARDEN("options") end)
        Button(tutorial, "My reports", 317, -569, 145, function() ns.OpenPersonal("reports") end)
        Button(tutorial, "Close", 662, -569, 100, function() tutorial:Hide() end)
        tutorial:HookScript("OnHide", function() body:ClearFocus() end)
    end
    SetPage(type(requestedPage) == "string" and requestedPage or pageID)
    Fit(tutorial); T.ShowWindow(tutorial)
end
function ns.OpenWelcome()
    if not ns.DB then return end
    if InCombatLockdown and InCombatLockdown() then
        ns.Print("Open the introduction after combat with /ocw welcome."); return
    end
    if not welcome then
        welcome = T.Window("OlympusChatWardenWelcome", UIParent, 680, 530)
        ns.WelcomeWindow = welcome; T.Title(welcome, ns.NAME); T.Crest(welcome)
        T.Gold(Label(welcome, "Welcome to Olympus ChatWarden", 78, -30, 570, "GameFontNormalLarge"))
        T.Muted(Label(welcome, "A personal wording filter you can adjust to suit your chat.", 78, -50, 570))
        local cards = {
            {"Choose what you see", "Use Settings to choose wording categories, text areas and sensitivity. Phrase modes use match strength and nearby wording. All listed terms also covers listed words in ordinary sentences."},
            {"Read a filtered message", "Click bars to reveal subdued words in the same line; click again to cover them. Left-click the minimap crest to read hidden originals in Review messages."},
            {"Correct a miss or mistake", "Right-click a player's chat name to report a miss, or report a problem from Review. Reports save examples. Apply a personal phrase rule explicitly when you want an immediate correction."},
        }
        for i, card in ipairs(cards) do
            local panel = T.Panel(welcome, 18, -84 - (i - 1) * 98, 644, 88, true)
            T.Heading(Label(panel, card[1], 14, -12, 616, "GameFontNormal", true))
            Label(panel, card[2], 14, -34, 616, nil, true)
        end
        welcome.Status = T.Muted(Label(welcome, "", 20, -398, 640))
        T.Muted(Label(welcome, "This introduction shows once per account. Reopen it with /ocw welcome.", 20, -432, 640))
        Button(welcome, "Got it", 20, -470, 110, function() welcome:Hide() end)
        Button(welcome, "Settings", 142, -470, 140, function()
            welcome:Hide(); SlashCmdList.OLYMPUSCHATWARDEN("options")
        end)
        Button(welcome, "How filtering works", 294, -470, 200, function()
            welcome:Hide(); ns.OpenTutorial("basics")
        end)
        T.Muted(Label(welcome, "Your choices and reports stay local. Nothing is sent automatically.", 20, -507, 640))
    end
    local preset = ({maximum = "All listed terms", aggressive = "Broad", balanced = "Balanced", strict = "Selective"})[ns.DB.preset]
    welcome.Status:SetText("Filter: " .. (ns.DB.enabled and "active" or "paused") .. "  |  Current sensitivity: " .. preset)
    Fit(welcome); T.ShowWindow(welcome)
    if welcome:IsShown() then ns.DB.welcomeSeen = 1 end
end
function ns.CheckWelcome(event)
    if event == "PLAYER_LOGIN" then loginReady = true end
    if not loginReady and IsLoggedIn then loginReady = IsLoggedIn() == true end
    if not loginReady or not ns.DB or ns.DB.welcomeSeen == 1 or queued
        or InCombatLockdown and InCombatLockdown() or not UIParent:IsVisible() then return end
    queued = true
    local function Show()
        queued = false
        if ns.DB and ns.DB.welcomeSeen ~= 1 and UIParent:IsVisible()
            and not (InCombatLockdown and InCombatLockdown()) then ns.OpenWelcome() end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0, Show)
    else
        if not deferFrame then deferFrame = CreateFrame("Frame") end
        deferFrame:SetScript("OnUpdate", function(self) self:SetScript("OnUpdate", nil); Show() end)
    end
end
