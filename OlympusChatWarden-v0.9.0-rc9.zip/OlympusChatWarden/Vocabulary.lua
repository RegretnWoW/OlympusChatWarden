-- User-supplied vocabulary preferences. Literal matches describe text, not intent.
local _, ns = ...
local V = {Rules = {}, Meta = {}, NormalAdded = 0, NormalRules = {}}
ns.Vocabulary = V
ns.RULE_VERSION = ns.RULE_VERSION .. "-vocabulary-1-maximum-1"
local function Catalog(pack, text)
    for phrase in text:gmatch("[^\n]+") do
        phrase = phrase:lower()
        if not V.Meta[phrase] then
            V.Rules[#V.Rules + 1] = phrase
            V.Meta[phrase] = {id = "maximum:" .. pack .. ":" .. phrase, pack = pack,
                origin = "user-supplied literal vocabulary preference; listed spelling or documented variant"}
        end
    end
end
Catalog("gender", [[trans
trans man
trans woman
transfeminine
transmasculine
transneutral
nonbinary
non-binary
genderqueer
agender
bigender
trigender
polygender
pangender
multigender
genderfluid
genderflux
fluidflux
xenogender
invisigender
catgender
neurogender
cassgender
anvisgender
androgyne
gender nonconforming
pronoun nonconforming
neopronouns
genderfae
genderfaun
genderflor
juxera
proxvir
quoigender
gendervoid
demigender
deminonbinary
demigirl
demiboy
hemigender
heminonbinary
hemigirl
hemiboy
paragender
paranonbinary
paragirl
paraboy
libragender
libranonbinary
librafeminine
libramasculine
gender questioning
neutrois
ningender
fingender
mingender
two spirit
two-spirit
greygender
maverique
aporagender
aliagender
girlflux
boyflux
intergender
alexigender
zie
zim
zir
zis
zieself
sie
hir
hirs
hirself
ey
em
eir
eirs
eirself
ve
ver
vis
vers
verself
tey
ter
tem
ters
terself
e
emself
mx
lgbt
lgbtq
lgbtq+
lgbtqia
lgbtqia+
assigned at birth
assigned female at birth
assigned male at birth
biologically female
biologically male
affirming care
gender
gender based
gender-based
gender based violence
gender-based violence
gender diversity
gender identity
gender ideology
gender-affirming care
gender affirming care
gender neutral
gender-neutral
gender pronoun
gender pronouns
genders
pronoun
pronouns
they/them
transgender
transsexual
female
females
women
women and underrepresented
gbv
men who have sex with men
msm
sex
sexual preferences
sexuality
orientation]])
Catalog("reproductive", [[breastfeed people
breastfeed person
breastfeeding people
breastfeeding person
people who breastfeed
person who breastfeeds
chestfeed people
chestfeed person
chestfeeding people
chestfeeding person
people who chestfeed
person who chestfeeds
people with a uterus
people with uteruses
person with a uterus
pregnant people
pregnant person
pregnant persons]])
Catalog("language", [[all-inclusive
allyship
belong
expression
inclusive
inclusive leadership
inclusiveness
inclusivity
fostering inclusivity
people-centered care
people centered care
person-centered
person centered
person-centered care
person centered care
sense of belonging]])
Catalog("institutional", [[activism
activists
advocacy
advocate
advocates
anti-racism
antiracist
bias
biased
biased toward
biases
biases towards
bipoc
black
community diversity
community equity
confirmation bias
cultural competence
cultural differences
cultural heritage
cultural sensitivity
culturally appropriate
culturally responsive
dei
deia
deiab
deij
discriminated
discrimination
discriminatory
disparity
diverse
diverse backgrounds
diverse communities
diverse community
diverse group
diverse groups
diversified
diversify
diversifying
diversity
enhance the diversity
enhancing diversity
equal opportunity
equality
equitable
equitableness
equity
ethnicity
excluded
exclusion
feminism
hate speech
health disparity
health equity
hispanic minority
historically
identity
immigrants
implicit bias
implicit biases
inclusion
increase diversity
increase the diversity
indigenous community
inequalities
inequality
inequitable
inequities
inequity
injustice
institutional
intersectional
intersectionality
latinx
marginalize
marginalized
minorities
minority
multicultural
native american
oppression
oppressive
prejudice
privilege
privileges
promote diversity
promoting diversity
race
race and ethnicity
racial
racial diversity
racial identity
racial inequality
racial justice
racially
racism
segregation
social justice
sociocultural
socioeconomic
stereotype
stereotypes
systemic
systemically
tribal
unconscious bias
underappreciated
underprivileged
underrepresentation
underrepresented
underserved
undervalued]])
Catalog("broad", [[accessible
at risk
barrier
barriers
clean energy
climate crisis
climate science
commercial sex worker
disabilities
disability
environmental quality
gulf of mexico
key groups
key people
key populations
mental health
most risk
polarization
political
pollution
prostitute
status
trauma
traumatic
victim
victims
vulnerable populations]])

-- Expand phrase-based modes selectively. Common single words, identities and
-- short pronoun forms remain Maximum-only. Existing phrase scores are retained.
local function Normal(pack, score, text)
    for phrase in text:gmatch("[^\n]+") do
        if not ns.RuleMeta[phrase] then
            local category = V.Meta[phrase] and V.Meta[phrase].pack or pack
            ns.StockRules[#ns.StockRules + 1] = phrase
            ns.RuleMeta[phrase] = {id = category .. ":" .. phrase, pack = category, base = score,
                origin = "user-supplied expanded phrase preference; listed spelling or documented variant", version = 1}
            V.NormalAdded = V.NormalAdded + 1
            V.NormalRules[#V.NormalRules + 1] = phrase
        end
    end
end
Normal("gender", 72, [[assigned at birth
biologically female
biologically male
affirming care
gender nonconforming
pronoun nonconforming
gender diversity
gender identity
gender ideology
gender based violence
gender-based violence]])
Normal("reproductive", 80, [[breastfeed people
breastfeed person
breastfeeding people
breastfeeding person
people who breastfeed
person who breastfeeds
chestfeed people
chestfeed person
chestfeeding people
chestfeeding person
people who chestfeed
person who chestfeeds
people with a uterus]])
Normal("language", 70, [[inclusive leadership
fostering inclusivity
people-centered care
people centered care
person-centered care
person centered care]])
Normal("institutional", 65, [[community diversity
community equity
cultural competence
cultural sensitivity
culturally appropriate
culturally responsive
diverse backgrounds
diverse communities
diverse community
diverse group
diverse groups
enhance the diversity
enhancing diversity
equal opportunity
health disparity
health equity
hispanic minority
implicit biases
increase diversity
increase the diversity
indigenous community
race and ethnicity
racial diversity
racial identity
racial inequality
promote diversity
promoting diversity
women and underrepresented]])
Normal("broad", 45, [[confirmation bias
cultural differences
cultural heritage
clean energy
climate crisis
climate science
commercial sex worker
environmental quality
hate speech
mental health
sense of belonging
sexual preferences
vulnerable populations]])
V.Matcher = assert(ns.Engine.CompileLiteral(V.Rules))
