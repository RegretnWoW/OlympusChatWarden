# Vocabulary in v0.9.0-rc9

The catalog and base phrase scores are retained from v0.8.2-dev. rc8 extends
short-pronoun and gameplay guards and allows a separate preset per category.

Maximum contains 309 unique literal entries. Existing phrase modes gain 71 new phrases.

Choose **All listed terms** as the main preset, or for selected categories in
**Configure categories**. Default follows the main preset; explicit category
presets stay fixed. Each eligible catalog hit has score 80 and redacts only its matched word or phrase. Phrase context adjustments do not reduce that literal score; eligibility
guards still apply. Existing independent stronger rules can still hide a message. Installing keeps the selected preset.

Entries are case-insensitive whole words/phrases with literal spaces and punctuation. They do not infer synonyms, arbitrary co-occurrence, intent, or membership in a group. Links/texture/atlas markup are skipped. Coverage, category switches, exceptions and personal overlaps still apply.

Common tokens such as `black`, `race`, `status`, `female` and `women` are included as supplied and can match ordinary game discussion in Maximum.
Ambiguous short forms `e`, `em` and `ve` need an explicit pronoun declaration
(for example, `pronouns: e/em`). Casual “spend em” remains visible. Internal
apostrophes do not start new words, so you've does not emit a ve match.
The word `racial` stays visible in clear racial
ability, bonus, cooldown or stat contexts, such as the reported Human/ranged-crit
example. Clear character race/portal and barber-customization phrases also
stay visible, including the captured user reports. These guards apply even
with phrase context scoring off. They suppress
only the qualifying match; other matches and personal overrides still apply. The other presets keep common single words and standalone identity labels visible. Personal phrases/exceptions retain their 3-character minimum; a longer phrase or category switch can control short catalog tokens.

## Input cleanup and variants

Duplicate `sie`, `em`, `eir`, `eirs`, `nonbinary`, and `trans` entries are combined. Table separators, `<br>` markup and trailing backslashes are removed. Demigender/Deminonbinary, Hemigender/Heminonbinary, Paragender/Paranonbinary and Libragender/Libranonbinary become separate alternatives. `they/them` remains an exact phrase.

The combination notation becomes these adjacent grammatical variants:

| Supplied notation | Literal variants |
| --- | --- |
| breastfeed + people/person | breastfeed people, breastfeed person, breastfeeding people, breastfeeding person, people who breastfeed, person who breastfeeds |
| chestfeed + people/person | chestfeed people, chestfeed person, chestfeeding people, chestfeeding person, people who chestfeed, person who chestfeeds |
| people + uterus | people with a uterus, people with uteruses, person with a uterus |

Documented spelling variants include two-spirit; gender-based violence; gender affirming care; person/people centered care; and LGBTQ+, LGBTQIA, LGBTQIA+. Existing gender-neutral and gender-pronoun phrases are also represented. No semantic co-occurrence detector is claimed.

## Complete Maximum catalog

The category controls both Maximum and the added phrases. A phrase-mode base score in the final column means the phrase also participates in context scoring; its actual score/action may change with nearby wording, chosen threshold, category switches and exceptions. Maximum-only entries do not trigger the other presets.

| Literal entry | Category | Phrase-mode base score |
| --- | --- | --- |
| accessible | broad | Maximum only |
| activism | institutional | Maximum only |
| activists | institutional | Maximum only |
| advocacy | institutional | Maximum only |
| advocate | institutional | Maximum only |
| advocates | institutional | Maximum only |
| affirming care | gender | 72 |
| agender | gender | Maximum only |
| alexigender | gender | Maximum only |
| aliagender | gender | Maximum only |
| all-inclusive | language | Maximum only |
| allyship | language | Maximum only |
| androgyne | gender | Maximum only |
| anti-racism | institutional | Maximum only |
| antiracist | institutional | Maximum only |
| anvisgender | gender | Maximum only |
| aporagender | gender | Maximum only |
| assigned at birth | gender | 72 |
| assigned female at birth | gender | 82 |
| assigned male at birth | gender | 82 |
| at risk | broad | Maximum only |
| barrier | broad | Maximum only |
| barriers | broad | Maximum only |
| belong | language | Maximum only |
| bias | institutional | Maximum only |
| biased | institutional | Maximum only |
| biased toward | institutional | Maximum only |
| biases | institutional | Maximum only |
| biases towards | institutional | Maximum only |
| bigender | gender | Maximum only |
| biologically female | gender | 72 |
| biologically male | gender | 72 |
| bipoc | institutional | Maximum only |
| black | institutional | Maximum only |
| boyflux | gender | Maximum only |
| breastfeed people | reproductive | 80 |
| breastfeed person | reproductive | 80 |
| breastfeeding people | reproductive | 80 |
| breastfeeding person | reproductive | 80 |
| cassgender | gender | Maximum only |
| catgender | gender | Maximum only |
| chestfeed people | reproductive | 80 |
| chestfeed person | reproductive | 80 |
| chestfeeding people | reproductive | 80 |
| chestfeeding person | reproductive | 80 |
| clean energy | broad | 45 |
| climate crisis | broad | 45 |
| climate science | broad | 45 |
| commercial sex worker | broad | 45 |
| community diversity | institutional | 65 |
| community equity | institutional | 65 |
| confirmation bias | institutional | 45 |
| cultural competence | institutional | 65 |
| cultural differences | institutional | 45 |
| cultural heritage | institutional | 45 |
| cultural sensitivity | institutional | 65 |
| culturally appropriate | institutional | 65 |
| culturally responsive | institutional | 65 |
| dei | institutional | Maximum only |
| deia | institutional | Maximum only |
| deiab | institutional | Maximum only |
| deij | institutional | Maximum only |
| demiboy | gender | Maximum only |
| demigender | gender | Maximum only |
| demigirl | gender | Maximum only |
| deminonbinary | gender | Maximum only |
| disabilities | broad | Maximum only |
| disability | broad | Maximum only |
| discriminated | institutional | Maximum only |
| discrimination | institutional | Maximum only |
| discriminatory | institutional | Maximum only |
| disparity | institutional | Maximum only |
| diverse | institutional | Maximum only |
| diverse backgrounds | institutional | 65 |
| diverse communities | institutional | 65 |
| diverse community | institutional | 65 |
| diverse group | institutional | 65 |
| diverse groups | institutional | 65 |
| diversified | institutional | Maximum only |
| diversify | institutional | Maximum only |
| diversifying | institutional | Maximum only |
| diversity | institutional | Maximum only |
| e | gender | Maximum only |
| eir | gender | Maximum only |
| eirs | gender | Maximum only |
| eirself | gender | Maximum only |
| em | gender | Maximum only |
| emself | gender | Maximum only |
| enhance the diversity | institutional | 65 |
| enhancing diversity | institutional | 65 |
| environmental quality | broad | 45 |
| equal opportunity | institutional | 65 |
| equality | institutional | Maximum only |
| equitable | institutional | Maximum only |
| equitableness | institutional | Maximum only |
| equity | institutional | Maximum only |
| ethnicity | institutional | Maximum only |
| excluded | institutional | Maximum only |
| exclusion | institutional | Maximum only |
| expression | language | Maximum only |
| ey | gender | Maximum only |
| female | gender | Maximum only |
| females | gender | Maximum only |
| feminism | institutional | Maximum only |
| fingender | gender | Maximum only |
| fluidflux | gender | Maximum only |
| fostering inclusivity | language | 70 |
| gbv | gender | Maximum only |
| gender | gender | Maximum only |
| gender affirming care | gender | 80 |
| gender based | gender | Maximum only |
| gender based violence | gender | 72 |
| gender diversity | gender | 72 |
| gender identity | gender | 72 |
| gender ideology | gender | 72 |
| gender neutral | gender | 72 |
| gender nonconforming | gender | 72 |
| gender pronoun | gender | 82 |
| gender pronouns | gender | 82 |
| gender questioning | gender | Maximum only |
| gender-affirming care | gender | 80 |
| gender-based | gender | Maximum only |
| gender-based violence | gender | 72 |
| gender-neutral | gender | 72 |
| genderfae | gender | Maximum only |
| genderfaun | gender | Maximum only |
| genderflor | gender | Maximum only |
| genderfluid | gender | Maximum only |
| genderflux | gender | Maximum only |
| genderqueer | gender | Maximum only |
| genders | gender | Maximum only |
| gendervoid | gender | Maximum only |
| girlflux | gender | Maximum only |
| greygender | gender | Maximum only |
| gulf of mexico | broad | Maximum only |
| hate speech | institutional | 45 |
| health disparity | institutional | 65 |
| health equity | institutional | 65 |
| hemiboy | gender | Maximum only |
| hemigender | gender | Maximum only |
| hemigirl | gender | Maximum only |
| heminonbinary | gender | Maximum only |
| hir | gender | Maximum only |
| hirs | gender | Maximum only |
| hirself | gender | Maximum only |
| hispanic minority | institutional | 65 |
| historically | institutional | Maximum only |
| identity | institutional | Maximum only |
| immigrants | institutional | Maximum only |
| implicit bias | institutional | 45 (broad) |
| implicit biases | institutional | 65 |
| inclusion | institutional | Maximum only |
| inclusive | language | Maximum only |
| inclusive leadership | language | 70 |
| inclusiveness | language | Maximum only |
| inclusivity | language | Maximum only |
| increase diversity | institutional | 65 |
| increase the diversity | institutional | 65 |
| indigenous community | institutional | 65 |
| inequalities | institutional | Maximum only |
| inequality | institutional | Maximum only |
| inequitable | institutional | Maximum only |
| inequities | institutional | Maximum only |
| inequity | institutional | Maximum only |
| injustice | institutional | Maximum only |
| institutional | institutional | Maximum only |
| intergender | gender | Maximum only |
| intersectional | institutional | Maximum only |
| intersectionality | institutional | Maximum only |
| invisigender | gender | Maximum only |
| juxera | gender | Maximum only |
| key groups | broad | Maximum only |
| key people | broad | Maximum only |
| key populations | broad | Maximum only |
| latinx | institutional | Maximum only |
| lgbt | gender | Maximum only |
| lgbtq | gender | Maximum only |
| lgbtq+ | gender | Maximum only |
| lgbtqia | gender | Maximum only |
| lgbtqia+ | gender | Maximum only |
| librafeminine | gender | Maximum only |
| libragender | gender | Maximum only |
| libramasculine | gender | Maximum only |
| libranonbinary | gender | Maximum only |
| marginalize | institutional | Maximum only |
| marginalized | institutional | Maximum only |
| maverique | gender | Maximum only |
| men who have sex with men | gender | Maximum only |
| mental health | broad | 45 |
| mingender | gender | Maximum only |
| minorities | institutional | Maximum only |
| minority | institutional | Maximum only |
| most risk | broad | Maximum only |
| msm | gender | Maximum only |
| multicultural | institutional | Maximum only |
| multigender | gender | Maximum only |
| mx | gender | Maximum only |
| native american | institutional | Maximum only |
| neopronouns | gender | Maximum only |
| neurogender | gender | Maximum only |
| neutrois | gender | Maximum only |
| ningender | gender | Maximum only |
| non-binary | gender | Maximum only |
| nonbinary | gender | Maximum only |
| oppression | institutional | Maximum only |
| oppressive | institutional | Maximum only |
| orientation | gender | Maximum only |
| pangender | gender | Maximum only |
| paraboy | gender | Maximum only |
| paragender | gender | Maximum only |
| paragirl | gender | Maximum only |
| paranonbinary | gender | Maximum only |
| people centered care | language | 70 |
| people who breastfeed | reproductive | 80 |
| people who chestfeed | reproductive | 80 |
| people with a uterus | reproductive | 80 |
| people with uteruses | reproductive | 88 |
| people-centered care | language | 70 |
| person centered | language | Maximum only |
| person centered care | language | 70 |
| person who breastfeeds | reproductive | 80 |
| person who chestfeeds | reproductive | 80 |
| person with a uterus | reproductive | 88 |
| person-centered | language | Maximum only |
| person-centered care | language | 70 |
| polarization | broad | Maximum only |
| political | broad | Maximum only |
| pollution | broad | Maximum only |
| polygender | gender | Maximum only |
| pregnant people | reproductive | 95 |
| pregnant person | reproductive | 95 |
| pregnant persons | reproductive | Maximum only |
| prejudice | institutional | Maximum only |
| privilege | institutional | Maximum only |
| privileges | institutional | Maximum only |
| promote diversity | institutional | 65 |
| promoting diversity | institutional | 65 |
| pronoun | gender | Maximum only |
| pronoun nonconforming | gender | 72 |
| pronouns | gender | Maximum only |
| prostitute | broad | Maximum only |
| proxvir | gender | Maximum only |
| quoigender | gender | Maximum only |
| race | institutional | Maximum only |
| race and ethnicity | institutional | 65 |
| racial | institutional | Maximum only |
| racial diversity | institutional | 65 |
| racial identity | institutional | 65 |
| racial inequality | institutional | 65 |
| racial justice | institutional | 45 (broad) |
| racially | institutional | Maximum only |
| racism | institutional | Maximum only |
| segregation | institutional | Maximum only |
| sense of belonging | language | 45 |
| sex | gender | Maximum only |
| sexual preferences | gender | 45 |
| sexuality | gender | Maximum only |
| sie | gender | Maximum only |
| social justice | institutional | 45 (broad) |
| sociocultural | institutional | Maximum only |
| socioeconomic | institutional | Maximum only |
| status | broad | Maximum only |
| stereotype | institutional | Maximum only |
| stereotypes | institutional | Maximum only |
| systemic | institutional | Maximum only |
| systemically | institutional | Maximum only |
| tem | gender | Maximum only |
| ter | gender | Maximum only |
| ters | gender | Maximum only |
| terself | gender | Maximum only |
| tey | gender | Maximum only |
| they/them | gender | Maximum only |
| trans | gender | Maximum only |
| trans man | gender | Maximum only |
| trans woman | gender | Maximum only |
| transfeminine | gender | Maximum only |
| transgender | gender | Maximum only |
| transmasculine | gender | Maximum only |
| transneutral | gender | Maximum only |
| transsexual | gender | Maximum only |
| trauma | broad | Maximum only |
| traumatic | broad | Maximum only |
| tribal | institutional | Maximum only |
| trigender | gender | Maximum only |
| two spirit | gender | Maximum only |
| two-spirit | gender | Maximum only |
| unconscious bias | institutional | 45 (broad) |
| underappreciated | institutional | Maximum only |
| underprivileged | institutional | Maximum only |
| underrepresentation | institutional | Maximum only |
| underrepresented | institutional | Maximum only |
| underserved | institutional | Maximum only |
| undervalued | institutional | Maximum only |
| ve | gender | Maximum only |
| ver | gender | Maximum only |
| vers | gender | Maximum only |
| verself | gender | Maximum only |
| victim | broad | Maximum only |
| victims | broad | Maximum only |
| vis | gender | Maximum only |
| vulnerable populations | broad | 45 |
| women | gender | Maximum only |
| women and underrepresented | gender | 65 |
| xenogender | gender | Maximum only |
| zie | gender | Maximum only |
| zieself | gender | Maximum only |
| zim | gender | Maximum only |
| zir | gender | Maximum only |
| zis | gender | Maximum only |
