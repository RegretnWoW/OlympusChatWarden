local _, ns = ...
local T = ns.Theme
local category, feedback, controls, packControls, sensitivity, sensitivityText, categoryWindow, integrationText
local labels = {maximum = "All listed terms", aggressive = "Broad", balanced = "Balanced", strict = "Selective"}
local descriptions = {aggressive = "Default: includes weaker matches and warnings.",
    balanced = "Uses the standard match threshold. A good starting point.",
    strict = "Filters stronger matches only. Leaves more borderline wording visible.",
    maximum = "Covers listed words even in ordinary conversation. May affect gameplay terms."}
local packLabels = {labels = "Body-label replacements", reproductive = "Pregnancy / reproductive wording",
    language = "General inclusive wording", gender = "Gender / pronoun wording", institutional = "DEI / institutional terminology",
    slogans = "Social / political slogans", broad = "Broad contextual phrases", guild = "Olympus-directed insults",
    creator = "Asmongold / nickname teasing"}
local shortLabels = {labels = "Body labels", reproductive = "Reproductive", language = "Inclusive wording", gender = "Gender / pronouns",
    institutional = "DEI / institutional", slogans = "Slogans", broad = "Contextual phrases", guild = "Olympus insults", creator = "Creator teasing"}
local summaries = {}
local function PackChoice(pack)
    return ns.DB.disabledPacks[pack] and "off" or ns.DB.packPresets[pack] or "default"
end
local function Sync()
    for key, control in pairs(controls or {}) do control:SetChecked(ns.DB[key]) end
    for _, control in pairs(packControls or {}) do control:Refresh() end
    for pack, text in pairs(summaries) do
        local choice = PackChoice(pack)
        text:SetText(shortLabels[pack] .. ": " .. (labels[choice] or (choice == "off" and "Off" or "Default")))
    end
    if sensitivity then sensitivity:Refresh(); sensitivityText:SetText(descriptions[ns.DB.preset]) end
    if categoryWindow then categoryWindow.DefaultText:SetText("Default follows the main preset: " .. labels[ns.DB.preset] .. ". Other choices stay fixed.") end
    if integrationText and ns.OlympusIntegration then integrationText:SetText(ns.OlympusIntegration.Status()) end
    if feedback then feedback:SetText(ns.DB.enabled and "Filter active - choose where it runs and which categories it uses."
        or "Filter paused - enable it above to filter new messages.") end
end
ns.SyncOptions = Sync
function ns.OpenCategories()
    if not ns.DB then return end
    if not categoryWindow then
        categoryWindow = T.Window("OlympusChatWardenCategories", UIParent, 650, 580)
        ns.CategoryWindow = categoryWindow; T.Title(categoryWindow, ns.NAME); T.Crest(categoryWindow)
        local function Text(x, y, width, value)
            local text = categoryWindow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            text:SetPoint("TOPLEFT", x, y); text:SetWidth(width); text:SetJustifyH("LEFT"); text:SetText(value or ""); T.Light(text); return text
        end
        T.Gold(Text(78, -32, 550, "Category sensitivity"))
        categoryWindow.DefaultText = T.Muted(Text(20, -70, 610))
        T.Muted(Text(20, -100, 610, "Choose a preset for each category, or Off. Personal phrase rules and exceptions still apply."))
        packControls = {}; ns.CategoryDropdowns = packControls
        local choices = {{"default", "Default (main preset)"}, {"off", "Off"}, {"strict", "Selective"},
            {"balanced", "Balanced"}, {"aggressive", "Broad"}, {"maximum", "All listed terms"}}
        for i, name in ipairs(ns.PackNames) do
            local pack = name
            local y = -141 - (i - 1) * 40
            Text(26, y - 5, 346, packLabels[pack])
            packControls[pack] = T.Dropdown(categoryWindow, 382, y, 240, choices,
                function() return PackChoice(pack) end,
                function(value) ns.SetPackPreset(pack, value); Sync() end)
            T.Tooltip(packControls[pack], packLabels[pack], pack == "labels"
                and "Built-in Male/Female replacements apply in every enabled preset. Off disables them. The preset controls other body-label phrases."
                or "Default uses the main preset. Selective: minimum 85. Balanced: 65. Broad: 40. All listed terms also uses this category's literal word list. Off disables this category.")
        end
        T.Muted(Text(20, -510, 610, "Body-label replacements apply in every enabled preset. All listed terms can affect ordinary conversation."))
        local close = CreateFrame("Button", nil, categoryWindow, "UIPanelButtonTemplate")
        close:SetSize(120, 26); close:SetPoint("BOTTOMRIGHT", -18, 16); close:SetText("Close")
        close:SetScript("OnClick", function() categoryWindow:Hide() end)
        categoryWindow:HookScript("OnShow", Sync)
    end
    local width, height = UIParent:GetWidth(), UIParent:GetHeight()
    categoryWindow:SetScale(math.min(1, math.max(0.5, (width - 30) / 650), math.max(0.5, (height - 30) / 580)))
    Sync(); T.ShowWindow(categoryWindow)
end
function ns.BuildOptions()
    if category or not ns.DB or not Settings or not Settings.RegisterCanvasLayoutCategory
        or not Settings.RegisterAddOnCategory then return end
    local panel = CreateFrame("Frame", nil, nil, "BackdropTemplate")
    panel:SetSize(640, 620); T.SkinWindow(panel)
    local function Text(parent, x, y, width, value, font)
        local text = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
        text:SetPoint("TOPLEFT", x, y); text:SetWidth(width); text:SetJustifyH("LEFT"); text:SetText(value or "")
        T.Light(text); return text
    end
    T.Crest(panel, 16, -8, 56)
    T.Gold(Text(panel, 84, -16, 530, ns.NAME, "GameFontNormalLarge"))
    T.Muted(Text(panel, 84, -44, 530, ns.TAGLINE .. "  |  v" .. ns.VERSION))
    local help = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    help:SetSize(100, 24); help:SetPoint("TOPRIGHT", -18, -16); help:SetText("Help / guide")
    help:SetScript("OnClick", ns.OpenTutorial)
    T.Tooltip(help, "How filtering works", "Learn about warnings, confidence, presets, revealing text and personal reports.")
    controls = {}
    local function Check(parent, key, label, x, y, width, callback, help)
        local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", x, y); check.Text:SetText(label); check.Text:SetFontObject("GameFontHighlightSmall")
        T.Light(check.Text); check.Text:SetWidth(width); check.Text:SetJustifyH("LEFT"); check.Text:SetWordWrap(false)
        check:SetScript("OnClick", callback)
        if help then T.Tooltip(check, label, help) end
        return check
    end
    controls.enabled = Check(panel, "enabled", "Enable Olympus ChatWarden", 14, -82, 500, function(self)
        ns.DB.enabled = self:GetChecked() == true; ns.PolicyChanged(); ns.BuildMinimap(); Sync()
    end, "Turn filtering on or off for new messages and supported game text.")
    feedback = T.Muted(Text(panel, 20, -117, 600))
    local mode = T.Panel(panel, 14, -146, 612, 82)
    T.Gold(Text(mode, 12, -10, 340, "Sensitivity", "GameFontNormal"))
    sensitivityText = T.Muted(Text(mode, 12, -30, 335))
    sensitivity = T.Dropdown(mode, 362, -20, 236, {{"strict", labels.strict}, {"balanced", labels.balanced}, {"aggressive", labels.aggressive}, {"maximum", labels.maximum}},
        function() return ns.DB.preset end, function(value) ns.SetPreset(value); Sync() end)
    local coverage = T.Panel(panel, 14, -239, 298, 282)
    T.Gold(Text(coverage, 12, -12, 274, "Where to filter", "GameFontNormal"))
    local specs = {{"chat", "Player chat", "Player messages in supported chat windows."},
        {"npc", "NPC chat", "Monster and NPC speech in the chat window."},
        {"dialogue", "Quests and NPC dialogue", "Quest and gossip narrative text."},
        {"bubbles", "Overhead chat bubbles", "Filter accessible speech-bubble text above characters."},
        {"talkingHead", "Talking-head captions", "Experimental support for talking-head captions."},
        {"barber", "Barber-shop wording", "Filter supported barber-shop tooltip text."},
        {"context", "Use context clues", "Consider nearby wording when scoring phrases. Literal word preferences remain active; ambiguous short pronouns and gameplay guards still apply."},
        {"history", "Keep review history", "Keep warnings and redacted words in the session inbox. Hidden originals always enter review."},
        {"minimap", "Show minimap icon", "Left-click the minimap icon for review; right-click for settings."}}
    for i, spec in ipairs(specs) do
        local key = spec[1]
        controls[key] = Check(coverage, key, spec[2], 5, -35 - (i - 1) * 26, 254, function(self)
            ns.DB[key] = self:GetChecked() == true; ns.PolicyChanged(); ns.BuildMinimap(); Sync()
        end, spec[3])
    end
    local packs = T.Panel(panel, 324, -239, 302, 282)
    T.Gold(Text(packs, 12, -12, 278, "Category sensitivity", "GameFontNormal"))
    local configure = CreateFrame("Button", nil, packs, "UIPanelButtonTemplate")
    configure:SetSize(274, 26); configure:SetPoint("TOPLEFT", 12, -34); configure:SetText("Configure categories")
    configure:SetScript("OnClick", ns.OpenCategories)
    for i, name in ipairs(ns.PackNames) do
        local pack = name
        summaries[pack] = Text(packs, 12, -72 - (i - 1) * 20, 278)
    end
    T.Muted(Text(packs, 12, -263, 275, "Default follows the main preset."))
    controls.olympusIntegration = Check(panel, "olympusIntegration", "Use Olympus tab instead of minimap icon", 14, -525, 580, function(self)
        ns.DB.olympusIntegration = self:GetChecked() == true; ns.OlympusIntegration.Refresh(); Sync()
    end, "Add a ChatWarden crest tab below Olympus's upper-left portrait. Open Olympus once to attach it. Turning this off restores your minimap preference. Olympus is optional.")
    integrationText = T.Muted(Text(panel, 20, -557, 600))
    for i, spec in ipairs({{"Preview test", ns.MakeDemo}, {"Review messages", ns.OpenReview},
        {"My reports & rules", ns.OpenPersonal}, {"Export reports", function() ns.OpenReportExport() end}}) do
        local button = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        button:SetSize(140, 26); button:SetPoint("TOPLEFT", 20 + (i - 1) * 151, -576)
        button:SetText(spec[1]); button:SetScript("OnClick", spec[2])
    end
    panel:SetScript("OnShow", Sync)
    category = Settings.RegisterCanvasLayoutCategory(panel, ns.NAME); Settings.RegisterAddOnCategory(category); Sync()
end

SLASH_OLYMPUSCHATWARDEN1 = "/chatwarden"
SLASH_OLYMPUSCHATWARDEN2 = "/ocw"
SlashCmdList.OLYMPUSCHATWARDEN = function(message)
    if not ns.DB then return end
    local command, argument = (message or ""):match("^%s*(%S*)%s*(.-)%s*$")
    command = (command or ""):lower()
    if command == "inbox" or command == "review" then ns.OpenReview()
    elseif command == "help" or command == "tutorial" then ns.OpenTutorial()
    elseif command == "welcome" then ns.OpenWelcome()
    elseif command == "personal" or command == "reports" then ns.OpenPersonal("reports")
    elseif command == "rules" then ns.OpenPersonal("rules")
    elseif command == "feedback" then ns.OpenReportLink()
    elseif command == "export" then ns.OpenReportExport(argument == "misses" and "misses" or nil)
    elseif command == "report" then ns.OpenReport(nil, "Missed match")
    elseif command == "history" then
        if argument == "on" or argument == "off" then
            ns.DB.history = argument == "on"
            ns.Print("Optional warning/redaction history " .. argument .. ". High-confidence items always go to review. Existing entries remain until clear/reload.")
        else ns.Print("History is " .. (ns.DB.history and "on" or "off") .. ": " .. #ns.Review.entries .. " session entries. Use /ocw history on|off.") end
    elseif command == "minimap" then
        if argument == "show" or argument == "hide" then
            ns.DB.minimap = argument == "show"; ns.BuildMinimap()
        else ns.Print("Use /ocw minimap show|hide. /ocw inbox works with the icon hidden.") end
    elseif command == "on" or command == "off" then
        ns.DB.enabled = command == "on"
        ns.PolicyChanged(); Sync()
        if ns.RefreshBubbles then ns.RefreshBubbles() end
        ns.Print(ns.DB.enabled and "Enabled for new chat and supported UI text." or "Disabled. Existing chat redactions remain clickable; new messages are untouched.")
    elseif command == "bubbles" then
        if argument == "on" or argument == "off" then
            ns.DB.bubbles = argument == "on"; ns.PolicyChanged(); Sync()
        end
        ns.Print(ns.BubbleStatus())
    elseif command == "preset" then
        local ok, err = ns.SetPreset(argument:lower())
        if ok then Sync(); ns.Status() else ns.Print(err) end
    elseif command == "logic" then
        if argument ~= "on" and argument ~= "off" then ns.Print("Use /ocw logic on or off."); return end
        ns.DB.context = argument == "on"; ns.PolicyChanged(); Sync()
    elseif command == "pack" then
        local pack, setting = argument:lower():match("^(%S+)%s+(%S+)$")
        local known = false
        for _, name in ipairs(ns.PackNames) do if name == pack then known = true end end
        if known and (setting == "on" or setting == "off") then
            ns.DB.disabledPacks[pack] = setting == "off"; ns.PolicyChanged()
            ns.Print(pack .. " pack " .. setting)
            Sync()
        elseif known and setting then
            local ok, err = ns.SetPackPreset(pack, setting); Sync(); ns.Print(ok and (pack .. " sensitivity: " .. setting) or err)
        else
            for _, name in ipairs(ns.PackNames) do ns.Print(name .. ": " .. (ns.DB.disabledPacks[name] and "off" or "on")) end
            ns.Print("Use /ocw pack NAME default|off|selective|balanced|broad|all, or /ocw categories.")
        end
    elseif command == "allow" or command == "unallow" then
        local rules = {}
        for _, phrase in ipairs(ns.DB.exceptions) do
            if command ~= "unallow" or phrase ~= argument:lower() then rules[#rules + 1] = phrase end
        end
        if command == "allow" then rules[#rules + 1] = argument end
        local ok, err = ns.SetExceptions(rules)
        ns.Print(ok and ("Saved " .. #ns.DB.exceptions .. " exceptions. Exceptions suppress nearby matches in the same bounded sentence window.") or err)
    elseif command == "exceptions" then
        ns.Print(#ns.DB.exceptions == 0 and "No exceptions." or table.concat(ns.DB.exceptions, ", "))
    elseif command == "stock" or command == "add" or command == "remove" then
        ns.Print("Open /ocw rules to add or edit personal phrase rules. Use pack switches and allow/unallow exceptions to adjust built-in categories.")
    elseif command == "categories" then ns.OpenCategories()
    elseif command == "status" then ns.Status()
    elseif command == "preview" or command == "test" then ns.MakeDemo()
    elseif command == "rescan" then ns.QueueScan(true); ns.RefreshBubbles()
    elseif command == "options" or command == "" then
        if category and Settings.OpenToCategory then Settings.OpenToCategory(category:GetID())
        else ns.Print("Options panel unavailable; use /ocw inbox, pack, allow, on, off, test, or status.") end
    else ns.Print("Commands: options | inbox | reports | report | feedback | export [misses] | rules | preview | on/off | status | rescan | preset selective/balanced/broad/all | logic on/off | pack NAME on/off | allow/unallow PHRASE | exceptions | history on/off | minimap show/hide | bubbles on/off") end
end
