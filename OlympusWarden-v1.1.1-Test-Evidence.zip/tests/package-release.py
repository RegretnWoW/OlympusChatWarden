from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,sys
r=Path(__file__).resolve().parents[2];o=Path(__file__).resolve().parent;stem='OlympusWarden-v1.1.1'
def sha(b):return hashlib.sha256(b).hexdigest()
baseline=r/'OlympusWarden-v1.1.1-preview8.zip'
assert sha(baseline.read_bytes())=='0941b6b8303f12cbc9a8929d139c1a8e3f5e82aeea076e3f036c6c4712a745a1'
assert sha((r/'OlympusWarden-v1.1.0.zip').read_bytes())=='29a5c528131e679951046d82aabcb17e5151e383741978d7891a927428ca32a4'
with zipfile.ZipFile(baseline) as z:old={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
files={n:(r/n).read_bytes() for n in old}
changed=sorted(n for n in files if files[n]!=old[n])
allow={'OlympusChatWarden/'+n for n in 'Core.lua OlympusChatWarden.toc ChronicleActivities.lua ChronicleIntelligence.lua PlayerMenus.lua WardenSearch.lua UpdateUI.lua README.md CHANGELOG.md RELEASE-NOTES.md RELAY.md'.split()}
assert set(changed)<=allow,set(changed)-allow
for n in old:
 if n not in allow or '/Media/' in n:assert old[n]==files[n],n
sys.path.insert(0,str(r/'.work/vendor-rc30'))
from lupa.lua51 import LuaRuntime
compileLua=LuaRuntime().eval('function(s,n) return assert(loadstring(s,n)) end')
toc=files['OlympusChatWarden/OlympusChatWarden.toc'].decode();modules=[n for n in toc.splitlines() if n.endswith('.lua')]
assert len(files)==167 and len(modules)==118
assert '## Version: 1.1.1\n' in toc.replace('\r\n','\n') and '## OptionalDeps: Olympus' in toc
assert '## SavedVariables: OlympusChatWardenDB, OlympusWardenRelayDB, OlympusWardenStartupDB' in toc
for n in modules:compileLua(files['OlympusChatWarden/'+n].decode('utf-8'),n)
digest=hashlib.sha256()
for p in sorted((r/'OlympusChatWarden').glob('*.lua'),key=lambda p:p.name):digest.update(p.name.encode());digest.update(p.read_bytes())
sourceHash=digest.hexdigest();assert (o/'release-tests-source-sha256.txt').read_text().strip()==sourceHash
results=json.loads((o/'release-suite-results.json').read_text());assert len(results)==11 and all(x['exitCode']==0 for x in results)
releaseSummary=json.loads((o/'release-summary.json').read_text());assert releaseSummary['failed']==0 and releaseSummary['assertions']>=27
baselineProof=json.loads((r/'OlympusWarden-v1.1.1-preview8-Validation.json').read_text());assert baselineProof['offlineSuitesPassed']==70
for name in releaseSummary['protectedFilesUnchanged']:assert files['OlympusChatWarden/'+name]==old['OlympusChatWarden/'+name],name
def archive(path,data):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(data.items()):
   p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and ':' not in n
   assert not any(s in n.lower() for s in ['authorsigningkit','private-key','savedvariables/','__pycache__','probe-current-private'])
   for kind in [b'PRIVATE KEY',b'RSA PRIVATE KEY',b'EC PRIVATE KEY']:assert b'-----BEGIN '+kind not in b,n
   info=zipfile.ZipInfo(n,(2026,10,18,12,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and len(z.namelist())==len(data)
  for n,b in data.items():assert z.read(n)==b
addon=r/(stem+'.zip');archive(addon,files)
proof={'version':'1.1.1','status':'release build prepared; final native acceptance results separated','baseline':{'file':baseline.name,'sha256':sha(baseline.read_bytes()),'offlineSuitesPassed':70,'sourceSha256':baselineProof['addon']['luaSourceSha256']},'addon':{'file':addon.name,'sha256':sha(addon.read_bytes()),'files':len(files),'bytes':addon.stat().st_size,'lua51Modules':len(modules),'luaSourceSha256':sourceHash},'releaseSuites':results,'releaseSuitesPassed':11,'releaseSummary':releaseSummary,'moduleConfigurationsTested':32,'changedSincePreview8':changed,'protectedFilesUnchanged':releaseSummary['protectedFilesUnchanged'],'mainHistorySchema':6,'consentVersion':5,'duelConsentVersion':1,'relaySchema':1,'moduleSelectionVersion':1,'savedVariables':['OlympusChatWardenDB','OlympusWardenRelayDB','OlympusWardenStartupDB'],'historyStorageAndCollectorsUnchangedFromPreview8':True,'relayTransportUnchangedFromPreview8':True,'existingArtworkUnchanged':True,'signedPacksAndTrustUnchanged':True,'backupToolUnchanged':True,'dependency':{'metadata':'OptionalDeps: Olympus','intentional':True,'reason':'Allow missing-addon/access guidance; existing runtime access checks still apply'},'nativeEvidence':{'performedByBuildEnvironment':False,'priorUserConfirmedLogoutReload':True,'priorUserConfirmedSelfDelivery':True,'reviewReportsImprovedNativePerformance':True,'currentReleaseTwoClientDeliveryVerified':False,'allCharacterNativeIntegrityVerified':False,'finalNativeChecklistIncluded':True},'public110PackageUnchanged':True,'publicationPerformed':False}
validation=r/(stem+'-Validation.json');validation.write_text(json.dumps(proof,indent=2)+'\n')
verification={'file':addon.name,'sha256':proof['addon']['sha256'],'files':len(files),'lua51Modules':len(modules),'luaSourceSha256':sourceHash,'archiveCRC':'passed','packagedSourceParity':'passed','allLua51Compile':'passed','releaseSuitesPassed':11,'baselinePreview8SuitesPassed':70,'moduleConfigurations':32,'nativeCurrentReleaseTestedByBuildEnvironment':False,'publicationPerformed':False}
verificationPath=r/(stem+'-Package-Verification.json');verificationPath.write_text(json.dumps(verification,indent=2)+'\n')
changedPath=r/(stem+'-Changed-Files.md');changedPath.write_text('# Changes from verified Preview 8\n\n'+'\n'.join('- '+n for n in changed)+'\n\nThe release fixes personal-note/watchlist Intel menu eligibility through a bounded derived profile phase, updates CommandWarden search and consolidates all changes since public 1.1.0. Main storage, archive loading, startup recovery, collectors, consent, module lifecycle, crypto, signed packs and Relay transport remain byte-identical to Preview 8. All existing artwork is unchanged.\n')
buildNotes=r/(stem+'-Build-Notes.md');buildNotes.write_text('''# 1.1.1 build validation

The clean release ZIP is rebuilt from the verified Preview 8 file inventory with an explicit allowlist of release edits. Every packaged file is compared to source, all 118 Lua modules compile as Lua 5.1, ZIP integrity and checksums pass, and signing kits/private keys are excluded.

Eleven focused release suites pass, covering the new personal-only dossier shortcut, all 32 module configurations, activity/intelligence summaries, existing menus and bounded lookup, closed-window startup, exact-once startup recovery, archive/export/restore safety and complete Windows backup/restore. The new release test includes 27 specific assertions and a 100-check startup/Chronicle/UI smoke host. The 70-suite Preview 8 report is retained as baseline evidence, not relabelled as 70 freshly rerun release suites.

Main history, schema, consent, lazy loader, startup journal, gameplay collectors and Relay transport are byte-identical to Preview 8. Its canonical retained-history comparisons preserved 51,840 events and 225 profiles across four characters; this release does not change those storage paths. Personal-profile indexing is derived state, bounded per frame, and creates no saved event or inspection.

Native evidence remains separate. The user previously confirmed normal logout/reload and developer self-delivery; the supplied review reports improved performance. Final release native data-integrity, all-character logout, two-client delivery and live UI acceptance are listed in the Release Checklist. Offline widgets and fixture results are not native gameplay verification.

No publication or GitHub update was performed by this build step. Public 1.1.0 remains unchanged. The release bundle includes the unchanged Windows backup tool, installation guidance, consolidated patch notes and evidence.
''')
docs=[r/(stem+s) for s in ['-Patch-Notes.md','-Install-and-Backup.md','-Release-Checklist.md','-Changed-Files.md','-Build-Notes.md']]
assert all(p.is_file() for p in docs)
evidence={p.name:p.read_bytes() for p in docs+[validation,verificationPath]}
evidence['baseline/Preview8-Validation.json']=(r/'OlympusWarden-v1.1.1-preview8-Validation.json').read_bytes()
evidence['baseline/Preview8-Package-Verification.json']=(r/'OlympusWarden-v1.1.1-preview8-Package-Verification.json').read_bytes()
for row in results:
 name=row['suite'];evidence['tests/'+name]=(o/name).read_bytes();evidence['results/'+name+'.log']=(o/(name+'.log')).read_bytes()
for name in ['release-summary','modules-summary','module-isolation-summary','preview7-summary','startup-journal-summary','archives-summary','backup-tool-summary','closed-loading-summary']:
 evidence['results/'+name+'.json']=(o/(name+'.json')).read_bytes()
for name in ['smoke.py','test-integration.py','test-chronicle.py','test-backup-tool.ps1','run-release-checks.py','package-release.py']:
 evidence['tests/'+name]=(o/name).read_bytes()
evidence['results/release-suite-results.json']=(o/'release-suite-results.json').read_bytes()
evidence['REPRODUCE.md']=b'Fresh release test sources/logs and separately labelled Preview 8 baseline evidence. Tests use bundled Python/Lupa plus inherited workspace fixtures, not all of which are distributed. No private saved history or signing material is included. Synthetic screenshots are not native client evidence.\n'
evidenceZip=r/(stem+'-Test-Evidence.zip');archive(evidenceZip,evidence)
screens={}
for name in ['release-notes','command','relay']:
 p=o/(name+'-preview.png');assert p.is_file();screens[name+'.png']=p.read_bytes()
screens['README.txt']=b'Production Lua widgets with illustrative synthetic fixtures. These are not native WoW screenshots; fixture data is not installed in the addon.\n'
previews=r/(stem+'-UI-Previews.zip');archive(previews,screens)
backup=r/'OlympusChatWarden-Backup-Tool-v1.0.3.zip';assert sha(backup.read_bytes())=='496185fda6704fbcbc04c398fe375dd38d6f680f1f9aa0a02569fbf1fcdd1386'
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
artifacts=[addon,backup,validation,verificationPath,evidenceZip,previews]+docs
checks=r/(stem+'-SHA256.txt');checks.write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in artifacts))
bundle=r/(stem+'-Release-Bundle.zip');archive(bundle,{p.name:p.read_bytes() for p in [checks]+artifacts})
with checks.open('a') as f:f.write(sha(bundle.read_bytes())+'  '+bundle.name+'\n')
print(json.dumps({'addon':proof['addon'],'releaseBundle':bundle.name,'freshReleaseSuitesPassed':11,'baselineSuitesPassed':70,'moduleConfigurations':32,'changedFiles':changed,'nativeReleaseTested':False,'publicationPerformed':False},indent=2))
