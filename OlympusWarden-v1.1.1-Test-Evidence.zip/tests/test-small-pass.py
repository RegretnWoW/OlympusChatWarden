from pathlib import Path
import json,time
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scope={'__file__':str(out/'smoke.py')};exec(compile((out/'smoke.py').read_text(encoding='utf-8'),'small-pass-host','exec'),scope)
lua=scope['lua'];start=time.perf_counter()
lua.execute(r'''
local before=checks;local Q,G=ns.WardenSearch,ns.WardenDossier
C.Clear();local owner=C.Owner();local c=S.Character(owner,true);local events={}
for n=1,200000 do events[n]={id=owner..':'..n,kind='location',source='checkpoint',character=owner,
 at=1800000000+n,details={},location={zone=n==1 and 'Original Needle' or 'Ordinary Place'}} end
c.events=events
local job=Q.Begin('Original Needle');local loops=0
while not Q.Pump(job) do loops=loops+1;assert(loops<2000) end
check(#job.results==1,'large search returns single oldest event')
local result=job.results[1];check(result.data.eventArray==events and result.data.eventIndex==1,'bounded results retain validated source position')
local oldOpen=ns.RecordingUI.OpenSource;local opened
ns.RecordingUI.OpenSource=function(_,e) opened=e end
local originalIpairs=ipairs;local walked=0
ipairs=function(t) if t==events then local f,state,key=originalIpairs(t);return function(s,k) walked=walked+1;return f(s,k) end,state,key end;return originalIpairs(t) end
Q.Open(result);check(opened==events[1] and not Q.pendingOpen and walked==0,'oldest event opens in constant time without history traversal')
ipairs=originalIpairs
events[#events+1]={id='append',details={},kind='location',character=owner};opened=nil
Q.Open(result);check(opened==events[1] and not Q.pendingOpen,'append preserves validated source position')
opened=nil;S.blocked=true;Q.Open(result);check(not opened and not Q.pendingOpen,'blocked saved history cannot open even a valid source anchor');S.blocked=nil
local oldCombat=InCombatLockdown;InCombatLockdown=function() return true end;opened=nil;Q.Open(result)
check(Q.pendingOpen and Q.pendingOpen.processed==0 and opened==nil,'indexed source waits during combat without scanning')
InCombatLockdown=oldCombat;Q.PumpOpen();check(opened==events[1] and not Q.pendingOpen,'combat resume uses constant-time source position')
local target=events[1];local noPosition={data={event=target,owner=owner,character=c}};opened=nil;Q.Open(noPosition)
check(Q.pendingOpen and Q.pendingOpen.processed<=128 and not opened,'legacy result starts bounded lookup instead of full synchronous scan')
local steps=1
while Q.pendingOpen do local j=Q.pendingOpen;local processed=j.processed;Q.PumpOpen();check(j.processed-processed<=128,'source lookup budget per frame');steps=steps+1;assert(steps<2000) end
check(opened==target and steps>1500,'cooperative fallback finds oldest original event')
opened=nil;table.insert(events,1,{id='late-insert',kind='location',details={},character=owner});Q.Open(result)
check(Q.pendingOpen~=nil and not opened,'shifted position falls back without showing unrelated entry')
while Q.pendingOpen do Q.PumpOpen() end;check(opened==target,'shifted original is resolved by exact object identity')
opened=nil;Q.Open(noPosition);local previous=c.events;c.events={};Q.PumpOpen()
check(not Q.pendingOpen and not opened,'replaced history invalidates pending source lookup');c.events=previous
Q.Open(noPosition);events[#events]={id='changed-tail'};Q.PumpOpen();check(not Q.pendingOpen,'tail mutation invalidates lookup snapshot')
Q.Open(noPosition);Q.Begin('new query');check(not Q.pendingOpen,'new search cancels previous source navigation')
Q.Open(noPosition);Q.Open({data={page='settings'}});check(not Q.pendingOpen and ns.Workspace.current=='settings','new result cancels lookup and opens requested section')
Q.Open(noPosition);ns.Workspace.current='intel';Q.PumpOpen();check(not Q.pendingOpen,'leaving source page cancels delayed navigation')
Q.Open(noPosition);ns.Workspace.window:Hide();Q.PumpOpen();check(not Q.pendingOpen,'closing Warden cancels delayed navigation');ns.Workspace.window:Show()
opened=nil;Q.Open({data={event={id=target.id},owner=owner,character=c}});while Q.pendingOpen do Q.PumpOpen() end
check(not opened,'same ID with a substituted event object cannot open stale evidence')
local removed=result;local array=c.events;c.events={};Q.Open(removed);check(not Q.pendingOpen,'stale anchored results explain changed history immediately');c.events=array
ns.RecordingUI.OpenSource=oldOpen;c.events={};Q.CancelOpen()

-- Item cache misses are distinct from empty/uninspected equipment. No inspections.
local parent=CreateFrame('Frame',nil,UIParent);local p=G.Build(parent,parent);p:Show()
local slots={};for n=1,19 do slots[n]={n,'unavailable',false,false} end
slots[1]={1,'present',1001,'item:1001:123:456:0:-7'};slots[2]={2,'empty',false,false};slots[3]={3,'pending',1002,false}
local record={object={capture={values={slots=slots}}},event={id='gear-evidence'},at=1800000000}
p.rows={record};p.index=1
local requests=0;C_Item=C_Item or {};local ready=false
GetItemInfo=function(link) if ready then return 'Historical Helm',link,3,nil,nil,nil,nil,nil,nil,12345 end end
GetItemInfoInstant=function() return 1001,'Armor','Cloth','INVTYPE_HEAD',23456 end
GetItemIcon=nil;C_Item.GetItemIconByID=nil
C_Item.RequestLoadItemDataByID=function(id) requests=requests+1;p.scripts.OnEvent(p,'GET_ITEM_INFO_RECEIVED',id,true) end
p:Render()
check(p.slots[1].icon.texture==23456 and p.slots[1].name:GetText()=='Item #1001','instant icon available before name/quality cache arrives')
check(p.slots[1].link==slots[1][4] and p.slots[1].clickLink==nil,'original payload retained; uncached name does not produce synthetic link')
check(requests==2,'only visible missing item IDs requested once')
p:Render();check(requests==2,'repeated renders do not repeatedly request missing item data')
p.scripts.OnEvent(p,'GET_ITEM_INFO_RECEIVED',9999,true);p.itemDirty=nil
p.scripts.OnEvent(p,'GET_ITEM_INFO_RECEIVED',9999,true);check(not p.itemDirty,'unrelated item cache events do not rebuild paper doll')
ready=true;p.scripts.OnEvent(p,'ITEM_DATA_LOAD_RESULT',1001,true);check(p.itemDirty,'relevant item load event queues one deferred refresh')
p.scripts.OnUpdate(p,.1)
check(p.slots[1].itemName=='Historical Helm' and p.slots[1].icon.texture==12345,'deferred refresh replaces placeholders with cached item details')
check(p.slots[2].name:GetText()=='Confirmed empty' and p.slots[4].name:GetText()=='Not inspected','cache behavior keeps empty versus uninspected states')
local handled=0;local nativeLink
HandleModifiedItemClick=function(link) handled=handled+1;nativeLink=link;return true end
G.ItemClick(p.slots[1],'LeftButton')
check(handled==1 and nativeLink=='|Hitem:1001:123:456:0:-7|h[Historical Helm]|h','native click handler receives exact recorded payload wrapped as full item link')
G.ItemClick(p.slots[1],'RightButton');G.ItemClick(p.slots[2],'LeftButton');G.ItemClick(p.slots[3],'LeftButton')
check(handled==1,'right-click, empty and missing-original-link slots do not invent item interactions')
local allowed=ns.Membership.Allowed;ns.Membership.Allowed=function() return false end;G.ItemClick(p.slots[1],'LeftButton')
check(handled==1,'native item interaction respects membership access');ns.Membership.Allowed=allowed
HandleModifiedItemClick=nil;G.ItemClick(p.slots[1],'LeftButton');check(true,'absent native modifier helper is safe')
GetItemInfo=nil;GetItemInfoInstant=nil;C_Item.GetItemInfo=function() return nil end
C_Item.GetItemInfoInstant=function() return 1001,'Armor','Cloth','INVTYPE_HEAD',34567 end
p:Render();check(p.slots[1].icon.texture==34567,'modern instant icon fallback works without legacy globals')
C_Item.GetItemInfoInstant=nil;C_Item.GetItemIconByID=function() return 45678 end
p:Render();check(p.slots[1].icon.texture==45678,'native item-ID icon fallback works')
C_Item.GetItemIconByID=function() return 0 end;p:Render()
check(p.slots[1].icon.texture=='Interface\\Icons\\INV_Misc_QuestionMark','unavailable icon uses real question-mark texture rather than blank/zero')
check(record.object.capture.values.slots[1][4]=='item:1001:123:456:0:-7','display and clicks leave original equipment evidence unchanged')
check(not C.Active() and S.VERSION==6 and S.CONSENT==5 and forbiddenRegistrations==0,'small pass preserves recording consent and protected API boundaries')
smallPassChecks=checks-before;sourceLookupSteps=steps
''')
summary={'version':'1.1.0','assertions':int(lua.globals().smallPassChecks),'sourceHistoryEvents':200000,'sourceFallbackSteps':int(lua.globals().sourceLookupSteps),'failed':0,'liveWoWTested':False,'seconds':round(time.perf_counter()-start,3)}
(out/'small-pass-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary,indent=2))
