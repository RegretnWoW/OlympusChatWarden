from pathlib import Path
import json,time,hashlib,zipfile
o=Path(__file__).resolve().parent;r=o.parents[1];began=time.perf_counter()
h={'__file__':str(o/'smoke.py')};exec(compile((o/'smoke.py').read_text(),'preview7 host','exec'),h);l=h['lua']
l.execute(r'''
local before=checks;local W,S,P=ns.Workspace,ns.RelayStore,ns.RelayTransport
W.Open('relay');p=W.pages.relay
check(not p.send:IsEnabled(),'empty form cannot submit')
p.title:SetText('Direct submission');p.description:SetText('Specific reproducible problem.');p.steps:SetText('')
check(p.send:IsEnabled() and not p.previewWire,'valid fields enable Submit without preview')
check(not p.attach:GetChecked() and p.diagnostics=='','diagnostics default off')
local unfinished=p.draft;local count=#S.db.reports
p:SetView('mine');check(#p.mine.list.items==0,'unfinished form never appears in My Reports')
p:SetView('diagnostics');check(#p.recoveryChoices>=2,'old unfinished text is recoverable under advanced tools')
p:SetDraft(unfinished);W.Open('messages');W.Open('relay')
check(p.draft==unfinished and p.title:GetText()=='Direct submission' and unfinished.state=='draft','closing/navigating keeps text local')
local tries=0;local originalTry=P.Try;P.Try=function(id) tries=tries+1;return true end
p.send:GetScript('OnClick')()
check(tries==1 and unfinished.state=='pending' and p.mode=='mine','single explicit Submit persists and begins delivery')
check(#p.mine.list.items==1 and p.mine.selected==unfinished,'submitted report selected immediately')
check(not p.mine.retry:IsShown() and not p.mine.automatic:IsShown() and not p.mine.delete:IsShown(),'ordinary controls omit queue management')
check(p.mine.document:GetText():find('automatically try again',1,true) and not p.mine.document:GetText():find('Report ID:',1,true),'simple pending status with hidden protocol details')
check(S.Decode(unfinished.wire).diagnostics=='' and unfinished.autoRetry==true,'plain submission freezes no diagnostics and schedules retries')
local wire=unfinished.wire;local checksum=unfinished.checksum
p.mine.advancedButton:GetScript('OnClick')()
check(p.mine.retry:IsShown() and p.mine.automatic:IsShown() and p.mine.delete:IsShown(),'advanced actions remain available')
check(p.mine.document:GetText():find('Report ID:',1,true),'technical failure/status retained in advanced details')
local last=0
for _,b in ipairs(p.mine.actions) do if b:IsShown() then
 local x=b.points[1].x;check(x>=0 and x+b:GetWidth()<=1140,'advanced action fits canvas')
end end
unfinished.state='received';unfinished.receivedAt=GetServerTime();S.Changed();p:Refresh()
check(p.mine.document:GetText():find('delivered successfully',1,true),'delivered label derives from received state')
check(unfinished.wire==wire and unfinished.checksum==checksum,'UI leaves frozen submission unchanged')
unfinished.state='pending';unfinished.autoRetry=false;S.Changed();p.mine.status='attention';p.mine.revision=nil;p.mine:Refresh()
check(#p.mine.list.items==1 and p.mine.document:GetText():find('paused',1,true),'paused report needs attention rather than promising automatic retry')
p.mine.status='pending';p.mine.revision=nil;p.mine:Refresh();check(#p.mine.list.items==0 and not p.mine.selected,'waiting filter excludes paused reports and clears stale details')
p:NewDraft();p.title:SetText('Optional details');p.description:SetText('Details are opt in.')
p.attach:SetChecked(true);p.attach:GetScript('OnClick')(p.attach)
-- V.Check reads the state the native checkbox has just set.
check(p.includeDiagnostics and ns.RelayDiagnostics.Valid(p.diagnostics),'explicit checkbox prepares approved diagnostic snapshot')
p:Preview();check(S.Decode(p.previewWire).diagnostics==p.diagnostics,'View Details shows exactly the attachment used for Submit')
p.title:SetText('Changed title');check(p.send:IsEnabled() and not p.previewWire,'changing valid text requires no extra review step')
local second=p.draft;p.send:GetScript('OnClick')();check(S.Decode(second.wire).diagnostics~='','explicitly selected details included')
p:NewDraft();check(not p.attach:GetChecked() and p.diagnostics=='','new reports clear attachment consent')
p:SetDraft(unfinished.state=='draft' and unfinished or S.New());check(not p.attach:GetChecked(),'switching unfinished reports resets details')
P.Try=originalTry
local emptyCount=#S.db.reports
for n=1,10 do p:NewDraft() end
check(#S.db.reports==emptyCount,'empty form reuse does not consume report capacity')
p.title:SetText('Deliberately discarded unfinished text');local discarded=p.draft.id
p:SetView('diagnostics');p.discard:GetScript('OnClick')();check(S.Find(discarded)~=nil,'first discard click only asks for confirmation')
p:SetView('report');p:SetView('diagnostics');p.discard:GetScript('OnClick')();check(S.Find(discarded)~=nil,'navigation disarms discard confirmation')
p.discard:GetScript('OnClick')();check(not S.Find(discarded) and S.Find(unfinished.id).wire==wire,'second explicit discard affects only unfinished text, never submitted reports')
S.db=nil;S.Initialize()
check(S.Find(unfinished.id).wire==wire and S.Find(second.id).wire==second.wire,'submitted content and attachments survive store reinitialization')
local E=ns.EventIcons
for _,e in ipairs({{kind='quest_turnin'},{kind='player_observed'},{kind='player_death'},{kind='achievement_earned'},{kind='unfamiliar_event'}}) do
 local key=E.Record(e);check(key:find('event:',1,true)==1,'all historical rows use shared event keys')
 local t=ns.Art.Icon(UIParent,key,32);check(not t.texture:find('WardenSmall',1,true),'event icons use existing atlas art instead of module crests')
end
check(ns.Art.Icon(UIParent,'chronicle',48).texture:find('ChronicleWardenSmall',1,true),'module crest is preserved')
check(E.Chat({categories={shield=true}})=='event:shield' and E.Relay({state='received'})=='event:export','action and delivery mappings are semantic')
preview7Checks=checks-before
''')
h2={'__file__':str(o/'test-integration.py')};exec(compile((o/'test-integration.py').read_text().split('count=0')[0],'module host','exec'),h2)
matrix=[]
for bits in range(32):
 selection={k:bool(bits&(1<<n)) for n,k in enumerate(['chat','chronicle','intel','shield','alerts'])}
 x=h2['fresh']('modern',True,selection=selection)
 x.execute(r'''
 local M,A,S,C=ns.PlayerMenus,ns.ChronicleActivities,ns.ChronicleStore,ns.Chronicle
 local request=A.Request;A.Request=function() error('menu must not start/rebuild an index') end
 function GetRealmName() return 'Test Realm' end
 function GetNormalizedRealmName() return 'TestRealm' end
 function UnitFullName(u) if u=='target' then return 'Known','Friend' end;return 'Self','Person' end;UnitName=UnitFullName
 function UnitGUID(u) if u=='target' then return 'Player-Known-1' end;return u=='player' and 'Player-Self-1' or nil end
 function UnitIsPlayer(u) return u=='target' or u=='player' end
 local function Menu() local t={items={}};function t:CreateButton(name,fn) local b=Menu();b.name=name;b.fn=fn;self.items[#self.items+1]=b;return b end;function t:CreateTitle() end;return t end
 local function Action(ctx)
   local t=Menu();M.AddHistory(ctx,t);local a={};for _,v in ipairs(t.items) do a[v.name]=v.fn end;return a
 end
 if not ns.Modules.Enabled('history') then
  local owner=C.Owner;C.Owner=function() error('disabled menu queried owner') end
  assert(next(Action({name='Known',surname='Friend',server='TestRealm'}))==nil);C.Owner=owner
 else
  local owner=C.Owner();local c=S.Character(owner,true);local st=A.New(owner)
  st.menuNames['known friend-testrealm']='Player-Known-1'
  st.intelligence={players={['Player-Known-1']={evidence={'event-1'}}}}
  st.players['Player-Known-1']={activities={'activity-1'}}
  A.caches[c]={state=st,raw=c.events,count=#c.events,tail=c.events[#c.events]}
  local ctx={name='Known',surname='Friend',server='TestRealm'};local a=Action(ctx)
  assert((a['View Player Intelligence']~=nil)==ns.Modules.Enabled('intel'))
  assert((a['View Shared History']~=nil)==ns.Modules.Enabled('chronicle'))
  assert(next(Action({name='Unknown',surname='Friend',server='TestRealm'}))==nil)
  assert(next(Action({name='Known',surname='Friend',server='OtherRealm'}))==nil)
  st.menuNames['known friend-testrealm']=false;assert(next(Action(ctx))==nil,'ambiguous names omitted')
  assert(next(Action({unit='target'}))~=nil,'exact live GUID resolves despite ambiguous name')
  st.menuNames['known friend-testrealm']='Player-Known-1'
  local nav=ns.WardenUI.Navigate;ns.WardenUI.Navigate=function(kind,o,guid) assert(o==owner and guid=='Player-Known-1');opened=kind;return true end
  if a['View Player Intelligence'] then a['View Player Intelligence']();assert(opened=='player') end
  if a['View Shared History'] then a['View Shared History']();assert(opened=='history') end
  S.loading={};assert(next(Action(ctx))==nil);S.loading=nil
  c.events={};assert(next(Action(ctx))==nil,'replaced history invalidates cached eligibility')
  for _,fn in pairs(a) do opened=nil;fn();assert(not opened,'stale action never opens another record') end
  ns.WardenUI.Navigate=nav
 end
 A.Request=request
 ''')
 matrix.append(selection)
# Actual indexing and direct Chronicle-only navigation with preserved evidence.
l.execute(r'''
freshRecording();units.target={guid='Player-Menu-SHARED',name='Menu Friend',realm='Test Realm',class='MAGE',level=30}
C.ObserveUnit('target','PLAYER_TARGET_CHANGED',true);units.party1=units.target;groupCount=2;ev('GROUP_ROSTER_UPDATE')
local A=ns.ChronicleActivities;local st
for n=1,1000 do st=A.Request(C.Owner());if st then break end;A.Pump() end
check(st and st.menuNames['menu friend-testrealm']==units.target.guid,'cooperative history build creates exact name index')
ns.Modules.Set('intel',false)
for n=1,1000 do st=A.Request(C.Owner());if st then break end;A.Pump() end
check(ns.WardenUI.Navigate('history',C.Owner(),units.target.guid),'Chronicle-only history link accepted')
for n=1,100 do ns.WardenUI.PumpNavigation();if not ns.WardenUI.pending then break end end
check(ns.Workspace.current=='chronicle' and ns.Workspace.pages.chronicle.activities.filter.guid==units.target.guid,'Chronicle-only link opens filtered shared activities without Intel')
check(not ns.Modules.Enabled('intel'),'Chronicle link never enables Intel')
''')
with zipfile.ZipFile(r/'OlympusWarden-v1.1.1-preview6.zip') as z:
 for name in ['RelayTransport.lua','RelayStore.lua','RelayDiagnostics.lua','ChronicleCodec.lua','PackCrypto.lua','Engine.lua']:
  assert z.read('OlympusChatWarden/'+name)==(r/'OlympusChatWarden'/name).read_bytes(),name
result={'version':'1.1.1-preview7','failed':0,'assertions':int(l.globals().preview7Checks)+4,'contextConfigurations':32,'nativeClientTested':False,'baselineSelfDelivery':'user confirmed Preview 6','seconds':time.perf_counter()-began}
(o/'preview7-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
