from pathlib import Path
import json,time,zipfile
o=Path(__file__).resolve().parent;r=o.parents[1];start=time.perf_counter()
h={'__file__':str(o/'smoke.py')};exec(compile((o/'smoke.py').read_text(),'release menu host','exec'),h);l=h['lua']
l.execute(r'''
local before=checks;local A,I,M=ns.ChronicleActivities,ns.ChronicleIntelligence,ns.PlayerMenus
freshRecording();C.SetEnabled(false);local owner=C.Owner();local c=S.Character(owner,false)
local function profile(guid,name,realm,note,watch)
 c.profiles[guid]={guid=guid,firstObserved=GetServerTime(),lastObserved=GetServerTime(),lastSource='checkpoint',facts={
  name={value=name,at=GetServerTime(),source='checkpoint'},realm=realm and {value=realm,at=GetServerTime(),source='checkpoint'} or nil},personal={note=note,watch=watch}}
end
local note,watch,other,unknown='Player-Note-ONLY','Player-Watch-ONLY','Player-Other-Realm','Player-Realm-UNKNOWN'
profile(note,'Remember Me','Test Realm','Saved note without historical events',false)
profile(watch,'Watch Me','Test Realm',nil,true)
profile(other,'Remember Me','Different Realm','Other realm note',false)
profile(unknown,'Unknown Realm',nil,'Identity requires a live exact GUID',false)
local B=ns.ChronicleBackup;local original=B.Encode(c.profiles);local events=B.Encode(c.events);A.Clear()
local function actions(ctx)
 local t={items={}};function t:CreateButton(label,fn) self.items[label]=fn;return {} end;function t:CreateTitle() end
 M.AddHistory(ctx,t);return t.items
end
check(next(actions({name='Remember Me',server='Test Realm'}))==nil,'menu does not start missing index')
local state;for n=1,1000 do state=A.Request(owner);if state then break end;A.Pump() end
check(state and state.menuNames['remember me-testrealm']==note,'cooperative profile-only identity alias is indexed')
check(B.Encode(c.profiles)==original and B.Encode(c.events)==events,'saved profiles and history remain byte-equivalent')
check(#I.Player(state,note).evidence==0 and I.Player(state,note).recordedEncounters==0,'personal note does not fabricate encounter evidence')
check(I.Player(state,note).tierLabel=='Personal note only','personal-only profile is labelled honestly')
local request=A.Request;A.Request=function() error('right click must not scan or initialize history') end
local saved=actions({name='Remember Me',server='Test Realm'})
check(saved['View Player Intelligence'] and not saved['View Shared History'],'saved note qualifies for Intel without inventing shared history')
check(actions({name='Watch Me',server='Test Realm'})['View Player Intelligence'],'watch-only entry qualifies')
check(actions({name='Remember Me',server='Different Realm'})['View Player Intelligence'],'other realm resolves its own GUID')
check(not actions({name='Remember Me',server='Wrong Realm'})['View Player Intelligence'],'different realm cannot substitute a dossier')
check(not actions({name='Unknown Realm',server='Test Realm'})['View Player Intelligence'],'missing recorded realm cannot qualify by guessed name')
check(not actions({name='Self',guid=owner:match('/(Player%-.+)$')})['View Player Intelligence'],'self is excluded')
A.Request=request;saved['View Player Intelligence']()
for n=1,100 do ns.WardenUI.PumpNavigation();if not ns.WardenUI.pending then break end end
local page=ns.Workspace.pages.intel;page:Refresh(true)
check(ns.Workspace.current=='intel' and page.currentRow and page.currentRow.id==note,'menu opens exact personal-only dossier')
check(page.note:GetText()=='Saved note without historical events','saved note remains available while recording paused')
check(not C.Active(),'dossier link grants no recording consent')
local watchRows=ns.WardenUI.Players(state,'watch','');local matched=false
for _,row in ipairs(watchRows) do if row.id==watch then matched=true end end
check(matched,'watch-only dossier is visible in the actual watchlist')
-- Identical full identity on two GUIDs is ambiguous; exact live GUID remains usable.
profile('Player-Note-DUPLICATE','Remember Me','Test Realm','Different identity',false);A.Clear()
for n=1,1000 do state=A.Request(owner);if state then break end;A.Pump() end
check(state.menuNames['remember me-testrealm']==false,'duplicate names never select one arbitrarily')
check(not actions({name='Remember Me',server='Test Realm'})['View Player Intelligence'],'ambiguous menu omits the shortcut')
units.target={guid=note,name='Remember Me',realm='Test Realm',class='MAGE',level=30}
check(actions({unit='target'})['View Player Intelligence'],'exact live GUID bypasses name ambiguity safely')
local stale=actions({unit='target'})['View Player Intelligence'];C.Clear();local navigation=ns.WardenUI.Navigate;local opened=false
ns.WardenUI.Navigate=function() opened=true;return true end;stale();ns.WardenUI.Navigate=navigation
check(not opened,'cleared/replaced history invalidates a captured menu action')
ns.Modules.Set('intel',false);check(not actions({unit='target'})['View Player Intelligence'],'disabled Intel never receives a shortcut')
ns.Modules.Set('intel',true);local search=ns.WardenSearch.Begin('CommandWarden')
for n=1,1000 do if ns.WardenSearch.Pump(search) then break end;S.PumpArchives() end
local destinations={};for _,row in ipairs(search.results) do if row.data.page then destinations[row.data.page]=row.title end end
check(destinations.overview=='CommandWarden' and destinations.modules=='Modules' and destinations.performance=='Performance' and destinations.settings=='Settings','suite search exposes the CommandWarden control center')
check(ns.VERSION=='1.1.1' and ns.InstalledUpdate.version=='1.1.1','release names match code and patch notes')
check(ns.UpdateHistory[2].version=='1.1.0' and ns.UpdateHistory[3].version=='1.0.3','prior public update screens remain available')
c=S.Character(owner,true);c.events={};for n=1,300 do profile('Player-Budget-'..n,'Budget '..n,'Test Realm','Fixture note',false) end
A.Clear();A.Request(owner);A.Pump(1)
local statePending;for _,cache in pairs(A.caches) do statePending=cache.state end
check(not statePending,'profile-only index cannot complete an unbounded profile pass in one frame')
local done=false;for n=1,400 do A.Pump(1);statePending=A.Peek(owner);if statePending then done=true;break end end
check(done and statePending.intelligence.players['Player-Budget-300'],'bounded profile phase eventually includes all saved identities')
check(I.Player(statePending,'Player-Budget-300').note=='Fixture note','a new profile-only summary is constructed even without event revisions')
releaseChecks=checks-before
''')
protected='Chronicle.lua ChronicleStore.lua ChronicleArchives.lua ChronicleBackup.lua ChronicleStartup.lua ChronicleStartupJournal.lua ChronicleCodec.lua ChronicleCapture.lua ChronicleLoadout.lua ChronicleDuels.lua ChronicleCombat.lua ChronicleStatistics.lua ChronicleCoverage.lua ChronicleTransitions.lua RelayStore.lua RelayTransport.lua RelayDiagnostics.lua WardenModules.lua SignalCore.lua Engine.lua PackCrypto.lua PackData.lua TrustedPackKeys.lua'.split()
with zipfile.ZipFile(r/'OlympusWarden-v1.1.1-preview8.zip') as z:
 for name in protected:
  assert z.read('OlympusChatWarden/'+name)==(r/'OlympusChatWarden'/name).read_bytes(),name
result={'version':'1.1.1','failed':0,'assertions':int(l.globals().releaseChecks),'protectedFilesUnchanged':protected,'nativeReleaseTested':False,'seconds':time.perf_counter()-start}
(o/'release-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
