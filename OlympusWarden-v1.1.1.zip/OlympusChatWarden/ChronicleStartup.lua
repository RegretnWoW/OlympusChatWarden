-- Bounded local recovery window while an existing archive validates.
-- Original event-time evidence only; no late inspection or inferred outcomes.
local _,ns=...
local function OwnedFrame(...) return ns.Modules and ns.Modules.Frame('history',...) or CreateFrame(...) end
local C,S=ns.Chronicle,ns.ChronicleStore
local J=ns.ChronicleStartupJournal
local B={LIMIT=J.LIMIT,BYTES=J.BYTES,diagnostics={}};ns.ChronicleStartup=B
local pending
local function Eligible(saved)
    return type(saved)=='table' and not getmetatable(saved) and saved.schema==S.VERSION
        and saved.enabled==true and saved.consentVersion==S.CONSENT and ns.DB
        and (not ns.Modules or ns.Modules.Enabled('history'))
        and ns.Membership and ns.Membership.Allowed()
end
function B.Begin(source)
    J.Cancel();pending=nil;B.diagnostics={captured=0,merged=0,overflow=0,discarded=0,deferred=0}
    if not Eligible(source) then return end
    local owner=C.Owner();local at=C.Stamp()
    pending={source=source,owner=owner,firstAt=at,duels=source.duels==true and source.duelConsent==1,quests={}}
end
function B.Cancel()
    J.Cancel();B.diagnostics.deferred=J.Count();pending=nil
end
function B.Handle(event,a,b,c,d,e,f)
    local p=pending
    if not p or not S.loading or ns.DB.chronicle~=p.source or not Eligible(p.source) then return end
    if event=='PLAYER_ENTERING_WORLD' then
        p.world=true;p.owner=p.owner or C.Owner();p.firstAt=p.firstAt or C.Stamp()
        if not p.entry and p.owner and p.firstAt then p.entry,p.run=J.Prepare(p.owner,p.firstAt) end
        if p.entry then p.entry.started=true;p.rows=p.entry.rows end
        return
    end
    if event=='PLAYER_LEAVING_WORLD' then p.world=false;return end
    if event=='PLAYER_LOGOUT' then B.Cancel();return end
    if not p.world or not p.entry or C.Owner()~=p.owner then return end
    if not C.PersonalEnabled() and (event:find('QUEST',1,true) or event=='ACHIEVEMENT_EARNED') then return end
    local kind,details,evidence='native_event',nil,'observed'
    local bosses
    if event=='QUEST_LOOT_RECEIVED' or event=='QUEST_CURRENCY_LOOT_RECEIVED' or event=='ENCOUNTER_LOOT_RECEIVED' then
        details=ns.ChronicleTransitions.Receipt(event,a,b,c,d)
    elseif event=='QUEST_TURNED_IN' then local id=S.Integer(a,1,10000000);if id then
        local tick=C.Tick();if not tick or p.quests[id] and tick-p.quests[id]<2 then return end
        details={questID=id,rewardXP=S.Integer(b,0),rewardCopper=S.Integer(c,0)};kind='quest_turnin';evidence='confirmed'
    end
    elseif event=='QUEST_ACCEPTED' or event=='QUEST_REMOVED' or event=='ACHIEVEMENT_EARNED' then
        local id=S.Integer(event=='QUEST_ACCEPTED' and (b~=nil and b or a) or a,1,10000000)
        if id then
            kind=event=='QUEST_ACCEPTED' and 'quest_accepted' or event=='QUEST_REMOVED' and 'quest_removed' or 'achievement_earned'
            details=kind=='achievement_earned' and {achievementID=id} or {questID=id};evidence='confirmed'
            local value;if ns.Readable(b) and type(b)=='boolean' then value=b end
            if kind=='achievement_earned' then details.alreadyEarned=value elseif kind=='quest_removed' then details.wasReplayQuest=value end
        end
    elseif event=='BOSS_KILL' or event=='ENCOUNTER_START' or event=='ENCOUNTER_END' then
        local id=S.Integer(a,1,10000000);if id then details={recordType=event=='BOSS_KILL' and 'boss_kill_event' or event=='ENCOUNTER_START' and 'encounter_started' or 'encounter_ended',encounterID=id,name=S.Text(b,144)}
            if event~='BOSS_KILL' then details.difficultyID=S.Integer(c,0);details.groupSize=S.Integer(d,0,100);details.success=S.Integer(e,0,1) end
            if event=='ENCOUNTER_END' then
                local total,complete;bosses,total,complete=ns.ChronicleTransitions.Bosses(f)
                details.bossStatusReadCount=#bosses;details.bossStatusTotal=total;details.bossStatusComplete=complete
            end
        end
    elseif event=='PVP_MATCH_COMPLETE' then details={recordType='pvp_match_complete',winner=S.Integer(a,0,100),duration=S.Number(b,0)}
    elseif p.duels and event=='DUEL_REQUESTED' then local name=S.Text(a,144);if name then details={recordType='duel_requested',name=name} end
    elseif p.duels and event=='DUEL_FINISHED' then details={recordType='duel_finished',resultKnown=false} end
    if not details then return end
    local at,clock=C.Stamp();local tick=C.Tick();local location=C.Place()
    if not at or not tick or C.Owner()~=p.owner then return end
    if kind=='native_event' then details.evidenceClass,details.outcome,details.outcomeScope=ns.ChronicleCapture.Classify(kind,event,details) end
    local row={kind=kind,source=event,details=details,evidence=evidence,at=at,elapsed=tick,timeSource=clock,location=location,run=p.run}
    local bytes=S.Size(row)
    if #p.rows>=B.LIMIT or p.entry.bytes+bytes>B.BYTES then
        if B.diagnostics.overflow==0 then ns.Print('Startup recovery buffer is full. Accepted observations are kept; additional omissions will be counted in your history coverage gap.') end
        local n=1+#(bosses or {});p.entry.overflow=p.entry.overflow+n;B.diagnostics.overflow=B.diagnostics.overflow+n;return
    end
    p.rows[#p.rows+1]=row;p.entry.bytes=p.entry.bytes+bytes;B.diagnostics.captured=B.diagnostics.captured+1
    local parent=#p.rows
    for _,data in ipairs(bosses or {}) do
        data.recordType='boss_status_observed';data.encounterID=details.encounterID;data.parts=details.bossStatusTotal
        data.evidenceClass,data.outcome,data.outcomeScope=ns.ChronicleCapture.Classify('native_event',event,data)
        local child={kind='native_event',source=event,details=data,evidence='observed',at=at,elapsed=tick,timeSource=clock,location=location,startupParent=parent,run=p.run}
        local size=S.Size(child)
        if #p.rows<B.LIMIT and p.entry.bytes+size<=B.BYTES then
            p.rows[#p.rows+1]=child;p.entry.bytes=p.entry.bytes+size;B.diagnostics.captured=B.diagnostics.captured+1
        else
            if B.diagnostics.overflow==0 then ns.Print('Startup recovery buffer is full. Accepted observations are kept; additional omissions will be counted in your history coverage gap.') end
            p.entry.overflow=p.entry.overflow+1;B.diagnostics.overflow=B.diagnostics.overflow+1
        end
    end
    if kind=='quest_turnin' then p.quests[details.questID]=tick end
end
function B.Merge()
    local p=pending;pending=nil;local owner=C.Owner();local staged=J.Has(owner)
    J.Merge()
    -- Preserve the prior unknown-coverage marker when access became available
    -- too late to start an eligible buffer. Never reconstruct missed events.
    if not p and not staged and owner and C.promptReady and Eligible(S.db) then
        local c=S.Character(owner,true);local at,clock=C.Stamp();local tick=C.Tick()
        if c and at and tick then
            c.sessionSequence=c.sessionSequence+1;local session=owner..'/s'..c.sessionSequence
            local saved=S.Append(owner,{kind='collection_gap',source='control',session=session,at=at,elapsed=tick,timeSource=clock,evidence='observed',location={},
                details={reason='Startup coverage is unknown: recording access became available after the preservation window began',lastAt=at,count=0,samples=0}})
            if saved then C.diagnostics.gaps=C.diagnostics.gaps+1 end
        end
    end
end
local frame=OwnedFrame('Frame')
for _,event in ipairs({'PLAYER_ENTERING_WORLD','PLAYER_LEAVING_WORLD','PLAYER_LOGOUT','QUEST_TURNED_IN','QUEST_ACCEPTED','QUEST_REMOVED','ACHIEVEMENT_EARNED',
    'BOSS_KILL','ENCOUNTER_START','ENCOUNTER_END','PVP_MATCH_COMPLETE','DUEL_REQUESTED','DUEL_FINISHED',
    'QUEST_LOOT_RECEIVED','QUEST_CURRENCY_LOOT_RECEIVED','ENCOUNTER_LOOT_RECEIVED'}) do pcall(frame.RegisterEvent,frame,event) end
frame:SetScript('OnEvent',function(_,event,...) B.Handle(event,...) end)
