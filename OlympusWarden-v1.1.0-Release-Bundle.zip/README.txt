Olympus Warden 1.1.0 release bundle

The addon ZIP is OlympusWarden-v1.1.0.zip. This is the ZIP to upload to an
addon distribution service. To install manually, close WoW, back up your
SavedVariables, then extract that ZIP into Interface/AddOns, replacing the
existing OlympusChatWarden folder. Do not install a second copy under a new name.

The separately zipped Windows backup tool is included. Extract it separately
and read its instructions. Keep backups outside the game folder. It is unchanged
from v1.0.3 and remains compatible with this addon identity and saved file.

56 offline regression suites passed. The exact release's native Forever UI,
gameplay and long-session behavior still require client verification; synthetic
previews and test fixtures do not count as native tests. No recorded personal
history or signing material is included in this bundle. Full test evidence and
UI/performance reports are supplied separately.

SHA256.txt checks every other file inside this bundle.
