Production Lua widgets with illustrative synthetic fixtures. These are not native WoW screenshots; fixture data is not installed in the addon.
